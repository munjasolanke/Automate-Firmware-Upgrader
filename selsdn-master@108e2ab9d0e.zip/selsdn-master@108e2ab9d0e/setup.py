#
# This file is used to package this libary up into something that can
# be installed by the python pip installer.
#
# To build the package run this command from the selsdn directory
#
#      python setup.py sdist bdist_wheel
#
#  NOTE: you must have python 3 and if "python" is bound to python2...then use "python3"
#
# To Label a release (create a git tag) do these two steps...of course use the "correct" tag
# and the correct tag should ALSO be in the "version" field down below so they match
#     git tag 2.1.1.11
#     git push origin 2.1.1.11
#

import setuptools
from selsdn import __version__

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="selsdn",
    version=__version__,
    author="Robert Meine",
    author_email="robert_meine@selinc.com",
    description="Tools to help build/test/simulate SDN Networks with the SEL-5056 Flow Controler",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="SEL",
    url="https://bitbucket.metro.ad.selinc.com/users/robemein/repos/selsdn/browse",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: SEL Internal License",
        "Operating System :: OS Independent",
    ],
)
