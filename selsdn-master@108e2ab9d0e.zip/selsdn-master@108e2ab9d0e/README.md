TODO: Make this better

