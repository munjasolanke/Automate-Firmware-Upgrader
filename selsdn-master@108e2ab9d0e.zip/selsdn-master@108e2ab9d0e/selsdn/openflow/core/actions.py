"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes for OpenFlow actions restricted to values supported by the
SEL-2740S.
"""

from ...base.value import Value
from ...base.values import UniqueValues
from .ports import PhysicalPort, IngressPort, AllPort, ControllerPort, LocalPort
from ...base.tools import merge_dicts


class Action(Value):
    """Base class for all OpenFlow actions.
    """
    @property
    def name(self):
        """Defined as the lowercase name of the action class.
        """
        return self.__class__.__name__[:-6].lower()


class OutputAction(Action):
    """Defines the Output action.
    """

    # can use friendly names of physical, all, local, ingress, controller ports
    TRANSLATER = merge_dicts(PhysicalPort.TRANSLATER, AllPort.TRANSLATER,
                             LocalPort.TRANSLATER, IngressPort.TRANSLATER,
                             ControllerPort.TRANSLATER)

    @staticmethod
    def _is_valid_value(value):
        """Checks if a value is the number or friendly name of a Physical,
        Ingress, All, Controller or Local port.

        Arguments:
            value {*} -- port number or alias

        Returns:
            {bool} -- true if value identifies a port that can output packets
        """
        return PhysicalPort.is_valid_value(value) or \
            IngressPort.is_valid_value(value) or \
            AllPort.is_valid_value(value) or \
            ControllerPort.is_valid_value(value) or \
            LocalPort.is_valid_value(value)


class GroupAction(Action):
    """Defines the Group action.
    """
    @staticmethod
    def _is_valid_value(value):
        """Checks if the value is a valid Group ID.

        Arguments:
            value {*} -- Group ID assigned packets by the flow

        Returns:
            {bool} -- true if value is a number between 0 and 0xffffff00
        """
        if isinstance(value, str):
            value = int(value)
        return 0 <= value <= 0xffffff00


class SetQueueAction(Action):
    """Defines the SetQueue instruction action.
    """
    @staticmethod
    def _is_valid_value(value):
        """Checks if the value is a valid queue priority number

        Arguments:
            value {int}} -- queue priority number

        Returns:
            {bool} -- true if value is between 1 and 4
        """
        return 1 <= value <= 4


class SetFieldAction(Action):
    """Defines the SetField instruction action.
    """
    pass


class SetVlanVidAction(SetFieldAction):
    """Defines the SetVlanVid instruction action.
    """
    @staticmethod
    def _is_valid_value(value):
        """Checks if the value is a valid VLAN identifier.

        Arguments:
            value {int} -- VlanVid number

        Returns:
            {bool} -- true if value is between 0 and 0xfff
        """
        return 0 <= value <= 0xfff


class SetVlanPcpAction(SetFieldAction):
    """Defines the SetVlanPcp instruction action.
    """
    @staticmethod
    def _is_valid_value(value):
        """Checks if the value is a valid VLAN priority code point.

        Arguments:
            value {int} -- VlanPcp number

        Returns:
            {bool} -- true if value is between 0 and 7
        """
        return 0 <= value <= 7


class PopVlanAction(Action):
    """Defines the PopVlan instruction action.
    """

    def __init__(self):
        """Sets the value of this action to True.
        """
        super().__init__(value=True)

    @staticmethod
    def _is_valid_value(value):
        """Checks if a value is left blank or does not exist (PopVlan action
        value must be True).

        Keyword Arguments:
            value {*} -- instruction action value (default: {True})

        Returns:
            {bool} -- true if value is True
        """
        return value is True
    
    def __repr__(self):
        """Defines the repr string for this object as representing the class
        and individual instance names of the object as readable text.

        Returns:
            {str} -- "[class name]:[object name]"
        """
        return "{}:{}".format(self.__class__.__name__, "True")


class PushVlanAction(Action):
    """Defines the PushVlan instruction action.
    """

    def __init__(self, value=0x8100):
        """Sets the value of this action to 0x8100.

        Keyword Arguments:
            value {hexadecimal} -- ethertype of pushed VLAN header (default: {0x8100})
        """
        super().__init__(value=value)

    @staticmethod
    def _is_valid_value(value):
        """Checks if a value is a supported ethertype.

        Arguments:
            value {*} -- instruction action value

        Returns:
            {bool} -- true if value is a number(cannot be str) equal to 0x8100
        """
        return value == 0x8100


class DropAction(Action):
    """Placeholder action for no output or group action. Has no value or
    effect, representing an equivalent explicit drop action to the implicit
    drop action of OpenFlow.
    """

    def __init__(self):
        """Sets the value of this action to none.
        """
        super().__init__(value=None)

    @staticmethod
    def _is_valid_value(value):
        """Checks if a value is left blank or does not exist (no action is
        being taken).

        Keyword Arguments:
            value {*} -- instruction action value

        Returns:
            {bool} -- true if value is None
        """
        return value is None


class Actions(UniqueValues):
    """Defines an object that is a list of OpenFlow instruction actions. Only
    one of each class of instruction action is permitted in the list.
    """

    # objects in list required to be instruction actions
    VALUE_CLASS = Action

    def __eq__(self, other):
        """Checks whether two sets of actions are equivalent. Drop counts as
        no actions.

        Arguments:
            other {object} -- list being used for comparison

        Returns:
            {bool} -- true if lists contain the same actions, or no/Drop action
        """
        if (len(self.values) == 0 and len(other.values) == 1 and other.get(DropAction)) or \
                (len(other.values) == 0 and len(self.values) == 1 and self.get(DropAction)):
            return True
        else:
            return super().__eq__(other)

# list of OpenFlow instruction actions
ACTIONS = [OutputAction, GroupAction, SetQueueAction, SetVlanVidAction,
           SetVlanPcpAction, PopVlanAction, PushVlanAction, DropAction]


class ActionSet(Actions):
    """Class to mimic the OpenFlow action set.
    """

    # objects in list required to be instruction actions
    VALUE_CLASS = Action

    def add_by_name(self, name, value):
        for action_object in ACTIONS:
            if action_object.__name__.replace("Action", "").lower() == name.lower():
                new_action = action_object(value)
                self.add(new_action)
                break
        else:
            raise TypeError("Unable to find matching action for name {}".format(name))            
