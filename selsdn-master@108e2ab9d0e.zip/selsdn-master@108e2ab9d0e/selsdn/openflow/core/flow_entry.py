"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

OpenFlow flow entry class.
"""

from copy import deepcopy

from .entry import Entry
from ...base.value import Value
from .actions import ActionSet, Actions
from .match_fields import MatchFields
from .instructions import Instructions

class FlowEntry(Entry):
    """The functions and properties of OpenFlow flow objects.
    """

    def __init__(self, entry_id=0, priority=1000, table_id=0, name=None,
                 node=None, match_fields=None, actions=None, instructions=None,
                 attributes=None):
        """Sets up a new flow entry, using the general settings, match fields
        and instructions as provided.

        Keyword Arguments:
            entry_id {int} -- OpenFlow Flow ID (default: {0})
            priority {int} -- priority of the flow (default: {1000})
            table_id {int} -- which table the flow belongs to (default: {0})
            name {str} -- alias of flow (default: {None})
            node {str}/{device} -- network node containing the flow (default: {None})
            match_fields {object} -- list of flow's match fields (default: {None})
            actions {object} -- list of the flow's instruction actions (default: {None})
            instructions {object} -- list of the flow's instructions (default: {None})
            attributes {dict} -- additional object attributes (default: {None})
        """
        super().__init__(name, node, entry_id, attributes)
        self.priority = priority
        self.table_id = table_id

        self._match_fields = MatchFields()
        if match_fields:
            for match_field in match_fields:
                self.match_fields.add(match_field.copy())

            if isinstance(match_fields, MatchFields):
                self._match_fields.attributes = match_fields.attributes

        self._actions = ActionSet()
        if actions:
            for action in actions:
                self.actions.add(action)

            if isinstance(action, Actions):
                self._actions.attributes = actions.attributes

        self._instructions = Instructions()
        if instructions:
            for instruction in instructions:
                self.instructions.add(instruction)

    @property
    def priority(self):
        """Returns the OpenFlow priority.
        """
        return self._priority

    @priority.setter
    def priority(self, value):
        """Setter for priority property. Raises error if invalid.
        """
        if 0 <= value <= 0xffff:
            self._priority = value
        else:
            raise ValueError("Invalid priority {}".format(value))

    @property
    def table_id(self):
        """Returns the Table ID.
        """
        return self._table_id

    @table_id.setter
    def table_id(self, value):
        """Setter for Table ID. Raises error if invalid.
        """
        if 0 <= value <= 3:
            self._table_id = value
        else:
            raise ValueError("Invalid table id {}".format(value))

    def add_match_field(self, match_field):
        """Adds a match field to the flow entry.

        Arguments:
            match_field {object} -- new match field requirement
        """
        self.match_fields.add(match_field)

    def add_action(self, action):
        """Adds an action to the flow entry.

        Arguments:
            action {object}} -- new instruction action
        """
        self.actions.add(action)

    def add_action_by_name(self, name, value):
        self.actions.add_by_name(name, value)

    def add_match_field_by_name(self, name, value):
        self.match_fields.add_by_name(name, value)

    def add_instruction(self, instruction):
        """Adds an instruction to the flow entry.

        Arguments:
            instruction {object} -- new instruction
        """
        self.instructions.add(instruction)

    @property
    def entry_id(self):
        """Returns the Flow ID.
        """
        return self._entry_id

    @entry_id.setter
    def entry_id(self, value):
        """Setter for Flow ID. Raises error if invalid.
        """
        if 0 <= value <= 0xffffffff:
            self._entry_id = value
        else:
            raise ValueError("Invalid flow id {}".format(value))

    @property
    def match_fields(self):
        """Returns the match fields of the flow entry.
        """
        return self._match_fields

    @match_fields.setter
    def match_fields(self, match_fields):
        """Setter for match_field property.
        """
        self._match_fields = match_fields

    @property
    def instructions(self):
        """Returns the instruction set of the flow entry.
        """
        return self._instructions

    @instructions.setter
    def instructions(self, instructions):
        """Setter for instructions property.
        """
        self._instructions = instructions

    @property
    def actions(self):
        """Returns the write-actions instructions set of the flow entry.
        """
        return self._actions

    @actions.setter
    def actions(self, actions):
        """Setter for actions property.
        """
        self._actions = actions

    def __eq__(self, other):
        """Two flows are equal if they have the same node name and Table ID,
        with equal priority, match fields, instructions, and instruction
        actions.

        Arguments:
            other {object} -- another flow entry used for comparison

        Returns:
            {bool} -- true if flow entries are equal
        """
        return self.node_name == other.node_name and \
            self.priority == other.priority and \
            self.table_id == other.table_id and \
            self.eq_partial(other)

    def eq_partial(self, other):
        return self.actions == other.actions and \
            self.instructions == other.instructions and \
            self.match_fields == other.match_fields and \
            self.compare_attribute("Enabled", other, default_value=True)

    def __repr__(self):
        """Defines the string representation format for flows.

        Returns:
            {str} -- "FlowEntry:[alias]@[node]([entry ID])-<[table ID] [priority]>[match fields]|[instructions]|[instruction actions]"
        """
        return "FlowEntry:{}@{}({})-<{} {}>{}|{}|{}".format(self.name, self.node, self.entry_id,
                                                            self.table_id, self.priority,
                                                            self.match_fields, self.instructions,
                                                            self.actions)

    def diff_updatable(self, other):
        """Checks whether or not this flow entry is updatable against the other

        Used by diff function to determine if one flow can be FLOW MOD'ed to the other

        Arguments:
            other {object} -- another flow entry used for comparison

        Returns:
            {bool} -- true if the flow can be updated to the other
        """
        return self.node_name == other.node_name and \
            self.priority == other.priority and \
            self.table_id == other.table_id and \
            self.diff_updatable_partial(other)

    def diff_updatable_partial(self, other):
        return self.match_fields == other.match_fields

    def overlaps(self, other):
        """Checks whether or not this flow entry overlaps with another flow
        entry.

        Two flows from the same device and table overlap if they have the same
        priority, and it is possible for a packet to match both of them. This
        means there are no match field types common to the match fields of both
        whose values do not overlap after adjusting for masking.

        Arguments:
            other {object} -- another flow entry used for comparison

        Returns:
            {bool} -- true if the flows overlap
        """
        return self.node_name == other.node_name and \
            self.priority == other.priority and \
            self.table_id == other.table_id and \
            self.overlaps_partial(other)
        # and (self.actions != other.actions or self.instructions != other.instructions)

    def overlaps_partial(self, other):
        return self.match_fields.overlaps(other.match_fields)


class FlowEntryStats(FlowEntry):
    def __init__(self, byte_count, duration, flags, packet_count, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.byte_count = byte_count
        self.duration = duration
        self.flags = flags
        self.packet_count = packet_count
