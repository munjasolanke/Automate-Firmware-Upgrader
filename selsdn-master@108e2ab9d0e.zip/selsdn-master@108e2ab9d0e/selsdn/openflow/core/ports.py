"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Defines classes for the ports defined by OpenFlow.
"""

from ...base.value import Value


class Port(Value):
    """Base class for OpenFlow ports, containing the port value.
    """
    @classmethod
    def _is_valid_value(cls, value):
        """Checks whether the port value is the correct one for this type of
        port.

        Arguments:
            value {*} -- the port value

        Returns:
            {bool} -- true if the port has the correct value
        """
        return value == cls.VALUE


class PhysicalPort(Port):
    """Defines a Physical type port as an object.
    """
    # Translater dict for physical ports. Keys are the ethernet cable port
    # names on the rear of the SEL-2740S hardware, values are the Openflow
    # port values used internally by the selsdn software.
    TRANSLATER = {'B1': 1, 'B2': 2, 'B3': 3, 'B4': 4, 'C1': 5, 'C2': 6,
                  'C3': 7, 'C4': 8, 'D1': 9, 'D2': 10, 'D3': 11, 'D4': 12,
                  'E1': 13, 'E2': 14, 'E3': 15, 'E4': 16, 'F1': 17, 'F2': 18,
                  'F3': 19, 'F4': 20}

    # list of all permitted physical port numbers for an SEL-2740S. Includes
    # Openflow port values as strings, Openflow port values as integers, and
    # hardware port names as strings.
    PHYSICAL_PORTS = [str(x) for x in range(1, 20 + 1)] + \
                     [x for x in range(1, 20 + 1)] + \
                     [x + str(y) for x in ('B', 'C', 'D', 'E', 'F') for y in range(1, 4 + 1)]

    @staticmethod
    def _is_valid_value(value):
        """Checks if a physical port's value is within the range of permitted
        values for SEL-2740S back ports.

        Arguments:
            value {*} -- the port value

        Returns:
            {bool} -- true if the value is permitted for a physical port
        """
        return 1 <= value <= 20  # in PhysicalPort.PHYSICAL_PORTS


class SingleValuePort(type):
    """Metaclass defining the creation of new single value port classes.
    """
    def __new__(cls, name, bases, ns, *, value, friendly_name):
        """Metaclass method for creating a new single value port class.

        Arguments:
            value {hexadecimal} -- the port value of the new class
            friendly_name {str} -- alias for a port, dict key for its value

        Returns:
            {class} -- new class inheriting from class Port
        """
        return super().__new__(cls, name, bases + (Port,), ns)

    def __init__(self, name, bases, ns, *, value, friendly_name):
        """Initializes a new single value port class with its OpenFlow value
        and translater dict as member variables.

        Arguments:
            value {hexadecimal} -- the port value of the new class
            friendly_name {str} -- alias for a port, dict key for its value
        """
        self.VALUE = value
        self.TRANSLATER = {friendly_name: value}
        super().__init__(name, bases, ns)


class IngressPort(metaclass=SingleValuePort,
                  value=0xfffffff8,
                  friendly_name="INGRESS"):
    """Defines Ingress Port.

    Keyword Arguments:
        value {hexadecimal} -- the port value (default: {0xfffffff8})
        friendly_name {str} -- alias for a port, dict key for its value (default: {"INGRESS"})
    """

    def __init__(self):
        """Assigns the value argument to the inherited Port object.
        """
        super().__init__(value=self.VALUE)


class AllPort(metaclass=SingleValuePort,
              value=0xfffffffc,
              friendly_name="ALL"):
    """Defines All Port.

    Keyword Arguments:
        value {hexadecimal} -- the port value (default: {0xfffffffc})
        friendly_name {str} -- alias for a port, dict key for its value (default: {"ALL"})
    """

    def __init__(self):
        """Assigns the value argument to the inherited Port object.
        """
        super().__init__(value=self.VALUE)


class ControllerPort(metaclass=SingleValuePort,
                     value=0xfffffffd,
                     friendly_name="CONTROLLER"):
    """Defines Controller Port.

    Keyword Arguments:
        value {hexadecimal} -- the port value (default: {0xfffffffd})
        friendly_name {str} -- alias for a port, dict key for its value (default: {"CONTROLLER"})
    """

    def __init__(self):
        """Assigns the value argument to the inherited Port object.
        """
        super().__init__(value=self.VALUE)


class LocalPort(metaclass=SingleValuePort,
                value=0xfffffffe,
                friendly_name="LOCAL"):
    """Defines Local Port.

    Keyword Arguments:
        value {hexadecimal} -- the port value (default: {0xfffffffe})
        friendly_name {str} -- alias for a port, dict key for its value (default: {"LOCAL"})
    """

    def __init__(self):
        """Assigns the value argument to the inherited Port object.
        """
        super().__init__(value=self.VALUE)


class AnyPort(metaclass=SingleValuePort,
              value=0xffffffff,
              friendly_name="ANY"):
    """Defines Any Port.

    Keyword Arguments:
        value {hexadecimal} -- the port value (default: {0xffffffff})
        friendly_name {str} -- alias for a port, dict key for its value (default: {"ANY"})
    """

    def __init__(self):
        """Assigns the value argument to the inherited Port object.
        """
        super().__init__(value=self.VALUE)


class AnyGroup(AnyPort,
               value=0xffffffff,
               friendly_name="ANY"):
    """Defines an Any Group.

    Keyword Arguments:
        value {hexadecimal} -- the group value (default: {0xffffffff})
        friendly_name {str} -- alias for a port, dict key for its value (default: {"ANY"})
    """

    def __init__(self):
        """Initializes an Any Group by running an Any Port initialization with
        the same value attribute.
        """
        super().__init__(value=self.VALUE)


class SpecialPorts(Port):
    """Defines the OpenFlow reserved ports, including the Ingress, All,
    Controller and Local types.
    """
    @staticmethod
    def is_valid_value(value):
        """Checks if an internal Openflow port's value is one of the
        values reserved for those types of ports.

        Arguments:
            value {*} -- the port value

        Returns:
            {bool} -- true if the port has a value reserved for special ports
        """
        return IngressPort.is_valid_value(value) or \
            AllPort.is_valid_value(value) or \
            ControllerPort.is_valid_value(value) or \
            LocalPort.is_valid_value(value)
