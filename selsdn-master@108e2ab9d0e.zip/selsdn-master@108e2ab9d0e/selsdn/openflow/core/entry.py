"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Base class for flow, group and meter entries.
"""

from ...base.base import BaseObject


class Entry(BaseObject):
    """Provides the shared methods and properties for all OpenFlow entries.
    """

    def __init__(self, name, node, entry_id, attributes):
        """Sets up the base properties of an entry.

        Arguments:
            name {str} -- controller alias for the entry
            node {str}/{device} -- network node that the entry belongs to
            entry_id {int} -- OpenFlow entry ID of the entry
            attributes {dict} -- additional object attributes
        """
        super().__init__(attributes=attributes)
        self._name = name
        self._node = node
        self.entry_id = entry_id

    @property
    def name(self):
        """Defines name as a property of entry.
        """
        return self._name

    @property
    def node(self):
        """Defines node as a property of entry.
        """
        return self._node

    @name.setter
    def name(self, name):
        """Setter for name property.
        """
        self._name = name

    @node.setter
    def node(self, node):
        """Setter for node property.
        """
        self._node = node

    @property
    def entry_id(self):
        """Defines entry_id as a property of entry.
        """
        return self._entry_id

    @entry_id.setter
    def entry_id(self, value):
        """Setter for entry_id property.
        """
        self._entry_id = value

    @property
    def node_name(self):
        """Defines node_name as the node if it is a string or doesn't exist,
        otherwise as the name property of the node(device) object.
        """
        return self.node if isinstance(self.node, str) or self.node is None else self.node.name

    def diff_eq(self, other):
        return self == other
