"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Defines classes for OpenFlow match fields.
"""

from re import match
from ipaddress import ip_address

from ...base.value import Value
from ...base.values import UniqueValues
from ...base.tools import merge_dicts

from .ports import PhysicalPort, ControllerPort, LocalPort, IngressPort


class MatchField(Value):
    """Base class for OpenFlow match fields.
    """

    @property
    def name(self):
        """Defines name property.

        Returns:
            {str} -- class match field name property in lowercase
        """
        return self.__class__.__name__[:-5].lower()

    # NOTE unused(???)
    @staticmethod
    def check_prerequistics(match):
        """Checks whether an object is a match field.

        Returns:
            {bool} -- true for match field objects
        """
        return True

    @classmethod
    def is_maskable(cls):
        """Checks whether a match field is maskable.

        Returns:
            {bool} -- false for match field that are not maskable
        """
        return False

    def is_matching_value(self, other_value):
        """Compares the value of this match field to another.

        Arguments:
            other_value {*} -- value used in comparison

        Returns:
            {bool} -- true if the values are equal
        """
        return self.value == other_value

    def convert_general(self, forward=True):
        """Returns either the source or destination version of a common set of
        match fields such as EthSrc and EthDst.

        Keyword Arguments:
            forward {bool} -- true if value is for a source address (default: {True})

        Returns:
            {object} -- source or destination address match field
        """
        if forward:
            return self.source(self.value)
        else:
            return self.destination(self.value)

    def reverse(self):
        """Returns an object of the opposite class(source if destination,
        destination if source) but same value as self.

        Returns:
            {object} -- match field with the same value but opposite type
        """
        return self.opposite(self.value)

    @property
    def is_reversable(self):
        """Defines whether a match field is reversable.

        Returns:
            {bool} -- false unless overridden
        """
        return False


class MatchFieldWithMask(MatchField):
    """Base class for maskable match fields.
    """

    def __init__(self, value, mask=None, *args, **kwargs):
        """Initializes variables used for address masking.

        Arguments:
            value {int} -- match field address value

        Keyword Arguments:
            mask {int} -- the mask of the address (default: {None})
        """
        super().__init__(value, *args, **kwargs)
        self._mask = None
        if mask:
            self.mask = mask

        if isinstance(value, MatchFieldWithMask):
            self.mask = value.mask

    def copy(self):
        """Makes a copy of the match field with the same address and mask.

        Returns:
            {object} -- a new iteration of this match field class
        """
        return self.__class__(self.value, mask=self.mask, attributes=self.attributes)

    @classmethod
    def is_maskable(cls):
        """Always returns True for derived classes.
        """
        return True

    @staticmethod
    def is_valid_mask_bits(value, mask):
        """Checks if the address and mask conform to the rules of OpenFlow
        masking. Raises an error if they are not integers.

        Arguments:
            value {int} -- match field address value
            mask {int} -- the mask of the address

        Returns:
            {bool} -- false if a value binary digit is 1 masked by 0
        """
        if not isinstance(value, int):
            raise TypeError("Value must be a number not {} of type {}".format(value, type(value)))

        if not isinstance(mask, int):
            raise TypeError("Mask must be a number not {} of type {}".format(mask, type(mask)))

        value_bits = bin(value)[2:]
        mask_bits = bin(mask)[2:].zfill(len(value_bits))

        for value_bit, mask_bit in zip(value_bits, mask_bits):
            if mask_bit == '0' and value_bit == '1':
                return False
        else:
            return True

    def is_valid_mask(self, mask):
        """Validates an OpenFlow mask.

        Arguments:
            mask {int} -- mask being validated

        Returns:
            {bool} -- true if mask is a valid value and masks the address, or if no mask is used
        """
        return mask is None or (self.is_valid_value(mask) and self.is_valid_mask_bits(self.value, mask))

    @property
    def mask(self):
        """Defines mask property.
        """
        return self._mask

    @mask.setter
    def mask(self, value):
        """Setter for mask. Raises error if mask value is invalid.

        Arguments:
            value {int} -- the mask of the address
        """
        if self.is_valid_mask(value):
            self._mask = value
        else:
            raise ValueError("Invalid mask {} for match field {} probably because a 0 bit in the mask must be a 0 bit in the value".format(value, str(self.__class__.__name__[:-5])))

    def __repr__(self):
        """Defines printable representation of a match field with masked value.

        Returns:
            {str} -- [class name]: [address] / [mask]
        """
        return "{}:{}/{}".format(self.__class__.__name__,
                                 self.value,
                                 self.mask)

    def __eq__(self, other):
        """Two maskable match fields are equal if their class, address and mask
        values are equal.

        Arguments:
            other {*} -- item the match field is being compared to

        Returns:
            {bool} -- true if class, address and mask values are equal
        """
        return self.__class__ == other.__class__ and \
            self.value == other.value and \
            self.mask == other.mask

    def overlaps(self, other):
        """Checks for overlap between two match fields.

        Two match fields overlap if they have the same type and the same value.
        If one or more of the match fields has a mask, apply each mask to both
        values before comparing them to see if they overlap: if one or both
        mask(s) makes the values equal, they overlap.

        Arguments:
            other {*} -- match field used for comparison

        Returns:
            {bool} -- true if the match fields overlap
        """
        if self.mask:
            mask_other_value = self.convert_to_binary(other.value)
            return self.masked_value == mask_other_value
        elif isinstance(other, MatchFieldWithMask) and other.mask:
            mask_self_value = self.convert_to_binary(self.value)
            return other.masked_value == mask_self_value
        else:
            return super().is_matching_value(other.value)

    def is_matching_value(self, other_value):
        """Compares the address value with another value, attempting to mask
        the other value with the address' mask if applicable. Otherwise, simply
        compares values.

        Arguments:
            other_value {*} -- value used for comparison

        Returns:
            {bool} -- true if the values are equal
        """
        if self.mask:
            mask_other_value = self.convert_to_binary(other_value)
            return self.masked_value == mask_other_value
        else:
            return super().is_matching_value(other_value)

    def convert_to_src_dst(self, forward):
        """Sets an Ethernet MAC address or IP address value, and its mask, to a
        source or destination match field.

        Keyword Arguments:
            forward {bool} -- true if value is for a source address(default: {True})

        Returns:
            {object} -- source or destination address match field
        """
        if forward:
            return self.source(self.value, self.mask)
        else:
            return self.destination(self.value, self.mask)

    @property
    def masked_value(self):
        """Defines masked_value property as the value after applying the
        mask, if present.
        """
        return self.convert_to_binary(self.value)

    def convert_to_binary(self, value):
        """Applies an OpenFlow mask to a numerical value, if one is provided.

        Arguments:
            value {int} -- number treated as an address and masked

        Returns:
            {int} -- the value, with its mask applied if one is provided
        """
        if self.mask:
            return int(value, 16) & int(self.mask, 16)
        else:
            return self.value

    def reverse(self):
        """Returns an object of the opposite class(source if destination,
        destination if source) but same value as self.

        Returns:
            {object} -- match field with the same value but opposite type
        """
        return self.opposite(self.value, mask=self.mask)


class InPortMatch(MatchField):
    """Defines the InPort match field.
    """

    # translater includes physical, local, ingress and controller dicts
    TRANSLATER = merge_dicts(PhysicalPort.TRANSLATER,
                             LocalPort.TRANSLATER,
                             IngressPort.TRANSLATER,
                             ControllerPort.TRANSLATER)

    @staticmethod
    def is_valid_value(value):
        """Checks if value is valid for the InPort match field.

        Arguments:
            value {*} -- value of an InPort match field

        Returns:
            {bool} -- true if valid for physical, controller or local ports, or is zero
        """
        return PhysicalPort.is_valid_value(value) or \
            ControllerPort.is_valid_value(value) or \
            LocalPort.is_valid_value(value) or \
            value == 0


# NOTE unused(???)
class InPortFullMatch(InPortMatch):
    """Defines the InPort(Full) match field.
    """
    @staticmethod
    def is_valid_value(value):
        """Checks if value is valid for the InPort(Full) match field.

        Arguments:
            value {*} -- value of an InPort(Full) match field

        Returns:
            {bool} -- true if valid for physical, controller or local ports, or is zero
        """
        return PhysicalPort.is_valid_value(value) or \
            ControllerPort.is_valid_value(value) or \
            LocalPort.is_valid_value(value) or \
            value == 0


class EthMatch(MatchFieldWithMask):
    """Shared functions and properties of Ethernet match fields.
    """
    @property
    def source(self):
        """Returns the source Ethernet match field EthSrcMatch.
        """
        return EthSrcMatch

    @property
    def destination(self):
        """Returns the destination Ethernet match field EthDstMatch.
        """
        return EthDstMatch

    @property
    def is_reversable(self):
        """Defines whether a match field is reversable.

        Returns:
            {bool} -- true for Ethernet match fields
        """
        return True

    @staticmethod
    def is_valid_value(value):
        """Checks if an Ethernet match field value is a valid MAC address.

        Arguments:
            value {str} -- value of an eth address match field

        Returns:
            {bool} -- true if the value is a MAC address
        """
        # reg ex that matches any valid Ethernet value
        RE_ETH_ADDR = "^([0-9A-Fa-f]{2}[:-]?){5}([0-9A-Fa-f]{2})$"

        if isinstance(value, int):
            value = hex(value)[2:].zfill(12)

        if not isinstance(value, str):
            raise TypeError("Invalid value {} for MAC address".format(value))

        return match(RE_ETH_ADDR, value)

    def is_valid_mask(self, value):
        """Checks if a value is valid as a mask for the Ethernet match field.

        Arguments:
            value {str} -- value being tested as a mask

        Returns:
            {bool} -- true if the value is valid as a mask for the match field
        """
        return value is None or self.is_valid_mask_bits(int(self.value, 16),
                                       int(value.replace(':', '').replace('-', ''), 16))

    @property
    def value(self):
        """value property of an Ethernet match field.
        """
        return self._value

    @value.setter
    def value(self, value):
        """Setter for the value property. Checks if value is a valid MAC
        address, then sets it to lower case and strips non-numeral characters.
        Raises an error if the value is not a valid MAC address.

        Arguments:
            value {str} -- match field value
        """
        if self.is_valid_value(value):
            if isinstance(value, int):
                value = hex(value)[2:].zfill(12)
            self._value = value.replace(':', '').replace('-', '').lower()
        else:
            raise ValueError("Invalid Ethernet MAC Address {}".format(value))

    @property
    def mask(self):
        """Defines mask property.
        """
        return self._mask

    @mask.setter
    def mask(self, value):
        """Setter for mask. Raises an error if mask value is invalid.

        Arguments:
            value {str} -- the mask of the address
        """
        if self.is_valid_mask(value.replace(':', '').replace('-', '').lower()):
            self._mask = value.replace(':', '').replace('-', '').lower()
        elif value is not None:
            raise ValueError("Invalid Ethernet MAC Address Mask {}".format(value))

    def __str__(self):
        return ":".join([self.value[0:2].upper(), self.value[2:4].upper(), self.value[4:6].upper(), self.value[6:8].upper(), self.value[8:10].upper(), self.value[10:12].upper()])


class EthDstMatch(EthMatch):
    """Defines the EthDst match field.
    """

    # names and codes for Ethernet protocols
    TRANSLATER = {"P2P PTP": "01-80-C2-00-00-0E", "PTP": "01-1B-19-00-00-00"}

    @property
    def opposite(self):
        """Returns the opposite match field EthSrcMatch.
        """
        return EthSrcMatch

    def is_unicast(self):
        return hex(int(self.value.replace(":", '').replace("-", ''), 16))[2:].rjust(12, '0')[1] == '0'

    def is_multicast(self):
        return not self.is_unicast()


class EthSrcMatch(EthMatch):
    """Defines the EthSrc match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field EthDstMatch.
        """
        return EthDstMatch


class EthTypeMatch(MatchField):
    """Defines the EthType match field.
    """

    # names and codes for Ethernet protocols
    TRANSLATER = {'LLDP': 0x88cc, 'IPV4': 0x800, 'ARP': 0x806, 'GOOSE': 0x88b8,
                  'PTP': 0x88f7, 'SV': 0x88ba, 'PRP': 0x88fb}

    @staticmethod
    def _is_valid_value(value):
        """Checks if the match field value is a valid EthType protocol code.

        Arguments:
            value {int} / {hexadecimal} -- a match field value

        Returns:
            {bool} -- true if the value is a number between 0 and 0xffff
        """
        if isinstance(value, int):
            return 0 <= value <= 65535


class VlanVidMatch(MatchFieldWithMask):
    """Defines the VlanVid match field.
    """
    @staticmethod
    def is_valid_value(value):
        """Checks if the match field value is a valid VLAN ID code.

        Arguments:
            value {*} -- a match field value

        Returns:
            {bool} -- true if value is a number between 0 and 0xfff, 'Present' or 'None'
        """
        if isinstance(value, int):
            return 0 <= value <= 0xfff
        else:
            return (value in ('Present, None')) or (int(value) in range(0, 0xfff + 1))

    def is_valid_mask(self, mask):
        """Checks if a value is valid as a mask for the VlanVid match field.

        Arguments:
            value {str} -- value being tested as a mask

        Returns:
            {bool} -- true if the value is valid as a mask for the match field
        """
        return (mask is None or mask == "Present") or (self.is_valid_value(mask) and self.is_valid_mask_bits(self.value, mask))

    def convert_to_binary(self, value):
        """Adds the VlanVid address to 0x10000, then applies a mask if one is
        available. Addresses and masks that are valid strings are converted to
        the equivalent numeral values.

        Arguments:
            value {*} -- the match field value being modified

        Returns:
            {int} -- value added to 0x10000 and masked if applicable, returning
                0x10000 if value or mask is 'Present', 0 if value is 'None'
        """
        if value == "Present" or self.mask == "Present":
            return 0x10000
        elif value == "None":
            return 0
        elif self.mask:
            return (value + 0x10000) & (self.mask + 0x10000)
        else:
            return value + 0x10000


class VlanPcpMatch(MatchField):
    """Defines the VlanPcp match field.
    """
    @staticmethod
    def is_valid_value(value):
        """Checks if the match field value is a valid VLAN PCP.

        Arguments:
            value {int} -- a match field value

        Returns:
            {bool} -- true if value is a number between 0 and 7
        """
        return 0 <= value <= 7


class IpProtoMatch(MatchField):
    """Defines the IpProto match field.
    """

    # names and codes for IP protocols
    TRANSLATER = {'UDP': 17, 'TCP': 6, 'ICMP': 1}

    # NOTE should this convert to int or raise an error if value is not an int?
    @staticmethod
    def _is_valid_value(value):
        """Checks if the match field value is a valid IPv4 protocol number.

        Arguments:
            value {int} -- a match field value

        Returns:
            {bool} -- true if value is a number between 0 and 255
        """
        if isinstance(value, int):
            return 0 <= value <= 255


class IpAddressMatch(MatchFieldWithMask):
    """Shared functions and properties of IPv4 address match fields.
    """
    @property
    def source(self):
        """Returns the source IP address match field Ipv4SrcMatch.
        """
        return Ipv4SrcMatch

    @property
    def destination(self):
        """Returns the destination IP address match field Ipv4DstMatch.
        """
        return Ipv4DstMatch

    @property
    def is_reversable(self):
        """Defines whether a match field is reversable.

        Returns:
            {bool} -- true for IPv4 match fields
        """
        return True

    @staticmethod
    def is_valid_value(value):
        """Checks if an IP match field value is a valid IPv4 address.

        Arguments:
            value {str} -- value of an IP address match field

        Returns:
            {bool} -- true if the value is an IPv4 address
        """

        # reg ex that matches any IPv4 address
        RE_IPv4_ADDR = "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"

        try:
            return match(RE_IPv4_ADDR, value)
        except TypeError:
            return False

    @property
    def mask(self):
        """Defines mask property.
        """
        return self._mask

    @mask.setter
    def mask(self, value):
        """Setter for mask. Raises error if mask value is invalid.

        Arguments:
            value {str} -- the mask of the address
        """
        if value is None:
            self._mask = value
        elif not self.is_valid_value(value) or not self.is_valid_mask_bits(int(ip_address(self.value)), int(ip_address(value))):
            raise ValueError("Invalid IP Address Mask {} for value {}".format(value, self.value))
        self._mask = value
        # return int(''.join([bin(int(x)+256)[3:] for x in self.value.split('.')]), 2)

    def convert_to_binary(self, value):
        """Converts an IP address string to a numeral, applying a mask if one
        is included in the IP address match field.

        Arguments:
            value {str} -- an IP address as a string

        Returns:
            {int} -- the IP address as a numeral, masked if applicable
        """
        if self.mask:
            return int(''.join([bin(int(x) + 256)[3:] for x in value.split('.')]), 2) & int(''.join([bin(int(x) + 256)[3:] for x in self.mask.split('.')]), 2)
        else:
            return int(''.join([bin(int(x) + 256)[3:] for x in value.split('.')]), 2)

    def is_unicast(self):
        return not self.is_multicast()

    def is_multicast(self):
        return ip_address(self.value).is_multicast


class Ipv4Match(IpAddressMatch):
    """Denotes a match field for a standard IPv4 connection.
    """
    pass


class Ipv4SrcMatch(Ipv4Match):
    """Defines the Ipv4Src match field.
    """
    @property
    def arped(self):
        """Defines the arped property of an IP source as an associated ARP
        Source(ArpSpa) match field sharing the same IP address.

        Returns:
            {object} -- ArpSpa match field with the same value as the Ipv4Src
        """
        return ArpSpaMatch(self.value)

    @property
    def opposite(self):
        """Returns the opposite match field Ipv4DstMatch.
        """
        return Ipv4DstMatch


class Ipv4DstMatch(Ipv4Match):
    """Defines the Ipv4Dst match field.
    """
    @property
    def arped(self):
        """Defines the arped property of an IP destination as an associated ARP
        Destination(ArpTpa) match field sharing the same IP address.

        Returns:
            {object} -- ArpTpa match field with the same value as the Ipv4Dst
        """
        return ArpTpaMatch(self.value)

    @property
    def opposite(self):
        """Returns the opposite match field Ipv4SrcMatch.
        """
        return Ipv4SrcMatch


class IpPortMatch(MatchField):
    """Shared functions and properties of IPv4 protocol ports match fields.
    """
    @staticmethod
    def is_valid_value(value):
        """Checks if the value is a valid IPv4 protocol port number.

        Arguments:
            value {*} -- a match field value

        Returns:
            {bool} -- true if the value is a number between 0 and 65535
        """
        return 0 <= int(value) <= 65535

    @property
    def is_reversable(self):
        """Defines whether a match field is reversable.

        Returns:
            {bool} -- true for IPv4 protocol port match fields
        """
        return True


class TcpPortMatch(IpPortMatch):
    """Shared attributes and properties of Ipv4 TCP protocol match fields.
    """

    # dictionary of TCP ports
    TRANSLATER = {'DNP3': 20000, 'HTTPS': 443, 'TELNET': 23, 'MODBUS': 502,
                  "HTTP": 80, "SYNCHROPHASORS": 4712, "LDAP": 389, "MMS": 102,
                  "SSH": 22}

    @property
    def source(self):
        """Returns the source version of a TCP port TcpSrcMatch.
        """
        return TcpSrcMatch

    @property
    def destination(self):
        """Returns the destination version of a TCP port TcpDstMatch.
        """
        return TcpDstMatch


class TcpSrcMatch(TcpPortMatch):
    """Defines the TcpSrc match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field TcpDstMatch.
        """
        return TcpDstMatch


class TcpDstMatch(TcpPortMatch):
    """Defines the TcpDst match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field TcpSrcMatch.
        """
        return TcpSrcMatch


class UdpPortMatch(IpPortMatch):
    """Shared attributes and properties of Ipv4 UDP protocol match fields.
    """

    # dictionary of UDP ports
    TRANSLATER = {'SNMP': 161, "NTP": 123,
                  "DNP3": 20000, "SYNCHROPHASORS": 4713}

    @property
    def source(self):
        """Returns the source version of a UDP port UdpSrcMatch.
        """
        return UdpSrcMatch

    @property
    def destination(self):
        """Returns the destination version of a UDP port UdpDstMatch.
        """
        return UdpDstMatch


class UdpSrcMatch(UdpPortMatch):
    """Defines the UdpSrc match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field UdpDstMatch.
        """
        return UdpDstMatch


class UdpDstMatch(UdpPortMatch):
    """Defines the UdpDst match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field UdpSrcMatch.
        """
        return UdpSrcMatch


class ArpOpMatch(MatchField):
    """Defines the ArpOp match field.
    """
    @staticmethod
    def is_valid_value(value):
        """Checks if the match field value is a valid ARP Opcode.

        Arguments:
            value {*} -- match field value

        Returns:
            {bool} -- true if value is a number between 0 and 255, or is 'request' or 'reply'
        """
        if isinstance(value, int):
            return 0 <= value <= 255
        elif isinstance(value, str):
            return value.lower() in ('request', 'reply')


class ArpMatch(IpAddressMatch):
    """Shared properties of ARP Ipv4 address match fields.
    """
    @property
    def source(self):
        """Returns the source version of ARP protocol address ArpSpaMatch.
        """
        return ArpSpaMatch

    @property
    def destination(self):
        """Returns the destination version of ARP protocol address ArpTpaMatch.
        """
        return ArpTpaMatch


class ArpSpaMatch(ArpMatch):
    """Defines the ArpSpa match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field ArpTpaMatch.
        """
        return ArpTpaMatch


class ArpTpaMatch(ArpMatch):
    """Defines the ArpTpa match field.
    """
    @property
    def opposite(self):
        """Returns the opposite match field ArpSpaMatch.
        """
        return ArpSpaMatch


class MatchFields(UniqueValues):
    """List of a flow entry's match fields, their values and prerequisites.
    """

    # values added to this object must be match fields
    VALUE_CLASS = MatchField

    def add(self, match_field):
        """Adds a match field to the list, along with all of its required
        OpenFlow prerequisites.

        Ignores the match field if the match field is equivalent to a match
        field already present. Raises an error if a match field of the same
        type is already present but the value is not equal, or if a VlanPcp is
        added without a VlanVid.

        Arguments:
            match_field {class} -- an OpenFlow match field type
        """
        if self.get(match_field) and self.get(match_field).value is not None:
            if self.get(match_field).value != match_field.value:
                raise ValueError("Attempting to add match field {} with value {} that is already present with a different value {}.".format(match_field.__class__.__name__[:-5],
                                                                                                                                            match_field,
                                                                                                                                            self.get(match_field)))
            else:
                return
                # ignore if you are simply adding a duplicate (same class same value)

        # Add OpenFlow defined prereqs if applicable
        if isinstance(match_field, ArpMatch) or isinstance(match_field, ArpOpMatch):
            self.add(EthTypeMatch("ARP"))
        elif isinstance(match_field, Ipv4Match) or isinstance(match_field, IpProtoMatch):
            self.add(EthTypeMatch("IPv4"))
        elif isinstance(match_field, TcpPortMatch):
            self.add(EthTypeMatch("IPv4"))
            self.add(IpProtoMatch("TCP"))
        elif isinstance(match_field, UdpPortMatch):
            self.add(EthTypeMatch("IPv4"))
            self.add(IpProtoMatch("UDP"))

        # while this statement is techinically true, the way the flow gets constructed
        # this logic will fail...so we remove it.
        # if isinstance(match_field, VlanPcpMatch) and not self.get(VlanVidMatch):
            # raise ValueError("Can't add VLAN PCP Value without a VLAN VID Match")

        if isinstance(match_field, MatchField):
            super().add(match_field)
        else:
            raise TypeError("{} is not a valid Match Field".format(match_field))

    def overlaps(self, other):
        """Checks whether or not two lists of match fields overlap.

        Lists of match fields overlap if there is the possibility for a packet
        to match both of them.  This occurs when there are no match field types
        common to the match fields of both whose values do not overlap after
        adjusting for masking.

        Arguments:
            other {object} -- object under comparison of match fields

        Returns:
            {bool} -- true if the lists overlap
        """

        for match_field in MATCH_FIELDS:
            if (self.get(match_field) and other.get(match_field) and not self.get(match_field).overlaps(other.get(match_field))):
                return False
        return True

    def reverse(self):
        """Returns a current set of match fields, but with all reversable match
        fields reversed.

        Returns:
            {object} -- MatchFields object with the current list of match
                fields substituted with the opposite where applicable
        """
        new_match_fields = MatchFields()
        for match_field in self.values:
            if match_field.is_reversable:
                new_match_fields.add(match_field.reverse())
            else:
                new_match_fields.add(match_field)
        return new_match_fields

    def add_by_name(self, name, value):
        for match_field in MATCH_FIELDS:
            if match_field.__name__.replace("Match", "").lower() == name.lower():
                new_match_field = match_field(value)
                self.add(new_match_field)
                break
        else:
            raise TypeError("Unable to find matching match field for name {}".format(name))

# list of OpenFlow match fields
MATCH_FIELDS = [InPortMatch, EthDstMatch, EthSrcMatch, EthTypeMatch,
                VlanVidMatch, VlanPcpMatch, IpProtoMatch, Ipv4SrcMatch,
                Ipv4DstMatch, TcpSrcMatch, TcpDstMatch, UdpSrcMatch,
                UdpDstMatch, ArpOpMatch, ArpSpaMatch, ArpTpaMatch]

# list of reversable OpenFlow match fields
# NOTE is this unused(???) is_reversable seems to be used instead, though it's false for ARP classes
MATCH_FIELDS_REVERSABLE = (EthDstMatch, EthSrcMatch, Ipv4SrcMatch,
                           Ipv4DstMatch, TcpSrcMatch, TcpDstMatch, UdpSrcMatch,
                           UdpDstMatch, ArpSpaMatch, ArpTpaMatch)
