"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Flow entry instructions packets.
"""

from ...base.value import Value
from ...base.values import Values
from .actions import Action, Actions, ActionSet


class Instruction:
    """Base class for all flow entry instructions.
    """
    pass


class NonActionInstruction(Instruction, Value):
    """Base class for instructions that do not contain actions.
    """
    pass


class GotoTableInstruction(NonActionInstruction):
    """Defines the GoTo-Table instruction.
    """

    def is_valid_value(self, value):
        """Checks if a valid flow Table ID is provided.

        Arguments:
            value {int} -- Table ID number

        Return:
            {bool} -- true if value is between 1 and 3
        """
        return 1 <= value <= 3


class MeterInstruction(NonActionInstruction):
    """Defines the Meter instruction.
    """
    @staticmethod
    def _is_valid_value(value):
        """Checks if a valid Meter ID is provided.

        Arguments:
            value {int} -- Meter ID number

        Returns:
            {bool} -- true if value is between 1 and 64
        """
        return 1 <= value <= 64


class ClearActionsInstruction(NonActionInstruction):
    """Defines the Clear-Actions instruction
    """
    def __init__(self):
        """Sets the value of this action to None.
        """
        super().__init__(value=True)

    def is_valid_value(self, value):
        """Checks whether the choice whether to clear actions is valid.

        Arguments:
            value {*} -- value determining whether clearing actions is enabled

        Returns:
            {bool} -- true if value is boolean
        """
        return value is True


class ActionInstruction(Instruction, ActionSet):
    """Base class for instructions that contain actions.
    """
    pass


class WriteActionsInstruction(ActionInstruction):
    """Defines the Write-Actions instruction.
    """

    # only instruction actions are permitted as values
    VALUE_CLASS = Action


class Instructions(Values):
    """Container class for instruction objects.
    """

    # only instructions are permitted as values
    VALUE_CLASS = Instruction


# list of all flow entry instructions
INSTRUCTIONS = [GotoTableInstruction, MeterInstruction,
                ClearActionsInstruction, WriteActionsInstruction]
