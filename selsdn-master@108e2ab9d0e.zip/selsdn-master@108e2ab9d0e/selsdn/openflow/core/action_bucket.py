"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes for OpenFlow group watch ports and action buckets.
"""

from ...base.value import Value
from ...base.values import Values
from .actions import OutputAction, GroupAction, DropAction, Actions
from .ports import PhysicalPort, AnyPort
from ...base.tools import merge_dicts


class WatchPort(Value):
    """Representation of an OpenFlow Watch Port.
    """

    # aliases for any port or a specified physical port available
    TRANSLATER = merge_dicts(PhysicalPort.TRANSLATER, AnyPort.TRANSLATER)

    def __init__(self, value=0xffffffff):
        """Sets up the Watch Port to the given value.

        Keyword Arguments:
            value {int}/{hexadecimal} -- number of Watch Port (default: {0xffffffff})
        """
        super().__init__(value)

    @staticmethod
    def _is_valid_value(value):
        """Checks if the value is a valid Watch Port value.

        Arguments:
            value {*} -- value being tested

        Returns:
            {bool} -- true if value is valid for a port of type Physical or Any
        """
        return PhysicalPort.is_valid_value(value) or AnyPort.is_valid_value(value)


class WatchGroup(Value):
    """Representation of an OpenFlow Watch Group.
    """

    # aliases for any port available
    TRANSLATER = AnyPort.TRANSLATER

    def __init__(self, value=0xffffffff):
        """Sets up the Watch Group to the given value.

        Keyword Arguments:
            value {hexadecimal} -- value used for Watch Group (default: {0xffffffff})
        """
        super().__init__(value)

    @staticmethod
    def _is_valid_value(value):
        """Checks if the value can be the ID of a Watch Group.

        Arguments:
            value {*} -- value being tested

        Returns:
            {bool} -- true if the value is the Any value or a valid Group ID
        """
        return AnyPort.is_valid_value(value) or GroupAction.is_valid_value(value)


class ActionBucket(Actions):
    """Representation of an OpenFlow action bucket.
    """

    def __init__(self, actions=None, watch_port=None, watch_group=None):
        """Sets up the action bucket with given actions, Watch Port and Watch
        Group.

        Keyword Arguments:
            actions {object} -- list of actions to apply to the bucket (default: {None})
            watch_port {object} -- Watch Port for the action bucket (default: {None})
            watch_group {object} -- Watch Group for the action bucket (default: {None})
        """
        super().__init__()
        self.watch_port = watch_port
        self.watch_group = watch_group

        if actions:
            if hasattr(actions, '__iter__'):
                for action in actions:
                    self.add(action)
            else:
                self.add(actions)

    @property
    def actions(self):
        """Returns the actions applied to the action bucket.
        """
        return self.values

    @property
    def watch_port(self):
        """Returns the Watch Port object.
        """
        return self._watch_port

    @watch_port.setter
    def watch_port(self, value):
        """Setter for watch_port property. Uses Any Port unless a different
        port value is provided. If the value arg is itself a Watch Port, sets
        the property to that one.

        Arguments:
                value {*} -- reference to or initial value of the Watch Port
        """
        if value is None:
            self._watch_port = WatchPort()
        elif isinstance(value, WatchPort):
            self._watch_port = value
        else:
            self._watch_port = WatchPort(value)

    @property
    def watch_group(self):
        """Returns the Watch Group object.
        """
        return self._watch_group

    @watch_group.setter
    def watch_group(self, value):
        """Setter for watch_group property. Uses Any Group unless a different
        group value is provided. If the value arg is itself a Watch Group, sets
        the property to that one.

        Arguments:
                value {*} --reference to or initial Group ID of the Watch Group
        """
        if value is None:
            self._watch_group = WatchGroup()
        elif isinstance(value, WatchGroup):
            self._watch_group = value
        else:
            self._watch_group = WatchGroup(value)

    def __repr__(self):
        """Defines the string represenation of the action bucket.

        Returns:
            {str} -- list of all actions in the bucket by name and value
        """
        return "ActionBucket(" + ",".join(["{}:{}+".format(x.name, x.value) for x in self.actions]) + ")"

    def __eq__(self, other):
        """Two action buckets are equal if they share the same Watch Port,
        Watch Group and actions.

        Arguments:
            other {object} -- action bucket used for comparison

        Returns:
            {bool} -- true if both action buckets are equal
        """
        return self.watch_port == other.watch_port and \
            self.watch_group == other.watch_group and \
            super().__eq__(other)


class SimpleActionBucket(ActionBucket):
    """Class for setting up an action bucket with Watch Port and Watch
    Group both set to Any.
    """

    def __init__(self, actions):
        """Sets up an action bucket watching Any Port and Any Group.

        Arguments:
            actions {object} -- list of actions to be included in the bucket
        """
        super().__init__(actions=actions, watch_port=WatchPort(), watch_group=WatchGroup())


class ActionBuckets(Values):
    """Holds the action buckets of a group entry.
    """

    # only action buckets may be added to this object
    VALUE_CLASS = ActionBucket
