"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes for OpenFlow meter entries and their associated properties.
"""

from .entry import Entry
from ...base.value import Value
from .instructions import MeterInstruction

# name units of measurement for bandwidth
MEASUREMENT_PPS = 'pps'
MEASUREMENT_KBPS = 'kbps'


class MeasurementType(Value):
    """Represents the measurement type of an OpenFlow meter entry.
    """

    @staticmethod
    def is_valid_value(value):
        """Checks if the value is a unit of data per second.

        Arguments:
            value {str} -- the unit of measurement to be validated

        Returns:
            {bool} -- true if value is abbreviation for kb/packets per second
        """
        return value in (MEASUREMENT_KBPS, MEASUREMENT_PPS)


class Rate(Value):
    """Represents the rate of an OpenFlow meter entry.
    """

    @staticmethod
    def is_valid_value(value):
        """Rate value is automatically validated.

        Returns:
            {bool} -- true
        """
        return True


class BurstSize(Value):
    """Sets the maximum allowable burst speed of data through the meter.
    """
    @staticmethod
    def is_valid_value(value):
        """BurstSize value is automatically validated.

        Returns:
            {bool} -- true
        """
        return True


class MeterEntry(Entry):
    """Represents an OpenFlow meter entry.
    """

    def __init__(self, name, node, entry_id, measurement_type, rate,
                 burst_size=None, attributes=None):
        """Representation of an OpenFlow meter entry.

        Arguments:
            name {str} -- alias of meter
            node {str}/{device} -- network node containing the meter
            entry_id {int} -- OpenFlow Meter ID
            measurement_type {str} -- unit of measurement of the rate and burst size
            rate {object} -- refill rate of the meter(in unit of measurement_type)

        Keyword Arguments:
            burst_size {object} -- may optionally provide the maximum burst size defining the size
                                of the meter, a required minimum will be applied on the SEL-2740S
                                according to this rate. (default: {None})
            attributes {dict} -- additional object attributes (default: {None})
        """
        super().__init__(name, node, entry_id, attributes=attributes)
        self.measurement_type = measurement_type
        self.rate = rate
        self.burst_size = None if not burst_size else burst_size

    @property
    def measurement_type(self):
        """Returns the unit of measurement for the rate and burst size.
        """
        return self._measurement_type.value

    @measurement_type.setter
    def measurement_type(self, value):
        """Setter for measurement_type. If a MeasurementType object is
        provided, use it. Otherwise, create a new MeasurementType object with
        value as the type name.

        Arguments:
            value {*} -- info used to set unit of bandwidth
        """
        if isinstance(value, MeasurementType):
            self._measurement_type = value
        else:
            self._measurement_type = MeasurementType(value)

    @property
    def entry_id(self):
        """Returns the Group ID.
        """
        return self._entry_id

    @entry_id.setter
    def entry_id(self, value):
        """Setter for the Group ID. Raises an error if an invalid ID is
        provided.
        """
        if MeterInstruction.is_valid_value(value):
            self._entry_id = value
        else:
            raise ValueError("Invalid Meter ID {}. Must be 1 through 64.".format(value))

    def __eq__(self, other):
        """Two meters are equal if they have the same node name, Meter ID,
        and bandwidth and meter settings.

        Arguments:
            other {object} -- another meter used for comparison

        Returns:
           {bool} -- true if the meters are equal
        """
        return self.node_name == other.node_name and \
            self.entry_id == self.entry_id and \
            self.rate == other.rate and \
            self.burst_size == other.burst_size and \
            self.measurement_type == other.measurement_type and \
            self.compare_attribute("Enabled", other, default_value=True)

    def overlaps(self, other):
        """Checks whether or not two meter entries overlap.

        Meter entries overlap if they are on the same device and have the same
        Meter ID.

        Arguments:
            other {object} -- another openflow entry used for comparison

        Returns:
            {bool} -- true if the meter entries overlap
        """
        return self.node_name == other.node_name and self.entry_id == self.entry_id

    def __repr__(self):
        """Defines the string representation of a meter.

        Returns:
            {str} -- "[alias]@[node]<[Group Type]:[Group ID]>:[action buckets]"
        """
        return "{}@{}<{},{}>[{},{},{}]".format(self.name, self.node,
                                        self.__class__.__name__, self.entry_id,
                                        self.rate, self.burst_size, self.measurement_type)
