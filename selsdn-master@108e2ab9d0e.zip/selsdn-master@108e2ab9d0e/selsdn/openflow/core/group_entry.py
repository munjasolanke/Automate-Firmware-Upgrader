"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

OpenFlow group entry class and group type classes.
"""

from .entry import Entry
from .action_bucket import WatchPort, WatchGroup, ActionBuckets
from .actions import OutputAction, GroupAction


class GroupEntry(Entry):
    """Base class for OpenFlow groups.
    """

    def __init__(self, name, node, entry_id,
                 action_buckets=None, attributes=None):
        """Sets up a new group entry, using the general settings and action
        buckets as provided.

        Arguments:
            name {str} -- alias of group
            node {str}/{device} -- network node containing the group
            entry_id {int} -- OpenFlow Group ID

        Keyword Arguments:
            action_buckets {object} -- list of the group's action buckets(default: {None})
            attributes {dict} -- additional object attributes (default: {None})
        """
        super().__init__(name, node, entry_id, attributes=attributes)
        self._action_buckets = ActionBuckets()

        if action_buckets:
            for action_bucket in action_buckets:
                self.add_action_bucket(action_bucket)

    def add_action_bucket(self, action_bucket):
        """Adds an action bucket to a group.

        Arguments:
            action_bucket {object} -- the action bucket being added
        """
        self._action_buckets.add(action_bucket)

    @property
    def entry_id(self):
        """Returns the Group ID.
        """
        return self._entry_id

    @entry_id.setter
    def entry_id(self, value):
        """Setter for the Group ID. Raises an error if an invalid ID is
        provided.
        """
        if GroupAction.is_valid_value(value):
            self._entry_id = value
        else:
            raise ValueError("Invalid Group ID {}".format(value))

    @property
    def action_buckets(self):
        """Returns the action buckets of the group.
        """
        return self._action_buckets

    def __repr__(self):
        """Defines the string representation of a group.

        Returns:
            {str} -- "[alias]@[node]<[Group Type]:[Group ID]>:[action buckets]"
        """
        return "{}@{}<{}:{}>:{}".format(self.name, self.node,
                                        self.__class__.__name__, self.entry_id,
                                        self.action_buckets)

    def __eq__(self, other):
        """Two groups are equal if they have the same node name, Group ID and
        Group Type, and their action buckets are also equal.

        Arguments:
            other {object} -- another group used for comparison

        Returns:
            {bool} -- true if groups are equal
        """
        return self.node_name == other.node_name and \
            self.entry_id == other.entry_id and \
            self.__class__ == other.__class__ and \
            self.are_action_buckets_eq(other.action_buckets) and \
            self.compare_attribute("Enabled", other, default_value=True)

    def overlaps(self, other):
        """Checks whether or not two groups overlap.

        Two groups from the same device overlap if they have the same Group ID
        but have different Group Type and/or action buckets.

        Arguments:
            other {object} -- another group used for comparison

        Returns:
            {bool} -- true if groups have the same Group ID and node name but
            are not equal, otherwise false
        """
        return self.node_name == other.node_name and \
            self.entry_id == other.entry_id and \
            self != other
        # and (self.actions != other.actions or self.instructions != other.instructions)

    def add_action_buckets(self, action_buckets):
        """Adds multiple action buckets to a group.

        Arguments:
            action_buckets {object} -- list of action buckets to be added
        """
        for action_bucket in action_buckets:
            self.add_action_bucket(action_bucket)


class NonOrderedGroupEntry(GroupEntry):
    """Shared functions of groups where the order of the action buckets does
    not effect functionality.
    """

    def are_action_buckets_eq(self, other_action_buckets):
        """Compares the groups's action buckets to another list of action
        buckets. Two lists of the same length with the same action buckets are
        considered equal, even if the order of the buckets is different.

        Arguments:
            other_action_buckets {object} -- action buckets used in comparison

        Returns:
            {bool} -- true if lists have the same length and buckets(regardless of order)
        """
        if len(self.action_buckets) != len(other_action_buckets):
            return False

        for action_bucket in self.action_buckets:
            if action_bucket not in other_action_buckets:
                return False
        else:
            return True


class AllGroup(NonOrderedGroupEntry):
    """Defines groups of type All.
    """

    def add_action_bucket(self, action_bucket):
        """Adds an action bucket to the All group only if its watch group and
        watch port are both set to Any. Otherwise, raises an error.

        Arguments:
            action_bucket {object} -- action bucket being added to the group
        """
        if action_bucket.watch_group == WatchGroup() and action_bucket.watch_port == WatchPort():
            self.action_buckets.add(action_bucket)
        else:
            raise ValueError("For All Groups, each action bucket's {} Watch Port and Watch Group must be Any and Any not {} and {}".format(self.entry_id,
                                                                                                                                           action_bucket.watch_port.value,
                                                                                                                                           action_bucket.watch_group.value))


class IndirectGroup(NonOrderedGroupEntry):
    """Defines groups of type Indirect.
    """

    def add_action_bucket(self, action_bucket):
        """Adds an action bucket to the Indirect group only if its watch group
        and watch port are both set to Any, and if the group doesn't have an
        action bucket already. Otherwise, raises an error.

        Arguments:
            action_bucket {object} -- action bucket being added to the group
        """
        if action_bucket.watch_group == WatchGroup() and action_bucket.watch_port == WatchPort() and len(self.action_buckets) == 0:
            self.action_buckets.add(action_bucket)
        else:
            # NOTE should be a different error message if bucket uses a non-Any watch port/group
            raise ValueError("Cannot add more than one action bucket to an Indirect group")


class SelectGroup(NonOrderedGroupEntry):
    """Defines groups of type Select.
    """

    def add_action_bucket(self, action_bucket):
        """Adds an action bucket to the Select group if its watch group and
        watch port are both set to Any and if it either has no actions or a
        single Output action. Otherwise, raises an error.

        Arguments:
            action_bucket {object} -- action bucket being added to the group
        """
        if action_bucket.watch_group == WatchGroup() and action_bucket.watch_port == WatchPort():
            if 0 <= len(action_bucket.actions) <= 1:
                if len(action_bucket.actions) == 1:
                    if isinstance(action_bucket.actions[0], OutputAction):
                        self.action_buckets.add(action_bucket)
                    else:
                        raise ValueError("Action must be Output not {}".format(action_bucket.actions[0]))
                else:
                    self.action_buckets.add(action_bucket)
            else:
                raise ValueError("Select Groups can only have a single action bucket with either no or the output action")
        else:
            raise ValueError("For Select Groups, each action bucket's {} Watch Port and Watch Group must be Any and Any not {} and {}".format(self.entry_id,
                                                                                                                                              action_bucket.watch_port,
                                                                                                                                              action_bucket.watch_group.value))


class FastFailoverGroup(GroupEntry):
    """Defines groups of type Fast Failover.
    """

    def add_action_bucket(self, action_bucket):
        """Adds an action bucket to the Fast Failover group as long as either
        the watch port or watch group is not set to Any. If both are Any,
        raises an error.

        Arguments:
            action_bucket {object} -- action bucket being added to the group
        """
        if action_bucket.watch_group != WatchGroup() or action_bucket.watch_port != WatchPort():
            self.action_buckets.add(action_bucket)
        else:
            raise ValueError("At least one of the Watch Port or Watch Group for an action bucket in a Fast Failover group must not be Any")

    def are_action_buckets_eq(self, other_action_buckets):
        """Compares the groups's action buckets to another list of action
        buckets. Two lists of the same length, with the same action buckets in
        the same order are considered equal for Fast Failover groups.

        Arguments:
            other_action_buckets {object} -- action buckets used in comparison

        Returns:
            {bool} -- true if lists are equal in length, buckets and iterated order of buckets
        """
        if len(self.action_buckets) != len(other_action_buckets):
            return False

        for self_bucket, other_action_bucket in zip(self.action_buckets, other_action_buckets):
            if self_bucket != other_action_bucket:
                return False
        else:
            return True
