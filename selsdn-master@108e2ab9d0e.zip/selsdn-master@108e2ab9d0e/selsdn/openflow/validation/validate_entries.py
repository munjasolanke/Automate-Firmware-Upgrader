from collections import defaultdict

from ..core.group_entry import SelectGroup
from ..core.actions import GroupAction, SetVlanVidAction, SetVlanPcpAction, PopVlanAction, PushVlanAction
from ..core.match_fields import VlanVidMatch, VlanPcpMatch

from ...base.collection import FlowCollection

from .validate_group_buckets import validate_group_buckets

from time import time

def get_entries_by_switch_table_priority(flow_entries):
    entries_by_switch_table_priority = defaultdict(dict)

    for index, flow_entry in enumerate(flow_entries):

        switch = flow_entry.node
        table_id = flow_entry.table_id
        priority = flow_entry.priority

        if table_id in entries_by_switch_table_priority[switch]:
            if priority in entries_by_switch_table_priority[switch][table_id]:
                entries_by_switch_table_priority[switch][table_id][priority].append(flow_entry)
            else:
                entries_by_switch_table_priority[switch][table_id][priority] = [flow_entry]
        else:
            entries_by_switch_table_priority[switch][table_id] = {priority:[flow_entry]}

    return entries_by_switch_table_priority

def validate_no_overlap(flow_entries):
    entries_by_switch_table_priority = get_entries_by_switch_table_priority(flow_entries)

    for switch, table_priorities in entries_by_switch_table_priority.items():
        for table, priorities in table_priorities.items():
            for priority, flow_entries in priorities.items():
                for index, flow_entry in enumerate(flow_entries):
                    for other_flow_entry in flow_entries[index+1:]:
                        if flow_entry.overlaps(other_flow_entry):
                            raise ValueError("Entry {} overlaps with {}".format(flow_entry, other_flow_entry))

def validate_match_fields_and_actions(flow_entries):
    for flow_entry in flow_entries:
        # Check to see if VLAN prerequistcs are met
        if flow_entry.actions.get(SetVlanVidAction) or flow_entry.actions.get(SetVlanPcpAction) or flow_entry.actions.get(PopVlanAction):
            if not ((flow_entry.match_fields.get(VlanVidMatch) and  flow_entry.match_fields.get(VlanVidMatch).value != "None") or flow_entry.actions.get(PushVlanAction)):
                raise ValueError("Trying to do a VLAN action with out a VlanVid match field that is not None or PushVlan action for flow entry {}".format(flow_entry))

        # Check to see if VlanVid and mask makes sense
        vlanvid_match = flow_entry.match_fields.get(VlanVidMatch)
        if vlanvid_match:
            if vlanvid_match.value == "Present" and vlanvid_match.mask != "Present":
                raise ValueError("If VlanVid value is Present, mask must also be Present for flow entry {}".format(flow_entry))
            
            if vlanvid_match.mask == "Present" and vlanvid_match.value != "Present":
                raise ValueError("If VlanVid mask value is Present, value must also be Present {}".format(flow_entry))

        # Check to see if VlanPcp is present, the VlanVid value also does
        vlanpcp_match = flow_entry.match_fields.get(VlanPcpMatch)
        if vlanpcp_match and not (flow_entry.match_fields.get(VlanVidMatch) and flow_entry.match_fields.get(VlanVidMatch).value != "None"):
            raise ValueError("Can't have VlanPcp if VlanVid is not present or None {}".format(flow_entry))

def validate_groups(group_objects):
    # Validate that no over lapping group IDs per switch
    validate_unique_IDs(group_objects)
    # that the number of group entries <= 256
    validate_number_of_groups(group_objects)
    validate_group_entry_group_actions(group_objects)
    validate_group_buckets(group_objects)
    validate_depth_of_chaining(group_objects)
    # that the number of select groups are <= 1
    #validate_number_of_select_groups(group_objects)
    # @TODO depth of chainging

def validate_depth_of_chaining(group_objects):
    bad_groups = list()
    for group_object in group_objects:
        all_chains = list()
        _validate_depth_of_chaining(group_objects, group_object=group_object, chain=[group_object], all_chains=all_chains)

        for chain in all_chains:
            if len(chain) > 3:
                bad_groups.append(chain)

    if bad_groups:
        bad_group_string = ""
        for bad_group in bad_groups:
            bad_group_string += "->".join(map(str, bad_group))
            bad_group_string += "\n\n"

        raise ValueError("The following chains exceed the chaining level of 3: {}".format(bad_group_string))

def _validate_depth_of_chaining(group_objects, group_object, chain, all_chains):
    one_group_action = False
    for action_bucket in group_object.action_buckets:
        if action_bucket.get(GroupAction):
            one_group_action = True
            group_entry = group_objects.has_switch(group_object.node_name).has_entry_id(action_bucket.get(GroupAction).value)[0]
            new_chain = chain[::]
            new_chain.append(group_entry)
            _validate_depth_of_chaining(group_objects, group_object=group_entry, chain=new_chain, all_chains=all_chains)

    if not one_group_action:
        all_chains.append(chain[::])

def validate_group_entry_group_actions(group_objects):
    for group_entry in group_objects:
        for action_bucket in group_entry.action_buckets:
            if action_bucket.get(GroupAction):
                group_id = action_bucket.get(GroupAction).value
                for subgroup_entry in group_objects:
                    if subgroup_entry.entry_id == group_id and subgroup_entry.node_name == group_entry.node_name:
                        break
                else:
                    raise ValueError("Cannot find group id {} referenced in action bucket in group {}".format(group_id, group_entry))

def validate_unique_IDs(group_objects):
    nodes = defaultdict(list)

    for group in group_objects:
        if group.entry_id in nodes[group.node_name]:
            raise ValueError("Duplicate ID {} for node {}".format(group.entry_id, group.node))
        else:
            nodes[group.node_name].append(group.entry_id)

def validate_number_of_groups(group_objects):
    group_ids = defaultdict(int)

    for group in group_objects:
        group_ids[group.node_name] += 1

    for switch_name, number in group_ids.items():
        if number >= 256:
            raise ValueError("Too many groups on switch {}, {} found (limit 256)".format(switch_name, number))

def validate_number_of_select_groups(group_objects):
    select_groups = 0

    for group in group_objects:
        if isinstance(group, SelectGroup):
            select_groups += 1

    if select_groups > 1:
        raise ValueError("Too many select groups, only 1 allowed, but {} found".format(select_groups))

def validate_flows(flow_entries, collection_check=False):
    validate_match_fields_and_actions(flow_entries)

    if not collection_check or not isinstance(flow_entries, FlowCollection):
        validate_no_overlap(flow_entries)

    return validate_number_per_table(flow_entries)

def validate_number_per_table(flow_entries):
    number_table = defaultdict(dict)

    for entry in flow_entries:
        table_id = entry.table_id
        if table_id not in number_table[entry.node_name]:
            number_table[entry.node_name][entry.table_id] = 0

        number_table[entry.node_name][entry.table_id] += 1

    for switch, tables in number_table.items():
        for table, count in tables.items():
            if table not in range(0, 3+1):
                raise ValueError("{} is not a valid table for switch {}".format(table, switch))
            elif count > 1024:
                raise ValueError("{} is too many flow entries for table {} on switch {}, limit 1024".format(count, table, switch))

    return number_table

def validate_flows_references_to_groups(flow_entries, group_entries):
    for flow_entry in flow_entries:
        if flow_entry.actions.get(GroupAction):
            group_id = flow_entry.actions.get(GroupAction).value

            for group_entry in group_entries:
                if group_entry.entry_id == group_id:
                    break
            else:
                raise ValueError("No such group id found {}".format(group_id))

def validate_flows_and_groups(flow_entries, group_entries, collection_check=False):
    validate_groups(group_entries)
    validate_flows_references_to_groups(flow_entries, group_entries)
    return validate_flows(flow_entries, collection_check=collection_check)
