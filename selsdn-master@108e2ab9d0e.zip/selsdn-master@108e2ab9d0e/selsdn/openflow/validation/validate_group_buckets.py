from collections import defaultdict

def validate_group_buckets(group_objects):
    validate_unique_action_buckets_per_switch(group_objects)
    validate_unique_action_buckets_per_group(group_objects)

def validate_unique_action_buckets_per_switch(group_objects):
    unique_action_buckets_per_switch = defaultdict(list)
    for group_entry in group_objects:
        node_name = group_entry.node
        group_id = group_entry.entry_id
        for this_action_bucket in group_entry.action_buckets:
            unique = True
            for found_action_bucket in unique_action_buckets_per_switch[node_name]:
                if this_action_bucket == found_action_bucket:
                    unique = False
                    break

            if unique:
                unique_action_buckets_per_switch[node_name].append(this_action_bucket)

    switch_list = list()
    for switch, unique_action_buckets in unique_action_buckets_per_switch.items():
        if len(unique_action_buckets) > 128:
            switch_list.append([switch, len(unique_action_buckets)])

    if switch_list:
        raise ValueError("Too many action buckets per switch for {}".format(switch_list))

def validate_unique_action_buckets_per_group(group_objects):
    action_buckets_per_group = list()
    for group_entry in group_objects:
        node_name = group_entry.node
        group_id = group_entry.entry_id
        if len(group_entry.action_buckets) > 30:
            action_buckets_per_group.append(group_entry)

    if action_buckets_per_group:
        raise ValueError("Too many action buckets per group for groups {}".format(", ".join(map(str, action_buckets_per_group))))
