from collections import defaultdict

from ..openflow.core.group_entry import GroupEntry
from ..openflow.core.action_bucket import ActionBucket
from ..openflow.core.actions import ACTIONS
from ...base.tools.csv.entry_parser import create_action

class CompactedGroupEntry:
    def __init__(self, node, group_type, group_id, name=None, buckets=None):
        self.name = name
        self.node = node
        self.group_type = group_type
        self.entry_id = group_id
        self.action_buckets = buckets

    def __repr__(self):
        return "{}({})<{}>[{}]".format(self.name, self.group_type, self.entry_id, self.action_buckets)

    @property
    def dict(self):
        dictionary = defaultdict(None)

        others = {'Name':self.name, 'Node':self.node, 'ID':self.entry_id, 'Type':self.group_type, 'Buckets':self.action_buckets}

        for key, value in others.items():
            dictionary[key] = value

        return dictionary


class CompactedGroupBucketEntry:
    def __init__(self, watch_port=None, watch_group=None, output=None, group=None, pushvlan=False, setvlanvid=None, setvlanpcp=None, popvlan=False, queue=None):
        self.watch_port = watch_port
        self.watch_group = watch_group
        self.output = output
        self.group = group
        self.pushvlan = pushvlan
        self.popvlan = popvlan
        self.setvlanvid = setvlanvid
        self.setvlanpcp = setvlanpcp
        self.queue = queue

    def __repr__(self):
        return str(self.dict)

    def convert(self):
        new_action_bucket = ActionBucket(watch_port=self.watch_port, watch_group=watch_group)

    @property
    def dict(self):
        dictionary = defaultdict(None)

        others = {'Watch Port':self.watch_port, 'Watch Group':self.watch_group, 'Output':self.output,
                'Group':self.group, 'PushVlan':self.pushvlan, 'SetVlanVid':self.setvlanvid, 'SetVlanPcp':self.setvlanpcp,
                'PopVlan':self.popvlan, 'SetQueue':self.queue}

        for key, value in others.items():
            dictionary[key] = value

        return dictionary
