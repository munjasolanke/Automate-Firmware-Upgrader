from collections import defaultdict

class CompactedFlowEntry:
    def __init__(self, node, entry_type, entry_id=None, name=None, table=0, priority=1000, inport=None, code=None, ethdst=None, ethtype=None, vlanvid=None, vlanvid_mask=None, vlanpcp=None, ipsrc=None, ipsrc_mask=None, ipdst=None, ipdst_mask=None, tu_src=None, tu_dst=None, output=None, group=None, queue=None, popvlan=False, pushvlan=False, setvlanvid=None, setvlanpcp=None, gototable=None, meter=None):
        if group and output:
            raise ValueError("Must be output or group, not both!")

        self.name = name
        self.node = node
        self.entry_type = entry_type
        self.table = table
        self.priority = priority
        self.ethdst = ethdst
        self.vlanvid = vlanvid
        self.vlanvid_mask = "Present" if vlanvid == "Present" and not vlanvid_mask else vlanvid_mask
        self.vlanpcp = vlanpcp
        self.inport = inport
        self.ipsrc = ipsrc
        self.ipsrc_mask = ipsrc_mask
        self.ipdst = ipdst
        self.ipdst_mask = ipdst_mask
        self.tu_src = tu_src
        self.tu_dst = tu_dst
        self.output = output
        self.group = group
        self.queue = queue
        self.setvlanpcp = setvlanpcp
        self.pushvlan = None if not pushvlan else pushvlan
        self.setvlanvid = setvlanvid
        self.gototable = gototable
        self.ethtype = ethtype
        self.popvlan = None if not popvlan else popvlan
        self.entry_id = entry_id
        self.code = code
        self.meter = meter

    def __repr__(self):
        base = "{}@{}:{}<{} {}>".format(self.name, self.node, self.entry_type, self.table, self.priority)
        if self.inport:
            base += "+InPort {}".format(self.inport)
        if self.ipsrc:
            mask_value = "" if not self.ipsrc_mask else "/{}".format(self.ipsrc_mask)
            base += "+IpSrc {}{}".format(self.ipsrc, mask_value)
        if self.ipdst:
            mask_value = "" if not self.ipdst_mask else "/{}".format(self.ipdst_mask)
            base += "+IpSrc {}{}".format(self.ipdst, mask_value)
        if self.tu_src:
            base += "+TUSrc {}".format(self.tu_src)
        if self.tu_dst:
            base += "+TUDst {}".format(self.tu_dst)
        if self.group is not None or self.group is not '':
            base += "+G {}".format(self.group)
        if self.output:
            base += "+O {}".format(self.output)
        return base

    @property
    def dict(self):
        dictionary = defaultdict(str)

        others = {'Name':self.name, 'Node':self.node, 'Type':self.entry_type, 'Table':self.table, 'Priority':self.priority, 'Code':self.code,
                    'InPort': self.inport, 'EthType': self.ethtype, 'VlanVid':self.vlanvid, 'VlanPcp':self.vlanpcp, 'EthDst':self.ethdst, 'IpSrc':self.ipsrc, 'IpSrcMask':self.ipsrc_mask, 
                    'IpDst':self.ipdst,'IpDstMask':self.ipdst_mask, 'TUPortSrc':self.tu_src, 'TUPortDst':self.tu_dst,
                    'Output':self.output, 'Group':self.group, 'SetQueue':self.queue, 'VlanVidMask':self.vlanvid_mask,
                    'SetVlanPcp':self.setvlanpcp, 'SetVlanVid': self.setvlanvid, 'PushVlan': self.pushvlan, 'PopVlan': self.popvlan,
                    'GotoTable': self.gototable, 'Meter':self.meter}

        for key, value in others.items():
            dictionary[key] = value

        return dictionary
