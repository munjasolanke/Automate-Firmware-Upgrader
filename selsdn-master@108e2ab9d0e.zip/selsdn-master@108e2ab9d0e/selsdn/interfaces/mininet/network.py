from time import sleep

from ...automation.device import SEL2740SDevice, TraditionalSwitchDevice
from ...automation.port import Port
from ..rest.exceptions import BadRequestError, NotFoundError
from ._export import TopologyGenerator
from . import LOGGER

def export_topology(file_name, node_entries, application_entries=None, networks=None, add_arp=True):
    generator = TopologyGenerator(node_entries, application_entries, networks=networks, add_arp=add_arp)
    generator.export_json(file_name)

def adopt_network(node_entries, session, failover_mode=True, filter_connected=True, add_traditional_switches=False):
    if filter_connected:
        node_entries = node_entries.is_connected()

    session.synchronize_all_nodes()
    operational_nodes = session.get_operational_nodes()

    switch_nodes = list()
    traditional_nodes = list()
    host_nodes = dict()
    ports_needing_traditional_switches = list()

    for node_entry in node_entries:
        if isinstance(node_entry, SEL2740SDevice):
            switch_nodes.append(node_entry)
        elif isinstance(node_entry, TraditionalSwitchDevice):
            traditional_nodes.append(node_entry)
            ports_needing_traditional_switches.append(node_entry.ports[0].end)
        else:
            for port in node_entry.ports:
                host_nodes[str(port.ip_address)] = port

    for node in operational_nodes:
        if node["state"] != "Unadopted":
            continue

        datapath_id = None
        ip_address = None

        for attribute in node['attributes']:
            if '@odata.type' in attribute and "OpenFlowAttr" in attribute['@odata.type']:
                datapath_id = attribute["dataPathId"]

            if '@odata.type' in attribute and "IpAttr" in attribute['@odata.type']:
                ip_address = attribute["ipAddress"]

        object_id = node["id"]
        if datapath_id:
            converted_datapath_id = hex(datapath_id)[2:].zfill(16).lower()

            if node_entries.has_datapath_id(converted_datapath_id):
                node_object = node_entries.has_datapath_id(converted_datapath_id)[0]
                response = session.adopt_node_by_name(object_id=object_id, configuration_object_name=node_object.print_name)
                if add_traditional_switches:
                    for port in ports_needing_traditional_switches:
                        if port.owner == node_object:
                            session.add_traditional_switch(port.owner.print_name, port.name, port.end.owner.print_name)

            elif node_entries.has_mac_address(converted_datapath_id[:12]):
                response = session.adopt_node_by_name(object_id=object_id, configuration_object_name=node_entries.has_mac_address(converted_datapath_id[:12])[0].print_name)
            else:
                response = session.adopt_node_by_name(object_id=object_id, configuration_object_name=switch_nodes[datapath_id-1-2199023255552].print_name)
            sleep(3)
        elif ip_address:
            if host_nodes.get(str(ip_address)):
                node_object = host_nodes[str(ip_address)]
                response = session.adopt_node_by_name(object_id=object_id, configuration_object_name=session.get_names_from_objects(node_object))

                if failover_mode and response:
                    if node_object.mode == "Failover":
                        port_object = session.get_operational_port(object_id=node["ports"][0])
                        if port_object:
                            session.enable_relay_failover(port_object["id"])

                if response is False:
                    LOGGER.error("Unable to adopt port {}".format(node_object.print_name))
            else:
                LOGGER.warning("Unable to find ip address {}, are you using the right sheets?".format(ip_address))
        else:
            LOGGER.warning("Skipping node {}".format(node))

    # adopt all of links
    opertional_links = session.get_operational_links()
    for link in opertional_links:
        object_id = link["id"]
        if link["state"] == "Unadopted":
            try:
                sleep(.15)
                response = session.adopt_operational_link_with_default(object_id=object_id)
            except (BadRequestError, NotFoundError):
                pass
                #LOGGER.error("Problem adopting link {}".format(object_id))
