#!/usr/bin/python
import re

from mininet.nodelib import LinuxBridge
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import Host, Switch
from mininet.log import setLogLevel
from mininet.cli import CLI

from ...automation.device import SEL2740SDevice

IDENTIFIER_FAILOVER_DEVICE = "r"

class MininetInterface(Topo):
    def __init__(self):
        self._name_to_id = dict()
        self._id_to_name = dict()

    def get_node_identifer_and_index(self, node):
        ident, index = node[0], node[1:]
        return ident, self._clean_name(index)

    def get_node_default_octets(self, node):
        o1 = 0
        o2 = 0
        index = node[1:]
        if "p" in index:
            pre, post = index.split("p")
            o1 = int(pre)
            o2 = int(post)
        elif len(index) > 2:
            o1 = int(index[:1])
            o2 = int(index[1:])
        else:
            o2 = int(index)

        return o1, o2

    def is_relay_failover_node(self, identifier):
        return identifier.lower() == IDENTIFIER_FAILOVER_DEVICE

    def add_link(self, node1, node2, port1=None, port2=None, key=None, **opts):
        def update_node(node, port):
            if node[0].lower() == IDENTIFIER_FAILOVER_DEVICE:
                identifier, index = self.get_node_identifer_and_index(node)
                node = "sr{}".format(index)
                port = None
            return node, port

        node1, port1 = update_node(node1, port1)
        node2, port2 = update_node(node2, port2)

        self.addLink(self._clean_name(node1), self._clean_name(node2), port1, port2, key, **opts)

    def add_host(self, name, ip=None, mac=None, program=None):
        identifier, index = self.get_node_identifer_and_index(name)
        if self.is_relay_failover_node(identifier):
            self.add_relay_failover_device("r1", ip=ip, mac=mac, program=program)
        else:
            self._add_host(name, ip=ip, mac=mac, program=program)

    def _add_host(self, name, ip=None, mac=None, program=None):
        def setup_host(h):
            h.setIP(h.params["ip"])
            if "mac" in h.params and h.params["mac"] is not None:
                h.setMAC(h.params["mac"])

            if h.params["program"] is not None:
                h.cmd(h.params["program"])

        o1, o2 = self.get_node_default_octets(name)
        if mac is None:
            mac = "00:02:00:00:{:02d}{:02d}".format(int(o1), int(o2))
        if ip is None:
            ip = "10.88.{}.{}".format(int(o1), int(o2))
        self.addHost(self._clean_name(name), ip=ip, mac=mac, program=program, setup=setup_host)

    def _clean_name(self, name):
        new_name = re.sub('\.', '', name)
        return new_name

    def add_switch(self, switch_object):
        switch_name = switch_object.name
        datapath_id = switch_object.datapath_id
        
        def switch_setup(s):
            subprocess.call(["sudo", "ovs-vsctl", "set-controller", s.name, self.controller_info])

        if not datapath_id:
            o1, o2 = self.get_node_default_octets(name)
            datapath_id = "000000000000{:02d}{:02d}".format(int(o1), int(o2))

        self.addSwitch(name,
                       setup=switch_setup,
                       dpid=datapath_id,
                       protocols='OpenFlow13')

    def add_relay_failover_device(self, host_name, ip=None, mac=None, program=""):
        identifier, index = self.get_node_identifer_and_index(host_name)
        switch_name = "sr{}".format(index)

        def switch_setup(s):
            Switch.flip_flop = s.params["flip_flop"]
            s.cmd("sysctl -w net.ipv6.conf.all.disable_ipv6=1")
            s.cmd("sysctl -w net.ipv6.conf.default.disable_ipv6=1")
            s.cmd("sysctl -w net.ipv6.conf.lo.disable_ipv6=1")

            s.fail_mode = False
            subprocess.call(["sudo", "ovs-vsctl", "del-controller", switch_name])
            subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "add-group", switch_name, "group_id=1,type=ff"])
            subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "mod-group", switch_name,
                             "group_id=1,type=ff,bucket=watch_port:2,actions=output:2,bucket=watch_port:3,actions=output:3"])
            subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "add-group", switch_name, "group_id=3,type=ff"])
            subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "mod-group", switch_name,
                             "group_id=3,type=ff,bucket=watch_port:2,actions=drop,bucket=watch_port:1,actions=output:1"])
            subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "add-group", switch_name, "group_id=2,type=ff"])
            subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "mod-group", switch_name,
                             "group_id=2,type=ff,bucket=watch_port:1,actions=output:1"])
            subprocess.call(
                ["sudo", "ovs-ofctl", "-O", "OpenFlow13", "add-flow", switch_name, "in_port=1,actions=group:1"])
            subprocess.call(
                ["sudo", "ovs-ofctl", "-O", "OpenFlow13", "add-flow", switch_name, "in_port=2,actions=group:2"])
            subprocess.call(
                ["sudo", "ovs-ofctl", "-O", "OpenFlow13", "add-flow", switch_name, "in_port=3,actions=group:3"])

        def flip_flop(s):
            if s.fail_mode:
                subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "mod-group", s.name,
                                 "group_id=1,type=ff,bucket=watch_port:2,actions=output:2,bucket=watch_port:3,actions=output:3"])
            else:
                subprocess.call(["sudo", "ovs-ofctl", "-O", "OpenFlow13", "mod-group", s.name,
                                 "group_id=1,type=ff,bucket=watch_port:3,actions=output:3,bucket=watch_port:2,actions=output:2"])
            s.fail_mode = not s.fail_mode

        o1, o2 = self.get_node_default_octets(host_name)
        self.addSwitch(switch_name, is_relay_failover_special_device=True,
                       dpid="00000badf00d{:02d}{:02d}".format(int(o1), int(o2)),
                       setup=switch_setup,
                       protocols='OpenFlow13',
                       flip_flop=flip_flop)

        self._add_host(host_name, ip=ip, mac=mac, program=program)
        self.addLink(self._clean_name(host_name), switch_name, port1=1, port2=1)

    def build(self, node_entries):
        for node_entry in node_entries:
            if isinstance(node_entry, SEL2740SDevice):
                self.add_switch(node_entry)
            else:
                self.add_host(node_entry)

        raise

        for switch in self._definition["switches"]:
            self.add_switch(switch)

        for host in self._definition["hosts"]:
            id = ""
            mac = host.get("mac", None)
            mac = mac if mac else None
            if "type" in host and host["type"] == "relay-failover":
                id = "r" + host["id"][1:]
                self.add_relay_failover_device(id, ip=host["ip"], mac=mac)
            else:
                id = host["id"]
                self.add_host(host["id"], ip=host["ip"], mac=mac)

            if "links" in host:
                for link in host["links"]:
                    sw, port = link.split("~")
                    self.add_link(id, sw, 1, int(port))

        for link in self._definition["links"]:
            h1, port1 = link[0].split("~")
            h2, port2 = link[1].split("~")

            self.add_link(h1, h2, int(port1), int(port2))

    def create_network(self, node_entries):
        return self.build(node_entries)

    def test_applications(self, application_entries):
        for application_entry in application_entries:
            raise
