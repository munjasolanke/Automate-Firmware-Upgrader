from json import dumps
from collections import defaultdict

from ...automation import DEVICE_PORT_SEPARATOR
from ...automation.device import SEL2740SDevice, OpenFlowDevice, Device, TwoMacDevice, TraditionalSwitchDevice, EndDevice, RouterDevice
from ...automation.port import Port
from ...automation.application import UnicastApplication
from ...automation.protocol import TUProtocol, Ipv4Protocol, ArpProtocol
from ...openflow.core.match_fields import EthMatch, EthTypeMatch
from ...automation.packet import form_packet_from_application

from . import LOGGER

class TopologyGenerator:
    def __init__(self, node_entries, application_entries, networks=None, add_arp=True):
        self.current_switch = 1
        self.current_traditional_switch = 1
        self.current_node = 1
        self.current_port = 1
        self.current_application_id = 0
        self.add_arp = add_arp

        node_entries = node_entries.is_connected()
        if networks:
            node_entries = node_entries.has_type(SEL2740SDevice).is_in_networks(networks).values + node_entries.has_type(TraditionalSwitchDevice).is_in_networks(networks).values + node_entries.has_type(EndDevice).is_in_networks(networks).ports_in_networks(networks).values
            if application_entries:
                application_entries = application_entries.is_in_networks(networks)
        self.node_entries = node_entries

        self.application_entries = application_entries if isinstance(application_entries, list) else list()
        self.networks = networks

        self.switches = list()
        self.ports = list()
        self.nodes = list()

        self.switch_ids = dict()
        self.host_ids = dict()
        self.port_ids = dict()
        self.device_ids = dict()

        self.generate_ids()
        self.generate_json_objects()
        self.generate_applications()

    def generate_port_id(self, port):
        if port.is_connected():
            port_id = self.get_next_port()
            self.port_ids[self.get_device_string(port)] = port_id
        else:
            LOGGER.warning("Skipping port {} because it is not connected".format(self.get_device_string(port)))

    def generate_ids(self):
        # First store the information of everything and create the mininet ID
        for node in self.node_entries:
            if not node.is_connected():
                LOGGER.warning("Skipping node {} because none of its ports are connected".format(node.print_name))
                continue
            # Port objects
            if isinstance(node, Port):
                if node.end:
                    if (self.networks and node.is_in_networks(self.networks)) or not self.networks:
                        self.port_ids[self.get_device_string(node)] = self.get_next_port()
                        if not self.host_ids.get(node.owner.name):
                            self.host_ids[node.owner.name] = self.get_next_node()
                    else:
                        print("Port {} is not in networks {} only networks".format(node, self.networks, node.networks))
                        LOGGER.info("Skipping port {} because it is not in network {}".format(self.get_device_string(port), self.networks))
                else:
                    LOGGER.info("Skipping port {} because it is not connected".format(self.get_device_string(port)))
            # SEL2740SDevice objects
            elif isinstance(node, SEL2740SDevice):
                switch_name = self.get_next_switch()
                self.switch_ids[node.name] = switch_name
                for port in node.ports + node.local_ports:
                    self.generate_port_id(port)
            # TraditionalSwitchDevice objects
            elif isinstance(node, TraditionalSwitchDevice):
                switch_name = self.get_next_traditional_switch()
                self.switch_ids[node.name] = switch_name
                for port in node.ports:
                    self.generate_port_id(port)
            # EndDevice Types
            elif isinstance(node, EndDevice) or isinstance(node, RouterDevice):
                if not self.host_ids.get(node.name):
                    self.host_ids[node.name] = self.get_next_node()
                mac_addresses = list()
                for port in node.ports:
                    self.generate_port_id(port)
            else:
                raise TypeError("Unknown object type {}".format(node))

    def create_switch_json(self, switch_object, switch_id):
        new_switch_dict = dict()
        new_switch_dict["name"] = switch_object.print_name
        new_switch_dict["id"] = switch_id
        new_switch_dict["type"] = switch_object.__class__.__name__.replace("Device", "")
        new_switch_dict["ports"] = list()
        return new_switch_dict

    def generate_json_objects(self):
        ports_added = list()

        for item in self.node_entries:
            LOGGER.info("Creating json object for {}".format(item))
            if not item.is_connected():
                continue

            # Now switches have their own objects instead of just an id
            if isinstance(item, OpenFlowDevice):
                switch_id = self.switch_ids[item.name]
                switch_dict = self.create_switch_json(item, switch_id)
                self.switches.append(switch_dict)
                for port in item.ports + item.local_ports:
                    if port.is_connected():
                        new_port_dict = self.create_port_json(port, owner_id=switch_id)
                        new_port_dict["number"] = int(port.name)
                        switch_dict["ports"].append(new_port_dict)

            elif isinstance(item, TraditionalSwitchDevice):
                switch_id = self.switch_ids[item.name]
                switch_dict = self.create_switch_json(item, switch_id)
                self.switches.append(switch_dict)
                for index, port in enumerate(item.ports):
                    if port.is_connected():
                        new_port_dict = self.create_port_json(port, owner_id=switch_id)
                        new_port_dict["number"] = int(index) + 1
                        switch_dict["ports"].append(new_port_dict)

            elif isinstance(item, RouterDevice):
                new_host_dict = self.create_device_json(item)
                self.nodes.append(new_host_dict)

                for port in item.ports:
                    if port.end:
                        new_port_dict = self.create_port_json(port)
                        new_host_dict['ports'].append(new_port_dict)

            elif isinstance(item, Port):
                if not item.end:
                    print(item, "not connected")
                    continue

                print(self.networks, item.is_in_networks(self.networks), item.networks, item)

                if self.networks and not item.is_in_networks(self.networks):
                    print("wrong network for {} because in {} not {}".format(item, item.networks, self.networks))
                    continue

                #if (item.mode == "Failover" or isinstance(item.owner, RouterDevice)) and item.owner in ports_added:
                #    print("skipping", item)
                #    continue
                owner_node = item.owner.name
                owner_dict = None
                for node_dict in self.nodes:
                    if node_dict['name'] == owner_node:
                        owner_dict = node_dict
                        break
                else:
                    new_host_dict = self.create_device_json(item.owner)
                    self.nodes.append(new_host_dict)
                    owner_dict = new_host_dict

                new_port_dict = self.create_port_json(item)
                owner_dict['ports'].append(new_port_dict)

            # Other devices
            elif len(item.ports) == 2 and item.ports[0].mode == "Failover":
                new_host_dict = self.create_device_json(item)
                self.nodes.append(new_host_dict)

                if item.ports[0].is_connected():
                    port = item.ports[0]
                    new_port_dict = self.create_port_json(port)
                    port_name = self.get_device_string(port)
                    port_id = self.port_ids[port_name]
                    first_port, second_port = item.ports[0], item.ports[1]
                    new_host_dict['ports'].append(new_port_dict)

                if item.ports[1].is_connected():
                    port = item.ports[1]
                    new_port_dict = self.create_port_json(port)
                    port_name = self.get_device_string(port)
                    port_id = self.port_ids[port_name]

                    new_host_dict['ports'].append(new_port_dict)
                else:
                    LOGGER.info("Skipping {} because not connected".format(item))
            else:
                new_host_dict = self.create_device_json(item)
                self.nodes.append(new_host_dict)
                for port in item.ports:
                    if port.end and (not self.networks or port.is_in_networks(self.networks)):
                        new_port_dict = self.create_port_json(port)
                        new_host_dict['ports'].append(new_port_dict)

    def get_next_traditional_switch(self):
        new_id = "t" + str(self.current_traditional_switch)
        self.current_traditional_switch += 1
        return new_id

    def get_next_switch(self):
        new_id = "s" + str(self.current_switch)
        self.current_switch += 1
        return new_id

    def get_next_node(self):
        new_id = "h" + str(self.current_node)
        self.current_node += 1
        return new_id

    def get_next_port(self):
        new_id = "p" + str(self.current_port)
        self.current_port += 1
        return new_id       

    def get_next_application_id(self):
        self.current_application_id += 1
        return self.current_application_id

    def int_to_mac_address(self, value):
        if type(value) is int:
            raw_string = hex(value)[2:].zfill(12)
        elif isinstance(value, EthMatch):
            raw_string = value.value
        else:
            raw_string = value
        return raw_string[0:2] + ":" + raw_string[2:4] + ":" + raw_string[4:6] + ":" + raw_string[6:8] + ":" + raw_string[8:10] + ":" + raw_string[10:12]

    def create_port_json(self, item, owner_id=None):
        LOGGER.info("Creating port for {}".format(item))
        port_name = self.get_device_string(item)
        port_id = self.port_ids[port_name]

        new_port_dict = dict()
        new_port_dict['id'] = port_id
        new_port_dict['name'] = port_name
        new_port_dict["ip"] = '' if not item.ip_address else item.ip_address
        if isinstance(item.owner, SEL2740SDevice):
            if item not in item.owner.local_ports:
                new_port_dict["mac"] = None
                other_end_id = self.port_ids[self.get_device_string(item.end)]
            elif item in item.owner.local_ports and owner_id:
                owner_number = int(owner_id[1:])
                new_port_dict["mac"] = self.int_to_mac_address(owner_number+0x020000000000) if not item.mac_address else item.mac_address
                other_end_id = None
            else:
                raise
        else:
            new_port_dict["mac"] = self.int_to_mac_address(int(port_id[1:])*2-1+0x040000000000) if not item.mac_address else item.mac_address
            if self.port_ids.get(item.end.print_name):
                other_end_id = self.port_ids[item.end.print_name]
            else:
                raise ValueError("Cannot find {} in the port list".format(item.end.print_name))

        new_port_dict["apps"] = list()
        new_port_dict["links"] = [other_end_id]
        new_port_dict["subnet"] = str(item.subnet)
        new_port_dict["network"] = item.network_address
        new_port_dict["gateway"] = item.default_gateway
        return new_port_dict

    def compute_device_type(self, item):
        if isinstance(item, RouterDevice):
            return 'router'
        elif item.mode == "Failover":
            return 'failover'
        else:
            return ''

    def create_device_json(self, item):
        host_id = self.host_ids[item.name]
        new_host_dict = dict()
        new_host_dict['id'] = host_id
        new_host_dict['name'] = item.name
        new_host_dict['type'] = self.compute_device_type(item)
        new_host_dict['ports'] = list()
        return new_host_dict

    def generate_json(self):
        return {"switches":self.switches, "hosts":self.nodes}#, "links":self.links}

    def filter_destinations_by_connected(self, destinations):
        return [destination for destination in destinations if self.find_host_by_name(destination)]

    def generate_applications(self):
        for application_entry in self.application_entries:
            application_name = application_entry.name
            source_name = self.get_device_string(application_entry.source)
            source_node_device, source_node_port = self.resolve_source(application_entry.source)
            if self.find_host_by_name(application_entry.source):
                destination_devices = self.filter_destinations_by_connected(application_entry.destinations)
                if not destination_devices:
                    LOGGER.warning("Skipping application {} because all destination devices were filtered out".format(application_entry))
                    continue
                destination_names = [self.get_device_string(destination) for destination in destination_devices if self.get_device_string(destination)]

                scapy_string = self.convert_match_fields_to_scapy(application_entry, direction="forward")
                app_dict = {"id":self.get_next_application_id(), "name":application_name, "source":source_name, "destinations":destination_names, "packets":list()}
                app_dict["packets"].append({"function": "forward", "packet":scapy_string})
                
                if application_entry.protocol.bidirectional:
                    scapy_string = self.convert_match_fields_to_scapy(application_entry.reverse(), direction="reverse")
                    app_dict["packets"].append({"function": "reverse", "packet":scapy_string})

                    if isinstance(application_entry.protocol, Ipv4Protocol) and self.add_arp:
                        scapy_string = self.convert_match_fields_to_scapy(application_entry.to_arp(), override_ethdst="ff:ff:ff:ff:ff:ff")
                        app_dict["packets"].append({"function": "ARP forward", "packet":scapy_string})

                        scapy_string = self.convert_match_fields_to_scapy(application_entry.reverse().to_arp())
                        app_dict["packets"].append({"function": "ARP reverse", "packet":scapy_string})

                host_index, port_index = self.find_host_index(source_name)
                if host_index is None:
                    LOGGER.warning("Skipping Application {} because source {} is not connected".format(application_entry, source_name))
                else:
                    (self.nodes+self.switches)[host_index]["ports"][port_index]["apps"].append(app_dict)
            else:
                LOGGER.warning("Skipping application {} because source {} is not present".format(application_entry, application_entry.source))

    def get_device_string(self, device):
        if isinstance(device, Port):
            return ":".join([device.owner.name, str(device.name)])
        elif isinstance(device, SEL2740SDevice):
            if device.is_connected():
                return ":".join([device.name, str(device.local_ports[0].name)])
        elif isinstance(device, Device):
            if device.is_connected():
                for port in device.ports:
                    if port.is_connected():
                        return ":".join([device.name, str(device.ports[0].name)])
        else:
            raise TypeError("Unknown type {}".format(type(device)))

    def resolve_source(self, source):
        if isinstance(source, Port):
            return source.owner.name, source.name
        else:
            return source.name, None

    def find_node_by_name(self, name):
        if isinstance(name, Device):
            return name

        if isinstance(name, Port):
            return name

        for node_entry in self.node_entries:
            if node_entry.name == name:
                return node_entry

    def find_host_by_name(self, name):
        if isinstance(name, Device) or isinstance(name, Port):
            name = self.get_device_string(name)

        if DEVICE_PORT_SEPARATOR in name:
            node_name, port_name = name.split(DEVICE_PORT_SEPARATOR)
        else:
            node_name, port_name = name, _

        for node in self.nodes + self.switches:
            if node["name"] == node_name:
                if port_name:
                    for port in node["ports"]:
                        if port["name"] == name:
                            return port
                else:
                    return node["ports"][0]
        else:
            LOGGER.error("Unable to find {}".format(name))

    def find_host_index(self, name):
        if isinstance(name, Device) or isinstance(name, Port):
            name = self.get_device_string(name)

        if DEVICE_PORT_SEPARATOR in name:
            node_name, port_name = name.split(DEVICE_PORT_SEPARATOR)

        for host_index, node in enumerate(self.nodes+self.switches):
            if node["name"] == node_name:
                for port_index, port in enumerate(node["ports"]):
                    if port["name"] == name:
                        return host_index, port_index
        else:
            return None, None

    def convert_match_fields_to_scapy(self, application_entry, override_ethdst=None, direction="forward"):
        match_fields = application_entry.protocol
        source_device = application_entry.source
        destination_devices = application_entry.destinations

        # Start building Scapy string
        scapy_string = "Ether("
        
        if override_ethdst:
            eth_dst = override_ethdst
        elif isinstance(application_entry.protocol, ArpProtocol) and direction == "forward":
            eth_dst = "ff:ff:ff:ff:ff:ff"
        elif match_fields.get("EthDst"):
            eth_dst = self.int_to_mac_address(match_fields.get("EthDst").value)
        else:
            eth_dst = None
        
        if eth_dst:
            scapy_string += "dst='{}',".format(eth_dst)
        elif isinstance(application_entry, UnicastApplication):
            node_entry = self.find_node_by_name(destination_devices[0])
            if node_entry.mac_address:
                scapy_string += "dst='{}',".format(self.int_to_mac_address(node_entry.mac_address))
            else:
                found_host = self.find_host_by_name(destination_devices[0])
                if found_host:
                    scapy_string += "dst='{}',".format(found_host["mac"])

        eth_src = match_fields.get("EthSrc")
        if eth_src:
            scapy_string += "src='{}',".format(self.int_to_mac_address(eth_src.value))
        else:
            node_entry = self.find_node_by_name(source_device)
            if node_entry.mac_address and isinstance(node_entry, TwoMacDevice) and match_fields.get("EthType") and match_fields.get("EthType") == EthTypeMatch("GOOSE"):
                scapy_string += "src='{}',".format(self.int_to_mac_address(node_entry.other_mac_address))
            elif node_entry.mac_address:
                scapy_string += "src='{}',".format(self.int_to_mac_address(node_entry.mac_address))
            else:
                found_host = self.find_host_by_name(source_device)
                if found_host is not None:
                    scapy_string += "src='{}',".format(found_host["mac"])

        eth_type = match_fields.get("EthType")
        if match_fields.get("VlanVid") or match_fields.get("VlanPcp"):
            scapy_string += "type={}".format(0x8100)
        elif eth_type:
                scapy_string += "type={}".format(eth_type.value)

        scapy_string += ")"

        if match_fields.get("VlanVid"):
            scapy_string += "/Dot1Q(vlan={},".format(match_fields.get("VlanVid"))

            if match_fields.get("VlanPcp"):
                scapy_string += "prio={},".format(match_fields.get("VlanPcp"))
            if eth_type:
                scapy_string += "type={},".format(eth_type.value)
            scapy_string += ")"

        if eth_type and eth_type.value == 0x800:
            scapy_string += "/IP("
            ip_src = match_fields.get("Ipv4Src")
            if ip_src:
                scapy_string += "src='{}',".format(ip_src)
            else:
                node_entry = self.find_node_by_name(source_device)
                if node_entry.ip_address:
                    scapy_string += "src='{}',".format(node_entry.ip_address)

            ip_dst = match_fields.get("Ipv4Dst")
            if ip_dst:
                scapy_string += "dst='{}',".format(ip_dst)
            elif len(destination_devices) == 1:
                node_entry = self.find_node_by_name(destination_devices[0])
                if node_entry.ip_address:
                    scapy_string += "dst='{}',".format(node_entry.ip_address)
            ip_proto = match_fields.get("IpProto")
            if ip_proto:
                scapy_string += "proto={}".format(ip_proto.value)
            scapy_string += ")"

            if ip_proto and ip_proto.value == 6:
                scapy_string += "/TCP("
                tcp_dst = match_fields.get("TcpDst")
                if tcp_dst:
                    scapy_string += "dport={},".format(tcp_dst.value)
                tcp_src = match_fields.get("TcpSrc")
                if tcp_src:
                    scapy_string += "sport={}".format(tcp_src.value)    
                scapy_string += ")"

            elif ip_proto and ip_proto.value == 17:
                scapy_string += "/UDP("
                udp_dst = match_fields.get("UdpDst")
                if udp_dst:
                    scapy_string += "dport={},".format(udp_dst.value)
                udp_src = match_fields.get("UdpSrc")
                if udp_src:
                    scapy_string += "sport={}".format(udp_src.value)
                scapy_string += ")"

        elif eth_type and eth_type.value == 0x806:
            scapy_string += "/ARP("
            arp_op = match_fields.get("ArpOp")
            if arp_op:
                scapy_string += "op={},".format(arp_op.value)
            arp_tpa = match_fields.get("ArpTpa")
            if arp_tpa:
                scapy_string += "pdst='{}',".format(arp_tpa)
            else:
                node_entry = self.find_node_by_name(destination_devices[0])
                if node_entry.ip_address:
                    scapy_string += "pdst='{}',".format(node_entry.ip_address)
            arp_spa = match_fields.get("ArpSpa")
            if arp_spa:
                scapy_string += "psrc='{}'".format(arp_spa)
            else:
                node_entry = self.find_node_by_name(source_device)
                if node_entry.ip_address:
                    scapy_string += "psrc='{}',".format(node_entry.ip_address)
            scapy_string += ")"

        return scapy_string

    def export_json(self, file_name):
        final_dict = self.generate_json()

        with open(file_name, "w") as f:
            f.write(dumps(final_dict, sort_keys=True, indent=4))

        return final_dict
