CONFIGURATION_NODES = "confignode_configtree_element"
CONFIGURATION_PORTS = "configport_configtree_element"
CONFIGURATION_FLOWS = "flow_configtree_element"
CONFIGURATION_CSTS = "communicationservicetype_configtree_element"
CONFIGURATION_LINKS = "configlink_configtree_element"
CONFIGURATION_GROUPS = "group_configtree_element"
CONFIGURATION_METERS = "meter_configtree_element"


OPERATIONAL_NODES = "operationalnetworknode_operationaltree_element"
OPERATIONAL_PORTS = "operationalnetworkport_operationaltree_element"
OPERATIONAL_LINKS = "operationalnetworklink_operationaltree_element"

SECURITY_USERS = "user_securitytree_element"

CERTIFICATES_PRIVATE_KEYS = "privatekeyinformation_certificatetree_element"
CERTIFICATES_CERTIFICATES = "certificateinformation_certificatetree_element"

SETTINGS_REST_SETTINGS = "restsettings_settingstree_element"
SETTINGS_COMMISSIONING = "commissioningstate_settingstree_element"

DATABASE_LOCATION_DEFAULT = r"C:/ProgramData/SEL/SEL-5056/database/database.db"

USAGE_POLICY_DEFAULT = "This system is for the use of authorized users only. Individuals using this system without authority, or in excess of their authority, are subject to having all their activities on this system monitored and recorded by system personnel. Anyone using this system expressly consents to such monitoring and is advised that if such monitoring reveals possible evidence of criminal activity, system personnel may provide the evidence of such monitoring to law enforcement officials."

COMMAND_GET = "GET"
COMMAND_POST = "POST"
COMMAND_DELETE = "DELETE"
COMMAND_PATCH = "PATCH"
COMMAND_PUT = "PUT"

PROPERTY_TYPE = "$type"
PROPERTY_NAME = "DisplayName"
PROPERTY_STATE = "State"
PROPERTY_ERROR_STATE = "errorState"
PROPERTY_ERRORS = "errors"
PROPERTY_SETQUEUE = "setQueue"
PROPERTY_ID = "Id"
PROPERTY_PARENT = "parentNode"
PROPERTY_LINKED = "LinkedKey"
PROPERTY_IP_ADDRESS = "ipAddress"
PROPERTY_MAC_ADDRESS = "macAddress"
PROPERTY_CONFIGURATIONS = "configurations"
PROPERTY_PORTS = "Ports"
PROPERTY_TAGS = "Tags"
PROPERTY_ATTRIBUTES = "Attributes"
PROPERTY_TRUST_STATE = "trustState"
PROPERTY_LINKS = "AttachedLinks"
PROPERTY_END_POINTS = "EndPoints"

SETTINGS_ISCOMMISSIONED = "IsCommissioned"
SETTINGS_USAGE_POLICY = "LoginBanner"
