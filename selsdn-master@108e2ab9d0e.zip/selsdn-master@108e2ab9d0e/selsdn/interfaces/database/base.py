from .constants import *
from ..rest import constants as REST_CONSTANTS
from . import constants as DATABASE_CONSTANTS
from ..rest.base import RestObject

PROPERTY_NAME_CONVERSION = dict()
database_constants = vars(DATABASE_CONSTANTS)
for var, value in vars(REST_CONSTANTS).items():
    if "PROPERTY_" in var:
        PROPERTY_NAME_CONVERSION[value] = database_constants[var]


class DatabaseObject(RestObject):
    pass


class SingleTreeDatabaseObject(DatabaseObject):
    OBJECT_TYPE = None

    def __init__(self, body, interface):
        super().__init__(interface)
        self._unsynchronized = False
        self._body = body

    # def get(self, value, default_value=None):
    #     if self._body.get(value, default_value):
    #         return getattr(self, value)
    #     elif PROPERTY_NAME_CONVERSION.get(value) and self._body.get(PROPERTY_NAME_CONVERSION[value]):
    #         return getattr(self, PROPERTY_NAME_CONVERSION[value])

    @property
    def body(self):
        return self._body

    @property
    def id(self):
        return self.body[PROPERTY_ID]

    @property
    def type(self):
        return self.body[PROPERTY_TYPE]

    @property
    def unsynchronized(self):
        return self._unsynchronized

    @property
    def name(self):
        return self.body.get(PROPERTY_NAME)
    
    @property
    def state(self):
        return self.body.get(PROPERTY_STATE)

    @property
    def tags(self):
        if self.body.get("Tags"):
            return self.body["Tags"]["$values"]
        else:
            return list()

    def __repr__(self):
        return self._body.__repr__()


class DualTreeDatabaseObject(DatabaseObject):
    CONFIG_TYPE = None
    OPERATIONAL_TYPE = None

    def __init__(self, config_body, operational_body, interface):
        super().__init__(interface)
        self._original_config_body = None
        self._original_operational_body = None
        self._config_body = config_body
        self._operational_body = operational_body

    @property
    def unsynchronized(self):
        return self._original_operational_body != self._operational_body or self._original_config_body != self._config_body

    @property
    def config_body(self):
        return self._config_body

    @property
    def operational_body(self):
        return self._operational_body

    @property
    def config_id(self):
        return self._config_body[PROPERTY_ID]

    @property
    def operational_id(self):
        return self._operational_body[PROPERTY_ID]

    def get_tags_by_type(self, name):
        return_value = list()
        for tag in self.config_body.get("tags", list()):
            if name in tag[PROPERTY_TYPE]:
                return_value.append(tag)

        return return_value

    def get_attributes_by_type(self, name):
        return_value = list()
        for tag in self.config_body.get("attributes", list()):
            if name in tag["@odata.type"]:
                return_value.append(tag)

        return return_value

    def add_tag_by_type(self, type, object_id, **kwargs):
        body = {PROPERTY_TYPE: '#Sel.Sel5056.Tags.{}'.format(type), "id": object_id}

        for name, value in kwargs.items():
            body[name] = value

    def synchronize(self):
        if self._original_operational_body != self._operational_body:
            raise

        if self._original_config_body != self._config_body:
            self.interface(object_type=self.CONFIG_TYPE, object_id=self.config_body["id"], body=self.config_body)


class GenericNodeDatabaseObject(SingleTreeDatabaseObject):
    @property
    def linked_key(self):
        return self.body[PROPERTY_LINKED]

    @property
    def display_name(self):
        return self.body[PROPERTY_NAME]

    @property
    def ports(self):
        raise
        return self.body[PROPERTY_PORTS]

    @property
    def state(self):
        return self.body[PROPERTY_STATE]

    @property
    def port_ids(self):
        if self.body[PROPERTY_PORTS]:
            return self.body[PROPERTY_PORTS]["$values"]
        else:
            return list()


class OperationalNodeDatabaseObject(GenericNodeDatabaseObject):
    @property
    def connected(self):
        return self.body[PROPERTY_STATE] == VALUE_ADOPTED

    @property
    def disconnected(self):
        return self.body[PROPERTY_STATE] == VALUE_DISCONNECTED

    @property
    def attributes(self):
        return self.body[PROPERTY_ATTRIBUTES]

    @property
    def trustState(self):
        return self.body[PROPERTY_TRUST_STATE]


class ConfigurationNodeDatabaseObject(GenericNodeDatabaseObject):
    @property
    def configurations(self):
        return self.body[PROPERTY_CONFIGURATIONS]


class GenericPortDatabaseObject(SingleTreeDatabaseObject):
    @property
    def link_ids(self):
        if self._body.get(PROPERTY_LINKS):
            return self._body[PROPERTY_LINKS]["$values"]
        else:
            return list()

    @property
    def display_name(self):
        return self.body[PROPERTY_NAME]

    @property
    def linked_key(self):
        return self.body[PROPERTY_LINKED]

    @property
    def parent_node(self):
        return self.body[PROPERTY_PARENT_NODE]

    @property
    def state(self):
        return self.body[PROPERTY_STATE] 


class OperationalPortDatabaseObject(GenericPortDatabaseObject):
    @property
    def attributes(self):
        return self.body[PROPERTY_ATTRIBUTES]

    @property
    def is_connected(self):
        return self.body[PROPERTY_IS_CONNECTED]

    @property
    def trustState(self):
        return self.body[PROPERTY_TRUST_STATE]


class ConfigurationPortDatabaseObject(GenericPortDatabaseObject):
    @property
    def configurations(self):
        return self.body[PROPERTY_CONFIGURATIONS]


class GenericLinkDatabaseObject(SingleTreeDatabaseObject):
    @property
    def linked_key(self):
        return self.body[PROPERTY_LINKED]


class ConfigurationLinkDatabaseObject(GenericLinkDatabaseObject):
    pass
