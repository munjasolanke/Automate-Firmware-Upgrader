from sqlite3 import connect, OperationalError
from json import dumps, loads
from random import randrange

from . import LOGGER
from .constants import *
from .base import *

from ...base.collection import NodeCollection
from ...base.values import Values

from ..rest.base import ConfigurationNodeObjectCollection, ConfigurationPortObjectCollection

from ...automation.device import EndDevice, ControllerDevice, OpenFlowDevice, TraditionalSwitchDevice
from ...automation.port import Port

from ..rest.interface import ControllerInterface
from ..rest import constants as REST_CONSTANTS

class IDCollection(Values):
    pass


class DatabaseInterface(ControllerInterface, name=None, url=None):
    def __init__(self, database_location=DATABASE_LOCATION_DEFAULT, caching=True):
        super().__init__(caching=caching)
        self._database_location = database_location

    @property
    def database_location(self):
        return self._database_location

    def get_data(self, value):
        value = self._convert_object_type_to_table_name(value)
        if self.raw_data.get(value):
            return self.raw_data[value]

    def get_objects_by_name(self, name):
        if name == CONFIGURATION_NODES:
            if self.raw_information[CONFIGURATION_NODES]:
                return self.raw_information[CONFIGURATION_NODES]
            else:
                config_node_jsons = self.get_json_from_table(CONFIGURATION_NODES)

    def get_database_version(self):
        results = self.execute_select_statement(["product_version"], "db_version")
        return results[0][0]

    def login(self):
        if not self.session:
            LOGGER.info("Connecting to database at {}".format(self.database_location))
            self._session = connect(self.database_location)

    def __enter__(self):
        self.login()
        return self

    def logout(self):
        if self.session:
            self.session.close()
            self._session = None

    def commit(self):
        if self.session:
            self.session.commit()
        else:
            raise

    def __exit__(self, exc_ty, exc_val, exc_tb):
        self.logout()

    def vacuum(self):
        return self.session.execute('VACUUM')

    def _convert_object_type_to_table_name(self, object_type):
        if object_type[0] == "/":
            if object_type == REST_CONSTANTS.OPERATIONAL_NODES:
                return OPERATIONAL_NODES
            elif object_type == REST_CONSTANTS.CONFIGURATION_NODES:
                return CONFIGURATION_NODES
            elif object_type == REST_CONSTANTS.CONFIGURATION_PORTS:
                return CONFIGURATION_PORTS
            elif object_type == REST_CONSTANTS.OPERATIONAL_PORTS:
                return OPERATIONAL_PORTS
            elif object_type == REST_CONSTANTS.CONFIGURATION_PORTS:
                return CONFIGURATION_PORTS
            elif object_type == REST_CONSTANTS.CONFIGURATION_FLOWS:
                return CONFIGURATION_FLOWS
            elif object_type == REST_CONSTANTS.CONFIGURATION_LINKS:
                return CONFIGURATION_LINKS
            elif object_type == REST_CONSTANTS.OPERATIONAL_LINKS:
                return OPERATIONAL_LINKS
            else:
                raise ValueError("Not sure how to convert from {} to database name".format(object_type))
        else:
            return object_type

    def get_wrap_object_from_url(self, object_type):
        if object_type == REST_CONSTANTS.CONFIGURATION_NODES:
            return ConfigurationNodeDatabaseObject
        elif object_type == REST_CONSTANTS.OPERATIONAL_NODES:
            return OperationalNodeDatabaseObject
        elif object_type == REST_CONSTANTS.CONFIGURATION_PORTS:
            return ConfigurationPortDatabaseObject
        elif object_type == REST_CONSTANTS.OPERATIONAL_PORTS:
            return OperationalPortDatabaseObject
        elif object_type == REST_CONSTANTS.CONFIGURATION_LINKS:
            return ConfigurationLinkDatabaseObject
        elif object_type == REST_CONSTANTS.OPERATIONAL_LINKS:
            return OperationalLinkDatabaseObject
        else:
            raise ValueError("Unable to find wrap object for object type {}".format(object_type))

    def execute_select_statement(self, keys, table_name, where=None, number_to_fetch=True):
        table_name = self._convert_object_type_to_table_name(table_name)
        statement = "SELECT {} FROM {}".format(",".join(keys), table_name)
        if where:
            statement += " WHERE " + " AND ".join(where)

        results = self.execute_statement(statement)
        if number_to_fetch is True:
            return results.fetchall()
        else:
            raise

    def _get_cursor(self):
        self.login()
        return self.session.cursor()

    def execute_statement(self, statement, row=None):
        if not row:
            row = dict()

        #statement = statement.format(",".join(row.keys()), ",".join(["?" for key in tuple(row.keys())]))
        LOGGER.info("Executing statement '{}'".format(statement))
        try:
            cur = self._get_cursor()
            results = cur.execute(statement, tuple(row.values()))
        except OperationalError as e:
            # TODO check if the file exists, if it does, probably administrator problem
            raise ValueError("Either I can't find the file or you are not running as Administrator")
        finally:
            self.commit()

        return results

    def get_table_values(self, table_name, items=None, status_id=1, deleted=0, object_id=None):
        where = self._combine_where_statements(list(), status_id=status_id, deleted=deleted, unique_id=object_id)
        return self.execute_select_statement(keys=items, table_name=table_name, where=where)

    def get_jsons_from_table(self, table_name, object_id=None, deleted=0, status_id=1):
        return IDCollection([loads(x[0]) for x in self.get_table_values(table_name, ["json"], object_id=object_id, deleted=deleted, status_id=status_id) if x[0]])

    # def _convert_dict(self, value):
    #     new_dict = {}
    #     for v_name, v_value in value.items():
    #         if v_name == "$type":
    #             v_name = "@odata.type"
    #             v_value = "#" + v_value.split(",")[0]
    #         else:
    #             v_name = v_name[0].lower()+v_name[1:]

    #         if isinstance(v_value, dict):
    #             if v_value.get("$values") is not None:
    #                 v_value = self._convert_list(v_value["$values"])

    #         new_dict[v_name] = v_value

    # def _convert_list(self, value):
    #     new_list = list()
    #     for v in value:
    #         new_v_dict = {}
    #         for v_name, v_value in v.items():
    #             if v_name == "$type":
    #                 v_name = "@odata.type"
    #                 v_value = "#" + v_value.split(",")[0]
    #             else:
    #                 v_name = v_name[0].lower() + v_name[1:]

    #             if isinstance(v_value, dict):
    #                 v_value = self._convert_dict(v_value)

    #             new_v_dict[v_name] = v_value
    #         new_list.append(new_v_dict)
    #     return new_list      

    # def _convert_object(self, object):
    #     new_dict = {}
    #     for name, value in object.items():
    #         if isinstance(value, dict) and value.get("$values") is not None:
    #             value = value["$values"]
    #         elif isinstance(value, dict):
    #             del(value["$type"])
            
    #         if isinstance(value, dict) and value.get("MatchFields") is not None:
    #             value["MatchFields"] = self._convert_list(value.get("MatchFields")["$values"])

    #         if isinstance(value, list) and len(value) and isinstance(value[0], dict):
    #             value = self._convert_list(value)

    #         elif name == "$type":
    #             name = "@odata.type"
    #             value = "#" + value.split(",")[0]
            
    #         new_dict[name[0].lower()+name[1:]] = value
        
    #     return new_dict

    def get_objects(self, url):
        if self.caching and self.get_cached_objects(url):
            return self.get_cached_objects(url)

        function = self.gets_function_from_url(url)
        objects = function()
        objects = self._get_wrapped_objects(object_type=url, objects=objects)

        if self.caching:
            self.set_cached_objects(url, objects)
        return objects

    def get_object(self, url, object_id, find_if_not_cached=False):
        if self.caching:
            if not self.get_cached_objects(url):
                self.get_objects(url)

            for value in self.get_cached_objects(url):
                if value.id == object_id:
                    return value

        if not self.caching or (self.caching and find_if_not_cached):
            function = self.get_function_from_url(url)
            try:
                response = function(object_id=object_id)
                response = self._get_wrapped_object(object_type=url, object=response)
            except NotFoundError as e:
                return None
            else:
                if self.caching and response:
                    self.add_cached_object(url, response)
                return response
        else:
            return None

    def make_simple_request(self, url, object_id=None, function=None, command=COMMAND_GET, check=True, *args, **kwargs):
        return self._make_simple_request(url, object_id, function, command, *args, **kwargs)

    def _make_simple_request(self, url, object_id=None, function=None, command=COMMAND_GET, parameters=None, headers=None, *args, **kwargs):
        if command == COMMAND_GET:
            url = self._convert_object_type_to_table_name(url)
            return self.get_jsons_from_table(table_name=url, object_id=object_id)
        else:
            raise ValueError("Not sure how to do command {}".format(command))

    def clear_history(self):
        tables = self.execute_select_statement(keys=["name"], table_name="sqlite_master", where=["type = 'table'"])
        for tbl in tables:
            name = tbl[0].__str__().replace("('", "").replace(",')", "")
            if name.endswith("element"):
                self._execute_delete_statement(table_name=name, where=["status_id <> 1"])
                self._execute_delete_statement(table_name=name, where=["deleted == 1"])

        self.vacuum()

    def delete_rows_from_table(self, table_name):
        self.execute_delete_statement(table_name, unique_id=None)

    def _format_where_statement(self, where):
        if where:
            return " WHERE " + " AND ".join(where)
        else:
            return ""

    def _combine_where_statements(self, where, unique_id=None, status_id=1, deleted=0):
        if not where and (unique_id is not None or status_id is not None or unique_id is not None):
            where = list()

        # TODO Need to check if these things are already there
        if status_id is not None:
            where.append("status_id = {}".format(status_id))
        if deleted is not None:
            where.append("deleted = {}".format(deleted))
        if unique_id is not None:
            where.append("unique_identifier = '{}'".format(unique_id))

        return where

    def execute_delete_statement(self, table_name, unique_id, status_id=1, deleted=0, where=None):
        table_name = self._convert_object_type_to_table_name(table_name)
        where = self._combine_where_statements(where, unique_id=unique_id, status_id=status_id, deleted=deleted)
        self._execute_delete_statement(table_name, where=where)

    def _execute_delete_statement(self, table_name, where=None):
        statement = "DELETE FROM {}".format(table_name) + self._format_where_statement(where)
        self.execute_statement(statement)

    def add_user(self, username, roles=None):
        # TODO check values here
        if not roles:
            roles = [
                "SecurityAdministrator",
                "PermissionLevel3",
                "Monitor"]

        body = {
            "$type": "Sel.BlueFrame.Core.SecurityManager.LocalUser, BlueFrameCore",
            "ClearTextPass": None,
            "CurrentSalt": {
                "$type": "System.Byte[], mscorlib",
                "$value": "xUQHKyvenNAQ2168eO8nizBARoj1LQsDLh56RTO5pVGAz2eBKasAJ5Ze/iNQN11Im5LeshgULtZdSbIQAwGA9aeztDPs+dXRjDJVVhApOMuCO6x9LUTUIeGFfZOwSfmZNcNp4DPJ+MzpFR+0TnjLUtcpk1+tSX/yA1tGLI8hw7fqGSdsmiYMs33VMXAikyHcX5qqXGFoWAVkw5VIQBrMsetNV9S6Jcij5vI4uZDoW5zN/wRHIogy3EnYX78Ox5v3Sp8zLx/MmW6kQAjEpeUkyNr9f6VVFsjgCNGIb1dCKrZ/ywtlia5FvHtsR/s8SxKHtwUVy/V0Lr9//dV/MvcekA=="
            },
            "DisplayName": username,
            "Enabled": True,
            "FailedLogins": {
                "$type": "System.Collections.Generic.List`1[[Sel.BlueFrame.Core.SecurityManager.UserFailedLogin, BlueFrameCore]], mscorlib",
                "$values": [
                ]
            },
            "Id": "a0278bcde86f14f3e9be4249023e2eb7",
            "IsLockedOut": False,
            "LastSuccessLoginIp": "127.0.0.1",
            "LastSuccessfulLogin": "2019-06-08T08:49:51.1741503-06:00",
            "LockedOutUntil": "0001-01-01T00:00:00",
            "LockoutTime": "0001-01-01T00:00:00",
            "Roles": {
                "$type": "System.Collections.Generic.List`1[[System.String, mscorlib]], mscorlib",
                "$values": [
                    roles
                ]
            },
            "SaltedHashPassword": {
                "$type": "System.Byte[], mscorlib",
                "$value": "LfUf8F0POAXdTm59psBMotXW9Zs="
            },
            "Username": username
        }

        row = {
            "unique_identifier": body["Id"],
            "version": 1,
            "create_timestamp": "2019-08-27 15:07:13.9968248",
            "deleted": 0,
            "role": None,
            "user": None,
            "module": "Security Manager",
            "json": dumps(body),
            "status_id": 1,
            "errors": None,
            "errorstate": 0,
            "username": "admin"
        }

        self.execute_insert_statement(table_name=SECURITY_USERS, row=row)

    def execute_insert_statement(self, table_name, row):
        table_name = self._convert_object_type_to_table_name(table_name)
        self._execute_insert_statement(table_name, row)

    def _execute_insert_statement(self, table_name, row):
        statement = "INSERT INTO {}({}) VALUES({})".format(table_name, "{}", "{}")
        statement = statement.format(",".join(row.keys()), ",".join(["?" for key in tuple(row.keys())]))
        self.execute_statement(statement, row=row)

    def get_flow_objects(self):
        return self.get_json_from_table(CONFIGURATION_FLOWS)

    def _format_set_clause(self, items):
        clause = list()
        for item_name, item_value in items.items():
            clause.append("{} = {}".format(item_name, "?"))

        return ", ".join(clause)

    def execute_update_statement(self, table_name, items, unique_id, status_id=1, deleted=0, where=None):
        table_name = self._convert_object_type_to_table_name(table_name)
        where = self._combine_where_statements(where, unique_id=unique_id, status_id=status_id, deleted=deleted)
        self._execute_update_statement(table_name=table_name, items=items, where=where)

    def _execute_update_statement(self, table_name, items, where=None):
        statement = "UPDATE {} SET {}".format(table_name, self._format_set_clause(items)) + self._format_where_statement(where)
        self.execute_statement(statement, row=items)

    def set_usage_policy(self, value=USAGE_POLICY_DEFAULT):
        self.change_single_setting(name=SETTINGS_USAGE_POLICY, value=value)

    def send_request(self, request, *args, **kwargs):
        return request

    def execute_json_update(self, table_name, body):
        value = dumps(body)
        self.execute_update_statement(table_name=table_name, items={"json": value}, unique_id=body["id"])

    def execute_json_single_setting_update(self, table_name, key, value, unique_id):
        body = self.get_jsons_from_table(table_name=table_name, object_id=unique_id)[0]
        body[key] = value
        self.execute_json_update(table_name=table_name, body=body)

    def change_single_setting(self, name, value):
        if name == SETTINGS_ISCOMMISSIONED:
            if value not in (True, False):
                raise ValueError("Setting {} must be True or False".format(name))
            self.execute_json_single_setting_update(table_name=SETTINGS_COMMISSIONING, key=SETTINGS_ISCOMMISSIONED, value=value, unique_id="Settings")
        elif name == SETTINGS_USAGE_POLICY:
            # TODO type check
            self.execute_json_single_setting_update(table_name=SETTINGS_REST_SETTINGS, key=SETTINGS_USAGE_POLICY, value=value, unique_id="Web")
        else:
            raise ValueError("Don't recognize setting {}".format(name))
