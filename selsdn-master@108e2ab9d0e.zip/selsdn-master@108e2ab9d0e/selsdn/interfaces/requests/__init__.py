from logging import getLogger

LOGGING_NAME = __name__
LOGGER = getLogger(LOGGING_NAME)

from .interface import RequestsInterface
