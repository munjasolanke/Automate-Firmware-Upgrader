import requests

from logging import getLogger

LOGGING_NAME = __name__
LOGGER = getLogger(LOGGING_NAME)

from ..rest.session import Session as RESTSession
from ..rest.commands import Response, ResponseHeaders, Body
from ..rest.constants import COMMAND_GET, COMMAND_POST, COMMAND_PATCH, COMMAND_PUT, COMMAND_DELETE


class Session(RESTSession):
    def set_timeout(self, timeout):
        self.socket_timeout = timeout

    @property
    def socket(self):
        return True

    def disconnect(self):
        pass

    def connect(self):
        pass

    def _full_url(self, url):
        return "https://{}:{}{}".format(self.host, self.port, url)

    def _send(self, data, relogin=True, check=True):
        url = self._full_url(data.url)
        body = data.body
        timeout = self.socket_timeout
        headers = data.headers.headers

        kwargs = {"url": url, "timeout": self.socket_timeout, "verify": False, "headers": headers}

        if data.command != COMMAND_GET and data.parameters and not data.body:
            body = data.parameters
        elif data.parameters:
            kwargs["params"] = data.parameters

        if data.command == COMMAND_GET:
            response = requests.get(**kwargs)
        elif data.command == COMMAND_POST:
            if headers and "json" in headers.get('Content-Type'):
                response = requests.post(json=body, **kwargs)
            else:
                response = requests.post(data=body, **kwargs)
        elif data.command == COMMAND_PATCH:
            response = requests.patch(data=body, **kwargs)
        elif data.command == COMMAND_PUT:
            response = requests.put(data=body, **kwargs)
        elif data.command == COMMAND_DELETE:
            response = requests.delete(**kwargs)

        if self.verbose:
            print("DATA Send")
            print(response.request.url)
            print(response.request.headers)
            body = response.request.body
            data_written = str(body)
            if body:
                print(str(data_written[:1000]).replace("\r\n", "\n"))
                if len(data_written) > 1050:
                    print("\nTruncated...Sent", len(data_written), "bytes of data, last 50 characters")
                    print(data_written[-50:].replace("\r\n", "\n"))
                print()
                print()
            else:
                print("No body")
                print()
                print()

        self._last_response = response

        return None

    def flush_response_buffer(self, size=4096):
        pass

    def receive(self, size=8192):
        last_response = self._last_response

        headers = ResponseHeaders(last_response.headers)
        code = last_response.status_code
        if headers.get_header("Content-Type") and 'application/json' in headers.get_header("Content-Type"):
            body = last_response.json()
        else:
            body = last_response.text
        
        if self.verbose:
            print("DATA Received")
            print(last_response.url, code)
            data_written = str(body)
            if body:
                print(str(data_written[:1000]).replace("\r\n", "\n"))
                if len(data_written) > 1050:
                    print("\nTruncated...Sent", len(data_written), "bytes of data, last 50 characters")
                    print(data_written[-50:].replace("\r\n", "\n"))
                print()
                print()
            else:
                print("No body")
                print()
                print()

        body = Body(body)
        response = Response(headers=headers, body=body, code=code)

        return response
