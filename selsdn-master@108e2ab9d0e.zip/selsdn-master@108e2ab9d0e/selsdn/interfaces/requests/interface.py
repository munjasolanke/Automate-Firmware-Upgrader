from .session import Session
from ..rest.interface import RESTInterface
from ..rest.constants import *

class RequestsInterface(RESTInterface, name=None, url=None):
    def __init__(self, username, password, role="PermissionLevel3", url="localhost", oauth_type=OAUTH_TYPE_USER, port=None, verbose=False, version_5056=None, caching=False, key_file=None, cert_file=None, auto_login=True, timeout=120):
        self._session = Session(url=url, verbose=verbose, role=role, port=port, version_5056=version_5056, username=username, password=password, oauth_type=oauth_type, key_file=key_file, cert_file=cert_file, auto_login=auto_login, timeout=timeout)
        self.verbose = verbose
        self._caching = caching
        self.id_to_display_name = {}
        self.id_to_value = {}
        self.name_to_id = {}
        self.get_responses = True
        self._start_cache(caching)
