"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions for converting OpenFlow group entries from selsdn to pyselflow and
vice versa.
"""

from pyselflow import config_tree

from .actions import actions_convert_to_pyselflow, actions_convert_from_pyselflow

from ...openflow.core.action_bucket import ActionBucket
from ...openflow.core.actions import DropAction
from ...openflow.core.group_entry import IndirectGroup, AllGroup, FastFailoverGroup, SelectGroup


def group_entries_convert_to_pyselflow(group_objects):
    """Converts internal GroupEntry objects to pyselflow group objects.

    Arguments:
        group_objects {object} -- lists internal GroupEntry objects

    Returns:
        {list} -- list of converted pyselflow group objects
    """
    return [group_entry_convert_to_pyselflow(group_object) for group_object in group_objects]


def group_entry_convert_to_pyselflow(group_entry):
    """Converts an internal GroupEntry object to a pyselflow group object.

    Arguments:
        group_entry {object} -- a selsdn GroupEntry object

    Returns:
        {object} -- converted pyselflow group object
    """
    buckets = list()
    for index, action_bucket in enumerate(group_entry.action_buckets):
        actions = actions_convert_to_pyselflow(action_bucket.actions)
        bucket = action_bucket_convert_to_pyselflow(action_bucket.watch_port,
                                                    action_bucket.watch_group,
                                                    actions)
        buckets.append(bucket)

    sel_group = config_tree.Group()
    sel_group.buckets = buckets
    sel_group.group_type = convert_group_type(group_entry)
    sel_group.group_id = group_entry.entry_id
    sel_group.enabled = True
    sel_group.node = group_entry.node if type(group_entry.node) is str else group_entry.node.name
    sel_group.display_name = group_entry.name

    return sel_group


def convert_group_type(group_entry):
    """Derive the config_tree.Group.group_type for a pyselflow group object
    from a GroupEntry object.

    Arguments:
        group_entry {object} -- a selsdn GroupEntry object

    Returns:
        {str} -- the Group Type of the entry
    """
    return group_entry.__class__.__name__.replace(' ', '')[:-5]


def action_bucket_convert_to_pyselflow(watch_port, watch_group, actions):
    """Creates a pyselflow action bucket.

    Arguments:
        watch_port {object} -- Watch Port of an action bucket
        watch_group {object} -- Watch Group of an action bucket
        actions {object} -- actions contained within a bucket

    Returns:
        {object} -- a pyselflow action bucket
    """
    bucket = config_tree.Bucket()
    bucket.watch_port = 'Any' if watch_port == 0xffffffff else str(watch_port)
    bucket.watch_group = 'Any' if watch_group == 0xffffffff else str(watch_group)
    if actions:
        bucket.actions = actions
    return bucket


def group_entries_convert_from_selflow(group_objects):
    """Converts pyselflow group objects to internal GroupEntry objects.

    Arguments:
        group_objects {list} -- list of pyselflow group objects

    Returns:
        {list}-- list of converted internal GroupEntry objects
    """
    return [group_entry_convert_from_pyselflow(group_entry) for group_entry in group_objects]


def group_entry_convert_from_selflow(group_object):
    """Converts a pyselflow group object to an internal GroupEntry object.
    Provides an error message to check unsupported group types.

    Arguments:
        group_object {object} -- a pyselflow group object

    Returns:
        {object} -- converted internal GroupEntry object
    """
    action_buckets = [action_bucket_convert_from_pyselflow(action_bucket) for action_bucket in group_object.buckets]

    if group_object.group_type == 'Indirect':
        group_class = IndirectGroup
    elif group_object.group_type == 'Select':
        group_class = SelectGroup
    elif group_object.group_type == 'All':
        group_class = AllGroup
    elif group_object.group_type == 'FastFailover':
        group_class = FastFailoverGroup
    else:
        raise TypeError("No such group type {}".format(group_object.group_type))

    return group_class(entry_id=group_object.group_id,
                       name=group_object.display_name,
                       node=group_object.node,
                       action_buckets=action_buckets)


def action_bucket_convert_from_pyselflow(action_bucket):
    """Converts a pyselflow action bucket to an internal ActionBucket object.

    Arguments:
        action_bucket {object} -- pyselflow action bucket object

    Returns:
        {object} -- converted internal ActionBucket object
    """
    if action_bucket.actions:
        actions = actions_convert_from_pyselflow(action_bucket.actions)
    else:
        actions = (DropAction(),)
    return ActionBucket(watch_group=action_bucket.watch_group,
                        watch_port=action_bucket.watch_port,
                        actions=actions)
