"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Init for PySelFlow. Provides the PySelFlow network class under the alias
PySelflowInterface.
"""

from .network import PyselflowNetwork as PyselflowInterface
