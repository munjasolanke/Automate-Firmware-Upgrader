"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Accessor for the pyselflow HttpSession object.
"""

from pyselflow._httpsession import HttpSession
import requests

# disable the insecure request warning
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


def create_session(username, password, url):
    """Returns a HttpSession object for calls to the REST interface through
    pyselflow.

    Arguments:
        username {str} -- controller username
        password {str} -- controller password
        url {str} -- location where controller is hosted

    Returns:
        {object} -- pyselflow session
    """
    return HttpSession.from_user_credentials("https://{}/".format(url),
                                             user=username,
                                             password=password,
                                             role='PermissionLevel3')
