"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions for converting OpenFlow meters from selsdn to pyselflow and vice
versa.
"""

from pyselflow import config_tree

from ...openflow.core.meter_entry import MeterEntry


def meter_entries_convert_to_pyselflow(meter_entries):
    """Disabled: DO NOT USE
    Converts a list of internal MeterEntry objects to pyselflow meter objects.
    """
    raise


def meter_entry_convert_to_pyselflow(meter_entry):
    """Disabled: DO NOT USE
    Converts an internal MeterEntry object to a pyselflow meter object.
    """
    raise


def meter_entries_convert_from_pyselflow(meter_entries):
    """Disabled: DO NOT USE
    Converts a list of pyselflow meter objects to internal MeterEntry objects.
    """
    raise


def meter_entry_convert_from_pyselflow(meter_entry):
    """Disabled: DO NOT USE
    Converts a pyselflow meter object to an internal MeterEntry object.
    """
    raise
