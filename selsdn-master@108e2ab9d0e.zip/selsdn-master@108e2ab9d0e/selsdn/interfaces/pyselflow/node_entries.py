"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions for managing selsdn node entries when using a pyselflow connection.
"""

from collections import defaultdict

from pyselflow import config_tree
from pyselflow import operational_tree

from ...automation.device import SEL2740SDevice, Device


def node_entries_convert_to_pyselflow(node_entries):
    """Converts list of internal Devices objects to pyselflow node objects.

    Arguments:
        node_entries {list} -- list of internal Device objects

    Returns:
        {list} -- the list of nodes, each converted to pyselflow format
    """
    return [node_entry_convert_to_pyselflow(node_entry) for node_entry in node_entries]


def node_entry_convert_to_pyselflow(node_entry):
    """Converts an internal Device object to a pyselflow node object.

    Arguments:
        node_entry {device} -- internal Device object

    Returns:
        {object} -- node_entry configured to pyselflow-readable format
    """
    if isinstance(node_entry, SEL2740SDevice):
        to_node = config_tree.Sel2740SConfigNode(display_name=node_entry.name,
                                                 ip_address=node_entry.ip_address,
                                                 subnet_mask=node_entry.subnet,
                                                 default_gateway=node_entry.default_gateway,
                                                 controller_ip=node_entry.controller_ip)
        if hasattr(to_node, "enable_ptp"):
            to_node.enable_ptp = node_entry.ptp_enable
            to_node.enable_snmp = node_entry.snmp_enable
    else:
        to_node = config_tree.ConfigNode(display_name=node_entry.name)

    return to_node


def node_entries_convert_from_pyselflow(node_entries):
    """Converts multiple nodes from pyselflow configuration to internal
    Device objects.

    Arguments:
        node_entries {list} -- nodes from controller accessed by pyselflow

    Returns:
        {list} -- list of nodes, each converted to selsdn entries if possible
    """
    converted_node_entries = list()
    for node_entry in node_entries:
        converted_node_entry = node_entry_convert_from_pyselflow(node_entry)
        if converted_node_entry:
            converted_node_entries.append(converted_node_entry)

    return converted_node_entries


def node_entry_convert_from_pyselflow(node_entry):
    """Converts a pyselflow node object to an internal Device object. If the
    node is a SEL-2740S switch, include the MAC and IP addresses, subnet mask,
    default gateway, controller IP and datapath ID.

    If the node is another type of device, require only its name. If it is an
    Operational Network Node, require its attributes. Raise an error for any
    other type of node.

    Arguments:
        node_entry {device} -- node in the controller accessed by pyselflow

    Returns:
        {object} -- node converted to selsdn node entry, return None if
            required properties not found
    """
    if isinstance(node_entry, config_tree.Sel2740SConfigNode):
        from_node = SEL2740SDevice(name=node_entry.display_name,
                                   mac_address=None,
                                   ip_address=node_entry.ip_address,
                                   subnet=node_entry.subnet_mask,
                                   default_gateway=node_entry.default_gateway,
                                   controller_ip=node_entry.controller_ip,
                                   datapath_id=None)
    elif isinstance(node_entry, config_tree.ConfigNode):
        if node_entry.display_name:
            from_node = Device(name=node_entry.display_name)
        else:
            return None
    elif isinstance(node_entry, operational_tree.OperationalNetworkNode):
        attributes = node_entry_convert_attributes_from_pyselflow(node_entry.attributes)
        if attributes:
            from_node = Device(name=node_entry.display_name, **attributes)
        else:
            return None
    else:
        raise TypeError("Unsupported node type {}".format(type(node_entry)))
    return from_node


def node_entry_convert_attributes_from_pyselflow(node_attributes):
    """Parse Ethernet, IPv4, and OpenFlow addressing information from a
    pyselflow node object. Raises an error if an unsupported type of attribute
    is found.

    Arguments:
        node_attributes {object} -- attributes of the Operational Network Node

    Returns:
        {dict} -- node_attributes converted to Python dictionary format
    """
    attributes = dict()

    for node_attribute in node_attributes:
        if isinstance(node_attribute, operational_tree.EthernetAttr):
            attributes['mac_address'] = node_attribute.mac_address
        elif isinstance(node_attribute, operational_tree.IpAttr):
            attributes['ip_address'] = node_attribute.ip_address
        elif isinstance(node_attribute, operational_tree.ControllerAttr):
            print("skipping", node_attribute)
        elif isinstance(node_attribute, operational_tree.OpenFlowAttr):
            attributes['openflow'] = node_attribute.data_path_id
        elif isinstance(node_attribute, operational_tree.SelSapphireAttr):
            print("skipping", node_attribute)
        else:
            raise TypeError("Unsupported node attribute {}".format(type(node_attribute)))

    return attributes


def combine_objects_from_pyselflow(configuration_nodes, operational_nodes):
    """DO NOT USE
    """
    configuration_dict = dict()
    for configuration_node in configuration_nodes:
        configuration_dict[configuration_node.id] = configuration_node

    operational_dict = dict()
    for operational_node in operational_nodes:
        if operational_node.linked_key:
            operational_dict[operational_node] = configuration_dict[operational_node.linked_key]
        else:
            operational_dict[operational_node] = None

    return operational_dict


def combine_ports_to_nodes(nodes, ports):
    """DO NOT USE
    """
    ports_dict = dict()
    for port in ports:
        ports_dict[port.id] = port

    for node in nodes:
        connected_ports = defaultdict(list)
        for linked_port in node.ports:
            connected_ports[node.id].append(ports_dict[linked_port])

    return connected_ports


def convert_nodes_objects(nodes):
    """DO NOT USE
    """
    raise
