from pyselflow import config_tree
from pyselflow import operational_tree

from time import asctime,time,strftime
from math import floor

from .session import create_session
from .group_entries import group_entries_convert_to_pyselflow, group_entry_convert_from_selflow, group_entry_convert_to_pyselflow
from .flow_entries import flow_entries_convert_to_pyselflow, flow_entry_convert_from_selflow, flow_entry_convert_to_pyselflow, flow_entries_convert_from_selflow
from .node_entries import node_entries_convert_from_pyselflow, node_entries_convert_to_pyselflow, combine_objects_from_pyselflow, combine_ports_to_nodes
from ...automation.device import SEL2740SDevice
from ...tools.diff.diff import create_flow_entries_diff, create_group_entries_diff

from ...base.collection import FlowCollection

DEFAULT_PRIORITY = range(601, 60000)

class PyselflowNetwork:
	def __init__(self, username, password, url='localhost'):
		self._session = create_session(username, password, url)

	@property
	def session(self):
		return self._session

	def program_group_entries(self, group_objects):
		print("Starting upload at time", asctime())
		
		totalNumGroups = len(group_objects)
		if totalNumGroups > 20:
			one_percent = totalNumGroups / 100
			current_progress = 0
			print("Each % is", one_percent, "groups")
			display = True
		else:
			display = False

		lasttime = time()
		starttime = time()
		last_percent = 0

		for index, group_entry in enumerate(group_objects):
			group_object = group_entry_convert_to_pyselflow(group_entry)

			cur_percent = floor((index / totalNumGroups) * 100)
			if display and cur_percent > last_percent:
				last_percent = cur_percent
				current_progress += 1
				curtime = time()
				difftime = curtime-lasttime
				timepergroup = difftime/one_percent
				timerunning = curtime-starttime
				if index > 0:
					avetimepergroup = timerunning/index
				else:
					avetimepergroup = 0
				timeleft = avetimepergroup * (totalNumGroups - index)						  
				tlhours, remainder = divmod(timeleft, 3600)
				tlminutes, tlseconds = divmod(remainder, 60)					  
				tthours, remainder = divmod(timerunning, 3600)
				ttminutes, ttseconds = divmod(remainder, 60)
				print("groups({}/{}) {}% @ {} -- tpg: {:.2f} -- ave-tpg: {:.2f} -- ~time-left: {:02d}:{:02d}:{:02d} -- total-time: {:02d}:{:02d}:{:02d}".format(
																					index,totalNumGroups,cur_percent, 
																					strftime("%H:%M:%S"), 
																					timepergroup,
																					avetimepergroup,
																					int(tlhours),int(tlminutes),int(tlseconds),
																					int(tthours),int(ttminutes),int(ttseconds)))
																				

				lasttime = curtime

			try:
				self.program_group_entry(group_object)
			except Exception as e:
				raise ValueError("Error programming group {} because {}".format(group_entry, e))

	def program_group_entry(self, group_entry):
		group_entry.node = self.find_create_config_node(group_entry.node)
		config_tree.GroupsEntityAccess(self.session).create_single(group_entry)

	def program_flow_entries(self, flow_objects):
		response_objects = list()

		print("Starting upload at time", asctime())
		
		totalNumFlows = len(flow_objects)
		if totalNumFlows > 100:
			one_percent = totalNumFlows / 100
			current_progress = 0
			print("Each % is", one_percent, "flows")
			display = True
		else:
			display = False

		lasttime = time()
		starttime = time()
		last_percent = 0
		for index, flow_object in enumerate(flow_objects):
			flow_entry = flow_entry_convert_to_pyselflow(flow_object)
			cur_percent = floor((index / totalNumFlows) * 100)
			if display and cur_percent > last_percent:
				last_percent = cur_percent
				current_progress += 1
				curtime = time()
				difftime = curtime-lasttime
				timeperflow = difftime/one_percent
				timerunning = curtime-starttime
				if index > 0:
					avetimeperflow = timerunning/index
				else:
					avetimeperflow = 0
				timeleft = avetimeperflow * (totalNumFlows - index)						  
				tlhours, remainder = divmod(timeleft, 3600)
				tlminutes, tlseconds = divmod(remainder, 60)					  
				tthours, remainder = divmod(timerunning, 3600)
				ttminutes, ttseconds = divmod(remainder, 60)
				print("flows({}/{}) {}% @ {} -- tpf: {:.2f} -- ave-tpf: {:.2f} -- ~time-left: {:02d}:{:02d}:{:02d} -- total-time: {:02d}:{:02d}:{:02d}".format(
																					index,totalNumFlows,cur_percent, 
																					strftime("%H:%M:%S"), 
																					timeperflow,
																					avetimeperflow,
																					int(tlhours),int(tlminutes),int(tlseconds),
																					int(tthours),int(ttminutes),int(ttseconds)))
																				

				lasttime = curtime
			try:
				response = self.program_flow_entry(flow_entry)
				reponse_objects = response_objects.append(response)
			except Exception as e:
				raise ValueError("Unable to program entry {} (number {}) because of the following error {}".format(flow_object, index, e))
				print(e)

		print("Finished at", asctime())
		return response_objects

	def program_flow_entry(self, flow_entry):
		flow_entry.node = self.find_create_config_node(flow_entry.node)
		return config_tree.FlowsEntityAccess(self.session).create_single(flow_entry)

	def delete_config_node(self, node_id):
		# TODO need to see if Established else it ain't gonna happen
		node_to_delete = self.find_config_node(node_id)
		if node_to_delete and node_to_delete.state == "Configured":
			self.delete_group_entries_by_config_node(node_id)
			self.delete_flow_entries_by_config_node(node_id, priorities=None)
			config_tree.NodesEntityAccess(self.session).delete_single(node_to_delete.id)

	def delete_no_switch_group_entries(self):
		node_ids = [node.id for node in self.gather_config_nodes()]
		for group_entry in self.gather_group_entries():
			if group_entry.node not in node_ids:
				self.delete_group_entry(group_entry)

	def delete_no_switch_flow_entries(self):
		node_ids = [node.id for node in self.gather_config_nodes()]
		for flow_entry in self.gather_flow_entries():
			if flow_entry.node not in node_ids:
				self.delete_group_entry(group_entry)

	def nuke_all_configuration_objects_and_programming(self):
		all_config_ids = [node.display_name for node in self.gather_config_nodes()]
		self.delete_config_nodes(all_config_ids)

	def delete_config_nodes(self, node_ids):
		for node_id in node_ids:
			self.delete_config_node(node_id)

	def gather_operational_nodes(self):
		return operational_tree.NodesEntityAccess(self.session).read_collection()

	def gather_config_nodes(self):
		return config_tree.NodesEntityAccess(self.session).read_collection()

	def gather_group_entries(self):
		return config_tree.GroupsEntityAccess(self.session).read_collection()

	def find_config_node(self, node_id):
		for config_node in self.gather_config_nodes():
			if config_node.display_name == node_id:
				return config_node

	def create_config_node(self, node):
		try:
			config_tree.NodesEntityAccess(self.session).create_single(node)
		except Exception as e:
			print("Error while trying to program {}".format(node))
			raise e

	def program_node_entries(self, node_entries):
		self.create_config_nodes(node_entries)

	def program_only_2740S_node_entries(self, node_entries):
		to_convert = list()
		for node in node_entries:
			if isinstance(node, SEL2740SDevice):
				to_convert.append(node)

		self.program_node_entries(to_convert)

	def create_config_nodes(self, nodes):
		for node in node_entries_convert_to_pyselflow(nodes):
			self.create_config_node(node)

	def create_2740S_node(self, node_id, ip_address, subnet_mask, default_gateway, controller_ip):
		node = config_tree.Sel2740SConfigNode(display_name=node_id, ip_address=ip_address, subnet_mask=subnet_mask, default_gateway=default_gateway, controller_ip=controller_ip)
		config_tree.NodesEntityAccess(self.session).create_single(node)

	def find_create_config_node(self, node_id):
		if not self.find_config_node(node_id):
			self.create_config_node(node_id)
		else:
			return self.find_config_node(node_id)

	def get_flow_entry_by_priority(self, priority, node=None, convert=True):
		flow_objects = self.get_flow_entries_by_priority([priority], node=node)

		if convert:
			flow_objects = self.convert_flow_entries(flow_objects)

		if len(flow_objects) != 1:
			raise ValueError("Excepted 1 flow entry, but recevied {}".format(len(flow_objects)))
		else:
			return flow_objects[0]

	def get_flow_entries_by_priority(self, priorities, node=None):
		gathered_flow_entries = list()

		flow_entries = self.retrieve_flow_entries() if not node else self.retrieve_flow_entries_by_node_name(node=node)

		for flow_entry in flow_entries:
			if int(flow_entry.priority) in priorities:
				gathered_flow_entries.append(flow_entry)
		return gathered_flow_entries

	def delete_flow_entries_by_id(self, flow_ids):
		for flow_entry in flow_entries:
			if int(flow_entry.cookie) in flow_ids:
				self.delete_flow_entry(flow_entry)
				return True
		return False

	def get_converted_flow_entries(self, priorities=DEFAULT_PRIORITY, node=None):
		if node:
			flow_objects = self.retrieve_flow_entries_by_node_name(priorities=priorities, node=node)
		else:
			flow_objects = self.retrieve_flow_entries(priorities=priorities)
		return self.convert_flow_entries(flow_objects)

	def convert_flow_entries(self, flow_objects):
		self.convert_config_node_to_display_name(flow_objects)
		return FlowCollection(values=[flow_entry_convert_from_selflow(flow_object) for flow_object in flow_objects])

	def get_converted_group_entries(self, controller_groups=False):
		group_objects = self.retrieve_group_entries(controller_groups)
		self.convert_config_node_to_display_name(group_objects)
		return [group_entry_convert_from_selflow(group_entry) for group_entry in group_objects]

	def convert_config_node_to_display_name(self, entries):
		config_nodes = self.gather_config_nodes()

		for entry in entries:
			for config_node in config_nodes:
				if config_node.id == entry.node:
					entry.node = config_node.display_name
					#converted_objects.append(flow_entry_convert_from_selflow(flow_object))

	def retrieve_flow_entry(self, flow_id):
		return config_tree.FlowsEntityAccess(self.session).read_single(item_id=flow_id)

	def retrieve_flow_entries_by_node_name(self, node, priorities=DEFAULT_PRIORITY):
		config_node = self.find_config_node(node)
		return self.retrieve_flow_entries(config_node, priorities)

	def retrieve_flow_entries(self, node=None, priorities=DEFAULT_PRIORITY):
		if node:
			flow_entries = config_tree.FlowsEntityAccess(self.session).read_by_node(value=node.id)
		else:
			flow_entries = config_tree.FlowsEntityAccess(self.session).read_collection()

		if priorities is not None:
			filtered_flow_entries = list()
			for flow_entry in flow_entries:
				if self.priority_filter(priority=flow_entry.priority, priority_range=priorities):
					filtered_flow_entries.append(flow_entry)
		else:
			filtered_flow_entries = flow_entries

		return filtered_flow_entries

	def retrieve_group_entries(self, node=None, controller_groups=False):
		if node:
			group_entries = config_tree.GroupsEntityAccess(self.session).read_by_node(value=node.id)
		else:
			group_entries = config_tree.GroupsEntityAccess(self.session).read_collection()

		if not controller_groups:
			filtered_groups = list()
			for group_entry in group_entries:
				if 'SEL-5056:' not in group_entry.display_name:
					filtered_groups.append(group_entry)
			group_entries = filtered_groups
		return group_entries

	def delete_flow_entry(self, flow_object):
		if isinstance(flow_object, config_tree.Flow):
			return config_tree.FlowsEntityAccess(self.session).delete_single(flow_object.id)
		else:
			raise TypeError("Unsupported Flow Entry object type")

	def delete_group_entry(self, group_object):
		if isinstance(group_object, config_tree.Group):
			return config_tree.GroupsEntityAccess(self.session).delete_single(group_object.id)
		else:
			raise TypeError("Unsupported Group Entry object type")

	def delete_flow_entries_by_config_node(self, config_node, priorities=DEFAULT_PRIORITY):
		if isinstance(config_node, str):
			config_node = self.find_config_node(config_node)
		config_node_flow_entries = self.retrieve_flow_entries(config_node, priorities=priorities)
		for entry in config_node_flow_entries:
			if (priorities is None) or (entry.priority in priorities):
				self.delete_flow_entry(entry)

	def resolve_entry_diff(self, new_flow_entries, new_group_entries):
		self.resolve_group_entry_diff(new_group_entries)
		self.resolve_flow_entry_diff(new_flow_entries)

	def resolve_flow_entry_diff(self, new_flow_entries):
		current_controller_entries = self.retrieve_flow_entries()
		add_entries, delete_entries = create_flow_entries_diff(old_entries=self.get_converted_flow_entries(), new_entries=new_flow_entries)
		add_entries = sorted(add_entries, key=lambda add_entry: add_entry.priority)

		if add_entries:
			try:
				self.program_flow_entries(add_entries)
			except ValueError as e:
				if "identical with another flow entry in same table" in str(e):
					pass

		delete_cookies = [f.entry_id for f in delete_entries]

		for current_controller_entry in current_controller_entries:
			if current_controller_entry.cookie in delete_cookies:
				self.delete_flow_entry(current_controller_entry)

		add_entries, delete_entries = create_flow_entries_diff(old_entries=self.get_converted_flow_entries(), new_entries=new_flow_entries)

		self.program_flow_entries(add_entries)
		assert(len(delete_entries)==0)

		add_entries, delete_entries = create_flow_entries_diff(old_entries=self.get_converted_flow_entries(), new_entries=new_flow_entries)
		assert(len(add_entries)==0)
		assert(len(delete_entries)==0)

	def resolve_group_entry_diff(self, new_group_entries):
		add_entries, delete_entries = create_group_entries_diff(old_entries=self.get_converted_group_entries(), new_entries=new_group_entries)

		try:
			self.program_group_entries(add_entries)
		except ValueError as e:
			if "Unable to add group entry because a group entry with identical ID already exists on switch" in str(e):
				pass

		self.delete_group_entries_by_internal(delete_entries)

		add_entries, delete_entries = create_group_entries_diff(old_entries=self.get_converted_group_entries(), new_entries=new_group_entries)

		self.program_group_entries(add_entries)

		add_entries, delete_entries = create_group_entries_diff(old_entries=self.get_converted_group_entries(), new_entries=new_group_entries)
		#print(add_entries)
		assert(len(add_entries)==0)
		assert(len(delete_entries)==0)	
		#self.program_group_entries(add_entries)

	def delete_group_entries_by_internal(self, group_entries):
		for group_entry in group_entries:
			node_name = group_entry.node
			entry_id = group_entry.entry_id

			self.delete_group_entries_by_node_name(node_name=node_name, entry_ids=[entry_id])

	def delete_group_entries_by_node_name(self, node_name, entry_ids):
		config_node = self.find_config_node(node_name)
		group_entries = self.retrieve_group_entries(config_node)

		for group_entry in group_entries:
			if group_entry.group_id in entry_ids:
				self.delete_group_entry(group_entry)

	def delete_flow_entries_by_node_name(self, node_name, priorities=DEFAULT_PRIORITY):
		config_node = self.find_config_node(node_name)
		self.delete_flow_entries_by_config_node(config_node, priorities=priorities)

	def delete_group_entries(self, controller_groups=False):
		group_entries = self.gather_group_entries()
		for group_entry in group_entries:
				if controller_groups and 'SEL-5056:' in group_entry.display_name:
					self.delete_group_entry(group_entry)
				if 'SEL-5056:' not in group_entry.display_name:
					self.delete_group_entry(group_entry)

	def delete_group_entries_by_config_node(self, config_node):
		group_entries = self.gather_group_entries()
		for group_entry in group_entries:
			if group_entry.display_name == config_node:
				self.delete_group_entry(group_entry)

	def delete_flow_entries(self, priorities=DEFAULT_PRIORITY):
		return [self.delete_flow_entry(f) for f in self.retrieve_flow_entries(priorities=priorities)]

	def program_meter_entries(self, meter_entries):
		raise

	def priority_filter(self, priority, priority_range):
		return priority_range is None or priority in priority_range

	def get_converted_combined_node_entries(self):
		combined_nodes = combine_objects_from_pyselflow(self.gather_config_nodes(), self.gather_operational_nodes())
		return convert_nodes_objects(combined_nodes)

	def get_combined_port_entries(self):
		return combine_objects_from_pyselflow(self.gather_config_ports(), self.gather_operational_ports())

	def get_combined_link_entries(self):
		return combine_objects_from_pyselflow(self.gather_config_links(), self.gather_operational_links())

	def export_network(self):
		nodes = self.get_combined_node_entries()
		ports = self.get_combined_port_entries()
		links = self.get_combined_link_entries()

		c_n = self.gather_config_nodes()
		c_p = self.gather_config_ports()
		o_n = self.gather_operational_nodes()
		o_p = self.gather_operational_ports()

		o_n_p = combine_ports_to_nodes(c_n, c_p)
		c_n_p = combine_ports_to_nodes(o_n, o_p)

		nodes = self.get_combined_node_entries()
		ports = self.get_combined_port_entries()

	def gather_operational_links(self):
		return operational_tree.LinksEntityAccess(self.session).read_collection() 

	def gather_config_links(self):
		return config_tree.LinksEntityAccess(self.session).read_collection() 

	def gather_operational_ports(self):
		return operational_tree.PortsEntityAccess(self.session).read_collection()

	def gather_config_ports(self):
		return config_tree.PortsEntityAccess(self.session).read_collection()

	def get_converted_configuration_node_entries(self):
		return node_entries_convert_from_pyselflow(self.gather_config_nodes())

	def get_converted_operational_node_entries(self):
		return node_entries_convert_from_pyselflow(self.gather_operational_nodes())

	def gather_operational_nodes(self):
		return operational_tree.NodesEntityAccess(self.session).read_collection()

Network = PyselflowNetwork
