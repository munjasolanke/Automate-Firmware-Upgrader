"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions for converting OpenFlow flow entries from selsdn to pyselflow and
vice versa.
"""

from re import fullmatch

from pyselflow import config_tree

from ...openflow.core.flow_entry import FlowEntry
from ...openflow.core.instructions import Instructions, WriteActionsInstruction, MeterInstruction, GotoTableInstruction
from ...openflow.core.match_fields import InPortMatch, EthTypeMatch, EthSrcMatch, EthDstMatch, VlanVidMatch, VlanPcpMatch
from ...openflow.core.match_fields import IpProtoMatch, Ipv4DstMatch, Ipv4SrcMatch, TcpSrcMatch, TcpDstMatch, UdpSrcMatch, UdpDstMatch
from ...openflow.core.match_fields import ArpOpMatch, ArpTpaMatch, ArpSpaMatch
from ...openflow.core.match_fields import MatchFields, MATCH_FIELDS
from ...openflow.core.actions import Actions

from .actions import action_convert_to_pyselflow, action_convert_from_pyselflow


def flow_entries_convert_to_pyselflow(flow_objects):
    """Converts internal FlowEntry objects to pyselflow flow objects.

    Arguments:
        flow_objects {list} -- a list of FlowEntry objects

    Returns:
        {list} -- pyselflow flow objects
    """
    flow_entries = list()
    for flow_object in flow_objects:
        flow_entry = flow_entry_convert_to_pyselflow(flow_object)
        flow_entries.append(flow_entry)
    return flow_entries


def flow_entry_convert_to_pyselflow(flow_object):
    """Convert an internal FlowEntry object to a pyselflow flow object.

    Arguments:
        flow_object {object} -- selsdn FlowEntry object

    Returns:
        {object} -- pyselflow flow object
    """
    match_fields = match_fields_convert_to_pyselflow(flow_object)
    instructions = instructions_convert_to_pyselflow(flow_object)
    enabled = True if flow_object.get_attribute("enabled") is None else flow_object.get_attribute("enabled")

    sel_flow = config_tree.Flow(table_id=flow_object.table_id,
                                priority=flow_object.priority,
                                match=match_fields,
                                instructions=instructions,
                                node=flow_object.node_name,
                                enabled=enabled,
                                display_name=flow_object.name)
    return sel_flow


def match_fields_convert_to_pyselflow(flow_object):
    """Converts the match fields of a FlowEntry object to a pyselflow Match
    object.

    Arguments:
        flow_object {object} -- a selsdn FlowEntry object

    Returns:
        {object} -- match fields of the FlowEntry configured as a pyselflow
            Match object
    """
    match_fields = list()
    for match_field in flow_object.match_fields:
        match_field_name = match_field.__class__.__name__[:-5]
        match_field_mask = None if not getattr(match_field, 'mask', None) else str(match_field.mask)
        if (isinstance(match_field, TcpDstMatch) or isinstance(match_field, TcpSrcMatch)) and str(match_field) in ("DNP3", "MMS"):
            match_field_value = str(match_field.value)
        else:
            match_field_value = str(match_field)

        pyselflow_object = config_tree.__dict__[match_field_name]

        if match_field_mask:
            pyselflow_match_field = pyselflow_object(value=match_field_value,
                                                     mask=match_field_mask)
        else:
            pyselflow_match_field = pyselflow_object(value=match_field_value)

        match_fields.append(pyselflow_match_field)

    return config_tree.Match(match_fields=match_fields)


def instructions_convert_to_pyselflow(flow_object):
    """Converts instructions that do not contain actions from internal
    Instruction object types to the appropriate pyselflow instruction object
    types. Raises an error if a different type of instruction is included in
    the flow(Clear-Actions not supported).

    Arguments:
        flow_object {object} -- a selsdn FlowEntry object

    Returns:
        {list} -- list of the FlowEntry's instructions in pyselflow format
    """
    instructions = list()
    actions = actions_convert_to_pyselflow(flow_object)
    if actions:
        write_actions = config_tree.WriteActions()
        write_actions.instruction_type = config_tree.OfpInstructionType.write_actions()
        write_actions.actions = actions
        instructions.append(write_actions)

    for instruction in flow_object.instructions.values:
        if isinstance(instruction, GotoTableInstruction):
            gototable_instruction = config_tree.GoToTable()
            gototable_instruction.instruction_type = config_tree.OfpInstructionType.goto_table()
            gototable_instruction.table_id = instruction.value
            instructions.append(gototable_instruction)
        elif isinstance(instruction, MeterInstruction):
            meter_instruction = config_tree.MeterInstruction()
            meter_instruction.instruction_type = config_tree.OfpInstructionType.meter()
            meter_instruction.meter_id = instruction.value
            instructions.append(meter_instruction)
        else:
            raise TypeError("Instruction type {} not supported".format(instruction))

    return instructions


def actions_convert_to_pyselflow(flow_object):
    """Converts the actions of a FlowEntry object to a list of pyselflow
    action objects.

    Arguments:
        flow_object {object} -- a selsdn FlowEntry object

    Returns:
        {list} -- list of pyselflow actions
    """
    actions = list()
    for action in flow_object.actions:
        sel_action = action_convert_to_pyselflow(action)
        if sel_action:
            actions.append(sel_action)
    return actions


def flow_entries_convert_from_selflow(pyselflow_entries):
    """Converts pyselflow flow objects to FlowEntry objects.

    Arguments:
        pyselflow_entries {list} -- list of pyselflow flow objects

    Returns:
        {list} -- list of FlowEntry objects
    """
    flow_entries = list()
    for pyselflow_entry in pyselflow_entries:
        converted_entry = flow_entry_convert_from_selflow(pyselflow_entry)
        flow_entries.append(converted_entry)
    return flow_entries


def flow_entry_convert_from_selflow(pyselflow_entry):
    """Converts a pyselflow flow object to a FlowEntry object.

    Arguments:
        pyselflow_entry {object} -- a pyselflow flow object

    Returns:
        {object} -- a selsdn FlowEntry object
    """
    priority = int(pyselflow_entry.priority)
    node = pyselflow_entry.node
    table_id = int(pyselflow_entry.table_id)
    flow_id = int(pyselflow_entry.cookie)
    flow_entry = FlowEntry(name=pyselflow_entry.display_name,
                           entry_id=flow_id,
                           priority=priority,
                           node=node,
                           table_id=table_id)
    flow_entry.match_fields = match_fields_convert_from_pyselflow(pyselflow_entry.match)
    flow_entry.instructions = instructions_convert_from_pyselflow(pyselflow_entry.instructions)
    flow_entry.actions = actions_convert_from_pyselflow(pyselflow_entry.instructions)

    return flow_entry


def match_fields_convert_from_pyselflow(pyselflow_match_fields):
    """Converts a pyselflow flow object's match field list to selsdn MatchField
    objects, raising an error if a match field couldn't be converted.

    Arguments:
        pyselflow_match_fields {object} -- match fields of a pyselflow object

    Returns:
        {object} -- Matchfields object listing converted MatchField objects
    """
    match_fields = MatchFields()

    for pyselflow_match_field in pyselflow_match_fields.match_fields:
        selsdn_match_field_name = pyselflow_match_field.__class__.__name__ + 'Match'
        for match_field in MATCH_FIELDS:
            match_field_name = match_field.__name__
            if match_field_name == selsdn_match_field_name:

                pyselflow_match_value = pyselflow_match_field.value
                mask = getattr(pyselflow_match_field, 'mask', None)

                # pyselflow only does strings, so need to convert some values to integers
                if match_field_name in ('InPortMatch', 'VlanPcpMatch') and type(pyselflow_match_value) is str and fullmatch('\d+', pyselflow_match_value):
                    pyselflow_match_value = int(pyselflow_match_value)

                if mask:
                    if match_field_name in ("VlanVidMatch") and not mask in ("Present", "None"):
                        mask = int(mask)
                    selsdn_match_field = match_field(pyselflow_match_value, mask=mask)
                else:
                    selsdn_match_field = match_field(pyselflow_match_value)

                match_fields.add(selsdn_match_field)
                break
        else:
            raise ValueError("Unknown Match type {}".format(pyselflow_match_field))

    return match_fields


def instructions_convert_from_pyselflow(pyselflow_instructions):
    """Converts a list of pyselflow instruction objects that do not contain
    actions to Instruction objects. Raises an error if an unsupported type of
    instruction is included in the flow(Clear-Actions is not supported).

    Arguments:
        pyselflow_instructions {object} -- pyselflow instruction objects

    Returns:
        {object} --Instructions object listing converted Instruction objects
    """
    instructions = Instructions()

    for pyselflow_instruction in pyselflow_instructions:
        if pyselflow_instruction.instruction_type == 'WriteActions':
            # Actions are added by actions_convert_from_pyselflow
            continue
        if pyselflow_instruction.instruction_type == 'Meter':
            instruction = MeterInstruction(pyselflow_instruction.meter_id)
        elif pyselflow_instruction.instruction_type == 'GotoTable':
            instruction = GotoTableInstruction(pyselflow_instruction.table_id)
        else:
            raise TypeError("Instruction not supported")
        instructions.add(instruction)

    return instructions


def actions_convert_from_pyselflow(pyselflow_instructions):
    """Converts pyselflow write-action instruction object to Action objects.

    Arguments:
        pyselflow_instructions {object} -- pyselflow instructions objects

    Returns:
        {object} -- list of Action objects
    """
    actions = Actions()
    for pyselflow_instruction in pyselflow_instructions:
        if pyselflow_instruction.instruction_type == 'WriteActions':
            instruction = WriteActionsInstruction()
            for pyselflow_action in pyselflow_instruction.actions:
                action = action_convert_from_pyselflow(pyselflow_action)
                if action:
                    actions.add(action)
            return actions
    else:
        return actions
