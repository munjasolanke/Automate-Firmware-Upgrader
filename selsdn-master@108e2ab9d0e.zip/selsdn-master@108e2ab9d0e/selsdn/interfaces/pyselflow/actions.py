"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions for converting OpenFlow actions from selsdn to pyselflow and vice
versa.
"""

from pyselflow import config_tree

from ...openflow.core.actions import OutputAction, GroupAction, SetQueueAction, DropAction, PopVlanAction, SetVlanVidAction, PushVlanAction, SetVlanPcpAction


def actions_convert_to_pyselflow(actions):
    """Converts internal Action objects to pyselflow action objects.

    Arguments:
        actions {list} -- list of internal selsdn Action objects

    Returns:
        {list} -- list of converted pyselflow action objects
    """
    return [action_convert_to_pyselflow(action) for action in actions]


def actions_convert_from_pyselflow(actions):
    """Converts pyselflow action objects to internal Action objects.

    Arguments:
        actions {list} -- list of pyselflow action objects

    Returns:
        {list} -- list of converted selsdn Action objects
    """
    return [action_convert_from_pyselflow(action) for action in actions]


def action_convert_to_pyselflow(action):
    """Takes an internal Action object and converts it to the equivalent action
    object in pyselflow. Raises an error if the action given is invalid.

    Arguments:
        action {object} -- a selsdn Action object

    Returns:
        {object} -- converted pyselflow action object
    """
    action_value = str(action)

    if isinstance(action, OutputAction):
        sel_action = config_tree.OutputAction()
        sel_action.out_port = action_value
        sel_action.max_length = 65535
    elif isinstance(action, GroupAction):
        sel_action = config_tree.GroupAction()
        sel_action.group_id = int(action_value)
    elif isinstance(action, SetQueueAction):
        sel_action = config_tree.SetQueueAction()
        sel_action.queue_id = int(action_value)
    elif isinstance(action, DropAction):
        sel_action = None
    elif isinstance(action, SetVlanVidAction):
        sel_action = config_tree.SetFieldAction()
        sel_action.field = config_tree.VlanVid()
        sel_action.field.value = action_value
    elif isinstance(action, SetVlanPcpAction):
        sel_action = config_tree.SetFieldAction()
        sel_action.field = config_tree.VlanPcp()
        sel_action.field.value = action_value
    elif isinstance(action, PushVlanAction):
        sel_action = config_tree.PushVlanAction()
        sel_action.ether_type = action_value
    elif isinstance(action, PopVlanAction):
        sel_action = config_tree.PopVlanAction()
    else:
        raise TypeError("Action not supported '{}'".format(action))

    return sel_action


def action_convert_from_pyselflow(pyselflow_action):
    """Takes a pyselflow action object and converts it to the equivalent selsdn
    Action object. SetField actions other than for VLAN-related or ByAlias
    actions are not supported and produce an error.

    Arguments:
        pyselflow_action {object} -- a pyselflow action object

    Returns:
        {object} -- converted selsdn Action object
    """
    if isinstance(pyselflow_action, config_tree.OutputAction):
        return OutputAction(pyselflow_action.out_port)
    elif isinstance(pyselflow_action, config_tree.GroupAction):
        return GroupAction(pyselflow_action.group_id)
    elif isinstance(pyselflow_action, config_tree.SetQueueAction):
        return SetQueueAction(pyselflow_action.queue_id)
    elif isinstance(pyselflow_action, config_tree.OutputActionByAlias):
        print("skipping", pyselflow_action)
        return None
    elif isinstance(pyselflow_action, config_tree.PushVlanAction):
        return PushVlanAction(pyselflow_action.ether_type)
    elif isinstance(pyselflow_action, config_tree.PopVlanAction):
        return PopVlanAction()
    elif isinstance(pyselflow_action, config_tree.SetFieldAction):
        if isinstance(pyselflow_action.field, config_tree.VlanVid):
            return SetVlanVidAction(pyselflow_action.field.value)
        elif isinstance(pyselflow_action.field, config_tree.VlanPcp):
            return SetVlanPcpAction(pyselflow_action.field.value)
        else:
            raise TypeError("Set Field not supported {}".format(pyselflow_action.field))
    else:
        if "ByAlias" in pyselflow_action.__class__.__name__:
            raise TypeError("ByAlias actions are not supported in this interface, use the rest interface instead, {}".format(pyselflow_action))
        else:
            raise TypeError("Action not supported {}".format(pyselflow_action))
