from xlrd import open_workbook
from collections import defaultdict

from selsdn.interfaces.csv.interface import CSVInterface#, import_flow_entries, import_node_entries, import_topology, import_application_entries, import_group_entries, import_protocol_entries

class ExcelInterface(CSVInterface):
    def __init__(self):
        super().__init__()
        self.file_names = list()
        self.sheet_names = defaultdict(list)

    @staticmethod
    def get_rows_by_sheet(file_name, sheet_name):
        print(file_name, sheet_name)
        wb = open_workbook(file_name)
        file_rows = dict()
        for sheet in wb.sheets():
            print(sheet.name, sheet.name == sheet_name)
            if sheet.name == sheet_name:
                rows = list()
                row_headers = sheet.row_values(0)
                start_row = 1
                    
                for index in range(start_row, sheet.nrows):
                    row = dict()
                    row_data = sheet.row_values(index)
                    for index, cell in enumerate(row_data):
                        if type(cell) is float:
                            cell = int(cell)
                        row[row_headers[index]] = cell
                    rows.append(row)
                return rows

    def get_first_row(self, file_name, sheet_name):
        return self.get_rows_by_sheet(file_name, sheet_name)[0]

    def determine_csv_parser(self, file_name):
        file_name, sheet_name = file_name.split(":", 1)
        first_line = self.get_first_row(file_name, sheet_name)
        try:
            print(first_line)
            first_line_headers = [value.strip().lower() for value in first_line.keys()]
            return self._determine_csv_parser(first_line_headers)
        except ValueError as e:
            print("Ignoring sheet {} from file {} because it is not recognized".format(sheet_name, file_name))

    def parse_entries_upper(self, input_file_name):
        file_name, sheet_name = input_file_name.split(":", 1)
        return self.get_rows_by_sheet(file_name=file_name, sheet_name=sheet_name)
    
    @staticmethod
    def get_sheet_names(file_name):
        sheet_names = list()
        wb = open_workbook(file_name)
        for sheet in wb.sheets():
            sheet_names.append(sheet.name)
        return sheet_names

    def import_entries(self, *file_names, **kwargs):
        sheet_names = list()
        self.file_names = file_names
        for file_name in file_names:
            for sheet_name in self.get_sheet_names(file_name):
                self.sheet_names[sheet_name].append(file_name)
                sheet_names.append(":".join([file_name, sheet_name]))
            
        return super().import_entries(*sheet_names, **kwargs)

def import_entries(*args, **kwargs):
    return ExcelInterface().import_entries(*args, **kwargs)

def import_entries_by_file_type(import_file_name, file_type, *args, **kwargs):
    kwargs[file_name] = [import_file_name]
    return ExcelInterface().import_entries_by_file_type(*args, **kwargs)
