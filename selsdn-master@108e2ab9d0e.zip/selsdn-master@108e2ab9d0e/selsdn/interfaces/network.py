class BaseNetwork:
    @property
    def session(self):
        return self._session
