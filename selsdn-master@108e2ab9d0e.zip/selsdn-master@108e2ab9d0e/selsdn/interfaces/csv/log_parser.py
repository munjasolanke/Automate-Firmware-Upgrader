from . import LOGGER

from .entry_parser import EntryParser
from ...base.collection import LogCollection
from ...automation.device import SEL2740SSyslogServer, SEL2740SAlarmContact, SEL2740SLocalEvents

class LogParser(EntryParser):
    COLLECTION_TYPE = LogCollection
    CATEGORY_NAMES = ["Chassis and Module", "Configuration", "Link", "Openflow", "Security", "System Integrity"]
    VALID_COLUMNS = ["name", "type", "all"]
    VALID_TYPES = ["Syslog Server", "Alarm Contact", "Local Events"]
    VALID_SEVERITY = ["Informational", "Notice", "Warning", "Error", "Critical", "Alert", "Emergency"]

    def __init__(self, raise_at_end=False, file_name=None):
        super().__init__(raise_at_end=raise_at_end, file_name=file_name)
        self.current_row_name = None

    def get_category_logger_settings(self, row):
        category_dict = dict()

        all_category = self.gkft(row, "All")
        if all_category and all_category not in self.VALID_SEVERITY:
            raise ValueError("Severity must be in {} not {}".format(", ".join(self.VALID_SEVERITY), all_category))

        for category_name in self.CATEGORY_NAMES:
            value = self.gkft(row, category_name)
            dict_category_name = category_name.lower().replace(" ", "_")
            if value:
                if value not in self.VALID_SEVERITY:
                    raise ValueError("Severity must be in {} not {}".format(", ".join(self.VALID_SEVERITY), value))
                category_dict[dict_category_name] = value
            elif all_category:
                category_dict[dict_category_name] = all_category
            else:
                category_dict[dict_category_name] = None

        return category_dict

    def get_extra_logger_settings(self, row):
        extra_dict = dict()

        for name in ("IP Address", "Port", "Transport Type"):
            value = self.gkft(row, name, default=None)
            if name == "Port" and value:
                value = int(value)

            if value:
                extra_dict[name.lower().replace(" ", "_")] = value

        return extra_dict

    def create_entry(self, row, row_name):
        log_type = self.gkft(row, "Type")
        if log_type not in self.VALID_TYPES:
            raise ValueError("Log type must be one of {} not '{}'".format(", ".join(self.VALID_TYPES), log_type))

        category_dict = self.get_category_logger_settings(row)

        for value in category_dict.values():
            if value is not None:
                break
        else:
            raise ValueError("Must fill out at least one category")
        
        extra_categories = self.get_extra_logger_settings(row)

        if log_type == "Syslog Server":
            if not extra_categories.get("ip_address"):
                raise ValueError("Syslog servers require an IP Address")
        else:
            if extra_categories:
                for name, category in extra_categories.items():
                    raise ValueError("{} does not have attribute {}".format(log_type.replace("_", ""), name))

        entry = {"name": row_name}
        entry.update(category_dict)
        entry.update(extra_categories)

        if log_type == "Syslog Server":
            entry = SEL2740SSyslogServer(**entry)
        elif log_type == "Alarm Contact":
            entry = SEL2740SAlarmContact(**entry)
        elif log_type == "Local Events":
            entry = SEL2740SLocalEvents(**entry)
        else:
            raise ValueError("No such log type {}".format(log_type))

        return entry
