from .entry_parser import EntryParser, COMMENTS_STARTS
from ...base.collection import GroupCollection
from ...openflow.core.group_entry import AllGroup, FastFailoverGroup, SelectGroup, IndirectGroup
from ...openflow.core.action_bucket import WatchPort, WatchGroup, ActionBucket

class GroupEntryParser(EntryParser):
    COLLECTION_TYPE = GroupCollection

    def create_action_buckets(self, new_tuples, node):
        group_action_buckets = list()
        for entry_tuple_again in new_tuples:
            watch_port = self.gkft(entry_tuple_again, "Watch Port")
            watch_group = self.gkft(entry_tuple_again, "Watch Group")
            actions = self.create_actions(entry_tuple_again, node=node)
            watch_port = self.get_int_from_value(watch_port)
            watch_group = self.get_int_from_value(watch_group)

            if watch_port == node:
                self.add_error("Watch port can't be Local or have the same name as the node", exception_type=ValueError)
                #raise ValueError("Watch port can't be Local")
            else:
                node_object = self.get_node_from_name(node)
                if node_object and watch_port:
                    watch_port = self.resolve_port(node_object=node_object, value=watch_port)

            watch_port = WatchPort() if not watch_port else WatchPort(watch_port)
            watch_group = WatchGroup() if not watch_group else WatchGroup(watch_group)

            if actions:
                action_bucket = ActionBucket(actions=actions, watch_port=watch_port, watch_group=watch_group)
                group_action_buckets.append(action_bucket)
            else:
                actions = self.create_actions(entry_tuple_again, node=node)
                action_bucket = ActionBucket(actions=actions, watch_port=watch_port, watch_group=watch_group)
                group_action_buckets.append(action_bucket)

        return group_action_buckets

    def create_group_entry(self, name, node, group_id, group_type, new_tuples, attributes=None):
        group_action_buckets = self.create_action_buckets(new_tuples, node=node)

        # Remove the action bucket if it comes from a "blank" line, aka one that defines a group but no action buckets
        if len(group_action_buckets) == 1 and len(group_action_buckets[0]) == 0 and not self.gkft(new_tuples[0], "Watch Port") and not self.gkft(new_tuples[0], "Watch Group"):
            group_action_buckets = list()

        if group_type == 'All':
            entry = AllGroup(name=name, node=node, entry_id=group_id, action_buckets=group_action_buckets, attributes=attributes)
        elif group_type.lower().replace(" ", "") in ('fastfailover', 'ff'):
            entry = FastFailoverGroup(name=name, node=node, entry_id=group_id, action_buckets=group_action_buckets, attributes=attributes)
        elif group_type == 'Select':
            entry = SelectGroup(name=name, node=node, entry_id=group_id, action_buckets=group_action_buckets, attributes=attributes)
        elif group_type == 'Indirect':
            entry = IndirectGroup(name=name, node=node, entry_id=group_id, action_buckets=group_action_buckets, attributes=attributes)
        else:
            raise ValueError("Unknown group type {}".format(group_type))

        return entry

    def create_entries(self, tuples):
        # pending_entry indicates that there is a group ready already, required for multicast Nodes
        pending_entry = False
        # keep a copy of the action buckets that don't appear on the name, node, group_id, group_type line
        new_tuples = list()
        nodes = list()
        last_group = 0
        group_id = None
        group_type = None
        nodes = None

        for index, entry_tuple in enumerate(tuples):
            self.current_row_number = index + 1
            try:
                row_name = self.get_name_or_alias(entry_tuple)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(entry_tuple, row_name):
                    continue

                if self.gkft(entry_tuple, "ID") and (int(self.gkft(entry_tuple, "ID")) != group_id or self.gkft(entry_tuple, "Type") != group_type or self.listify(self.gkft(entry_tuple, "Node")) != nodes):
                    if pending_entry:
                        for node in nodes:
                            entry = self.create_group_entry(name, node, group_id, group_type=group_type, new_tuples=new_tuples, attributes={"Enabled": enabled})
                            self.add_entry(entry)
                            new_tuples = list()

                    pending_entry = True
                    name = row_name
                    nodes = self.listify(self.gkft(entry_tuple, "Node"))
                    if not nodes:
                        raise ValueError("No value found for node")
                    group_id = int(self.gkft(entry_tuple, "ID"))
                    group_type = self.gkft(entry_tuple, "Type")
                    enabled = self.get_boolean_from_value(self.gkft(entry_tuple, "Enabled"), default_value=True)
                    last_group = index

                new_tuples.append(entry_tuple)
            except Exception as e:
                self.add_error(e, row_number=last_group+2)
                #raise Exception("An error occured while processing group starting on line {}".format(last_group+2))

        # Now I need to do the last group. The above only creates the group when the next group is found,
        # which doesn't occur with the last group
        if tuples and nodes:
            for node in nodes:
                try:
                    entry = self.create_group_entry(name, node, group_id, group_type=group_type, new_tuples=new_tuples)
                    self.add_entry(entry)
                except Exception as e:
                    self.add_error(e, row_number=last_group+2)
                    #raise Exception("An error occured while processing group starting on line {}".format(last_group+2))

        return self.entries
