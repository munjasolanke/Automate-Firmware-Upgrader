from ...automation import DEVICE_PORT_SEPARATOR
from ...automation.device import TraditionalSwitchDevice
from ...automation.device import SEL274XSDevice
from ...openflow.core.actions import ActionSet, OutputAction, GroupAction, SetQueueAction, SetVlanVidAction, PushVlanAction, PopVlanAction, DropAction, ACTIONS, SetVlanPcpAction
from ...base.value import Value

COMMENTS_STARTS = ("#",)

class EntryParser(list):
    SUPPORTED_TYPES = ("int", "integer", "bool", "boolean", "str", "string")

    def __init__(self, node_entries=None, variables=None, raise_at_end=False, file_name=None):
        self._entries = list() if not hasattr(self, "COLLECTION_TYPE") else self.COLLECTION_TYPE()
        self.node_entries = node_entries
        if not node_entries:
            self._nodes = dict()
        elif isinstance(node_entries, list):
            node_dict = dict()
            for node in node_entries:
                node_dict[node.name] = node
            self._nodes = node_dict
        else:
            raise TypeError("Nodes are not in a recognizable format")

        self._variables = dict() if not variables else variables
        self._errors = dict()
        self.raise_at_end = raise_at_end
        self.current_row_number = 0
        self.file_name = file_name

    def is_ignore_row(self, entry_tuple, row_name):
        if self.check_for_empty_row(entry_tuple):
            return True
        elif row_name and row_name[0] in COMMENTS_STARTS:
            if not self.get_boolean_from_value(self.gkft(entry_tuple, "Ignore"), True, additional_mappings={"#": True}):
                self.add_error("The row name cannot BOTH start with # AND ignore False", exception_type=ValueError)
            return True
        elif self.get_boolean_from_value(self.gkft(entry_tuple, "Ignore"), False, additional_mappings={"#": True}):
            return True
        else:
            return False

    def check_for_empty_row(self, row):
        for name, value in row.items():
            if value not in ("", None):
                return False
        else:
            return True

    def raise_all(self):
        if self.raise_at_end and self.errors:
            total_exceptions = list()
            for row_number, errors in self.errors.items():
                for error in errors:
                    total_exceptions.append("Row {}: {}".format(row_number, error))
            raise Exception(total_exceptions)

    @property
    def errors(self):
        return self._errors

    def add_error(self, error, row_number=None, exception_type=Exception):
        if row_number is None:
            row_number = self.current_row_number

        if isinstance(error, Exception):
            exception_type = error.__class__
            error_str = str(error)
        else:
            error_str = error

        if "Row " in error_str:
            full_error = error_str
        else:
            if self.file_name:
                full_error = "{}: ".format(self.file_name)
            else:
                full_error = ""

            full_error += "Row {}: {}".format(row_number, error_str)

        if self.raise_at_end is False:
            raise exception_type(full_error)

        if not self._errors.get(row_number):
            self._errors[row_number] = list()
        self._errors[row_number].append(full_error)

    def __getitem__(self, key):
        return self._entries.__getitem__(key)

    def __iter__(self):
        return iter(self._entries)

    def __len__(self):
        return len(self._entries)

    def convert_str_to_type(self, key):
        if key.lower() in ("int", "integer"):
            return int
        elif key.lower() in ("bool", "boolean"):
            return bool
        elif key.lower() in ("str", "string"):
            return str
        else:
            raise

    def check_row_data(self, row):
        if "" in row and row[""] != "":
            self.add_error("Detected data '{}' in a row that has no column name".format(row[""]), exception_type=ValueError)

    def check_column_names(self, first_row):
        type_translator = dict()
        for key in first_row:
            if key == "" or key.lower() == "comment":
                continue
            elif key[0] == "&":
                if key.count(":") > 1:
                    raise ValueError("Only 0 or 1 : character allowed")
                elif key.count(":") == 1:
                    key_type = key.split(":")[1]
                    if key_type[:4] == "list" and (len(key_type) == 4 or len(key_type) > 4 and key_type[4] != '('):
                        raise TypeError("Unknown column type {} for column {}. Did you mean list(X) where X is a one of {}?".format(key_type, key, ", ".join(self.SUPPORTED_TYPES)))
                    elif key_type[:5] == "list(" and key_type[-1] == ')':
                        list_type = key_type[5:-1]
                        if list_type[-1] == ')':
                            default_value = list_type.split("(")[1][0:-1]
                            list_type = list_type.split("(")[0]
                            list_type = self.convert_str_to_type(list_type)
                            try:
                                default_value = self.convert_column_value(column_value=default_value, column_type=list_type)
                            except (TypeError, ValueError):
                                raise ValueError("Unable to convert default value '{}' into type '{}'".format(default_value, key_type))
                        else:
                            default_value = None
                            if not list_type:
                                list_type = 'str'
                            elif list_type not in self.SUPPORTED_TYPES:
                                raise TypeError("Unknown column type {} for column {}".format(list_type, key))

                            list_type = self.convert_str_to_type(list_type)
            
                        column_type = [list_type]
                    else:
                        if key_type[-1] == ')':
                            default_value = key_type.split("(")[1][0:-1]
                            key_type = key_type.split("(")[0]
                            column_type = self.convert_str_to_type(key_type)
                            try:
                                default_value = self.convert_column_value(column_value=default_value, column_type=column_type)
                            except (TypeError, ValueError):
                                raise ValueError("Unable to convert default value '{}' into type '{}'".format(default_value, key_type))
                        else:
                            default_value = None

                            if key_type not in self.SUPPORTED_TYPES:
                                raise TypeError("Unknown column type {} for column {}".format(key_type, key))
                            else:
                                column_type = self.convert_str_to_type(key_type)
                    type_translator[key] = {"name": key.split(":")[0][1:], "type": column_type, "default":default_value}
                else:
                    type_translator[key] = {"name": key[1:], "type": str, "default":None}
            elif key.lower() not in self.VALID_COLUMNS:
                raise ValueError("Column name '{}' is not one of the supported columns names: {}".format(key, ", ".join(self.VALID_COLUMNS)))
        return type_translator

    # call_other is a variable that prevent infinite recursion 
    # get_node_from_name->get_port_from_name->get_node_from_name, etc.
    def get_node_from_name(self, name, required=False, call_other=True):
        if DEVICE_PORT_SEPARATOR in name and call_other:
            port = self.get_port_from_name(name, required=False, call_other=False)
            if port:
                return port

        if isinstance(name, Value):
            name = name.value
        if name in self._nodes:
            return self._nodes[name]
        else:
            if required:
                self.add_error("No node with name '{}' found".format(name), exception_type=ValueError)

    def get_extra_attributes(self, row, ignore_attributes):
        extra_attributes = dict()
        for name, value in row.items():
            if name not in ignore_attributes:
                extra_attributes[name] = value
        return extra_attributes

    # call_other is a variable that prevent infinite recursion 
    # get_node_from_name->get_port_from_name->get_node_from_name, etc.
    def get_port_from_name(self, name, networkable=False, required=True, call_other=True):
        name = name.strip()
        device_name, port_name = [value.strip() for value in name.rsplit(DEVICE_PORT_SEPARATOR, 1)]
        
        device_object = self.get_node_from_name(device_name, call_other=False)
        if not device_object:
            device_object = self.get_node_from_name(name.strip(), call_other=False)
            # I only received the node name, so must return the first port
            if device_object:
                return device_object.ports[0]

        if not device_object:
            return None
        
        port_number = None
        port_object = None
        
        if device_object.get_port(port_name):
            port_object = device_object.get_port(port_name)

        if not port_object:
            try:
                port_number = int(port_name)
                port_object = device_object.get_port(port_number)
            except ValueError:
                pass
            finally:
                if not port_object:
                    if networkable:
                        port_object = device_object.get_ports_by_network(port_name)
                        if len(port_object) == 1:
                            port_object = port_object[0]
                        elif len(port_object) > 2:
                            raise ValueError("{} returned {} ports, need to be more specific in port reference".format(name, len(port_object)))
                        elif len(port_object) == 0:
                            port_object = None
                    else:
                        try:
                            port_number = int(port_name)
                            port_object = device_object.ports[port_number]
                        except ValueError:
                            pass

        if isinstance(port_object, list):
            raise ValueError("{} returned multiple ports {}, need to be more specific in port reference".format(name, port_object))

        return port_object

    def listify(self, value):
        if value == "" or value is None:
            return list()
        else:
            # Strip white space before and after the value
            value = value.strip()
            # Strip the last , if there is no value after it
            value = value.rstrip(",")
            if "," in value:
                value_list = value.split(",")
                # strip white space before and after each value in the list
                return [value.strip() for value in value_list]
            else:
                return [value]

    def get_user_attributes_from_row(self, entry_tuple):
        attributes = dict()
        for column_name, definition in self.type_translator.items():
            row_value = self.gkft(entry_tuple, column_name)
            column_type = definition["type"]
            converted_column_name = definition["name"]
            try:
                if row_value == '' and definition["default"] is not None:
                    converted_row_value = definition["default"]
                elif row_value == '':
                    converted_row_value = None
                else:
                    converted_row_value = self.convert_column_value(row_value, column_type=column_type)
                attributes[converted_column_name] = converted_row_value
            except ValueError as e:
                self.add_error("Unable to convert column '{}' with value '{}'' into type {}".format(converted_column_name, row_value, column_type), exception_type=TypeError)
                #raise TypeError("Unable to convert column '{}' with value '{}'' into type {}".format(converted_column_name, row_value, column_type))
        return attributes

    def convert_column_value(self, column_value, column_type):
        if column_type == str:
            converted_row_value = column_value
        elif column_type == int:
            converted_row_value = int(column_value)
        elif column_type == bool:
            if (isinstance(column_value, str) and column_value.lower() in ("true",)) or isinstance(column_value, int) and column_value == 1:
                converted_row_value = True
            elif (isinstance(column_value, str) and column_value.lower() in ("false",)) or isinstance(column_value, int) and column_value == 0:
                converted_row_value = False
            else:
                if column_value == '':
                    raise ValueError("Unable to convert a blank into a boolean".format(column_value))
                else:
                    raise ValueError("Unable to convert {} into a boolean".format(column_value))
        elif type(column_type) == list:
            sub_column_type = column_type[0]
            row_values = column_value.split(",")
            converted_row_value = [self.convert_column_value(value, column_type=sub_column_type) for value in row_values]
        else:
            raise TypeError("Unknown type {}".format(column_type))      
        return converted_row_value

    def get_name_or_alias(self, row):
        row_name = self.gkft(row, "Name")
        if row_name is None:
            row_name = self.gkft(row, "Alias")
        if row_name is None:
            raise ValueError("A column with Name or Alias required")
        return row_name

    def get_int_from_value(self, value, default_value=None, range=None):
        if value in ('', None):
            return default_value
        try:
            new_value = int(value)
        except (ValueError, TypeError):
            return value
        else:
            if range:
                if new_value in range:
                    return new_value
                else:
                    self.add_error("Value {} not in {}".format(new_value, range), exception_type=ValueError)
            else:
                return new_value

    def get_boolean_from_value(self, value, default_value, additional_mappings=None):
        if default_value not in (False, True):
            self.add_error("Default boolean value must be True or False not {}".format(default_value), exception_type=ValueError)
        
        if additional_mappings and additional_mappings.get(value):
            return bool(additional_mappings.get(value))
        if value in ("", None):
            return default_value
        else:
            if value is True or value == 1 or (isinstance(value, str) and value.lower() in ("true", "t")):
                return True
            elif value is False or value == 0 or (isinstance(value, str) and value.lower() in ("false", "f")):
                return False
            else:
                self.add_error("Unable able to decode '{}' as either True or False".format(value), exception_type=ValueError)

    @property
    def variables(self):
        return self._variables

    def add_node(self, node):
        self._nodes[node.name] = node

    @property
    def entries(self):
        return self._entries

    def add_entry(self, entry):
        self._entries.append(entry)

    def gkft(self, entry_tuple, key, default=None, required=False):
        return self.get_value_from_tuple(entry_tuple, key, default=default, required=required)

    def get_value_from_tuple(self, entry_tuple, key, default=None, required=False):
        value = entry_tuple.get(key)

        if value in (None, '') and default is not None:
            value = default
        elif isinstance(value, str):
            value = value.strip()

        if value and type(value) is str and value[0] == "$":
            dict_value = self.get_value_from_key(value)

            if dict_value:
                return dict_value

        if required and value is None:
            self.add_error("Unable to get {} from entry".format(key), exception_type=ValueError)

        return value

    def get_value_from_key(self, key):
        if key in self.variables:
            return self.variables[key]
        else:
            return None

    # Last port should be the last SEL-2740S port 
    # I can't return the Traditional Switch port, I need the SEL-2740S port
    def resolve_port(self, node_object, value, last_port=None):
        # Looking for value connected to node_object
        if value is None:
            self.add_error("Cannot resolve a None value for a port", exception_type=ValueError)
            #raise ValueError("Cannot resolve a None value")

        for port in node_object.ports:
            if port.end and port.end.owner:
                if isinstance(port.end.owner, TraditionalSwitchDevice):
                    returned_name = self.resolve_port(node_object=port.end.owner, value=value, last_port=port)
                    if returned_name != value:
                        return returned_name
                elif port.end.owner.name == value:
                    if isinstance(node_object, TraditionalSwitchDevice):
                        return last_port.name
                    else:
                        return port.name
                elif port.end.print_name == value:
                    if isinstance(node_object, TraditionalSwitchDevice):
                        return last_port.name
                    else:
                        return port.name
        else:
            # Couldn't find it
            return value

    def create_action(self, action_name, value, node=None):
        action_name = action_name.lower()

        if action_name == 'output':
            node_object = self.get_node_from_name(value)
            if node_object:
                current_node_object = self.get_node_from_name(node)
                if isinstance(node_object, SEL274XSDevice):
                    if node_object.name == node:
                        node_port = "Local"
                    else:
                        node_port = self.resolve_port(node_object=current_node_object, value=node_object.name)
                        if not node_port:
                            self.add_error("There is no connection found for {} from {}. Check topology.".format(node_object.name, node))
                            #raise ValueError("There is no connection found for {} from {}. Check topology.".format(node_object.name, node))
                else:
                    node_port = self.resolve_port(node_object=current_node_object, value=value)

                    if not node_port:
                        self.add_error("There is no connection found for {}. Check topology.".format(node_object.name))
                        #raise ValueError("There is no connection found for {}. Check topology.".format(node_object.name))
                return OutputAction(node_port)
            else:
                return OutputAction(value)
        elif action_name == 'group':
            if node and isinstance(value, str):
                try:
                    node = int(value)
                except ValueError:
                    entry = self.lookup_id_by_alias(alias=value, node=node)
                    if not entry:
                        self.add_error("Cannot resolve value {} to an integer or as an alias to an already defined group on node {}".format(value, node))
                        #raise ValueError("Can not resolve value {} to an integer or as an alias to an already defined group on node {}".format(value, node))
                    value = entry.entry_id
            return GroupAction(value)
        elif action_name == 'setqueue':
            return SetQueueAction(int(value))
        elif action_name == 'setvlanvid':
            return SetVlanVidAction(int(value))
        elif action_name == 'pushvlan':
            if (isinstance(value, bool) and value is True) or value.lower() not in ("false"):
                return PushVlanAction(0x8100)
        elif action_name == 'popvlan':
            if (isinstance(value, bool) and value is True) or value.lower() not in ("false"):
                return PopVlanAction()
        elif action_name == 'setvlanpcp':
            return SetVlanPcpAction(int(value))
        elif action_name == 'drop':
            return DropAction()
        else:
            self.add_error("Unknown type '{}'".format(action_name), TypeError)

    def create_actions(self, entry_tuple, node=None):
        actions = ActionSet()
        
        for action in ACTIONS[:-1]:
            action_name = action.__name__[:-6]
            action_value = self.gkft(entry_tuple, action_name)
            if action_value or action_value == 0: # 0 is a valid value sometimes
                action_object = self.create_action(action_name, action_value, node=node)
                if action_object:
                    actions.add(action_object)

        return actions

    def lookup_id_by_alias(self, alias, node):
        for entry in self.entries:
            if entry.node == node and entry.name == alias:
                return entry
        else:
            return None

    def create_entries(self, rows):
        for index, row in enumerate(rows):
            row_name = None
            self.current_row_number = index + 2
            try:
                row_name = self.get_name_or_alias(row)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(row, row_name):
                    continue 
                
                entry = self.create_entry(row, row_name)
                if entry:
                    self.add_entry(entry)

            except Exception as e:
                self.add_error(e)
                #raise Exception("An error occured while processing topology entry number {}".format(index+1))

        return self.entries


class VariableParser(EntryParser):
    def __init__(self):
        self.variable_dict = {}

    def create_entries(self, entry_tuples):
        for entry_tuple in entry_tuples:
            key = entry_tuple.Key
            value = entry_tuple.Value

            self.add_variable(key=key, value=value)

        return self.variable_dict

    def add_variable(self, key, value):
        self.variable_dict[key] = value
