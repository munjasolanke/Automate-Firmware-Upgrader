from .entry_parser import EntryParser, COMMENTS_STARTS
from ...base.collection import ProtocolCollection
from ...openflow.core.match_fields import MATCH_FIELDS, MatchFields
from ...automation.protocol import Protocol
from ...automation.device import TwoMacDevice
from ...automation.associations import Associations


class ProtocolParser(EntryParser):
    COLLECTION_TYPE = ProtocolCollection
    DEFINED_NAMES = [x.lower() for x in ["Unicast", "Bidirectional", "LinkRedundancy", "FlowPriority", "SetQueue", "Associations"] + [x.__class__.__name__ for x in MATCH_FIELDS]]

    def __init__(self, raise_at_end=False, node_entries=None, file_name=None):
        super().__init__(raise_at_end=raise_at_end, node_entries=node_entries, file_name=file_name)
        self._associations = Associations()

    def add_object_to_association(self, node, association):
        self._associations.add_entry(node, association)

    def resolve_attributes(self, row):
        attributes = dict()

        for name in row:
            value = self.gkft(row, name)
            if name.lower() not in self.DEFINED_NAMES:
                attributes[name] = value

        return attributes

    def create_entries(self, tuples):
        for index, row in enumerate(tuples):
            self.current_row_number = index + 2
            try:
                row_name = self.get_name_or_alias(row)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(row, row_name):
                    continue

                unicast = self.get_boolean_from_value(self.gkft(row, "Unicast"), default_value=True)
                    #self.add_error(ValueError("{} is not a valid value for Unicast".format(unicast)))
                    #raise ValueError("{} is not a valid value for Unicast".format(unicast))
                bidirectional = self.get_boolean_from_value(self.gkft(row, "Bidirectional"), default_value=True if unicast is True else False)
                    #self.add_error(ValueError("{} is not a valid value for Bidirectional".format(bidirectional)))

                if unicast is False and bidirectional is True:
                    self.add_error(ValueError("Multicast traffic (Unicast = False) can't be bidirectional"))

                link_redundancy = self.gkft(row, "LinkRedundancy")
                if (type(link_redundancy) is str and link_redundancy.lower() in ("true", "false")) or (type(link_redundancy) is int and link_redundancy == 1):
                    link_redundancy = 1 if link_redundancy.lower() == "true" else 0
                elif (type(link_redundancy) is str and link_redundancy in ("0", "1")) or (type(link_redundancy) is int and link_redundancy == 0):
                    link_redundancy = int(link_redundancy)
                elif link_redundancy in ('', None):
                    link_redundancy = None
                else:
                    self.add_error(ValueError("{} is not a valid value for Link Redundancy".format(link_redundancy)))

                match_fields = self.get_match_fields(row, node=None)

                attributes = self.resolve_attributes(row)

                protocol = Protocol.create_protocol_from_match_fields(row_name, unicast=unicast, unidirectional=not bidirectional, match_fields=match_fields, attributes=attributes)
                
                if link_redundancy is not None:
                    protocol.add_attribute("LinkRedundancy", link_redundancy)

                flow_priority = self.gkft(row, "FlowPriority")
                flow_priority = self.get_int_from_value(flow_priority, default_value=2000)
                protocol.add_attribute("FlowPriority", flow_priority)

                set_queue = self.gkft(row, "SetQueue")
                set_queue = self.get_int_from_value(set_queue, default_value=2, range=range(0,4+1))
                protocol.add_attribute("SetQueue", set_queue)

                self.add_entry(protocol)

                associations = self.listify(self.gkft(row, "Associations"))
                for association in associations:
                    self.add_object_to_association(node=protocol, association=association)

            except Exception as e:
                if "Row " in str(e):
                    raise e
                else:                
                    self.add_error(e)
                #raise Exception("An error occured while processing protocol entry number {}".format(index+1))

        return self.entries

    def get_match_fields(self, entry_tuple, match_field_types=MATCH_FIELDS, node=None):
        match_fields = MatchFields()

        for index, match_field in enumerate(match_field_types):
            match_field_name = match_field.__name__[:-5]
            if entry_tuple.get(match_field_name, False):
                enty_tuple_value = self.gkft(entry_tuple, match_field_name)
                if match_field_name == "EthSrc":
                    node_object = self.get_node_from_name(enty_tuple_value)
                    match_field_value = enty_tuple_value
                    if node_object:
                        if isinstance(node_object, TwoMacDevice):
                            match_field_value = node_object.other_mac_address
                        else:
                            match_field_value = node_object.mac_address

                        if not match_field_value:
                            raise ValueError("{} does not have a MAC address".format(enty_tuple_value))
                elif match_field_name == "EthDst":
                    node_object = self.get_node_from_name(enty_tuple_value)
                    match_field_value = enty_tuple_value
                    if node_object:
                        match_field_value = node_object.mac_address

                        if not match_field_value:
                            raise ValueError("{} does not have a MAC address".format(enty_tuple_value))                        

                elif match_field_name == 'InPort':
                    raise ValueError("Cannot set the InPort for a protocol entry")
                elif match_field_name in ('VlanVid'):
                    match_field_value = enty_tuple_value
                    if match_field_value not in ('Present', 'None'):
                        match_field_value = int(match_field_value)
                elif match_field_name in ('VlanPcp',):
                    match_field_value = int(enty_tuple_value)
                elif match_field_name in ('Ipv4Src', "Ipv4Dst", "ArpTpa", "ArpSpa"):
                    tuple_value = self.gkft(entry_tuple, match_field_name)
                    node_object = self.get_node_from_name(tuple_value)
                    match_field_value = enty_tuple_value if not node_object else node_object.ip_address

                    if not match_field_value:
                        raise ValueError("{} does not have an IP address".format(enty_tuple_value))
                else:
                    match_field_value = enty_tuple_value
                
                if match_field.is_maskable():
                    mask_value = entry_tuple.get(match_field_name+'Mask', None)
                    if match_field_name in ('VlanVid') and mask_value and mask_value != 'Present':
                        mask_value = int(mask_value)

                    mask_value = None if not mask_value else mask_value
                    match_field_object = match_field(match_field_value, mask_value)
                else:
                    match_field_object = match_field(match_field_value)

                match_fields.add(match_field_object)

        return match_fields

    @property
    def associations(self):
        return self._associations
