from collections import defaultdict

from .entry_parser import EntryParser, COMMENTS_STARTS
from ...automation.connections import Connections
from ...openflow.core.actions import OutputAction
from ...automation.device import SEL274XSDevice, TraditionalSwitchDevice, OpenFlowDevice, SEL2742SDevice, SEL2740SDevice
from ...automation import DEVICE_PORT_SEPARATOR
from ...automation.port import Port

# assumes if there is multiple connections between switches, they maintain the same order
# as when if 9 and 10 on one switch connections to 11 and 12 on the other, 9 connections to 11 and never 9 to 12
class TopologyParser(EntryParser):
    def __init__(self, node_entries, raise_at_end=True, file_name=None):
        super().__init__(node_entries=node_entries, raise_at_end=raise_at_end, file_name=file_name)
        self._entries = Connections()
        self.start_switch = 0

    def get_row_value(self, row, port_number):
        if self.gkft(row, "P"+str(port_number)):
            return self.gkft(row, "P"+str(port_number))
        else:
            return self.gkft(row, str(OutputAction(port_number)))

    def get_next_switch(self):
        self.start_switch += 1
        return self.start_switch

    def create_entries(self, tuples):
        found_switches = defaultdict(dict)
        inner_error = False
        list_of_switch_names = dict()

        for index, row in enumerate(tuples):
            self.current_row_number = index + 2
            try:
                inner_error = False
                switch_name = self.gkft(row, "Switch")

                # Skip the line if comment
                if self.is_ignore_row(row, switch_name):
                    continue

                if switch_name in list_of_switch_names:
                    self.add_error("Switch with name {} already found on line {}".format(switch_name, list_of_switch_names[switch_name]))
                else:
                    list_of_switch_names[switch_name] = self.current_row_number

                if not switch_name:
                    self.add_error("Switch value empty")

                switch = self.get_node_from_name(switch_name)

                if not switch:
                    self.add_error("Unable to find switch with name {} in nodes".format(switch_name))

                if not isinstance(switch, OpenFlowDevice):
                    self.add_error("Switch must be an OpenFlow switch not type {}".format(switch.__class__.__name__))

                networks = self.listify(self.gkft(row, "Network"))

                if networks:
                    switch.add_networks(networks)

                for port in range(1, 20+1):

                    other_device_name = self.get_row_value(row, port)

                    # If there is nothing in the port, skip
                    if not other_device_name:
                        continue
                    try:
                        other_device_names = self.listify(other_device_name)
                        if len(other_device_names) > 1:
                            other_device_names = other_device_names
                            traditional_switch_name = "Traditional Switch {}".format(self.get_next_switch())
                            new_traditional_node = TraditionalSwitchDevice(name=traditional_switch_name, ports=len(other_device_names)+1, networks=networks)
                            self.node_entries.append(new_traditional_node)
                            self.add_node(new_traditional_node)
                            self.assign_port(other_device_name=new_traditional_node.name, switch=switch, port=port, found_switches=found_switches, networks=networks, referring_switch=switch, referring_port=port)
                            for other_port, other_device_name in enumerate(other_device_names):
                                self.assign_port(other_device_name=other_device_name, switch=new_traditional_node, port=other_port+2, found_switches=found_switches, networks=networks, referring_switch=switch, referring_port=port)
                        else:
                            self.assign_port(other_device_name=other_device_name, switch=switch, port=port, found_switches=found_switches, networks=networks, referring_switch=switch, referring_port=port)
                    except Exception as e:
                        #print("Aa", str(e))
                        if str(e)[:4] == "Row " or len(str(e).split(":")) > 1 and str(e).split(":")[1][0:5] == " Row ":
                            raise e
                        else:
                            inner_error = True
                            self.add_error(e)
            except Exception as e:
                #print("Bb", e, str(e)[:4] == "Row ", str(e)[:4])
                if str(e)[:4] == "Row " or len(str(e).split(":")) > 1 and str(e).split(":")[1][0:5] == " Row ":
                    raise e
                elif not inner_error:
                    self.add_error(e)

        try:
            self.resolve_found_switches(found_switches)
        except Exception as e:
            self.add_error(e)

        self.raise_all()

        return self.entries

    def assign_port(self, other_device_name, switch, port, found_switches, networks=None, referring_switch=None, referring_port=None):
        # Resolve device name to host
        #print("All", other_device_name, switch, port, found_switches, networks, referring_switch, referring_port)
        if DEVICE_PORT_SEPARATOR in other_device_name:
            other_port = self.get_port_from_name(other_device_name)
            if other_port:
                other_device = other_port.owner
            else:
                other_device, other_port = self.get_node_from_name(other_device_name), None
        else:
            other_device, other_port = self.get_node_from_name(other_device_name), None

        #print("After", other_device, other_port)
        
        if other_device:
            if isinstance(other_device, SEL274XSDevice) and other_port not in other_device.local_ports:
                #print("other", other_port not in other_device.local_ports)
                # Need to see if the SEL-2740S on the other end has been detected yet.
                # Why do I need to?
                resolved_switch_name = referring_switch.name if referring_switch else switch.name
                resolved_port = referring_port if referring_port else port
                if other_device.name in found_switches[resolved_switch_name]:
                    found_switches[resolved_switch_name][other_device.name].append([resolved_port, other_port])
                else:
                    found_switches[resolved_switch_name][other_device.name] = [[resolved_port, other_port]]
            else:
                if not other_port:
                    other_port = self.find_next_available_port(other_device, networks)
                    if not other_port:
                        end_port_prints = ", ".join([port.find_connected_openflow_switch_port().print_name for port in other_device.ports])
                        self.add_error("No empty port found for {} to connect to {}. There are a total of {} ports for the device already connected to {}.".format(other_device_name, ":".join([referring_switch.print_name, str(referring_port)]), len(other_device.ports), end_port_prints))
                        return False
                        #raise ValueError("No empty port found for {}. Confirm there are not too many connection in topology.".format(other_device_name))
                self.set_ports(switch_object=switch, switch_port=port, other_object=other_device, other_port=other_port)
                other_port.add_networks(networks)
        else:
            self.add_error("Cannot find {} in nodes".format(other_device_name))
            return False
            #raise ValueError("Cannot find {} in nodes".format(other_device_name))

        #print("A", port)
        #print("B", other_port)

    def find_next_available_port(self, other_device, networks):
        if networks:
            for network in networks:
                ports_in_network = other_device.get_ports_by_network(network)
                if ports_in_network:
                    for port in ports_in_network:
                        if not port.is_connected():
                            return port

        for other_device_port in other_device.ports:
            if not other_device_port.end:
                return other_device_port

    def set_ports(self, switch_object, switch_port, other_object, other_port):
        #print("set port", switch_object, switch_port, other_object, other_port, other_port.find_connected_openflow_switch_ports())
        if not isinstance(switch_port, Port):
            switch_port_object = switch_object.get_port(switch_port)
        else:
            switch_port_object = switch_port

        if not switch_port_object:
            if isinstance(switch_object, SEL2740SDevice):
                local_port_names = [str(port.name) for port in switch_object.local_ports]
                if local_port_names:
                    ending = ", " if len(local_port_names) > 1 else ", and "
                    ending += ", and ".join(local_port_names) + "."
                else:
                    ending = "."
                self.add_error("Switch {} does not have a port {} to connect with {} port {} because this SEL2740S switch has only ports 1-20{}".format(switch_object.name, switch_port, other_object.name, other_port.name, ending))
            elif isinstance(switch_object, SEL2742SDevice):
                local_port_names = [str(port.name) for port in switch_object.local_ports]
                if local_port_names:
                    ending = ", " if len(local_port_names) > 1 else ", and "
                    ending += ", and ".join(local_port_names) + "."
                else:
                    ending = "."
                self.add_error("Switch {} does not have a port {} to connect with {} port {} because this SEL2742S switches only have ports 1-12{}".format(switch_object.name, switch_port, other_object.name, other_port.name, ending))
            else:
                self.add_error("Unable to find port {} on switch {}".format(switch_port, switch_object.name))
        #print("set port2", switch_object, switch_port, other_object, other_port, other_port.find_connected_openflow_switch_ports())

        if other_port.end and switch_port in other_port.find_connected_openflow_switch_ports() and switch_port_object.end and other_port in switch_port_object.find_connected_openflow_switch_ports():
            return True

        #print("set port3", switch_object, switch_port, other_object, other_port, other_port.find_connected_openflow_switch_ports())


        if switch_port_object.end and isinstance(switch_port_object.end.owner, TraditionalSwitchDevice):
            traditional_switch = switch_port_object.end.owner
            for port in switch_port_object.end.owner.ports:
                if not port.end:
                    traditional_switch.set_port(port.name, other_port)
                    other_object.set_port(other_port.name, port)
                    self.entries.add_link(other_object.name, other_port.name, traditional_switch.name, port.name)
                    return

        #print("set port4", switch_object, switch_port, other_object, other_port, other_port.find_connected_openflow_switch_ports())

        if other_port.end is None:
            other_object.set_port(other_port, switch_port_object)
            switch_object.set_port(switch_port_object, other_port)
            self.entries.add_link(switch_object.name, switch_port_object.name, other_object.name, other_port.name)
        else:
            self.add_error("Trying to connect port {}:{} to {}:{} but it is already connected to {}:{}.".format(other_port.owner.name, other_port.name, switch_port_object.owner.name, switch_port_object.name, other_port.end.owner.name, other_port.name))
            #raise ValueError("Trying to connect port {}:{} to {}:{} but it is already connected to {}:{}.".format(other_port.owner.name, other_port.name, switch_port.owner.name, switch_port.name, other_port.end.owner.name, other_port.name))

        #print("O", other_object.get_port(other_port.name))
        #print("S", switch_object.get_port(switch_port.name))

    def resolve_found_switches(self, found_switches):
        found_switches = dict(found_switches)
        self.check_switch_to_switch_connections(found_switches)
        self.connect_found_switches(found_switches)

    def connect_found_switches(self, found_switches):
        for found_switch, other_switches in found_switches.items():
            for other_switch, ports in other_switches.items():
                for index, port_tuple in enumerate(ports):
                    port, right_port = port_tuple

                    left_switch = self.get_node_from_name(found_switch) #node_dict[found_switch_name]
                    left_port = left_switch.get_port(port)
                    right_switch = self.get_node_from_name(other_switch) #node_dict[other_switch_name]

                    #print("L", left_port)
                    #print("R", right_port)

                    if left_port.end and left_port.end.owner == right_switch:
                        continue

                    try:
                        if not right_port:
                            for right_port_tuple in found_switches[right_switch.name][left_switch.name]:
                                right_port_1, left_port_2 = right_port_tuple
                                if not left_port_2:
                                    right_port = right_switch.get_port(right_port_1)
                                    if not right_port.end:
                                        # Need to find out if this is connected to an assigned port
                                        break
                                else:
                                    if not left_port_2.end:
                                        right_port = right_switch.get_port(right_port_1)
                                        break
                            else:
                                raise ValueError("Inconsistent topology: {} port {} cannot be connected to switch {}".format(left_switch.name, left_port.name, right_switch.name))

                        if right_port.end:
                            if right_port.end == left_port:
                                continue
                            else:
                                args = (left_switch.name, left_port.name, right_switch.name, right_port.name, right_switch.name, right_port.name, right_port.end.owner.name, right_port.end.name)
                                raise ValueError("Could not connect {} port {} to {} port {} because {} port {} is already connected to {} port {}".format(*args))
                        
                        self.set_ports(switch_object=left_switch, switch_port=left_port, other_object=right_switch, other_port=right_port)
                    except KeyError as e:
                        self.add_error("Inconsistent topology: Check that the switch {} is connected to {} and vice versa".format(right_switch.name, left_switch.name))
                        #raise ValueError("Inconsistent topology: Check that the switch {} is connected to {} and vice versa".format(right_switch, left_switch))
                    except IndexError as e:
                        self.add_error("Inconsistent topology: Check that the switch {} is connected to {} and vice versa".format(right_switch.name, left_switch.name))
                        #raise ValueError("Inconsistent topology: Check that the switch {} is connected to {} and vice versa".format(right_switch, left_switch))

    def find_if_port_resolves_to_switch(self, found_switches, switch_name, port_number):
        if not found_switches.get(switch_name):
            #print("Switches", switch_name, port_number, found_switches)
            raise ValueError("Unable to find switch {} in found switches".format(switch_name))
        for other_switch, ports in found_switches[switch_name].items():
            for port in ports:
                if port[0] == port_number:
                    return other_switch, port[1]
        return None, None

    def check_switch_to_switch_connections(self, found_switches):
        for found_switch, other_switches in found_switches.items():
            for other_switch, ports in other_switches.items():
                for index, port_tuple in enumerate(ports):
                    port, right_port = port_tuple
                    if right_port:
                        # Need to check that right port is connect back
                        other_switch_of_port, other_port_of_port = self.find_if_port_resolves_to_switch(found_switches, right_port.owner.name, right_port.name)
                        if found_switch != other_switch_of_port:
                            args = (found_switch, port, right_port.owner.name, right_port.name, right_port.owner.name, right_port.name, other_switch_of_port, found_switch)
                            raise ValueError("Inconsistent topology: {} port {} is configured to connect to {} port {}, but {} port {} is connected to {} not {}".format(*args))
