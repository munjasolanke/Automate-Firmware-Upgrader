from collections import OrderedDict, ChainMap
from functools import partial

from ...openflow.core.flow_entry import FlowEntry
from ...openflow.core.group_entry import AllGroup, FastFailoverGroup, SelectGroup, IndirectGroup
from ...openflow.core.action_bucket import WatchPort, WatchGroup, ActionBucket
from ...openflow.core.actions import OutputAction, GroupAction, SetQueueAction, ACTIONS
from ...openflow.core.match_fields import MATCH_FIELDS, InPortMatch
from ...openflow.core.instructions import INSTRUCTIONS
from ...automation.device import SEL274XSDevice, SEL2740SDevice, SEL2742SDevice, Device, ControllerDevice, TwoMacDevice, TraditionalSwitchDevice
from ...automation.port import Port
from ...automation.application import UnicastApplication
from ...automation import DEVICE_PORT_SEPARATOR
from ...automation.policy import IDSMissPolicy, IDSPolicy

def create_protocol_entries(protocol_entries, include_attributes=None):
    rows = list()

    for protocol_entry in protocol_entries:
        row = dict()
        row['Name'] = '' if protocol_entry.name is None else protocol_entry.name
        row['Unidirectional'] = protocol_entry.unidirectional
        row['Unicast'] = protocol_entry.unicast

        for match_field in protocol_entry:
            match_field_name = match_field.__class__.__name__[:-5]
            match_field_value = str(match_field)

            row[match_field_name] = match_field_value

        add_included_attributes(include_attributes, row, protocol_entry)

        rows.append(row)
    return rows

def create_flow_entries(flow_entries, group_entries=None, include_attributes=None):
    rows = list()

    for flow_entry in flow_entries:
        row = create_flow_entry(flow_entry, group_entries=group_entries, include_attributes=include_attributes)
        rows.append(row)

    return rows

def create_flow_entry(flow_entry, group_entries=None, include_attributes=None):
    row = dict()

    row['Name'] = '' if flow_entry.name is None else flow_entry.name
    row['Node'] = flow_entry.node_name
    row['Priority'] = flow_entry.priority
    row['ID'] = flow_entry.entry_id
    row['Table'] = flow_entry.table_id
    
    for match_field in flow_entry.match_fields.values:
        match_field_name = match_field.__class__.__name__[:-5]
        match_field_value = str(match_field)

        row[match_field_name] = match_field_value

        if match_field.is_maskable() and match_field.mask:
            match_field_mask_name = match_field_name + 'Mask'
            row[match_field_mask_name] = match_field.mask

    if flow_entry.match_fields.get_attribute("Errors"):
        for match_field_error in flow_entry.match_fields.get_attribute("Errors"):
            row[match_field_error] = "???"

    for instruction in flow_entry.instructions.values:
        instruction_name = instruction.__class__.__name__[:-11]
        row[instruction_name] = instruction.value

    for action in flow_entry.actions.values:
        action_name = action.__class__.__name__[:-6]
        action_value = str(action)
        row[action_name] = action_value

    if flow_entry.actions.get_attribute("Errors"):
        for action_error in flow_entry.actions.get_attribute("Errors"):
            row[action_error] = "???"

        if isinstance(action, GroupAction) and group_entries:
            for group_entry in group_entries:
                if group_entry.node == flow_entry.node and group_entry.entry_id == action.value:
                    action_value = group_entry.name
                    break

            raise

        row[action_name] = action_value

    add_included_attributes(include_attributes, row, flow_entry)

    return row

def add_included_attributes(include_attributes, row, entry):
    if include_attributes:
        for name in include_attributes:
            if isinstance(entry.get_attribute(name), list):
                row[name] = ", ".join(entry.get_attribute(name))
            else:
                row[name] = entry.get_attribute(name)

def create_group_entries(group_entries, include_attributes=None):
    rows = list()

    for group_entry in group_entries:
        row = dict()
        row['Name'] = '' if group_entry.name is None else group_entry.name
        row['Node'] = group_entry.node if type(group_entry.node) is str else group_entry.node.name
        row['ID'] = group_entry.entry_id
        row['Type'] = group_entry.__class__.__name__[:-5]

        for name in include_attributes:
            row[name] = group_entry.get_attribute(name)

        if group_entry.action_buckets:
            for index, action_bucket in enumerate(group_entry.action_buckets):
                row["Bucket ID"] = index
                row['Watch Group'] = None if not action_bucket.watch_group or action_bucket.watch_group == WatchGroup().value else action_bucket.watch_group
                row['Watch Port'] = None if not action_bucket.watch_port or action_bucket.watch_port == WatchPort().value else action_bucket.watch_port
                for action in action_bucket.actions:
                    action_name = action.__class__.__name__[:-6]
                    # SEL-5056 doesn't accept explicit Drop
                    if action_name == "PopVlan":
                        row[action_name] = True
                    elif action_name != "Drop":
                        row[action_name] = str(action)

                add_included_attributes(include_attributes, row, group_entry)

                rows.append(row)
                row = dict()
                row['Name'] = '' if group_entry.name is None else group_entry.name
                row['Node'] = group_entry.node if type(group_entry.node) is str else group_entry.node.name
                row['ID'] = group_entry.entry_id
                row['Type'] = group_entry.__class__.__name__[:-5]
        else:
            rows.append(row)

    return rows

def create_meter_entries(entries, include_attributes=None):
    rows = list()

    for entry in entries:
        row = dict()
        row['Name'] = '' if entry.name is None else entry.name
        row['Node'] = entry.node if type(entry.node) is str else entry.node.name
        row['ID'] = entry.entry_id
        row["Measurement"] = entry.measurement_type
        row["Rate"] = entry.rate
        row["Burst Size"] = "" if not entry.burst_size else entry.burst_size

        add_included_attributes(include_attributes, row, entry)

        rows.append(row)

    return rows

def create_node_entries(node_entries, include_attributes=None):
    rows = list()

    for node_entry in node_entries:
        # Skip traditional switches
        if isinstance(node_entry, TraditionalSwitchDevice):
            continue
        
        row = dict()
        
        row['Name'] = node_entry.name

        if isinstance(node_entry, SEL274XSDevice):
            if isinstance(node_entry, SEL2740SDevice):
                row["Type"] = 'SEL2740S'
            elif isinstance(node_entry, SEL2742SDevice):
                row["Type"] = 'SEL2742S'
            
            row['Controller'] = node_entry.controller_ip
            row["NTP Servers"] = ",".join(node_entry.ntp_servers)
            row["PTP"] = node_entry.ptp_enable
            row["SNMP"] = node_entry.snmp_enable
        elif isinstance(node_entry, ControllerDevice):
            row['Type'] = "Controller"
        else:
            row['Type'] = 'Host'

        row['Mode'] = node_entry.mode

        add_included_attributes(include_attributes, row, node_entry)

        if not isinstance(node_entry, SEL274XSDevice):
            #row['Ports'] = ",".join(["'"+str(port.name)+"'" for port in node_entry.ports]
            if node_entry.mode == "PRP":
                if len(node_entry.ports) == 2:
                    row["Ports"] = 2
                    networks = list()
                    for n in node_entry.ports:
                        for network in n.networks:
                            if network not in networks:
                                networks.append(network)

                    row["Networks"] = ", ".join(networks)

                    ports_to_export = node_entry.ports[:1]
                else:
                    raise ValueError("Cannot be PRP and have {} ports. Must have 2".format(len(node_entry.ports)))
            else:
                ports_to_export = node_entry.ports

            for port in ports_to_export:
                port_row = dict()
                if port.ip_address:
                    port_row['IP Address'] = ", ".join(port.ip_addresses)
                    port_row['Subnet'] = port.subnet

                if port.mac_address:
                    port_row['MAC Address'] = str(port._mac_address)
                
                port_row['Gateway'] = port.default_gateway

                if not row.get("Networks"):
                    port_row["Networks"] = ",".join(port.networks)

                add_included_attributes(include_attributes, row, port)
                rows.append(ChainMap(port_row, row))
        else:
            row["IP Address"] = node_entry.ip_address
            row["Gateway"] = node_entry.default_gateway
            row["Subnet"] = node_entry.subnet
            row["Networks"] = ",".join(node_entry.networks)
            if node_entry.local_port.mac_address:
                row["MAC Address"] = str(node_entry.local_port._mac_address)
            rows.append(row)
    return rows

def create_topology_entries(node_entries, include_attributes=None):
    rows = list()
    switch_list = list()

    for node_entry in node_entries:
        if isinstance(node_entry, SEL274XSDevice):
            switch_list.append(node_entry)

    for switch in switch_list:
        row = dict()

        row['Switch'] = switch.name

        for port_number in range(1, 20+1):
            port_object = switch.get_port(port_number)
            if port_object and port_object.end:
                if isinstance(port_object.end.owner, TraditionalSwitchDevice):
                    end_devices = list()
                    for traditional_port in port_object.end.owner.ports:
                        if traditional_port.end and traditional_port.end.owner.name != switch.name:
                            end_devices.append(traditional_port.end.owner.name)
                    name = ", ".join(end_devices)
                else:
                    name = port_object.end.owner.name
            else:
                name = ''

            row["P{}".format(port_number)] = name

        add_included_attributes(include_attributes, row, switch)

        rows.append(row)

    return rows

def get_name_from_node(node):
    if type(node) is str:
        return node
    elif isinstance(node, Port):
        return DEVICE_PORT_SEPARATOR.join([node.owner.name, str(node.name)])
    else:
        return node.name

def create_application_entries_matrix(application_entries):
    matrix = OrderedDict()
    headers = set()
    for index, application in enumerate(application_entries):
        for destination in application.destinations:
            headers.add(destination.print_name)
            if matrix.get(application.source.print_name):
                if matrix[application.source.print_name].get(destination.print_name):
                    matrix[application.source.print_name][destination.print_name].append(application.protocol.name)
                else:
                    matrix[application.source.print_name][destination.print_name] = [application.protocol.name]
            else:
                matrix[application.source.print_name] = {destination.print_name: [application.protocol.name]}

    return matrix, headers

def create_application_entries(application_entries, include_attributes=None):
    rows = list()

    for index, application in enumerate(application_entries):
        row = OrderedDict()

        try:
            row['Name'] = application.name
            if not application.protocol:
                protocol_name = None
            elif application.protocol.name:
                protocol_name = application.protocol.name
            else:
                protocol_name = application.protocol.__class__.__name__
            row['Protocol'] = protocol_name
            row['Destination'] = get_name_from_node(application.destination) if isinstance(application, UnicastApplication) else ",".join([get_name_from_node(node) for node in application.destinations])
            row['Source'] = "" if not application.source else get_name_from_node(application.source)
            row['Priority'] = application.classification

            row['VID'] = None if not application.protocol else application.protocol.get("VlanVid")
            row['EthDst'] = None if not application.protocol else application.protocol.get("EthDst")

            policies_str = ''
            if application.policies:
                policy_list = list()
                for policy in application.policies:
                    policy_str = ""
                    if isinstance(policy, IDSPolicy):
                        policy_str += policy.destination.owner.name

                    if isinstance(policy, IDSMissPolicy):
                        policy_str += ":MISS:{}:{}".format(policy.vid, policy.strip)

                    policy_list.append(policy_str)

                policies_str = ", ".join(policy_list)

            row["Policies"] = policies_str

            add_included_attributes(include_attributes, row, application)
        except Exception as e:
            raise Exception("An error occured while processing application entry number {}".format(index))

        rows.append(row)

    return rows

def create_test_report(application_entries, node_entries, ids_names=None, include_attributes=None):
    if ids_names and not isinstance(ids_names, list):
        ids_names = [ids_names]
    elif ids_names is None:
        ids_names = list()

    rows = list()

    def get_node_object(name, node_entries):
        if isinstance(name, Device):
            return name
        elif node_entries.has_name(name):
            return node_entries.has_name(name)[0]
        else:
            return name

    def add_device_cells(row_dict, prefix, device, node_entries):
        def get_name(name, prefix):
            return "{} {}".format(prefix, name)

        name = partial(get_name, prefix=prefix)

        if isinstance(device, Device):
            device = device.name

        elif isinstance(device, str):
            raise ValueError("Received {} as a str not a device".format(device))

        devices = node_entries.has_name(device)
        if not devices:
            raise ValueError("Unable to find device with name {}".format(device))
        device = devices[0]

        new_row[name("")] = device.name
        new_row[name("IP Address")] = device.ip_address
        new_row[name("Subnet")] = device.subnet
        new_row[name("MAC Address")] = "" if not device.mac_address else ":".join([device.mac_address[0:2].upper(), device.mac_address[2:4].upper(), device.mac_address[4:6].upper(), device.mac_address[6:8].upper(), device.mac_address[8:10].upper(), device.mac_address[10:12].upper()])
        
        if isinstance(device, SEL274XSDevice):
            switch_port_owner_name = device.name
            switch_port_name = "Local"
        else:
            switch_port = device.port.find_connected_openflow_switch_port()

            if not switch_port:
                LOGGER.warning("There is no attached switch for {}".format(device.port))
                switch_port_name = "?"
                switch_port_owner_name = "?"
            else:                   
                switch_port_name = str(InPortMatch(switch_port.name))
                switch_port_owner_name = switch_port.owner.name

        new_row[name("Switch")] = switch_port_owner_name
        new_row[name("Port")] = switch_port_name

    for application_entry in application_entries:
        ids_for_row = None
        destinations = list()
        for destination in application_entry.destinations:
            destination_object = get_node_object(destination, node_entries)
            if destination_object.name not in ids_names:
                destinations.append(destination_object)
            else:
                ids_for_row = destination_object

        if application_entry.policies:
            ids_for_row = get_node_object(application_entry.policies[0].destination, node_entries)

        if application_entry.policies and isinstance(application_entry.policies[0], IDSMissPolicy) and not destinations:
            destinations = [get_node_object(application_entry.policies[0].destination, node_entries)]

        #source = application_entry.source
        source = get_node_object(application_entry.source, node_entries)

        for destination in destinations:
            new_row = dict()
            new_row["Name"] = application_entry.name
            if application_entry.get_attribute("Status"):
                new_row["Status"] = ", ".join(application_entry.get_attribute("Status"))
            #new_row["Classification"] = application_entry.classification
            add_device_cells(new_row, prefix="Source", device=source, node_entries=node_entries)
            add_device_cells(new_row, prefix="Destination", device=destination, node_entries=node_entries)

            if ids_for_row:
                new_row["IDS"] = ids_for_row if isinstance(ids_for_row, str) else ids_for_row.name

            protocol_entry = application_entry.protocol
            new_row["Protocol"] = protocol_entry.name
            new_row["Unicast"] = not protocol_entry.multicast
            new_row["Bidirectional"] = protocol_entry.bidirectional

            #new_row["FlowPriority"] = protocol_entry.get_attribute("FlowPriority", default_value=2000)
            #new_row["SetQueue"] = "" if protocol_entry.get_attribute("SetQueue") is None else protocol_entry.get_attribute("SetQueue")

            for match_field in protocol_entry.protocol_fields:
                new_row[match_field.__class__.__name__[:-5]] = "" if not str(match_field.value) else str(match_field)

            add_included_attributes(include_attributes, new_row, application_entry)

            rows.append(new_row)

    return rows

def create_flow_diff_report(diff_entries, group_entries=None, include_attributes=None):
    rows = list()

    for diff_entry in diff_entries:
        row = create_flow_entry(diff_entry, group_entries, include_attributes)
        row["Action"] = diff_entry.get_attribute("$synchronization_action")
        rows.append(row)

    return rows
