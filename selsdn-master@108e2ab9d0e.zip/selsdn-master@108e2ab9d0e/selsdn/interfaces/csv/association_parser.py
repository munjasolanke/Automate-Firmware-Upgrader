from . import LOGGER

from ...automation.associations import Associations
from .entry_parser import EntryParser, COMMENTS_STARTS

class AssociationParser(EntryParser):
    VALID_COLUMNS = ["name", "associations", "client associations", "server associations"]

    def __init__(self, raise_at_end=False, file_name=None):
        super().__init__(raise_at_end=raise_at_end, file_name=file_name)
        self.current_row_name = None
        self._entries = Associations()

    def create_entries(self, tuples):
        #self.type_translator = self.check_column_names(tuples[0])

        for index, entry_tuple in enumerate(tuples):
            #self.check_row_data(entry_tuple)
            
            row_name = None
            self.current_row_number = index + 2
            try:
                row_name = self.get_name_or_alias(entry_tuple)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(entry_tuple, row_name):
                    continue

                new_associations = either_associations = self.listify(self.gkft(entry_tuple, "Associations"))

                client_associations = self.listify(self.gkft(entry_tuple, "Client Associations"))
                for association in client_associations:
                    new_associations.append("_C$"+association)

                server_associations = self.listify(self.gkft(entry_tuple, "Server Associations"))
                for association in server_associations:
                    new_associations.append("_P$"+association)                

                self.entries.add_association(row_name, new_associations)

            except Exception as e:
                if "Row " in str(e):
                    raise e
                else:
                    # The exception is being raised by the add_error function
                    self.add_error(str(e))
        return self.entries
