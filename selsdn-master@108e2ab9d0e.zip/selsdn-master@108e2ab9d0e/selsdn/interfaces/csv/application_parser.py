from functools import partial
from collections import defaultdict
from re import search
from ipaddress import IPv4Network, IPv4Address, AddressValueError

from . import LOGGER
from .entry_parser import EntryParser, COMMENTS_STARTS
from ...base.collection import ApplicationCollection
from ...automation.policy import IDSPolicy, IDSMissPolicy
from ...automation.associations import Associations
from ...automation.host_profiles import HostProfiles
from ...automation import DEVICE_PORT_SEPARATOR
from ...automation.application import UnicastApplication, MulticastApplication
from ...automation.port import Port
from ...automation.device import Device
from ...automation.protocol import ArpProtocol, MMSProtocol, NTPProtocol, SVProtocol 
from ...automation.protocol import TelnetProtocol, HTTPSProtocol, HTTPProtocol, Ipv4Protocol
from ...automation.protocol import SNMPProtocol, PTPProtocol, GOOSEProtocol, DNP3TCPProtocol
from ...automation.protocol import SyslogProtocol, ICMPProtocol, TableMissProtocol
from .flow_parser import flow_entry_match_fields

from ...openflow.core.match_fields import MatchFields

class ApplicationParser(EntryParser):
    COLLECTION_TYPE = ApplicationCollection
    VALID_COLUMNS = ["ignore", "alias", "name", "priority", "protocol", "override arp", "destination", "destinations", "source", "classification", "vid", "policies", "networks", "comments"] + [x.lower() for x in flow_entry_match_fields.split(",")]

    def __init__(self, node_entries, protocol_entries=None, associations=None, host_profiles=None, raise_at_end=False, networks=None, ignore_disconnected=False, file_name=None, require_user_defined_protocols=False):
        super().__init__(node_entries=node_entries, raise_at_end=raise_at_end, file_name=file_name)
        self.associations = associations if associations else Associations()
        self.host_profiles = host_profiles if host_profiles else HostProfiles()
        self.protocol_entries = protocol_entries if protocol_entries else list()

        if protocol_entries and protocol_entries.associations:
            self.protocol_associations = protocol_entries.associations
        else:
            self.protocol_associations = Associations()

        self.current_row_name = None
        self.reserved_vids = list()
        self.networks = networks if networks else list()
        self.ignore_disconnected = ignore_disconnected
        self.require_user_defined_protocols = require_user_defined_protocols

    def get_node(self, node, required=True, source=True):
        if type(node) is str and source is False and self.associations.get("_P$"+node): # in self.host_profiles.responders:
            return [self.get_node(node) for node in self.associations.get("_P$"+node)]#self.host_profiles.responders["_P$"+node]]
        elif type(node) is str and source is False and self.associations.get("_C$"+node):# and "_C$"+node in self.host_profiles.requesters:
            self.add_error('Cannot reference a requester association as a destination')
        elif type(node) is str and source is True and self.associations.get("_C$"+node):# and "_C$"+node in self.host_profiles.requesters:
            return [self.get_node(node) for node in self.associations.get("_C$"+node)]
        elif type(node) is str and source is True and self.associations.get("_P$"+node):# and "_P$"+node in self.host_profiles.responders:
            self.add_error('Cannot reference a responding association as a source')
        elif type(node) is str and self.get_association(node):
            return [self.get_node(node) for node in self.get_association(node)]
        elif isinstance(node, Device):
            return node
        elif isinstance(node, Port):
            return node
        else:
            return super().get_node_from_name(node, required=True)

    def add_entry(self, application):
        is_valid = self.check_application(application)
        if is_valid:
            super().add_entry(application)
        else:
            LOGGER.warning("Skipping application {} because it is not valid".format(application))

    def check_application(self, application):
        if application.policies:
            for policy in application.policies:
                if isinstance(policy, IDSPolicy):
                    if application.source == policy.destination:
                        return False
                    #if len(application.destinations) == 1 and application.destinations[0] == policy.destination:
                    #   return False
        return True

    def _get_access_point_information(self, string):
        if search(r"^([^|]+)\|(.+)", string):
            ip_address, arp_addressing = search(r"^([^|]+)\|(.+)", string)
            if search(r"^([^/]/(.+)", ip_address):
                ip_address, ip_subnet = search(r"^([^/]/(.+)", ip_address)
            else:
                ip_subnet = None
        else:
            ip_address, ip_subnet, arp_address = string, None, None

        return ip_address, ip_subnet, arp_address

    def get_node_list(self, names, required=False, source=True):
        nodes = list()
        match_fields = list()
        port = None
        for name in names:
            node = None
            # TODO better check here
            if search(r"^([^[]+)\[([^]]+)\]", name):
                name, access_point_info = search(r"^([^[]+)\[([^]]+)\]", name).groups()
                ip_address, ip_subnet, arp_address = _get_access_point_information(access_point_info)
                if not ip_address:
                    raise ValueError("Access Point information must be of the form [X/Y|Z] where X (required) is the IPv4 address override, Y (optional) is the subnet, Z (optional) is the default gateway address), not {}".format(access_point_info))
                
                try:
                    if ip_subnet:
                        ip_address = IPv4Network("/".join([ip_address, ip_subnet]), strict=True)
                        if source:
                            new_match_field = Ipv4SrcMatch(str(ip_address.network_address), mask=str(ip_address.netmask))
                        else:
                            new_match_field = Ipv4DstMatch(str(ip_address.network_address), mask=str(ip_address.netmask))
                        match_fields.append(new_match_field)
                    else:
                        ip_address = IPv4Address(ip_address)
                        if source:
                            new_match_field = Ipv4SrcMatch(str(ip_address), mask=None)
                        else:
                            new_match_field = Ipv4DstMatch(str(ip_address), mask=None)
                        match_fields.append(new_match_field)

                    if arp_address:
                        if source:
                            new_match_field = ArpSpaMatch(str(arp_address))
                        else:
                            new_match_field = ArpTpaMatch(str(arp_address))
                        match_fields.append(new_match_field)

                except AddressValueError as e:
                    raise ValueError("Access Point information must be of the form [X/Y|Z] where X (required) is the IPv4 address override, Y (optional) is the subnet, Z (optional) is the default gateway address), not {}".format(access_point_info))

            if DEVICE_PORT_SEPARATOR in name:
                port = self.get_port_from_name(name, networkable=True)
                if port:
                    node = port
            else:
                node = self.get_node(name, True, source=source)

            if type(node) is list:
                nodes.extend(node)
            elif node is None and required:
                if port:
                    self.add_error("Cannot find port {}".format(name), exception_type=ValueError)
                    #raise ValueError("Cannot find port {}".format(name))
                else:
                    self.add_error("Cannot find node {}".format(name), exception_type=ValueError)
                    #raise ValueError("Cannot find node {}".format(name))
            elif node is None:
                LOGGER.warning("Cannot find a node/port with name {}".format(name))
                nodes.append(name)
            else:
                nodes.append(node)
        
        return nodes, match_fields

    def parse_networks(self, value):
        if not value:
            return list()
        elif "|" in value and "," in value:
            self.add_error("Can't have both | and , operators for Networks for {}".format(value), exception_type=ValueError)
        elif "&" in value:
            self.add_error("Unknown operator for Networks in {}".format(value), exception_type=ValueError)
        elif "," in value:
            return value.split(",")
        elif "|" in value:
            return value.split("|")
        else:
            return [value]

    def resolve_network(self, values, network, single=True):
        return_values = list()
        for value in values:
            if isinstance(value, Port) and value.is_in_network(network):
                return_values.append(value)
            elif isinstance(value, Device) and value.is_in_network(network):
                ports = value.get_ports_by_network(network)
                if len(ports) == 0:
                    LOGGER.info("Device {} has no ports in network {}".format(value, network))
                    continue
                    #raise ValueError("Device {} has no ports in network {}".format(value, network))
                else:
                    return_values.extend(ports)
            else:
                LOGGER.info("Port {} is not in network {}".format(value.name, network))
                #raise ValueError("Port {} is not in network {}".format(value.name, network))

        return return_values

    def filter_same_destinations(self, source, destinations):
        if type(source) is not list:
            source = [source]
        for source_port in source:
            if source_port in destinations:
                destinations.remove(source_port)
                LOGGER.info("Filtering out destination {} because also a source port".format(source_port))
        return destinations

    def filter_connected_to_the_same_switch_port(self, source, destinations, application_name):
        if self.ignore_disconnected:
            return destinations

        if type(source) is not list:
            sources = [source]
        else:
            sources = source

        connected_ports = list()

        for sub_source in sources:
            if isinstance(sub_source, Port):
                if sub_source.is_connected():
                    if sub_source.find_connected_openflow_switch_port():
                        connected_ports.append(sub_source.find_connected_openflow_switch_port())
            else:
                for port in sub_source.local_ports:
                    if port.is_connected():
                        if port.find_connected_openflow_switch_port():
                            connected_ports.append(port.find_connected_openflow_switch_port())

        if not connected_ports:
            raise ValueError("Source {} is not connected".format(source))

        # Only destinations that are connected to two different ports or if one port, a non-source port
        # Need to consider traditional switches
        filtered_destinations = list()

        def add_filtered_destination(destination):
            if destination not in filtered_destinations:
                filtered_destinations.append(destination)

        for destination in destinations:
            if isinstance(destination, Port) and destination.find_connected_openflow_switch_port() not in connected_ports:
                add_filtered_destination(destination)
            elif not isinstance(destination, Port):
                destination_connected_ports = []

                for port in destination.local_ports:
                    destination_connected_port = port.find_connected_openflow_switch_port()
                    if destination_connected_port:
                        # If connected, then need to see if there are multiple different connected ports or
                        # if the connected port is not the same as a source port
                        if port.find_connected_openflow_switch_port() not in connected_ports:
                            add_filtered_destination(destination)
                        elif destination_connected_ports and destination_connected_port not in destination_connected_ports:
                            add_filtered_destination(destination)
                        elif not destination_connected_ports:
                            destination_connected_ports.append(destination_connected_port)
                    else:
                        LOGGER.info("Skipping {} because not connected".format(port))
            
            if destination not in filtered_destinations:
                LOGGER.warning("Filtering out destination {} from application {} because it is singly attached and connected to the same OpenFlow switch port {} as the source {}".format(destination.print_name, self.current_row_name, ", ".join(map(str, [connected_port.print_name for connected_port in connected_ports])), ", ".join(map(str,[source.print_name for source in sources]))))

        return filtered_destinations

    def filter_unconnected(self, values, network=None):
        if self.ignore_disconnected:
            return values

        return_values = list()
        for value in values:
            if value.is_connected(network):
                return_values.append(value)
            else:
                if not network:
                    LOGGER.warning("Filtering %s from application %s because it is not connected", value.print_name, self.current_row_name)
                elif network in value.networks:
                    LOGGER.warning("Filtering %s from application %s because it is not connected to network %s", value.print_name, self.current_row_name, network)

        return return_values

    def _override_protocols_for_access_point(self, protocols, protocol_overrides):
        if protocol_overrides:
            new_protocols = list()
            for protocol in protocols:
                new_protocol = protocol.copy()
                for protocol_override in protocol_overrides:
                    if isinstance(protocol_override, ArpTpaMatch) or isinstance(protocol_override, ArpSpaMatch):
                        if isinstance(new_protocol, Ipv4Protocol):
                            if new_protocol.arp_protocol:
                                new_protocol.arp_protocol.override(protocol_override)
                            else:
                                arp_protocol = new_protocol.to_arp()
                                arp_protocol.override(protocol_override)
                                new_protocol.arp_protocol = arp_protocol
                        elif isinstance(protocol, ArpProtocol):
                            new_protocol.override(protocol_override)
                    else:
                        if isinstance(new_protocol, Ipv4Protocol):
                            new_protocol.override(protocol_override)
                        elif isinstance(protocol, ArpProtocol):
                            pass                       

                new_protocols.append(new_protocol)
        else:
            return protocols

    def create_entries(self, tuples):
        self.type_translator = self.check_column_names(tuples[0])

        for index, entry_tuple in enumerate(tuples):
            self.check_row_data(entry_tuple)
            row_name = None
            self.current_row_number = index + 2
            try:
                row_name = self.get_name_or_alias(entry_tuple)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(entry_tuple, row_name):
                    continue

                attributes = self.get_user_attributes_from_row(entry_tuple)

                application_name = row_name

                source_name = self.gkft(entry_tuple, "Source")
                
                if self.gkft(entry_tuple, "Classification"):
                    classification_name = "Classification"
                    classification = self.gkft(entry_tuple, classification_name)
                else:
                    classification_name = "Priority"
                    classification = self.get_int_from_value(self.gkft(entry_tuple, classification_name))

                if classification in ('',):
                    classification = None

                networks = self.gkft(entry_tuple, "Networks")
                networks = self.parse_networks(networks)
                
                # If none of the networks of the application is not in scope, skip
                if self.networks and networks:
                    for network in networks:
                        if network in self.networks:
                            break
                    else:
                        continue

                destination_name = self.gkft(entry_tuple, "Destination")
                if destination_name:
                    destination_names = self.listify(destination_name)
                    destinations, protocol_fields = self.get_node_list(destination_names, required=self.node_entries, source=False)
                else:
                    destinations = list()

                source_names = self.listify(source_name)
                sources, protocol_fields = self.get_node_list(source_names, required=self.node_entries, source=True)
                if None in sources:
                    self.add_error(ValueError("None in list of sources {}".format(sources)))
                    #raise ValueError("None in list of sources {}".format(sources))

                policies = self.gkft(entry_tuple, "Policies")
                if policies:
                    policies = self.listify(policies)
                    policies = [self.resolve_policy(policy) for policy in policies]
                else:
                    policies = list()

                if policies and len(sources) == 1:
                    for policy in policies:
                        if isinstance(policy, IDSPolicy) and policy.destination == sources[0]:
                            self.add_error(ValueError("If there is only one destination, the IDS can't be the source"))
                            #raise ValueError("If there is only one destination, the IDS can't be the source")

                #if policies and len(destinations) == 1:
                #   for policy in policies:
                #       if isinstance(policy, IDSPolicy) and policy.destination == destinations[0]:
                #           raise ValueError("If there is only one destination, the IDS can't be the destination")

                if len(sources) == 0:
                    self.add_error("No sources for application {}".format(application_name), exception_type=ValueError)
                    #raise ValueError("No sources for application {}".format(application_name))

                protocol_names = self.listify(self.gkft(entry_tuple, "Protocol"))
                protocols = self.get_protocols(protocol_names, entry_tuple)
                if protocol_fields:
                    protocols = self._override_protocols_for_access_point(protocols, protocol_fields)

                # Allow the user to override the default ARP behavior for single application lines
                if self.gkft(entry_tuple, "Override ARP"):
                    arp_protocol = self.get_protocols([self.gkft(entry_tuple, "Override ARP")])[0][1]
                else:
                    arp_protocol = None

                if networks:
                    for network in networks:
                        # If the network is not in scope from self.networks, then skip it
                        if self.networks and network not in self.networks:
                            continue
                        source_ports = self.resolve_network(sources, network)
                        if not source_ports:
                            LOGGER.warning("Skipping application {} because all of the source(s) {} do not belong to the given network {}, only {}".format(row_name, " ,".join([source.print_name for source in sources]), network, " ,".join(sources[0].networks)))
                            continue
                        source_ports = self.filter_unconnected(source_ports, network)
                        source_ports = self.combine_ports_by_owner(source_ports)
                        if not source_ports:
                            LOGGER.warning("Skipping application {} because the source(s) {} were all filtered out".format(row_name, " ,".join([source.print_name for source in sources])))
                            #continue
                        filtered_policies = self.filter_policies(policies, network)
                        for source_port in source_ports:
                            if isinstance(source_port, list):
                                print_source_ports = ", ".join([source_p.print_name for source_p in source_port])
                            else:
                                print_source_ports = source_port.print_name

                            if destinations:
                                destination_ports2 = self.resolve_network(destinations, network)
                                if not destination_ports2:
                                    LOGGER.warning("Skipping application {} from {} to {} because all of the destination(s) are not in the given network {}".format(row_name, print_source_ports, ", ".join([destination.print_name for destination in destinations]), network))
                                    continue
                                destination_ports = self.filter_unconnected(destination_ports2, network)
                                dp = destination_ports[::]
                                if not destination_ports:
                                    LOGGER.warning("Skipping application {} from {} to {} because all of the destinations are disconnected".format(row_name, print_source_ports, ", ".join([destination_p.print_name for destination_p in destination_ports2])))
                                    continue
                                new_destinations = self.filter_same_destinations(source_port, destination_ports)
                                if not new_destinations:
                                    LOGGER.warning("Skipping application {} from {} to {} because the sources are the same as the destinations".format(row_name, print_source_ports, ", ".join([destination_p.print_name for destination_p in dp])))
                                    continue
                                #new_destinations = self.combine_ports_by_owner(destination_ports)
                                new_destinations = self.filter_connected_to_the_same_switch_port(source_port, new_destinations, row_name)
                            else:
                                new_destinations = list()
                                destinations = list()
                            
                            if new_destinations or not destinations:
                                self.create_applications(application_name=application_name, protocols=protocols, destinations=new_destinations, source=source_port, classification=classification, policies=filtered_policies, attributes=attributes, arp_override=arp_protocol)
                            else:
                                if not isinstance(source_port, list):
                                    source_port = [source_port]
                                LOGGER.warning("Skipping application {} from {} because the destination(s) {} were filtered out".format(row_name, ", ".join([source_p.print_name for source_p in source_port]), ", ".join([destination.print_name for destination in destinations])))
                else:
                    sources = self.filter_unconnected(sources)
                    sources = self.combine_ports_by_owner(sources)
                    if not sources:
                        LOGGER.warning("Skipping application %s because all sources were filtered out", row_name)
                    else:
                        for source in sources:
                            new_destinations = self.filter_same_destinations(source, destinations)
                            if destinations and not new_destinations:
                                LOGGER.warning("Skipping application {} because all destinations were the same as sources".format(row_name))
                            new_destinations2 = self.filter_unconnected(new_destinations)
                            if new_destinations and not new_destinations2:
                                LOGGER.warning("Skipping application {} because all destinations were the same as sources or unconnected".format(row_name))
                            new_destinations = self.filter_connected_to_the_same_switch_port(source, new_destinations2, row_name)
                            if new_destinations or not destinations or (policies and isinstance(policies[0], IDSMissPolicy)):
                                self.create_applications(arp_override=arp_protocol, application_name=application_name, protocols=protocols, destinations=new_destinations, source=source, classification=classification, policies=policies, attributes=attributes)
                            else:
                                LOGGER.warning("Skipping application %s because all destination were filtered out", row_name)

            except Exception as e:
                if "Row " in str(e):
                    raise e
                else:
                    # The exception is being raised by the add_error function
                    self.add_error(str(e))
        return self.entries

    def combine_ports_by_owner(self, owners):
        # Need to combine ports that belong to the same owner.
        # I have already filtered networks so just need to combine as a list of list as necessary
        owner_to_ports = defaultdict(list)
        dont_apply = list()
        is_port_in_list = [isinstance(owner, Port) for owner in owners]
        if True in is_port_in_list:
            for owner in owners:
                if isinstance(owner, Port):
                    if owner.mode == "Failover":
                        owner_to_ports[owner.owner.name].append(owner)
                    else:
                        dont_apply.append(owner)
                else:
                    for port in owner.ports:
                        if port == None:
                            self.add_error("Unexpectedly found None in ports{}".format(ports))
                            #raise ValueError("None in ports {}", ports)
                        if port.mode == "Failover":
                            owner_to_ports[port.owner.name].append(port)
                        else:
                            dont_apply.append(port)
            return list(owner_to_ports.values()) + dont_apply
        else:
            return owners

    def create_applications(self, application_name, protocols, destinations, source, classification, policies, attributes, arp_override=None):
        for application_type, protocol in protocols:
            application_partial = partial(application_type, name=application_name, protocol=protocol, source=source, classification=classification, policies=policies, attributes=attributes)#, arp_protocol=override_arp)
            if application_type == UnicastApplication:
                if destinations:
                    combined_destinations = self.combine_ports_by_owner(destinations)
                    # One destination per application
                    for destination in combined_destinations:
                        application = application_partial(destination=destination)
                        LOGGER.info("Adding application %s", application)
                        if isinstance(application.protocol, Ipv4Protocol):
                            application.protocol.arp_protocol = arp_override
                        self.add_entry(application)
                else: # For explicit drop rule (an application with no destination)
                    application = application_partial(destination=None)
                    LOGGER.info("Adding application %s", application)
                    if isinstance(application.protocol, Ipv4Protocol):
                        application.protocol.arp_protocol = arp_override
                    self.add_entry(application)
            else:
                application = application_partial(destinations=destinations)
                LOGGER.info("Adding application %s", application)
                self.add_entry(application)

    def filter_policies(self, policies, network):
        filtered_policies = list()
        for policy in policies:
            if isinstance(policy, IDSPolicy):
                if isinstance(policy.destination, Device):
                    for port in policy.destination.ports:
                        if port.is_in_network(network):
                            new_policy = policy.copy(destination=port)
                            filtered_policies.append(new_policy)
                elif policy.destination.is_in_network(network):
                    filtered_policies.append(new_policy)
        return filtered_policies

    def resolve_policy(self, policy):
        if ":" in policy:
            policy_name, policy_arguments = policy.split(":", 1)
            policy_arguments = [p.strip() for p in policy_arguments.split(":")]
        else:
            policy_name, policy_arguments = policy, []

        policy_name = policy_name.strip()
        
        device = self.get_node(policy_name)
        if device:
            if policy_arguments:
                if policy_arguments[0].upper() == "MISS":
                    if len(policy_arguments) > 1:
                        if policy_arguments[1] == "":
                            vid = None
                        else:
                            vid = int(policy_arguments[1])
                            if vid in self.reserved_vids:
                                LOGGER.error("Unable to add table miss because VID {} already used for another application".format(vid))
                                self.add_error("Unable to add table miss because VID {} already used for another application".format(vid))
                            else:
                                self.reserved_vids.append(vid)

                        if len(policy_arguments) == 3:
                            strip = self.get_boolean_from_value(policy_arguments[2], default_value=False)
                        else:
                            strip = False
                    else:
                        vid = None
                        strip = False
                    return IDSMissPolicy(destination=device, name=policy_name, vid=vid, strip=strip)
                else:
                    self.add_error("Unknown IDS type argument {}".format(policy_arguments[0]), exception_type=TypeError)
            else:
                return IDSPolicy(destination=device, name=policy_name)
        else:
            self.add_error("Unknown device {} for policy".format(policy), exception_type=ValueError)
            #raise ValueError("Unknown device {} for policy".format(policy))

    def get_association(self, name):
        return self.associations.get_entry(name)

    def get_protocols(self, protocol_names, entry_tuple=None):
        protocols = list()
        for protocol_name in protocol_names:
            if self.protocol_associations.get_entry(protocol_name):
                for protocol_entry in self.protocol_associations.get_entry(protocol_name):
                    application_type = UnicastApplication if protocol_entry.unicast else MulticastApplication
                    protocols.append((application_type, protocol_entry))
            else:
                protocols.append(self.get_protocol(protocol_name, entry_tuple))
        return protocols

    def get_protocol(self, protocol_name, entry_tuple=None):
        for protocol_entry in self.protocol_entries:
            if protocol_entry.name == protocol_name:
                return UnicastApplication if protocol_entry.unicast else MulticastApplication, protocol_entry

        if self.require_user_defined_protocols or not entry_tuple:
            raise ValueError("Unable to find protocol {} in imported protocol list".format(protocol_name))
        else:
            vlan_vid = self.gkft(entry_tuple, "VID") if self.gkft(entry_tuple, "VID") else None
            eth_dst = self.gkft(entry_tuple, "EthDst") if self.gkft(entry_tuple, "EthDst") else None
            application_type = UnicastApplication
            name = protocol_name.upper()
            #protocol_fields = self.get_protocol_fields(entry_tuple)
            if name == "MMS":
                protocol = MMSProtocol()
            elif name == "HTTPS":
                protocol = HTTPSProtocol()
            elif name in ("NTP",):
                protocol = NTPProtocol()
            elif name.upper() == "TELNET":
                protocol = TelnetProtocol()
            elif name == "HTTP":
                protocol = HTTPProtocol()
            elif name in ("IPV4", "IP"):
                protocol = Ipv4Protocol()
            elif name == "SNMP":
                protocol = SNMPProtocol()
            elif name == "PTP":
                protocol = PTPProtocol(vlan_vid=vlan_vid)
                application_type = MulticastApplication
            elif name == "GOOSE":
                protocol = GOOSEProtocol(vlan_vid=vlan_vid, eth_dst=eth_dst)
                application_type = MulticastApplication
            elif name == "SV":
                protocol = SVProtocol(vlan_vid=vlan_vid, eth_dst=eth_dst)
                application_type = MulticastApplication
            elif name in ("DNP3/TCP", "DNP3", "DNP3TCP"):
                protocol = DNP3TCPProtocol()
            elif name == "SYSLOG":
                protocol = SyslogProtocol()
            elif name in ("ICMP", "PING"):
                protocol = ICMPProtocol()
            elif name == "TABLE MISS":
                protocol = TableMissProtocol()
                application_type = MulticastApplication
            elif name in ("ARP",):
                protocol = ArpProtocol()
            else:
                self.add_error("Unable to find protocol with name '{}' in default or imported protocol lists".format(protocol_name), exception_type=ValueError)
                #raise ValueError("Unable to find protocol with name '{}' in default or imported protocol lists".format(protocol_name))

            return application_type, protocol
