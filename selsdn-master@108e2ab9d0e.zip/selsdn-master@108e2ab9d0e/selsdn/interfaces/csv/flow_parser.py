from .entry_parser import EntryParser, COMMENTS_STARTS
from ...base.collection import FlowCollection
from ...openflow.core.flow_entry import FlowEntry
from ...openflow.core.match_fields import MATCH_FIELDS, MatchFields
from ...openflow.core.match_fields import ArpTpaMatch, ArpSpaMatch, ArpOpMatch, Ipv4SrcMatch, Ipv4DstMatch, IpProtoMatch
from ...openflow.core.match_fields import UdpDstMatch, UdpSrcMatch, TcpDstMatch, TcpSrcMatch, VlanVidMatch, EthTypeMatch, EthDstMatch, EthSrcMatch
from ...openflow.core.instructions import INSTRUCTIONS, GotoTableInstruction, Instructions, MeterInstruction, ClearActionsInstruction
from ...automation.device import SEL274XSDevice, Device, TwoMacDevice

flow_entry_match_fields = "InPort,EthDst,EthDstMask,EthSrc,EthSrcMask,EthType,VlanVid,VlanVidMask,VlanPcp,IpProto,Ipv4Src,Ipv4SrcMask,Ipv4Dst,Ipv4DstMask,TcpSrc,TcpDst,UdpSrc,UdpDst,ArpOp,ArpSpa,ArpSpaMask,ArpTpa,ArpTpaMask"
flow_entry_third_line = "Name,Node,ID,Table,Priority,IdleTimeout,HardTimeout," + flow_entry_match_fields + ",Output,Group,SetQueue,PushVlan,PopVlan,SetVlanVid,SetVlanPcp,GotoTable,Meter,ClearActions"
flow_entry_headers = flow_entry_third_line.split(',')

flow_entry_match_fields_v2 = "InPort,EthDst,EthDstMask,EthSrc,EthSrcMask,EthType,VlanVid,VlanVidMask,VlanPcp,Code,IpSrc,IpSrcMask,IpDst,IpDstMask,TUPortSrc,TUPortDst,Output,Group,SetQueue,PushVlan,PopVlan,SetVlanVid,SetVlanPcp,GotoTable,Meter,ClearActions"
flow_entry_third_line_v2 = "Name,Node,Type,ID,Table,Priority," + flow_entry_match_fields_v2
flow_entry_headers_v2 = flow_entry_third_line_v2.split(',')

OTHER_MATCH_FIELD_TYPES = [item for item in MATCH_FIELDS if item not in (EthTypeMatch, )]

class FlowEntryParser(EntryParser):
    COLLECTION_TYPE = FlowCollection

    def __init__(self, node_entries, group_entries, meter_entries=None, variables=None, perform_validation=True, raise_at_end=False, file_name=None):
        super().__init__(node_entries=node_entries, variables=variables, raise_at_end=raise_at_end, file_name=file_name)
        self._entries = FlowCollection(perform_validation=perform_validation)
        self._group_entries = group_entries
        self._meter_entries = meter_entries if meter_entries else list()
        self.perform_validation = perform_validation

    def create_entries(self, tuples):
        version = 2 if 'Type' in tuples[0] else 1
        for index, entry_tuple in enumerate(tuples):
            self.current_row_number = index + 2
            try:
                self.create_entry(entry_tuple, version)
            except Exception as e:
                self.add_error(str(e))
                # raise Exception("An error occured while processing flow entry number {}".format(index+1))

        return self.entries

    @property
    def meter_entries(self):
        return self._meter_entries

    def lookup_id_by_alias(self, alias, node):
        if not self.group_entries:
            self.add_error("Unable to resolve alias {} because no group entries".format(alias), exception_type=ValueError)
            #raise ValueError("No group entries found")

        if isinstance(node, Device):
            node = node.name

        for entry in self.group_entries:
            if type(entry.node) is str:
                if entry.node == node and entry.name == alias:
                    return entry
            else:
                if entry.node.name == node and entry.name == alias:
                    return entry
        else:
            self.add_error("Unable to resolve alias {} because no such group found in {}".format(alias, node), exception_type=ValueError)
            #raise ValueError("No such group {} in node {}".format(alias, node))

    @property
    def group_entries(self):
        return self._group_entries

    def resolve_attributes(self, entry_tuple, version):
        attributes = dict()

        for name in entry_tuple:
            if version == 2 and name in flow_entry_headers_v2:
                continue
            else:
                value = self.gkft(entry_tuple, name)
                if name == "Enabled":
                    if not value:
                        attributes["Enabled"] = True
                    elif type(value) is bool:
                        attributes["Enabled"] = value
                    elif type(value) is str and value.lower() in ("true", "false"):
                        value = True if value.lower() == "true" else False
                        attributes["Enabled"] = value
                    else:
                        self.add_error("Enabled value must be True or False not {} for value in column {}".format(value), name)
                        #raise ValueError("Enabled value must be True or False not {}".format(value))
                else:
                    attributes[name] = value

        return attributes

    def create_entry(self, entry_tuple, version):
        row_name = self.get_name_or_alias(entry_tuple)
        self.current_row_name = row_name

        # Check if need to ignore this line
        if self.is_ignore_row(entry_tuple, row_name):
            return

        node_value = self.gkft(entry_tuple, "Node")
        attributes = self.resolve_attributes(entry_tuple, version)
        nodes = self.listify(node_value)
        entry_id = self.get_int_from_value(self.gkft(entry_tuple, "ID"), default_value=0)

        if version == 1:
            entry_types = ('',)
        elif version == 2:
            if self.gkft(entry_tuple, "Type"):
                type_value = self.gkft(entry_tuple, "Type")
                entry_types = self.listify(type_value)
            elif self.gkft(entry_tuple, "IpSrc") or self.gkft(entry_tuple, "IpDst"):
                entry_types = ('IP','ARP')
                # TODO check that the Ethtype is correct
            else:
                entry_types = ('L2',)

        for entry_type in entry_types:
            for node in nodes:
                node = node if self.get_node_from_name(node) else node
                table_id = 0 if not self.gkft(entry_tuple, "Table") else int(self.gkft(entry_tuple, "Table"))
                priority = 1000 if not self.gkft(entry_tuple, "Priority") else int(self.gkft(entry_tuple, "Priority"))
                joined_name = " ".join([row_name, entry_type]) if entry_type else row_name
                entry = FlowEntry(name='' if not row_name else joined_name, node=node, entry_id=entry_id, table_id=table_id, priority=priority, attributes=attributes)

                if version == 1:
                    match_fields = self.create_match_fields(entry_tuple, node=node)
                elif version == 2:
                    match_fields = self.create_match_fields_v2(entry_tuple, flow_type=entry_type, single=True if len(entry_types)==1 else False, node=node)

                entry.match_fields = match_fields
                entry.instructions = self.create_instructions(entry_tuple)
                entry.actions = self.create_actions(entry_tuple, node=node)
                self.add_entry(entry)

    def create_match_fields_v2(self, entry_tuple, flow_type, single=True, node=None):
        match_fields = MatchFields()
        flow_type = flow_type.lower()

        if flow_type in ('l2', 'layer2'):
            if self.gkft(entry_tuple, "EthType"):
                tuple_value = self.gkft(entry_tuple, "EthType")
                match_field = EthTypeMatch(value=tuple_value)
                match_fields.add(match_field)
            if self.gkft(entry_tuple, "IpSrc") or self.gkft(entry_tuple, "IpDst"):
                self.add_error("For Layer 2, no IP addresses allowed in row", exception_type=ValueError)
                #raise ValueError("For Layer 2, no IP addresses allowed")

        elif flow_type == 'arp':
            match_field = EthTypeMatch("ARP")
            match_fields.add(match_field)
            if self.gkft(entry_tuple, "IpSrc"):
                tuple_value = self.gkft(entry_tuple, "IpSrc")
                node_object = self.get_node_from_name(tuple_value)
                value = tuple_value if not node_object else node_object.ip_address
                match_field = ArpSpaMatch(value, self.gkft(entry_tuple, "IpSrcMask"))
                match_fields.add(match_field)
            if self.gkft(entry_tuple, "IpDst"):
                tuple_value = self.gkft(entry_tuple, "IpDst")
                node_object = self.get_node_from_name(tuple_value)
                value = tuple_value if not node_object else node_object.ip_address
                match_field = ArpTpaMatch(value, self.gkft(entry_tuple, "IpDstMask"))
                match_fields.add(match_field)
            if self.gkft(entry_tuple, "Code"):
                tuple_value = self.gkft(entry_tuple, "Code")
                match_field = ArpOpMatch(tuple_value)
                match_fields.add(match_field)
            if single and (self.gkft(entry_tuple, "TUPortSrc") or self.gkft(entry_tuple, "TUPortDst")):
                self.add_error("For ARP Flow entry type, TU ports must be blank", exception_type=ValueError)
                #raise ValueError("For ARP Flow entry type, TU ports must be blank")

        elif flow_type in ('ip', 'udp', 'tcp'):
            match_field = EthTypeMatch("IPv4")
            match_fields.add(match_field)
            if self.gkft(entry_tuple, "IpSrc"):
                tuple_value = self.gkft(entry_tuple, "IpSrc")
                node_object = self.get_node_from_name(tuple_value)
                value = tuple_value if not node_object else node_object.ip_address
                match_field = Ipv4SrcMatch(value, self.gkft(entry_tuple, "IpSrcMask"))
                match_fields.add(match_field)
            if self.gkft(entry_tuple, "IpDst"):
                tuple_value = self.gkft(entry_tuple, "IpDst")
                node_object = self.get_node_from_name(tuple_value)
                value = tuple_value if not node_object else node_object.ip_address
                match_field = Ipv4DstMatch(value, self.gkft(entry_tuple, "IpDstMask"))
                match_fields.add(match_field)
            if self.gkft(entry_tuple, "Code"):
                tuple_value = self.gkft(entry_tuple, "Code")
                match_field = IpProtoMatch(tuple_value)
                match_fields.add(match_field)

            if flow_type == 'ip':
                if self.gkft(entry_tuple, "TUPortSrc") or self.gkft(entry_tuple, "TUPortDst"):
                    self.add_error("For IP Flow entry type, TU ports must be blank, use UDP or TCP for type instead", exception_type=ValueError)
                    #raise ValueError("For IP Flow entry type, TU ports must be blank, use UDP or TCP for type instead")
            elif flow_type == 'udp':
                if self.gkft(entry_tuple, "TUPortSrc"):
                    tuple_value = self.gkft(entry_tuple, "TUPortSrc")
                    match_field = UdpSrcMatch(tuple_value)
                    match_fields.add(match_field)
                if self.gkft(entry_tuple, "TUPortDst"):
                    tuple_value = self.gkft(entry_tuple, "TUPortDst")
                    match_field = UdpDstMatch(tuple_value)
                    match_fields.add(match_field)
                if self.gkft(entry_tuple, "Code") and self.gkft(entry_tuple, "Code") != 17:
                    self.add_error("UDP IpProtocol (Code) must be 17 or UDP", exception_type=ValueError)
                    #raise ValueError("UDP IpProtocol (Code) must be 17")
            elif flow_type == 'tcp':
                if self.gkft(entry_tuple, "TUPortSrc"):
                    tuple_value = self.gkft(entry_tuple, "TUPortSrc")
                    match_field = TcpSrcMatch(tuple_value)
                    match_fields.add(match_field)
                if self.gkft(entry_tuple, "TUPortDst"):
                    tuple_value = self.gkft(entry_tuple, "TUPortDst")
                    match_field = TcpDstMatch(tuple_value)
                    match_fields.add(match_field)
                if self.gkft(entry_tuple, "Code") and self.gkft(entry_tuple, "Code") != 6:
                    self.add_error("UDP IpProtocol (Code) must be 6", exception_type=ValueError)
                    #raise ValueError("UDP IpProtocol (Code) must be 6")
        else:
            self.add_error("Type must be ARP, IP, UDP, or TCP, not {}".format(flow_type), exception_type=ValueError)
            #raise ValueError("Type must be ARP, IP, UDP, or TCP, not {}".format(flow_type))

        other_match_fields = self.create_match_fields(entry_tuple=entry_tuple, match_field_types=OTHER_MATCH_FIELD_TYPES, node=node, other_match_fields=match_fields)
        for match_field in other_match_fields.values:
            match_fields.add(match_field)

        return match_fields

    def create_match_fields(self, entry_tuple, match_field_types=MATCH_FIELDS, node=None, other_match_fields=None):
        match_fields = MatchFields()

        for index, match_field in enumerate(match_field_types):
            match_field_name = match_field.__name__[:-5]
            if entry_tuple.get(match_field_name, False):
                enty_tuple_value = self.gkft(entry_tuple, match_field_name)
                if match_field_name == "EthSrc":
                    node_object = self.get_node_from_name(enty_tuple_value)
                    match_field_value = enty_tuple_value
                    if node_object:
                        match_field_value = node_object.mac_address
                        if other_match_fields.get(EthTypeMatch) and other_match_fields.get(EthTypeMatch) == EthTypeMatch("GOOSE") and isinstance(node_object, TwoMacDevice):
                            match_field_value = node_object.other_mac_address
                elif match_field_name == "EthDst":
                    node_object = self.get_node_from_name(enty_tuple_value)
                    match_field_value = enty_tuple_value
                    if node_object:
                        match_field_value = node_object.mac_address
                elif match_field_name == 'InPort':
                    match_field_value = enty_tuple_value
                    node_object = self.get_node_from_name(match_field_value)
                    if node_object:
                        if isinstance(node_object, SEL274XSDevice):
                            if node_object.name == node:
                                match_field_value = "Local"
                            else:
                                current_node_object = self.get_node_from_name(node, required=True)
                                match_field_value = self.resolve_port(node_object=current_node_object, value=node_object.name)
                                if not match_field_value:
                                    self.add_error("There is no connection found for {} from {}. Check topology.".format(node_object.name, node), exception_type=ValueError)
                                    #raise ValueError("There is no connection found for {} from {}. Check topology.".format(node_object.name, node))
                        else:
                            try:
                                # Need to find the end device from the switch to get the switch port that connects to it
                                switch_object = self.get_node_from_name(node, required=True)
                                match_field_value = self.resolve_port(node_object=switch_object, value=match_field_value)
                                #match_field_value = node_object.ports[0].end.name
                            except AttributeError:
                                self.add_error("There is no connection found for {}. Check topology.".format(node), exception_type=ValueError)
                                #raise ValueError("There is no connection found for {}. Check topology.".format(node))
                    #else:
                    #    self.add_error("Unable to find port or device with name {}".format(match_field_value))
                elif match_field_name in ('VlanVid'):
                    match_field_value = enty_tuple_value
                    if match_field_value not in ('Present', 'None'):
                        match_field_value = int(match_field_value)
                elif match_field_name in ('VlanPcp',):
                    match_field_value = int(enty_tuple_value)
                else:
                    match_field_value = enty_tuple_value
                
                if match_field.is_maskable():
                    mask_value = entry_tuple.get(match_field_name+'Mask', None)
                    if match_field_name in ('VlanVid') and mask_value and mask_value != 'Present':
                        mask_value = int(mask_value)

                    mask_value = None if not mask_value else mask_value
                    try:
                        match_field_object = match_field(match_field_value, mask_value)
                    except Exception as e:
                        self.add_error("Value {} and mask {} is not valid for match field {}".format(match_field_value, mask_value, match_field_name))
                else:
                    try:
                        match_field_object = match_field(match_field_value)
                    except Exception as e:
                        self.add_error("Value {} is not valid for match field {}".format(match_field_value, match_field_name))

                match_fields.add(match_field_object)

        return match_fields

    def create_instructions(self, entry_tuple):
        instructions = Instructions()

        for instruction in INSTRUCTIONS[:-1]:
            instruction_name = instruction.__name__[:-11]
            if entry_tuple.get(instruction_name, False):
                instruction_object = self.create_instruction(instruction_name, entry_tuple.get(instruction_name), node_name=entry_tuple.get("Node"))
                if instruction_object:
                    instructions.add(instruction_object)

        return instructions

    def get_meter_from_name(self, name, node_name):
        for meter_entry in self.meter_entries:
            if meter_entry.node_name == node_name and meter_entry.name == name:
                return meter_entry
        else:
            return None

    # @todo other instructions
    def create_instruction(self, instruction_name, value, node_name):
        if instruction_name == 'GotoTable':
            return GotoTableInstruction(int(value))
        elif instruction_name == 'Meter':
            meter_entry = self.get_meter_from_name(value, node_name)
            if meter_entry:
                return MeterInstruction(meter_entry.entry_id)
            else:
                return MeterInstruction(int(value))
        elif instruction_name == "ClearActions":
            if value.lower() not in "false":
                return ClearActionsInstruction()
            else:
                return None
        else:
            self.add_error("Unknown type {}".format(instruction_name), exception_type=TypeError)
            #raise TypeError("Unknown type {}".format(instruction_name))
