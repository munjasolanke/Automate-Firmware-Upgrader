from collections import defaultdict

from .entry_parser import EntryParser, COMMENTS_STARTS
from ...base.collection import MeterCollection
from ...openflow.core.meter_entry import MeterEntry

class MeterParser(EntryParser):
    COLLECTION_TYPE = MeterCollection

    def create_entries(self, rows):
        found_switches = defaultdict(dict)

        for index, row in enumerate(rows):
            self.current_row_number = index + 1
            try:
                row_name = self.get_name_or_alias(row)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(row, row_name):
                    continue

                switch_names = self.listify(self.gkft(row, "Node"))

                for switch_name in switch_names:
                    switch = self.get_node_from_name(switch_name)
                    if not switch:
                        switch = switch_name
                    entry_id = int(self.gkft(row, "ID"))
                    measurement_type = self.gkft(row, "Measurement").lower()
                    rate = int(self.gkft(row, "Rate"))
                    burst_size = int(self.gkft(row, "Burst Size")) if self.gkft(row, "Burst Size") else 0

                    enabled = self.get_boolean_from_value(self.gkft(row, "Enabled"), default_value=True)

                    new_meter_entry = MeterEntry(name=row_name, node=switch, entry_id=entry_id, measurement_type=measurement_type, rate=rate, burst_size=burst_size, attributes={"Enabled": enabled})
                    self.add_entry(new_meter_entry)
            except Exception as e:
                self.add_error(e)
                #raise Exception("An error occured while processing topology entry number {}".format(index+1))

        return self.entries
