from .entry_parser import EntryParser
from ...automation.host_profiles import HostProfiles

class HostProfileParser(EntryParser):
    def __init__(self, file_name, raise_at_end=False):
        super().__init__(raise_at_end=raise_at_end, file_name=file_name)
        self._entries = HostProfiles()
        self._entries.errors = dict()

    def create_entries(self, rows):
        for index, row in enumerate(rows):
            self.current_row_number = index + 2
            try:
                row_name = self.gkft(row, "Profile")
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(row, row_name):
                    continue

                if row_name in (None, ""):
                    raise ValueError("Host profiles must have the column Profile instead of Name")

                if not self.entries.get(row_name):
                    self.entries[row_name] = row
                else:
                    raise ValueError("Host Profile with name {} already found".format(row_name))
            except Exception as e:
                self.add_error(e)
