from collections import OrderedDict
from collections import namedtuple
from csv import DictReader

from ._export import export_entries, export_flow_entries, export_group_entries, export_node_entries, export_topology, export_application_entries, export_flow_entries_v2, export_test_cases, export_switch_parameters, export_protocol_entries, export_meter_entries, export_application_entries_matrix
from .flow_parser import FlowEntryParser
from .group_parser import GroupEntryParser
from .meter_parser import MeterParser
from .application_parser import ApplicationParser
from .node_parser import NodeParser
from .topology_parser import TopologyParser
from .protocol_parser import ProtocolParser
from .association_parser import AssociationParser
from .host_profile_parser import HostProfileParser
from .log_parser import LogParser


class CSVInterface:
    @property
    def ALL_PARSERS(self):
        return [self.import_association_entries, self.import_host_profiles, 
                self.import_node_entries, self.import_topology, self.import_protocol_entries,
                self.import_meter_entries, self.import_application_entries,
                self.import_group_entries, self.import_flow_entries,
                self.import_log_entries]

    @property
    def PARSER_DICT(self):
        return {self.import_association_entries: "associations",
        self.import_host_profiles: "profiles", self.import_node_entries: "nodes",
        self.import_topology: "topology", self.import_protocol_entries: "protocols",
        self.import_meter_entries: "protocols", self.import_meter_entries: "meters",
        self.import_application_entries: "applications", self.import_group_entries: "groups",
        self.import_flow_entries: "flows", self.import_log_entries: "loggers"}
    
    def _determine_csv_parser(self, first_line_headers):
        if first_line_headers[0] == "switch":
            return self.import_topology
        elif "protocol" in first_line_headers:
            return self.import_application_entries
        elif "node" in first_line_headers and "type" in first_line_headers:
            if "watch port" in first_line_headers or "watch group" in first_line_headers:
                return self.import_group_entries
            else:
                return self.import_flow_entries
        elif "node" in first_line_headers and "table" in first_line_headers:
            return self.import_flow_entries
        elif "profile" in first_line_headers:
            return self.import_host_profiles
        elif "unicast" in first_line_headers or "bidirectional" in first_line_headers:
            return self.import_protocol_entries
        elif "chassis and module" in first_line_headers:
            return self.import_log_entries
        elif "ip address" in first_line_headers or "ports" in first_line_headers:
            return self.import_node_entries
        elif "measurement" in first_line_headers:
            return self.import_meter_entries
        elif len(first_line_headers) <= 6 and False not in ["associations" in x or "name" in x or "comment" in x or "ignore" in x or "alias" in x for x in first_line_headers]:
            return self.import_association_entries
        else:
            raise ValueError("Unknown file type for {}".format(file_name))

    def convert_parser_to_friendly_name(self, parser):
        if self.PARSER_DICT.get(parser):
            return self.PARSER_DICT[parser]
        else:
            raise ValueError("Unknown parser type {}".format(parser))

    def convert_friendly_name_to_parser(self, friendly_name):
        for parser, name in self.PARSER_DICT.items():
            if name == friendly_name:
                return parser
        else:
            raise ValueError("Unknown parser type {}".format(parser))

    def determine_csv_parser(self, file_name):
        with open(file_name) as entry_stream:
            first_line = entry_stream.readline()
            first_line_headers = [value.strip().lower() for value in first_line.split(",")]
            return self._determine_csv_parser(first_line_headers)        

    def import_entries(self, *file_names, networks=None, raise_at_end=False, ignore_disconnected=False, require_user_defined_protocols=False):
        parsers = OrderedDict()
        for file_name in file_names:
            parser = self.determine_csv_parser(file_name)
            if parsers.get(parser):
                parsers[parser].append(file_name)
            else:
                parsers[parser] = [file_name]

        kwargs = {"networks": networks, "raise_at_end": raise_at_end, "ignore_disconnected":ignore_disconnected, "require_user_defined_protocols": require_user_defined_protocols}
        for parser, file_names in parsers.items():
            friendly_name = self.convert_parser_to_friendly_name(parser)
            kwargs[friendly_name] = file_names

        results = self.import_entries_by_file_type(**kwargs)

        entry_list = list()
        friendly_names = list()
        for parser in parsers:
            friendly_name = self.convert_parser_to_friendly_name(parser)
            friendly_names.append(friendly_name)
            entry_list.append(getattr(results, friendly_name))

        if len(parsers) == 0:
            return None
        elif len(parsers) == 1:
            return entry_list[0]
        else:
            collection_tuple = namedtuple("NetworkCollection", friendly_names)
            for parser in self.ALL_PARSERS:
                if self.convert_parser_to_friendly_name(parser) not in friendly_names:
                    setattr(collection_tuple, self.convert_parser_to_friendly_name(parser), None)

            return collection_tuple(*entry_list)

    def import_entries_by_file_type(self, nodes=None, topology=None, protocols=None, 
                applications=None, profiles=None, associations=None,
                flows=None, groups=None, meters=None, loggers=None,
                networks=None, raise_at_end=False, ignore_disconnected=False, require_user_defined_protocols=False):

        def get_file_names_from_argument(file_names):
            if not file_names:
                return list()
            elif isinstance(file_names, str):
                return [file_names]
            elif isinstance(file_names, list):
                return file_names
            else:
                raise TypeError("Don't know how to deal with argument of type {]".format(type(file_names)))

        entry_types = dict()

        # Added in defaults
        for entry_type in self.ALL_PARSERS:
            entry_types[entry_type] = None

        association_entries = None
        for file_name in get_file_names_from_argument(associations):
            association_entries = self.import_association_entries(file_name, raise_at_end=raise_at_end)
            if entry_types.get(import_association_entries):
                entry_types[self.import_association_entries] += association_entries
                association_entries = entry_types[self.import_association_entries]
            else:
                entry_types[self.import_association_entries] = association_entries

        for file_name in get_file_names_from_argument(loggers):
            entries = self.import_log_entries(file_name, raise_at_end=raise_at_end)
            if entry_types.get(import_log_entries):
                entry_types[self.import_log_entries] += entries
                entries = entry_types[self.import_log_entries]
            else:
                entry_types[self.import_log_entries] = entries

        for file_name in get_file_names_from_argument(profiles):
            entries = self.import_host_profiles(file_name, raise_at_end=raise_at_end)
            if entry_types.get(self.import_host_profiles):
                entry_types[self.import_host_profiles] += entries
            else:
                entry_types[self.import_host_profiles] = entries

        for file_name in get_file_names_from_argument(nodes):
            entries = self.import_node_entries(file_name, host_profiles=entry_types[self.import_host_profiles], loggers=entry_types[self.import_log_entries], associations=association_entries, raise_at_end=raise_at_end)
            if entry_types.get(self.import_node_entries):
                entry_types[self.import_node_entries] += entries
                association_entries = entry_types[self.import_node_entries].associations
            else:
                entry_types[self.import_node_entries] = entries
                association_entries = entry_types[self.import_node_entries].associations

        for file_name in get_file_names_from_argument(topology):
            entries = self.import_topology_entries(file_name, node_entries=entry_types[self.import_node_entries], raise_at_end=raise_at_end)
            entry_types[self.import_topology_entries] = entries

        for file_name in get_file_names_from_argument(protocols):
            entries = self.import_protocol_entries(file_name, node_entries=entry_types[self.import_node_entries], raise_at_end=raise_at_end)
            if entry_types.get(self.import_protocol_entries):
                entry_types[self.import_protocol_entries] += entries
            else:
                entry_types[self.import_protocol_entries] = entries

        for file_name in get_file_names_from_argument(applications):
            entries = self.import_application_entries(file_name, node_entries=entry_types[self.import_node_entries], protocol_entries=entry_types[self.import_protocol_entries], association_entries=association_entries, raise_at_end=raise_at_end, networks=networks, ignore_disconnected=ignore_disconnected, require_user_defined_protocols=require_user_defined_protocols)
            if entry_types.get(self.import_application_entries):
                entry_types[self.import_application_entries] += entries
            else:
                entry_types[self.import_application_entries] = entries

        for file_name in get_file_names_from_argument(meters):
            entries = self.import_meter_entries(file_name, node_entries=entry_types[self.import_node_entries], raise_at_end=raise_at_end)
            if entry_types.get(self.import_meter_entries):
                entry_types[self.import_meter_entries] += entries
            else:
                entry_types[self.import_meter_entries] = entries

        for file_name in get_file_names_from_argument(groups):
            entries = self.import_group_entries(file_name, node_entries=entry_types[self.import_node_entries], raise_at_end=raise_at_end)
            if entry_types.get(self.import_group_entries):
                entry_types[self.import_group_entries] += entries
            else:
                entry_types[self.import_group_entries] = entries

        for file_name in get_file_names_from_argument(flows):
            entries = self.import_flow_entries(file_name, group_entries=entry_types[self.import_group_entries], meter_entries=entry_types[self.import_meter_entries], node_entries=entry_types[self.import_node_entries], raise_at_end=raise_at_end)
            if entry_types.get(self.import_flow_entries):
                entry_types[self.import_flow_entries] += entries
            else:
                entry_types[self.import_flow_entries] = entries

        if networks and entry_types.get(self.import_node_entries):
            errors = entry_types[self.import_node_entries].errors
            entry_types[self.import_node_entries] = entry_types[self.import_node_entries].is_in_networks(networks)
            entry_types[self.import_node_entries].errors = errors          

        entry_list = list()
        friendly_names = []
        for parser in self.ALL_PARSERS:
            friendly_name = self.convert_parser_to_friendly_name(parser)
            friendly_names.append(friendly_name)
            results = entry_types.get(parser)
            entry_list.append(results)
        collection_tuple = namedtuple("NetworkCollection", friendly_names)
        return collection_tuple(*entry_list)

    def parse_entries_upper(self, input_file_name):
        with open(input_file_name) as entry_stream:
            file_csv = DictReader(entry_stream)
            return self.parse_entries(file_csv)

    def parse_entries(self, entry_stream):
        rows = list()
        for entry in entry_stream:
            rows.append(entry)
        return rows

    @staticmethod
    def parse_entries_lower(parser, raw_entries):
        parser.create_entries(raw_entries)
        parser.entries.errors = parser.errors
        return parser.entries

    def import_flow_entries(self, input_file_name, node_entries=None, group_entries=None, meter_entries=None, perform_validation=True, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = FlowEntryParser(node_entries=node_entries, group_entries=group_entries, meter_entries=meter_entries, perform_validation=perform_validation, raise_at_end=raise_at_end, file_name=input_file_name)
        return self.parse_entries_lower(parser, raw_entries)

    def import_host_profiles(self, input_file_name, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = HostProfileParser(raise_at_end=raise_at_end, file_name=input_file_name)
        return self.parse_entries_lower(parser, raw_entries)

    def import_group_entries(self, input_file_name, node_entries=None, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = GroupEntryParser(node_entries=node_entries, raise_at_end=raise_at_end, file_name=input_file_name)
        return self.parse_entries_lower(parser, raw_entries)

    def import_node_entries(self, input_file_name, host_profiles=None, associations=None, loggers=None, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = NodeParser(raise_at_end=raise_at_end, host_profiles=host_profiles, loggers=loggers, associations=associations, file_name=input_file_name)
        results = self.parse_entries_lower(parser, raw_entries)
        results.associations = parser.associations
        return results

    def import_topology_entries(self, input_file_name, node_entries, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = TopologyParser(node_entries, raise_at_end=raise_at_end, file_name=input_file_name)
        return self.parse_entries_lower(parser, raw_entries)

    # Can use old or new name
    import_topology = import_topology_entries

    def import_application_entries(self, input_file_name, node_entries=None, protocol_entries=None, association_entries=None, raise_at_end=False, networks=None, ignore_disconnected=False, require_user_defined_protocols=False):
        if association_entries:
            associations = association_entries
        elif node_entries.associations:
            associations = node_entries.associations
        else:
            associations = list()
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = ApplicationParser(node_entries=node_entries, protocol_entries=protocol_entries, associations=associations, raise_at_end=raise_at_end, networks=networks, ignore_disconnected=ignore_disconnected, file_name=input_file_name, require_user_defined_protocols=require_user_defined_protocols)
        return self.parse_entries_lower(parser, raw_entries)

    def import_meter_entries(self, input_file_name, node_entries=None, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = MeterParser(node_entries=node_entries, raise_at_end=raise_at_end, file_name=input_file_name)
        return self.parse_entries_lower(parser, raw_entries)

    def import_log_entries(self, input_file_name, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = LogParser(raise_at_end=raise_at_end, file_name=input_file_name)
        return self.parse_entries_lower(parser, raw_entries)

    def import_protocol_entries(self, input_file_name, node_entries=None, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = ProtocolParser(raise_at_end=raise_at_end, node_entries=node_entries, file_name=input_file_name)
        parser.create_entries(raw_entries)
        parser.entries.associations = parser.associations
        parser.entries.errors = parser.errors
        return parser.entries

    def import_association_entries(self, input_file_name, raise_at_end=False):
        raw_entries = self.parse_entries_upper(input_file_name)
        parser = AssociationParser(raise_at_end=raise_at_end, file_name=input_file_name)
        test = parser.create_entries(raw_entries)
        parser.entries.errors = parser.errors
        return parser.entries


def import_entries(*args, **kwargs):
    return CSVInterface().import_entries(*args, **kwargs)

def import_flow_entries(*args, **kwargs):
    return CSVInterface().import_flow_entries(*args, **kwargs)

def import_host_profiles(*args, **kwargs):
    return CSVInterface().import_host_profiles(*args, **kwargs)

def import_group_entries(*args, **kwargs):
    return CSVInterface().import_group_entries(*args, **kwargs)

def import_node_entries(*args, **kwargs):
    return CSVInterface().import_node_entries(*args, **kwargs)

def import_topology_entries(*args, **kwargs):
    return CSVInterface().import_topology_entries(*args, **kwargs)

# Can use old or new name
import_topology = import_topology_entries

def import_application_entries(*args, **kwargs):
    return CSVInterface().import_application_entries(*args, **kwargs)

def import_meter_entries(*args, **kwargs):
    return CSVInterface().import_meter_entries(*args, **kwargs)

def import_protocol_entries(*args, **kwargs):
    return CSVInterface().import_protocol_entries(*args, **kwargs)

def import_association_entries(*args, **kwargs):
    return CSVInterface().import_association_entries(*args, **kwargs)

def import_log_entries(*args, **kwargs):
    return CSVInterface().import_logn_entries(*args, **kwargs)
