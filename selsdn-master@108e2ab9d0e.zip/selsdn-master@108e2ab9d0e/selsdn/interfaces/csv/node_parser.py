from collections import ChainMap

from . import LOGGER
from .entry_parser import EntryParser, COMMENTS_STARTS
from ...base.collection import NodeCollection, PortCollection, LogCollection
from ...automation.port import Port
from ...automation.device import SEL2740SDevice, SEL2742SDevice, Device, EndDevice, ControllerDevice, TwoMacDevice, TraditionalSwitchDevice, RouterDevice, SEL2740SSyslogServer, SEL2740SLocalEvents, SEL2740SAlarmContact
from ...automation.host_profiles import HostProfiles
from ...automation.associations import Associations
from ...automation.device import SEL2740SSyslogServer, SEL2740SAlarmContact, SEL2740SLocalEvents


node_entry_first_line = "Name,Type,IP Address,MAC Address,Subnet,Gateway,Controller,Ports,Mode,Associations"
node_entry_headers = node_entry_first_line.split(',')

class NodeParser(EntryParser):
    COLLECTION_TYPE = NodeCollection

    def __init__(self, raise_at_end=False, file_name=None, loggers=None, associations=None, host_profiles=None):
        super().__init__(raise_at_end=raise_at_end, file_name=file_name)
        self._associations = associations if associations else Associations()
        self.host_profiles = host_profiles if host_profiles else HostProfiles()
        self.loggers = loggers if loggers else LogCollection()

    def add_entry(self, node):
        name = node.name
        if name in self._nodes:
            self.add_error(ValueError("Cannot add node {} because node {} already found for name {}".format(node, self._nodes[name], name)))
            return False

        if node.ip_address != "0.0.0.0" and self.entries.has_ip_address(node.ip_address):
            LOGGER.warning("Adding node {} with the same IP address {} as node(s) {}".format(name, node.ip_address, self.entries.has_ip_address(node.ip_address)))

        self._nodes[name] = node
        super().add_entry(node)
        return True

    def add_object_to_association(self, node, association):
        self._associations.add_entry(node, association)

    def create_port_object(self, port_attributes, port_index):
        port_objects = list()
        if port_attributes["mode"] in ("Failover", "PRP"):
            # Check if it is an int
            try:
                port_number = int(port_attributes['name'])
                names = [port_index for port_index in range(port_number)]
            except ValueError:
                names = self.listify(port_attributes['name'])

            if port_attributes.get("networks"):
                networks = port_attributes['networks']

                if len(networks) == 1:
                    networks = [networks for _ in range(len(names))]
                else:
                    networks = [[network] for network in networks]

                if len(networks) != len(names):
                    raise ValueError("The number of networks must be one or equal to the number of ports")

                # Only assign the appropriate name and network to each
                for name, network in zip(names, networks):
                    adjustment = {"name": name, "networks": network}
                    new_port_object = Port(**ChainMap(adjustment, port_attributes))
                    port_objects.append(new_port_object)
            else:
                for name in names:
                    adjustment = {"name": name}
                    new_port_object = Port(**ChainMap(adjustment, port_attributes))
                    port_objects.append(new_port_object)

            # Add the other ports as references to this port
            if port_objects:
                for index, port_object in enumerate(port_objects):
                    for other_port_object in [other_port_object for other_index, other_port_object in enumerate(port_objects) if other_index != index]:
                        port_object.add_related_port(other_port_object)
        else:
            port_attributes["mode"] = ""
            new_port_object = Port(**port_attributes)
            port_objects.append(new_port_object)

        return port_objects

    def create_port_objects(self, ports):
        port_objects = PortCollection()
        for index, port in enumerate(ports):
            new_port_objects = self.create_port_object(port, index)
            if isinstance(new_port_objects, list):
                port_objects.extend(new_port_objects)
            else:
                port_objects.append(new_port_objects)

        return port_objects

    def create_front_back_2740S_ports(self, ports_list, switch_parameters):
        front_port_found = False
        back_port_found = False
        default_gateway_found = False

        port_name = ""
        # for port_list in ports_list:
        #     if port_list.get("name"):
        #         port_name = port_list.get("name")
        #         break

        for port_object in ports_list:
            port_name = port_object.get("name")
            if not port_object.get("ip_address"):
                raise ValueError("Missing IP Address for {}".format(port_name))
            if not port_object.get("subnet"):
                raise ValueError("Missing subnet for {}".format(port_name))

            if port_name.lower() in ("front", "ethf", "oob"):
                if front_port_found:
                    raise ValueError("Can only define the front port once")
                front_port_found = True
                switch_parameters["front_ip_address"] = port_object.get("ip_address")
                switch_parameters["front_mac_address"] = port_object.get("mac_address")
                switch_parameters["front_name"] = port_object.get("name")
                switch_parameters["front_networks"] = port_object.get("networks")
                switch_parameters["front_subnet"] = port_object.get("subnet")
                switch_parameters["front_associations"] = port_object.get("associations")
                switch_parameters["front_default_gateway"] = port_object.get("default_gateway")

            elif port_name.lower() in ("back", "mgmt", "ib", ""):
                if back_port_found:
                    raise ValueError("Can only define the back port once")
                back_port_found = True
                switch_parameters["ip_address"] = port_object.get("ip_address")
                switch_parameters["mac_address"] = port_object.get("mac_address")
                switch_parameters["back_name"] = port_object.get("name")
                switch_parameters["networks"] = port_object.get("networks")
                switch_parameters["subnet"] = port_object.get("subnet")
                switch_parameters["associations"] = port_object.get("associations")
                switch_parameters["default_gateway"] = port_object.get("default_gateway")
            else:
                raise ValueError("The port name for a SEL-2740S must be Front, EthF, OOB, Back, Mgmt, IB, or blank (if only one port) not '{}'".format(port_name))

            if port_object.get("default_gateway"):
                if default_gateway_found:
                    raise ValueError("Default gateway already defined as {}".format(default_gateway_found))
                else:
                    default_gateway_found = port_object.get("default_gateway")

            if port_object.get("mode"):
                if switch_parameters.get("mode"):
                    raise ValueError("Mode already defined as {}".format(switch_parameters.get("mode")))
                elif port_object.get("mode") not in ("OOB", "IB", ""):
                    raise ValueError("Mode must be OOB or IB or blank (if only one port) not {}".format(port_object.get("mode")))
                else:
                    switch_parameters["mode"] = port_object.get("mode")

        if len(ports_list) == 1 and not port_object.get("mode") and front_port_found:
            switch_parameters["mode"] = "OOB"

        if not default_gateway_found:
            raise ValueError("No default gateway was given")

        return switch_parameters

    def create_alarm_contact_events(self, name):
        if name == "None":
            return False

        logger = self.loggers.has_name(name)
        if not logger:
            raise ValueError("Unable to find logger with name {}".format(name))
        else:
            logger = logger[0]
            if not isinstance(logger, SEL2740SAlarmContact):
                raise ValueError("Logger {} must have type Alarm Contact not {}".format(name, logger.class_name))
        
            return logger

    def create_local_events(self, name):
        if name == "None":
            return False

        logger = self.loggers.has_name(name)
        if not logger:
            raise ValueError("Unable to find logger with name {}".format(name))
        else:
            logger = logger[0]
            if not isinstance(logger, SEL2740SLocalEvents):
                raise ValueError("Logger {} must have type Local Events not {}".format(name, logger.class_name))
        
            return logger

    def create_syslog_servers(self, names):
        if len(names) == 1 and names[0] == "None":
            return list()

        loggers = list()
        for name in names:
            logger = self.loggers.has_name(name)
            if not logger:
                raise ValueError("Unable to find logger with name {}".format(name))
            else:
                logger = logger[0]
                if not isinstance(logger, SEL2740SSyslogServer):
                    raise ValueError("Logger {} must have type Syslog Server not {}".format(name, logger.class_name))
            
                loggers.append(logger)
        return loggers

    def create_node_entry(self, node_attributes, switch_attributes, ports_list):
        # I need to add the ports to the association is they are not in separate rows
        one_row = True
        node_name = node_attributes["name"]
        
        if len(ports_list) == 0:
            raise ValueError("ERROR STATE")

        entry_type = node_attributes["type"]
        
        # SEL-2740S is special
        if entry_type in ('SEL2740S', 'SEL2742S'):
            del(node_attributes["ports"])

            if len(ports_list) > 2:
                raise ValueError("A SEL-2740S may only have 1 or 2 management ports for front and back")

            switch_parameters = node_attributes
            switch_parameters.update(switch_attributes)

            if switch_parameters.get("alarm_contact"):
                switch_parameters["alarm_contact"] = self.create_alarm_contact_events(switch_parameters["alarm_contact"])
            else:
                switch_parameters["alarm_contact"] = None

            if switch_parameters.get("local_events"):
                switch_parameters["local_events"] = self.create_local_events(switch_parameters["local_events"])
            else:
                switch_parameters["local_events"] = None
            
            if switch_parameters.get("syslog_servers"):
                switch_parameters["syslog_servers"] = self.create_syslog_servers(switch_parameters["syslog_servers"])
            else:
                switch_parameters["syslog_servers"] = None

            switch_parameters = self.create_front_back_2740S_ports(ports_list, switch_parameters)

            del(switch_parameters["type"])
            if entry_type == "SEL2740S":
                node = SEL2740SDevice(**switch_parameters)
            elif entry_type == "SEL2742S":
                node = SEL2742SDevice(**switch_parameters)
        else:
            if len(ports_list) == 1 and (not ports_list[0]["mode"] or ports_list[0]["mode"] == "Failover"):
                if not node_attributes['ports']:
                    ports = 1
                else:
                    try:
                        ports = int(node_attributes['ports'])
                        if ports_list[0]["mode"] == '' and ports == 2:
                            ports_list[0]["mode"] = "Failover"
                    except ValueError:
                        ports = self.listify(node_attributes['ports'])
                        if ports_list[0]["mode"] == '' and len(ports) == 2:
                            ports_list[0]["mode"] = "Failover"

                node_attributes['ports'] = ports
                node_attributes = dict(ports_list[0], **node_attributes)
            # There are more than one row
            else:
                node_attributes['ports'] = self.create_port_objects(ports_list)
                one_row = False

            # Remove type because it is not an argument
            del(node_attributes["type"])

            if not entry_type:
                raise ValueError("Must specify a device type")
            elif entry_type == "Router":
                device_class = RouterDevice
            else:
                if entry_type == "Controller":
                    device_class = ControllerDevice
                elif entry_type == "2MAC":
                    device_class = TwoMacDevice
                elif entry_type == "Host" or entry_type == "Device":
                    device_class = EndDevice
                elif entry_type in self.host_profiles:
                    device_class = self.host_profiles[entry_type]["Type"]
                else:
                    raise ValueError("Unknown device type {}".format(entry_type))

            node = device_class(**node_attributes)

        if one_row and ports_list[0].get("associations"):
            associations = ports_list[0]["associations"]
            for association in associations:
                self.add_object_to_association(node, association)
        elif not one_row:
            for port in node.ports:
                for association in port.associations:
                    self.add_object_to_association(port, association)

        self.add_entry(node)

    def _combine_node_lines(self, profile, entry):
        for profile_name, profile_value in profile.items():
            if not entry.get(profile_name):
                entry[profile_name] = profile_value

        # Need to override the Type using the Profile as the Profile is referenced through the Type column
        if profile.get("Type"):
            entry["Type"] = profile["Type"]

        return entry

    def create_entries(self, tuples):
        last_node_attributes = False
        last_2740S_attributes = dict()
        last_start_row = 0
        ports_list = list()
        one_row = True
        last_node_name = ''

        for index, entry in enumerate(tuples):
            self.current_row_number = index + 2
            try:
                row_name = self.get_name_or_alias(entry)
                self.current_row_name = row_name

                # Check if need to ignore this line
                if self.is_ignore_row(entry, row_name):
                    continue

                row_type = self.gkft(entry, "Type", None)
                if row_type and self.host_profiles.get(row_type):
                    entry = self._combine_node_lines(profile=self.host_profiles.get(row_type), entry=entry)
                # If there is a row name, it is the next (or first) node entry
                # Allow the node name to stretch across multiple lines or a blank to represent multiple lines
                if row_name and row_name != last_node_name:
                    last_start_row = index
                    # This isn't the first device so need to close the last one
                    if last_node_attributes:
                        # There is one row
                        try:
                            self.create_node_entry(node_attributes=last_node_attributes, switch_attributes=last_2740S_attributes, ports_list=ports_list)
                        except ValueError as e:
                            self.add_error(e, row_number=last_start_row+1)

                    last_node_attributes = self.collect_node_attributes(entry)
                    last_2740S_attributes = self.collect_switch_attributes(entry)
                    last_2740S_attributes = self.collect_extra_2740S_attributes(entry, last_2740S_attributes)
                    port_attributes = self.collect_port_attributes(entry)
                    ports_list = [port_attributes]
                    last_node_name = row_name

                # Else there it is just a port
                else:
                    port_attributes = self.collect_port_attributes(entry)
                    last_2740S_attributes = self.collect_extra_2740S_attributes(entry, last_2740S_attributes)
                    ports_list.append(port_attributes)

            except Exception as e:
                self.add_error(e, row_number=last_start_row+1)
                #raise Exception("An error occured while processing node line {}".format(last_start_row+2))

        # need to close out the last device
        try:
            self.create_node_entry(node_attributes=last_node_attributes, switch_attributes=last_2740S_attributes, ports_list=ports_list)
        except Exception as e:
            self.add_error(e, row_number=last_start_row+1)
            #raise Exception("An error occured while processing node line {}".format(last_start_row+2))

        return self.entries

    def collect_extra_2740S_attributes(self, entry, attributes):
        if self.gkft(entry, "Controller"):
            if attributes.get("controller_ip"):
                raise ValueError("Controller ip already defined as {}".format(attributes["controller_ip"]))
            attributes["controller_ip"] = self.gkft(entry, "Controller")
        return attributes

    def collect_port_attributes(self, entry):
        attributes = dict()
        attributes['mac_address'] = self.gkft(entry, "MAC Address", None)
        attributes['ip_address'] = self.listify(self.gkft(entry, "IP Address", None))
        attributes['subnet'] = self.listify(self.gkft(entry, "Subnet", None))
        attributes['name'] = self.gkft(entry, "Ports")
        attributes["mode"] = self.gkft(entry, "Mode")
        if self.get_node_from_name(self.gkft(entry, "Gateway")):
            attributes["default_gateway"] = self.get_node_from_name(self.gkft(entry, "Gateway"))
        else:
            attributes["default_gateway"] = self.gkft(entry, "Gateway")
        attributes["attributes"] = self.get_extra_attributes(entry, node_entry_headers+["Networks"])
        attributes["associations"] = self.listify(self.gkft(entry, "Associations"))
        client_associations = self.listify(self.gkft(entry, "Client Associations"))
        for association in client_associations:
            attributes["associations"].append("_C$"+association)
        server_associations = self.listify(self.gkft(entry, "Server Associations"))
        for association in server_associations:
            attributes["associations"].append("_P$"+association)

        networks = self.gkft(entry, "Networks")
        if networks:
            networks = self.listify(networks)
            attributes["networks"] = networks
        return attributes

    def collect_node_attributes(self, entry):
        attributes = dict()
        attributes['name'] = self.get_name_or_alias(entry)
        attributes['type'] = self.gkft(entry, "Type")
        attributes['ports'] = self.gkft(entry, "Ports")
        attributes["attributes"] = self.get_extra_attributes(entry, node_entry_headers+["Networks"])
        return attributes

    def collect_switch_attributes(self, entry):
        attributes = dict()
        attributes["snmp_enable"] = self.get_boolean_from_value(self.gkft(entry, "SNMP"), False)
        attributes['ptp_enable'] = self.get_boolean_from_value(self.gkft(entry, "PTP"), False)
        attributes["ntp_servers"] = self.listify(self.gkft(entry, "NTP Servers"))
        if attributes.get("syslog_servers") and self.gkft(entry, "Syslog Servers"):
            raise ValueError("Syslog servers already defined to be {}".format(attributes.get("syslog_servers")))
        else:
            attributes["syslog_servers"] = self.listify(self.gkft(entry, "Syslog Servers"))
        
        if attributes.get("alarm_contact") and self.gkft(entry, "Alarm Contact"):
            raise ValueError("Alarm contact already defined to be {}".format(attributes.get("syslog_servers")))
        else:        
            attributes["alarm_contact"] = self.gkft(entry, "Alarm Contact")
        
        if attributes.get("local_events") and self.gkft(entry, "Local Events"):
            raise ValueError("Local events already defined to be {}".format(attributes.get("syslog_servers")))
        else:
            attributes["local_events"] = self.gkft(entry, "Local Events")
        
        return attributes

    @property
    def associations(self):
        return self._associations
