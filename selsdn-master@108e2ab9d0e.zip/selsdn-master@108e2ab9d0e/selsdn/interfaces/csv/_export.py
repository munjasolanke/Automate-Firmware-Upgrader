import csv
from collections import OrderedDict

from .entry_builder import create_flow_entries, create_group_entries, create_node_entries, create_meter_entries
from .entry_builder import create_topology_entries, create_application_entries, create_application_entries_matrix
from .entry_builder import create_protocol_entries, create_test_report, create_flow_diff_report
from .entry_builder import create_flow_entry

from ...automation.port import Port
from ...automation.device import Device
from ...automation.application import Application
from ...automation.protocol import Protocol

from ...openflow.core.group_entry import GroupEntry
from ...openflow.core.flow_entry import FlowEntry
from ...openflow.core.meter_entry import MeterEntry

flow_entry_match_fields = "InPort,EthDst,EthDstMask,EthSrc,EthSrcMask,EthType,VlanVid,VlanVidMask,VlanPcp,IpProto,Ipv4Src,Ipv4SrcMask,Ipv4Dst,Ipv4DstMask,TcpSrc,TcpDst,UdpSrc,UdpDst,ArpOp,ArpSpa,ArpSpaMask,ArpTpa,ArpTpaMask"
flow_entry_third_line = "Name,Node,ID,Table,Priority,IdleTimeout,HardTimeout," + flow_entry_match_fields + ",Output,Group,SetQueue,PushVlan,PopVlan,SetVlanVid,SetVlanPcp,GotoTable,Meter,ClearActions"
flow_entry_headers = flow_entry_third_line.split(',')

flow_entry_match_fields_v2 = "InPort,EthDst,EthDstMask,EthSrc,EthSrcMask,EthType,VlanVid,VlanVidMask,VlanPcp,Code,IpSrc,IpSrcMask,IpDst,IpDstMask,TUPortSrc,TUPortDst,Output,Group,SetQueue,PushVlan,PopVlan,SetVlanVid,SetVlanPcp,GotoTable,Meter,ClearActions"
flow_entry_third_line_v2 = "Name,Node,Type,ID,Table,Priority," + flow_entry_match_fields_v2
flow_entry_headers_v2 = flow_entry_third_line_v2.split(',')

group_entry_second_line = "Name,Node,ID,Type,Bucket ID,Watch Port,Watch Group,Output,Group,PushVlan,SetVlanVid,SetVlanPcp,PopVlan,SetQueue"
group_entry_headers = group_entry_second_line.split(',')

topology_entry_first_line = 'Switch,P' + ",P".join(map(str, range(1,20+1)))
topology_entry_headers = topology_entry_first_line.split(',')

application_entry_first_line = "Name,Protocol,Source,Destination,Priority,Policies,VID,EthDst"
application_entry_headers = application_entry_first_line.split(',')

protocol_entry_first_line = "Name,Unicast,Unidirectional,EthDst,EthSrc,EthType,VlanVid,VlanPcp,IpProto,Ipv4Src,Ipv4Dst,TcpSrc,TcpDst,UdpSrc,UdpDst,ArpOp,ArpSpa,ArpTpa"
protocol_entry_headers = protocol_entry_first_line.split(",")

meter_entry_first_line = "Name,Node,ID,Measurement,Rate,Burst Size"
meter_entry_headers = meter_entry_first_line.split(",")

test_case_first_line = "Application,Target,Source,SourcePort,Finish,FinishPort,Packet,UnderTest,Received,Errors,Path"

switch_parameters_first_line = "Switch,Parameter,Current,Maximum,%"
switch_paremeters_headers = switch_parameters_first_line.split(",")

node_entry_first_line = "Name,Type,IP Address,MAC Address,Subnet,Gateway,Controller,PTP,SNMP,NTP Servers,Ports,Mode,Associations,Networks"
node_entry_headers = node_entry_first_line.split(',')

association_first_line = "Name,Associations"
association_headers = association_first_line.split(",")

def export_switch_parameters(file_name, switch_parameters, use_lc_limit=False):
    with open(file_name, 'w', newline='') as f:
        f_csv = csv.DictWriter(f, switch_paremeters_headers, lineterminator="\r\n")
        f.write(switch_parameters_first_line + '\r\n')
        switch_parameters = OrderedDict(sorted(switch_parameters.items(), key=lambda t: t[0]))
        for switch, parameters in switch_parameters.items():
            for parameter, limit in (("groups", 256),("buckets",128),(0,1024),(1,1024),(2,1024),(3,1024), ("number_over_30", 0)):
                number = parameters[parameter]

                if parameter in (0, 1, 2, 3) and use_lc_limit:
                    limit = 900

                new_line = {"Switch":switch, "Current":number, "Maximum":limit}

                if parameter == "number_over_30":
                    new_line["%"] = "OK" if number == 0 else "BAD"
                else:
                    new_line["%"] = number*100//limit

                if parameter in (0, 1, 2, 3):
                    new_line["Parameter"] = "Table {}".format(parameter)
                elif parameter == "groups":
                    new_line["Parameter"] = "Groups"
                elif parameter == "buckets":
                    new_line["Parameter"] = "Unique Buckets"
                elif parameter == "number_over_30":
                    new_line["Parameter"] = "Number of groups with more than 30 buckets"
                else:
                    raise ValueError("Don't know type {}".format(parameter))

                f_csv.writerow(new_line)

def export_entries(file_name, entries, **kwargs):
    first_entry = entries[0]

    if kwargs.get("sort"):
        if kwargs["sort"] == "az":
            entries.sort()
        else:
            raise

    if isinstance(first_entry, Device):
        return export_node_entries(file_name, entries, **kwargs)
    elif isinstance(first_entry, FlowEntry):
        return export_flow_entries(file_name, entries, **kwargs)
    elif isinstance(first_entry, GroupEntry):
        return export_group_entries(file_name, entries, **kwargs)
    elif isinstance(first_entry, MeterEntry):
        return export_meter_entries(file_name, entries, **kwargs)
    elif isinstance(first_entry, Application):
        return export_application_entries(file_name, entries, **kwargs)
    elif isinstance(first_entry, Protocol):
        return export_protocol_entries(file_name, entries, **kwargs)
    else:
        raise TypeError("Type {} is not yet supported".format(type(first_entry)))

def _export_entries(file_name, entries, headers, include_attributes, create_function):
    if not include_attributes:
        include_attributes = list()
    if type(include_attributes) is tuple:
        include_attributes = list(include_attributes)

    all_headers = headers + include_attributes
    rows = create_function(entries, include_attributes=include_attributes)
    first_line = ",".join(all_headers) + '\r\n'
    with open(file_name, 'w', newline='') as f:
        f_csv = csv.DictWriter(f, all_headers, lineterminator="\r\n")
        f.write(first_line)
        try:
            for row in rows:
                f_csv.writerow(row)
        except ValueError as e:
            raise ValueError("Error occured writing entry {}".format(row))

def export_flow_diff(file_name, flow_entries, group_entries=None, include_attributes=None):
    return _export_entries(file_name, entries=flow_entries, headers=["Action"]+flow_entry_headers, include_attributes=include_attributes, create_function=create_flow_diff_report)

def export_flow_entries(file_name, flow_entries, group_entries=None, include_attributes=None):
    return _export_entries(file_name, entries=flow_entries, headers=flow_entry_headers, include_attributes=include_attributes, create_function=create_flow_entries)
    
def export_group_entries(file_name, group_entries, include_attributes=None):
    return _export_entries(file_name, entries=group_entries, headers=group_entry_headers, include_attributes=include_attributes, create_function=create_group_entries)

def export_meter_entries(file_name, meter_entries, include_attributes=None):
    return _export_entries(file_name, entries=meter_entries, headers=meter_entry_first_line.split(','), include_attributes=include_attributes, create_function=create_meter_entries)

def export_node_entries(file_name, node_entries, include_attributes=None, sort=None):
    return _export_entries(file_name, entries=node_entries, headers=node_entry_first_line.split(','), include_attributes=include_attributes, create_function=create_node_entries)

def export_flow_entries_v2(file_name, flow_entries, include_attributes=None):
    with open(file_name, 'w', newline='') as f:
        f_csv = csv.DictWriter(f, flow_entry_headers_v2, lineterminator="\r\n")
        f.write(flow_entry_third_line_v2 + '\r\n')
        for row in flow_entries:
            f_csv.writerow(row.dict)

def export_application_entries_matrix(file_name, application_entries):
    rows, headers = create_entries(function=create_application_entries_matrix, entries=application_entries, headers=list(), include_attributes=None)
    rows, other_headers = rows
    headers = list(other_headers)
    headers.sort()
    headers = ["Source"] + headers

    base_dict = dict()
    for header in list(other_headers):
        base_dict[header] = None

    with open(file_name, 'w', newline='') as f:
        f_csv = csv.DictWriter(f, headers, lineterminator="\r\n")
        f.write(",".join(headers) + '\r\n')
        for name in sorted(rows.keys()):
            row = rows[name]
            new_row = base_dict.copy()
            for key, entry in row.items():
                new_row[key] = ",".join(entry)
            new_row["Source"] = name
            f_csv.writerow(new_row)

def export_application_entries(file_name, application_entries, include_attributes=None):
    rows, headers = create_entries(function=create_application_entries, entries=application_entries, headers=application_entry_headers, include_attributes=include_attributes)
    write_entries(rows=rows, headers=headers, file_name=file_name)

def export_protocol_entries(file_name, protocol_entries, include_attributes=None):
    rows, headers = create_entries(function=create_protocol_entries, entries=protocol_entries, headers=protocol_entry_first_line.split(","), include_attributes=include_attributes)
    write_entries(rows=rows, headers=headers, file_name=file_name)

def export_topology(file_name, node_entries, include_attributes=None):
    node_rows = create_topology_entries(node_entries, include_attributes=include_attributes)
    with open(file_name, 'w', newline='') as f:
        f_csv = csv.DictWriter(f, topology_entry_headers, lineterminator="\r\n")
        f.write(topology_entry_first_line + '\r\n')
        for row in node_rows:
            f_csv.writerow(row)

def create_entries(function, entries, headers, include_attributes):
    if include_attributes:
        row_headers = headers + list(include_attributes)
        rows = function(entries, include_attributes=include_attributes)
    else:
        row_headers = headers
        rows = function(entries)
    return rows, row_headers

def write_entries(file_name, rows, headers):
    with open(file_name, 'w', newline='') as f:
        f_csv = csv.DictWriter(f, headers, lineterminator="\r\n")
        f.write(",".join(headers) + '\r\n')
        for row in rows:
            f_csv.writerow(row)

def export_test_cases(file_name, testcases):
    with open(file_name, 'w', newline='') as f:
        f.write(test_case_first_line + '\n')

        for testcase in testcases:
            application_name = testcase.application.name

            for subtest in testcase.tests:
                destination_list = list()
                for destination in subtest.target:
                    if isinstance(destination, Port):
                        destination_list.append(":".join([str(destination.owner.name), str(destination.name)]))
                    else:
                        destination_list.append(destination.name)
                destinations  = "-".join(destination_list)
                undertest = subtest.undertest
                
                if undertest is None:
                    undertest = ""
                elif isinstance(undertest, Port):
                    undertest = ".".join([str(undertest.owner.name), str(undertest.name)])
                elif isinstance(undertest, Device):
                    undertest = undertest.name
                else:
                    undertest = subtest.undertest.replace(",", ".")
                    #undertest = ":".join(map(str, subtest.undertest))

                for subsubtest in subtest.tests:
                    subpath = subsubtest.outcome
                    start_switch = str(subtest.start.owner.name)
                    start_port = str(subtest.start.name)
                    finish_switch = '-' if subsubtest.finish is None else str(subsubtest.finish.owner.name)
                    finish_port = '-' if subsubtest.finish is None else str(subsubtest.finish.name)
                    if subsubtest.result:
                        received = str(subsubtest.result)
                    else:
                        received = "False" if subsubtest.finish is None else str(subsubtest.finish.owner in subtest.target)
                    errors = "-".join(map(str, subpath.errors))
                    packet_type = subsubtest.outcome.packet.__class__.__name__

                    f.write(",".join([application_name, destinations, start_switch, start_port, finish_switch, finish_port, packet_type, undertest, received, errors]))
                    f.write(",")
                    if subpath.hops[0].device:
                        f.write(",".join([str(subpath.hops[0].device.name), str(subpath.hops[0].egress_port.name), str(subpath.hops[0].packet).replace(",", ".")]))
                    for hop in subpath.hops[1:]:
                        hop0 = '' if hop.ingress_port is None else hop.ingress_port.name
                        hop2 = '' if hop.egress_port is None else hop.egress_port.name
                        f.write(",".join([str(hop0), str(hop.flow_entries).replace(',','-')+"/"+str(hop.group_entries).replace(",", '-')+"/"+str(hop.actions).replace(",","-"), str(hop2), str(hop.packet).replace(",", ".")]))
                        f.write(",")
                    #if subpath.hops[-1][0]:
                    #   f.write(",".join([str(subpath.hops[-1][0].name), str(subpath.hops[-1][1].name), ]))

                    f.write("\n")

def export_test_report(file_name, application_entries, node_entries, include_attributes=None, ids_names=None):
    rows = create_test_report(application_entries, node_entries=node_entries, include_attributes=include_attributes, ids_names=ids_names)

    headers = list()

    for row in rows:
        for item in row:
            if item not in headers:
                headers.append(item)


    write_entries(rows=rows, headers=headers, file_name=file_name)

def export_flow_entries_diff(file_name, add_entries, delete_entries, include_attributes=None):
    rows = list()
    for add_entry in add_entries:
        add_dict = create_flow_entry(add_entry)

        if add_entry.get_attribute("linked_delete"):
            delete_dict = create_flow_entry(add_entry.get_attribute("linked_delete")[0])

            compare_dict = create_dict_diff(old=delete_dict, new=add_dict)

            compare_dict["Action"] = "Modify"
            rows.append(compare_dict)
        else:
            add_dict["Action"] = "Add"
            rows.append(add_dict)

    for delete_entry in delete_entries:
        if delete_entry.get_attribute("linked_add"): 
            # Skip because already above
            pass
        else:
            delete_dict = create_flow_entry(delete_entry)
            delete_dict["Action"] = "Delete"
            rows.append(delete_dict)

    write_entries(rows=rows, headers=["Action"] + flow_entry_headers, file_name=file_name)

def create_dict_diff(old, new):
    new_dict = dict()
    for key, value in old.items():
        if new.get(key) and new[key] != value:
            new_dict[key] = "-->".join([str(value), str(new[key])])
        else:
            new_dict[key] = value

    return new_dict
