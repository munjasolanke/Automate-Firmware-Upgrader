from ...base.collection import Collection

class RestCollection(Collection):
    pass
