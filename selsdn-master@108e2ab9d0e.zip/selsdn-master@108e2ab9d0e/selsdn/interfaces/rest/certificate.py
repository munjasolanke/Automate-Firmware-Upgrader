from base64 import b64encode

from . import LOGGER
from .metaclasses import ObjectMixin
from .constants import TREE_CERTIFICATE, CERTIFICATE_CERTIFICATEINFO, FUNCTION_CERTIFICATE_UPLOAD
from .decorators import no_body_url

class CertificateMixin(metaclass=ObjectMixin, name="certificate", url=CERTIFICATE_CERTIFICATEINFO):
    def add_certificate(self, certificate, purpose, password=None, thumbprint=None):
        # Check that the certificate is base64 encoded
        if isinstance(certificate, str):
            certificate = certificate.encode()

        if b"----BEGIN CERTIFICATE-----" in certificate:
            # Encode into base64
            certificate = b64encode(certificate)

        certificate = certificate.decode()

        # Validate the purpose
        if purpose.lower() == "trusted":
            purpose_string = "#Sel.BlueFrame.TrustAuthority.TrustedCertificates.TrustedCertificatePurpose"
        elif purpose.lower() == "internal":
            purpose_string = "#Sel.BlueFrame.TrustAuthority.InternalCertificateAuthority.InternalCaPurpose"
        elif purpose.lower() == "web":
            purpose_string = "#Sel.BlueFrame.TrustAuthority.WebCertificateManager.WebCertificatePurpose"
        else:
            raise ValueError("Purpose {} is not supported. Use one of the following: trusted, internal, or web".format(purpose))
        
        body = {"base64Certificate": certificate,
            "purpose": {"@odata.type": purpose_string},
            "certificatePassword": password
            }

        # Check to see if it is already present
        # Not sure how to calculate the thumbprint, have to pass one in
        if thumbprint:
            for certificate_object in self.get_certificates():
                if certificate_object["thumbprint"] == thumbprint.upper() and certificate_object["purpose"] == body["purpose"] and certificate_object["status"] == "Valid":
                    LOGGER.info("Certificate with thumbprint {} already found with purpose {}".format(thumbprint, purpose))
                    return False

        return self.make_body_request(url=TREE_CERTIFICATE, body=body, function=FUNCTION_CERTIFICATE_UPLOAD)

    def add_certificate_from_file(self, file_name, purpose, password=None, thumbprint=None):
        # Pull the file contents
        with open(file_name) as f:
            certificate = f.read()
        return self.add_certificate(certificate=certificate, purpose=purpose, password=password, thumbprint=thumbprint)
