OPERATIONAL_LINKS = "/api/default/operational/links"
OPERATIONAL_NODES = "/api/default/operational/nodes"
OPERATIONAL_PORTS = "/api/default/operational/ports"
OPERATIONAL_SYNCHRONIZATION = "/api/default/operational/synchronization"
OPERATIONAL_PACKETS = "/api/default/operational/packets"
OPERATIONAL_FLOW_STATS = "/api/default/operational/flowStats"
OPERATIONAL_SYNCHRONIZATION = "/api/default/operational/synchronization"

CONFIGURATION_CSTS = "/api/default/config/communicationServiceTypes"
CONFIGURATION_LCS = "/api/default/config/logicalConnections"
CONFIGURATION_NODES = "/api/default/config/nodes"
CONFIGURATION_FLOWS = "/api/default/config/flows"
CONFIGURATION_METERS = "/api/default/config/meters"
CONFIGURATION_SETTINGS = "/configuration/settings.json"
CONFIGURATION_GROUPS = "/api/default/config/groups"
CONFIGURATION_PORTS = "/api/default/config/ports"
CONFIGURATION_LINKS = "/api/default/config/links"

SECURITY_IS_COMMISSIONED = "/api/default/security/IsCommissioned"
SECURITY_COMMISSION = "/api/default/security/Commission"
SECURITY_APPLICATION_LINKS = "/api/default/security/applicationLinks"
SECURITY_ROLES = "/api/default/security/roles"
SECURITY_USERS = "/api/default/security/users"

SETTINGS_SECURITY_MANAGER = "/api/default/settings/securityManager"
SETTINGS_PREFERENCES = "/api/default/settings/preferences"
SETTINGS_PREFERENCES_SET = "/api/default/settings/SetUserPreference"

TREE_CONFIGURATION = "/api/default/config"
TREE_OPERATIONAL = "/api/default/operational"
TREE_CERTIFICATE = "/api/default/certificate"

CERTIFICATE_CERTIFICATEINFO = TREE_CERTIFICATE + "/certificateInfo"

FUNCTION_ADOPT_DEFAULT = "Sel.Adopt"
FUNCTION_ADOPT = "Sel.Adopt"
FUNCTION_ADOPT_WITH_CONFIGURATION = "Sel.AdoptWithConfig"
FUNCTION_REMOVE_RELAY_FAILOVER = "Sel.RemoveSelRelayFailoverFromPort"
FUNCTION_DETECT_RELAY_FAILOVER = "Sel.DetectSelRelayFailoverPort"
FUNCTION_ENABLE_RELAY_FAILOVER = "Sel.MarkPortAsSelRelayFailover"
FUNCTION_RESUBMIT_LC = "Sel.ResubmitLogicalConnection"
FUNCTION_UNADOPT = "Sel.Unadopt"
FUNCTION_PACKET_OUT = "PacketOut"
FUNCTION_SYNCHRONIZATION_NODE = "SynchronizeOpenFlowConfiguration"
FUNCTION_GET_SYNCHRONIZATION_NODE = "GetNodesThatRequireSynchronization"
FUNCTION_DISCONNECT = "Sel.Disconnect"
FUNCTION_REBOOT = "Sel.Reboot"
FUNCTION_APPLICATION_PAIR = "Sel.InitiateApplicationRegistration"
FUNCTION_APPLICATION_DISABLE = "Sel.DisableApplicationLink"
FUNCTION_APPLICATION_ENABLE = "Sel.EnableApplicationLink"
FUNCTION_ADD_ABSTRACT_NODE = "AddAbstractNode"
FUNTION_UPDATE_PASSWORD = "UpdatePassword"
FUNCTION_ADD_SILENT_HOST = "AddSilentHost"
FUNCTION_USER_INITIATED_HOST_DISCOVERY = "UserInitiatedHostDiscovery"
FUNCTION_CERTIFICATE_UPLOAD = "UploadCertificate"

COMMAND_GET = "GET"
COMMAND_POST = "POST"
COMMAND_DELETE = "DELETE"
COMMAND_PATCH = "PATCH"
COMMAND_PUT = "PUT"

APPLICATION_JSON = "application/json"

OPERATOR_EQUALS = "eq"
OPERATOR_GT = "gt"

PROPERTY_TYPE = "@odata.type"
PROPERTY_NAME = "displayName"
PROPERTY_STATE = "state"
PROPERTY_ERROR_STATE = "errorState"
PROPERTY_ERRORS = "errors"
PROPERTY_SETQUEUE = "setQueue"
PROPERTY_ID = "id"
PROPERTY_PARENT = "parentNode"
PROPERTY_LINKED = "linkedKey"
PROPERTY_IP_ADDRESS = "ipAddress"
PROPERTY_MAC_ADDRESS = "macAddress"
PROPERTY_CONFIGURATIONS = "configurations"
PROPERTY_PORTS = "ports"
PROPERTY_TAGS = "tags"
PROPERTY_ATTRIBUTES = "attributes"
PROPERTY_TRUST_STATE = "trustState"
PROPERTY_LINKS = "attachedLinks"
PROPERTY_END_POINTS = "endPoints"

VALUE_UNADOPTED = "Unadopted"
VALUE_ADOPTED = "Adopted"
VALUE_DISCONNECTED = "Disconnected"
VALUE_ESTABLISHED = "Established"

TREE_MATCHFIELDS = "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MatchFields"
TYPE_ACTION = "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects"

CODE_CREATED = 201
CODE_SUCCESS = 200
CODE_NO_CONTENT = 204

CODE_BAD_REQUEST = 400
CODE_UNAUTHORIZED = 401
CODE_FORBIDDEN = 403
CODE_NOT_FOUND = 404
CODE_CONFLICT = 409
CODE_INTERNAL_SERVER_ERROR = 500

OAUTH_TYPE_USER = "UserCredentials"
OAUTH_TYPE_CLIENT = "ClientCredentials"
OAUTH_TYPE_AUTHORIZATION = "AuthorizationCode"
OAUTH_TYPE_IMPLICIT = "Implicit"

ROLE_PL3 = "PermissionLevel3"
ROLE_SECURITY_ADMINISTRATOR = "SecurityAdministrator"
ROLE_MONITOR = "Monitor"

OBJECT_NODES = "nodes"

SOCKET_TIMEOUT = 300
