from functools import partial

from . import LOGGER

from ..network import BaseNetwork

from .session import Session
from .commands import Request
from .constants import *
from .exceptions import NotFoundError, BadRequestError

# Mixins
from .logical_connection import LogicalConnectionMixin
from .communication_service_type import CommunicationServiceTypeMixin
from .flow_entry import FlowEntryMixin
from .actions import ActionsMixin
from .group_entry import GroupEntryMixin
from .port import ConfigurationPortMixin, OperationalPortMixin
from .meter_entry import MeterEntryMixin
from .node import ConfigurationNodeMixin, OperationalNodeMixin
from .misc import MiscMixin
from .link import ConfigurationLinkMixin, OperationalLinkMixin
from .packet import PacketMixin
from .application import ApplicationMixin
from .role import RoleMixin
from .user import UserMixin
from .misc import SecurityManagerMixin
from .topology import TopologyMixin
from .host_discovery import HostDiscoveryMixin
from .certificate import CertificateMixin

from .base import *

from .information import CacheMixIn

from ...globals import LC_SUCCESS_RETRY

from ...automation.device import Device, SEL274XSDevice, OpenFlowDevice, TraditionalSwitchDevice
from ...automation.port import Port
from ...automation.application import Application
from ...automation.protocol import Protocol

from ...tools.diff.diff import create_flow_entries_diff, create_group_entries_diff, create_meter_entries_diff, create_node_entries_diff
from ...tools.misc.collection_printer import run_collection

from ...openflow.core.flow_entry import FlowEntry
from ...openflow.core.group_entry import GroupEntry
from ...openflow.core.meter_entry import MeterEntry

# This class is mostly mixins to reduce the size of the document. I don't split things by "tree" (config or operation), but by type: node, port, CST, etc.
# Purpose of caching is to store all of the data so that some information searching does not need to REST calls
class ControllerInterface(CertificateMixin, CacheMixIn, HostDiscoveryMixin, TopologyMixin, SecurityManagerMixin, UserMixin, RoleMixin, ApplicationMixin, MiscMixin, PacketMixin, FlowEntryMixin, GroupEntryMixin, ConfigurationNodeMixin, OperationalNodeMixin, ConfigurationLinkMixin, OperationalLinkMixin, MeterEntryMixin, ActionsMixin, LogicalConnectionMixin, CommunicationServiceTypeMixin, OperationalPortMixin, ConfigurationPortMixin, BaseNetwork, name=None, url=None):
    def __init__(self, verbose=False, caching=False):
        self._session = None
        self.verbose = verbose
        self._caching = caching
        self.id_to_display_name = {}
        self.id_to_value = {}
        self.name_to_id = {}
        self.get_responses = True
        self._start_cache(caching)
    
    def __enter__(self):
        return self

    def __exit__(self, exc_ty, exc_val, exc_tb):
        if self._session:
            self._session.logout()

    @property
    def caching(self):
        return self._caching

    @caching.setter
    def caching(self, value):
        if value not in (True, False):
            raise ValueError("Caching must be True or False")
        self._caching = value

    def make_simple_request(self, url, object_id=None, function=None, command=COMMAND_GET, check=True, *args, **kwargs):
        request = self._make_simple_request(url, object_id, function, command, *args, **kwargs)
        response = self.send_request(request, check=check)
        #if self.caching:
        #   self.update_cache(url=url, response=response, object_id=object_id, command=command)
        return response

    # Need to update
    def get_tag_value_from_type(self, tag_name, tags):
        for tag in tags:
            if tag_name in tag["@odata.type"]:
                if "LogicalConnectionTag" in tag_name:
                    return tag["logicalConnectionId"]
                elif "SystemTag" in tag_name:
                    return True

    def _make_simple_request(self, url, object_id=None, function=None, command=COMMAND_GET, parameters=None, headers=None, *args, **kwargs):
        if not self.session.token:
            self.login()

        if object_id:
            if url[-1] == "/":
                url = url[:-1]
            url += "('" + str(object_id) + "')"

        if function:
            if url[-1] != "/":
                url += "/"
            url += function
        
        r = Request(command=command, url=url)

        if kwargs.get("filters", False):
            filters = kwargs.get("filters")
            for filter in filters:
                if type(filter) is str:
                    r.add_filter_simple(filter)
                elif len(filter) == 1:
                    r.add_filter_simple(filter[0])
                elif len(filter) == 3:
                    r.add_filter_parameter(name=filter[0], value=filter[1], command=filter[2])
                else:
                    raise ValueError("Unable to understand filter {}".format(filter))

        if parameters:
            for parameter in parameters:
                key, value = parameter
                r.add_parameter(name=key, value=value)

        if headers:
            for name, value in headers:
                r.add_header(name, value=value)

        return r

    def _make_body_request(self, url, body, content_type=APPLICATION_JSON, object_id=None, function=None, command=COMMAND_POST, parameters=None):
        r = self._make_simple_request(url=url, object_id=object_id, function=function, command=command, parameters=parameters)
        if content_type:
            r.add_header("Content-Type", content_type)
            r.add_body(body)
        return self.send_request(r)

    def update_object(self, url, object_body, object_id, command="PATCH"):
        response = self.make_body_request(url=url, command=command, object_id=object_id, body=object_body)
        LOGGER.info("Updated object of type {} with id {}".format(url.split("/")[-1], object_id))
        self.update_cache(url, response, object_id=object_id, command=command)
        return response

    def make_body_request(self, url, body, content_type=APPLICATION_JSON, object_id=None, function=None, command=COMMAND_POST):
        response = self._make_body_request(url=url, content_type=content_type, object_id=object_id, body=body, function=function, command=command)
        if response:
            return response.contents

    # @TODO validate that the UUID looks correct
    def _validate_uuid(self, object_id, required=False):
        if required and not object_id:
            raise ValueError("This function requires an object id not {}".format(object_id))

    def send_request(self, request, check=True):
        return self.session.send_request(request, check=check, wait_for_response=self.get_responses)

    def get_name_from_id(self, object_id, object_type):
        if not object_id:
            raise ValueError("Object id cannot be None")
        if not self.caching or not self.get_cached_object_by_id(object_type=object_type, object_id=object_id):
            response = self.get_object(url=object_type, object_id=object_id)
            if response:
                display_name = response["displayName"]
                return display_name
            else:
                return None
        else:
            return self.get_cached_object_by_id(object_id=object_id, object_type=object_type)["displayName"]

    def get_object_from_property(self, value, property, object_type, operator=OPERATOR_EQUALS, grab=False):
        response = self.make_simple_request(url=object_type, filters=[(property, value, operator)])
        response_objects = response.value

        # There might be more than one, in that case, use the grab parameter to specify which
        if len(response_objects) and grab is not False:
            return response_objects[grab]
        elif len(response_objects) != 1:
            LOGGER.info("There are {} objects of type {} with the property value of {} {}".format(len(response_objects), object_type, property, value))
        else:
            return response_objects[0]

    # Returns the id of an object with the propery, such as IP address
    def get_id_from_property(self, property, value, object_type, grab=0):
        if property == PROPERTY_NAME:
            object_body = self.get_object_from_name(object_name=value, object_type=object_type, grab=0)
            if object_body:
                return object_body["id"]
            else:
                raise ValueError("Unable to find object of type {} with name {}".format(object_type, value))
        else:
            raise
            return self.get_id_from_value(*args, **kwargs)["id"]

    # Get the id from a display name and object type
    def get_id_from_name(self, object_name, object_type, find_if_not_cached=False):
        if not isinstance(object_name, str):
            object_name = object_name.name

        if self.caching:
            if self.get_cached_objects(object_type):
                self.get_objects(object_type)
            for object_body in self.get_cached_objects(object_type):
                if object_body["displayName"] == object_name:
                    return object_body["id"]

        if not self.caching or (self.caching and find_if_not_cached):
            response = self.get_id_from_property(value=object_name, property=PROPERTY_NAME, object_type=object_type)
            return response
        else:
            return None

    def get_object_from_name(self, object_name, object_type, grab=False):
        if not isinstance(object_name, str):
            object_name = object_name.name

        if self.caching:
            for object_body in self.get_cached_objects(object_type):
                if object_body["displayName"] == object_name:
                    return object_body

        return self.get_object_from_property(value=object_name, property=PROPERTY_NAME, object_type=object_type, grab=grab)

    def get_id_from_name(self, *args, **kwargs):
        response = self.get_object_from_name(*args, **kwargs)
        if response:
            return response["id"]

    def get_id_from_value(self, value, object_type, attribute, strict=False):
        if attribute is None or object_type is None or value is None:
            raise ValueError("Object type {} or attribute {} can't be None".format(object_id, object_type))

        if object_type in (OPERATIONAL_NODES,):
            response_objects = self.get_objects(url=object_type)
            if attribute in (PROPERTY_IP_ADDRESS, PROPERTY_MAC_ADDRESS):
                for response_object in response_objects:
                    for object_attribute in response_object["attributes"]:
                        if attribute == PROPERTY_IP_ADDRESS and "IpAttr" in object_attribute["@odata.type"]:
                            if value == object_attribute["ipAddress"]:
                                return response_object["id"]
                        if attribute == PROPERTY_MAC_ADDRESS and "EthernetAttr" in object_attribute["@odata.type"]:
                            if value == object_attribute["macAddress"]:
                                return response_object["id"]
            else:
                raise ValueError("Unknown attribute type {}".format(attribute))
        else:
            raise ValueError("Unknown object type {}".format(object_type))

    # Get the value from an attribute associated with an object id and object type
    def get_value_from_id(self, object_id, object_type, attribute, strict=False):
        if object_id is None or object_type is None:
            raise ValueError("Object id {} or object type {} can't be None".format(object_id, object_type))
        value = None

        if object_type == CONFIGURATION_CSTS:
            response_object = self.get_object(url=CONFIGURATION_CSTS, object_id=object_id)
            if response_object is None:
                raise ValueError("Unable to get CST with object id {}".format(object_id))
            else:
                value = response_object[attribute]
        elif object_type in (CONFIGURATION_NODES, OPERATIONAL_NODES):
            response_object = self.get_object(url=object_type, object_id=object_id)
            if not response_object:
                raise ValueError("Unable to find id {} of type {}".format(object_id, object_type))
            
            if attribute in (PROPERTY_NAME, PROPERTY_LINKED):
                value = response_object[attribute]
            elif attribute in (PROPERTY_IP_ADDRESS,):
                if response_object.get(attribute):
                    return response_object[attribute]

                if object_type == CONFIGURATION_NODES:
                    linked_id = self.get_value_from_id(object_id=object_id, object_type=CONFIGURATION_NODES, attribute=PROPERTY_LINKED)
                    response_object = self.get_operational_node(object_id=linked_id)

                for attr in response_object["attributes"]:
                    if "IpAttr" in attr["@odata.type"]:
                        value = attr[attribute]
            
            # TODO Need a special case for SEL-2740S nodes
            elif attribute in (PROPERTY_MAC_ADDRESS,):
                if object_type == CONFIGURATION_NODES:
                    linked_id = self.get_value_from_id(object_id=object_id, object_type=CONFIGURATION_NODES, attribute=PROPERTY_LINKED)
                    response_object = self.get_operational_node(object_id=linked_id)

                for attr in response_object["attributes"]:
                    if "EthernetAttr" in attr["@odata.type"]:
                        value = attr[attribute]
            else:
                raise ValueError("Unknown attribute/property {} for type {}".format(attribute, object_type))
        elif object_type == OPERATIONAL_PORTS:
            operational_object = self.get_object(url=OPERATIONAL_PORTS, object_id=object_id)
            if attribute in (PROPERTY_NAME,):
                if not operational_object or not operational_object.get(PROPERTY_LINKED, False):
                    return None
                configuration_object = self.get_object(url=CONFIGURATION_PORTS, object_id=operational_object[PROPERTY_LINKED])
                value = configuration_object[attribute]
        elif object_type == CONFIGURATION_PORTS:
            configuration_object = self.get_object(url=CONFIGURATION_PORTS, object_id=object_id)
            if attribute in (PROPERTY_NAME,):
                value = configuration_object[attribute]
            else:
                operational_port_object = self.get_object(url=OPERATIONAL_PORTS, object_id=configuration_object[PROPERTY_LINKED])

                if operational_port_object:
                    for single_attribute in operational_port_object["attributes"]:
                        if single_attribute["@odata.type"].split(".")[-1] == attribute:
                            if attribute == "OpenFlowPortAttr":
                                value = single_attribute["portId"]
                                break
                            elif attribute == "IpAttr":
                                value = single_attribute["ipAddress"]
                                break
                            elif attribute == "EthernetAttr":
                                value = single_attribute["macAddress"]
                                break
                            elif attribute == "EthernetApplicationAttr":
                                value = single_attribute["macAddress"]
                                break
                        elif attribute == "hardwareAddress" and single_attribute.get("hardwareAddress"):
                            return single_attribute["hardwareAddress"]

                if value is None:
                    raise ValueError("Unable to find value for attribute {}".format(attribute))
        elif object_type == CONFIGURATION_GROUPS:
            configuration_object = self.get_object(url=CONFIGURATION_GROUPS, object_id=object_id)
            value = configuration_object[attribute]
        else:
            raise ValueError("Unknown object type {}".format(object_type))

        if strict and value is None:
            raise ValueError("Unable to retrieve attribute {} from id {} of type {}".format(attribute, object_id, object_type))

        return value

    def gets_function_from_url(self, url):
        if url == CONFIGURATION_CSTS:
            return self._get_csts
        elif url == CONFIGURATION_LCS:
            return self._get_lcs
        elif url == CONFIGURATION_NODES:
            return self._get_configuration_nodes
        elif url == OPERATIONAL_NODES:
            return self._get_operational_nodes
        elif url == CONFIGURATION_FLOWS:
            return self._get_flows
        elif url == CONFIGURATION_METERS:
            return self._get_meters
        elif url == CONFIGURATION_GROUPS:
            return self._get_groups
        elif url == OPERATIONAL_PORTS:
            return self._get_operational_ports
        elif url == CONFIGURATION_PORTS:
            return self._get_configuration_ports
        elif url == OPERATIONAL_LINKS:
            return self._get_operational_links
        elif url == SECURITY_APPLICATION_LINKS:
            return self._get_applications
        elif url == SECURITY_ROLES:
            return self._get_roles
        elif url == SECURITY_USERS:
            return self._get_users
        else:
            return partial(self._get_objects, url=url)
            raise ValueError("Unable to find get function for url {}".format(url))

    def add_function_from_url(self, url):
        if url == CONFIGURATION_NODES:
            return self.convert_node_entry_to_rest
        elif url == CONFIGURATION_METERS:
            return self.convert_meter_entry_to_rest
        elif url == CONFIGURATION_FLOWS:
            return self.convert_flow_entry_to_rest
        elif url == CONFIGURATION_GROUPS:
            return self.convert_group_entry_to_rest
        elif url == CONFIGURATION_LCS:
            return self.add_application_entry
        elif url == CONFIGURATION_CSTS:
            return self.convert_protocol_entry_to_rest
        else:
            raise ValueError("Unable to find add function for url {}".format(url))

    def diff_function_from_url(self, url):
        if url == CONFIGURATION_NODES:
            return self.resolve_configuration_node_entries_diff
        elif url == CONFIGURATION_METERS:
            return self.resolve_meter_entries_diff
        elif url == CONFIGURATION_FLOWS:
            raise
        elif url == CONFIGURATION_GROUPS:
            raise
        elif url == CONFIGURATION_LCS:
            raise
        elif url == CONFIGURATION_CSTS:
            raise
        else:
            raise ValueError("Unable to find diff function for url {}".format(url))

    def external_diff_function_from_url(self, url):
        if url == CONFIGURATION_FLOWS:
            return create_flow_entries_diff
        elif url == CONFIGURATION_NODES:
            return create_group_entries_diff
        elif url == CONFIGURATION_METERS:
            return create_meter_entries_diff
        elif url == CONFIGURATION_GROUPS:
            return create_group_entries_diff
        else:
            raise ValueError("Unable to find diff function for url {}".format(url))

    def update_function_from_url(self, url):
        if url == SETTINGS_SECURITY_MANAGER:
            return self.convert_security_manager_to_rest
        else:
            raise ValueError("Unable to find update function for url {}".format(url))

    def get_function_from_url(self, url):
        if url == CONFIGURATION_CSTS:
            return self._get_cst
        elif url == CONFIGURATION_LCS:
            return self._get_lc
        elif url == CONFIGURATION_NODES:
            return self._get_configuration_node
        elif url == OPERATIONAL_NODES:
            return self._get_operational_node
        elif url == CONFIGURATION_FLOWS:
            return self._get_flow
        elif url == CONFIGURATION_METERS:
            return self._get_meter
        elif url == CONFIGURATION_GROUPS:
            return self._get_group
        elif url == OPERATIONAL_PORTS:
            return self._get_operational_port
        elif url == CONFIGURATION_PORTS:
            return self._get_configuration_port
        elif url == OPERATIONAL_LINKS:
            return self._get_operational_link
        elif url == SECURITY_ROLES:
            return self._get_role
        else:
            return partial(self._get_object, url=url)
            raise ValueError("Unable to find get function for url {}".format(url))

    def create_function_from_url(self, url):
        if url == CONFIGURATION_NODES:
            return self.convert_configuration_node_objects_to_rest
        elif url == SECURITY_ROLES:
            return self.convert_role_to_rest
        elif url == SECURITY_USERS:
            return self.convert_user_to_rest
        elif url == CONFIGURATION_FLOWS:
            return self.convert_flow_entry_to_rest
        elif url == CONFIGURATION_GROUPS:
            return self.convert_group_entry_to_rest
        elif url == CONFIGURATION_METERS:
            return self.convert_meter_entry_to_rest
        else:
            raise ValueError("Unable to find create function for url {}".format(url))

    def delete_function_from_url(self, url):
        if url == CONFIGURATION_CSTS:
            return self._delete_cst
        elif url == CONFIGURATION_FLOWS:
            return self._delete_flow
        elif url == CONFIGURATION_NODES:
            return self._delete_configuration_node
        elif url == CONFIGURATION_METERS:
            return self._delete_meter
        elif url == CONFIGURATION_LCS:
            return self._delete_lc
        elif url == SECURITY_ROLES:
            return self._delete_role
        else:
            return partial(self._delete_object, url=url)
            raise ValueError("Unable to find delete function for url {}".format(url))

    def modify_object(self, url, object_id, mod_body, command="PATCH", **arguments):
        response = self.make_body_request(url, object_id=object_id, body=mod_body, command=command)
        LOGGER.info("Modified object %s of type %s", object_id, url.split("/")[-1])
        if self.caching:
            self.update_cached_object_by_id(url, object_id, value=response)

        return response

    def modify_objects(self, url, objects, command="PATCH"):
        callback_partial = partial(self.modify_object, url=url, command=command)

        def callback_function(delete_entry):
            converted_entry = self.create_function_from_url(url)(delete_entry.get_attribute("linked_add")[0])
            #self.update_object(url=object_type, object_body=converted_entry, object_id=delete_entry.get_attribute("id"), command="PUT")
            return callback_partial(object=object, mod_body=converted_entry, object_id=delete_entry.get_attribute("id"))

        return run_collection(objects, callback_function, object_type=url.split("/")[-1], command="update")        

    def _delete_object(self, url, object_id):
        if not object_id:
            raise ValueError("Object ID cannot be {}".format(object_id))
        return self.make_simple_request(url, object_id=object_id, command="DELETE")

    def delete_object(self, url, object_id, **arguments):
        function = self.delete_function_from_url(url=url)
        response = function(object_id=object_id, **arguments)
        LOGGER.info("Deleted object %s of type %s", object_id, url.split("/")[-1])
        if self.caching and response.code == 204:
            self.delete_cached_object_by_id(object_type=url, object_id=object_id)

        return response

    def delete_objects(self, url, objects):
        callback_partial = partial(self.delete_object, url=url)

        def callback_function(object):
            if isinstance(object, dict):
                return callback_partial(object_id=object[PROPERTY_ID])
            else:
                return callback_partial(object_id=object.get_attribute(PROPERTY_ID))

        return run_collection(objects, callback_function, object_type=url.split("/")[-1], command="delete")
        #return [self.delete_object(object_id=object[PROPERTY_ID], url=url) for object in objects]

    # TODO clear the other date stores
    def delete_object_by_name(self, url, object_name):
        object_id = self.get_id_from_name(object_name=object_name, object_type=url)
        if object_id:
            self.delete_object(object_id=object_id, url=url)
        else:
            return None

    def get_wrap_object_from_url(self, object_type):
        if object_type == CONFIGURATION_NODES:
            return ConfigurationNodeRestObject
        elif object_type == OPERATIONAL_NODES:
            return OperationalNodeRestObject
        elif object_type == CONFIGURATION_PORTS:
            return ConfigurationPortRestObject
        elif object_type == OPERATIONAL_PORTS:
            return OperationalPortRestObject
        elif object_type == CONFIGURATION_LINKS:
            return ConfigurationLinkRestObject
        elif object_type == OPERATIONAL_LINKS:
            return OperationalLinkRestObject
        elif object_type == CONFIGURATION_CSTS:
            return CommunicationServiceTypeRestObject
        else:
            raise ValueError("Unable to find wrap object for object type {}".format(object_type))

    def get_wrap_object_collection_from_url(self, object_type):
        if object_type == CONFIGURATION_NODES:
            return ConfigurationNodeObjectCollection
        elif object_type == OPERATIONAL_NODES:
            return OperationalNodeObjectCollection
        elif object_type == CONFIGURATION_PORTS:
            return ConfigurationPortObjectCollection
        elif object_type == OPERATIONAL_PORTS:
            return OperationalPortObjectCollection
        elif object_type == CONFIGURATION_LINKS:
            return ConfigurationLinkObjectCollection
        elif object_type == OPERATIONAL_LINKS:
            return OperationalLinkObjectCollection
        elif object_type == CONFIGURATION_CSTS:
            return CommunicationServiceTypeCollection
        else:
            raise ValueError("Unable to find wrap object collection for object type {}".format(object_type))

    def _get_wrapped_objects(self, object_type, objects):
        wrap_object = self.get_wrap_object_from_url(object_type)
        wrap_collection = self.get_wrap_object_collection_from_url(object_type)
        return wrap_collection(values=objects, interface=self, object_type=wrap_object)        

    def get_wrapped_objects(self, object_type):
        unwrapped_objects = self.get_objects(object_type)
        if unwrapped_objects and not isinstance(unwrapped_objects, RestObjectCollection):
            return self._get_wrapped_objects(object_type, objects=unwrapped_objects)
        return unwrapped_objects

    def _get_wrapped_object(self, object_type, object):
        wrap_object = self.get_wrap_object_from_url(object_type)
        return wrap_object(object, interface=self)

    def get_wrapped_object(self, object_type, object_id):
        unwrapped_object = self.get_object(object_type, object_id=object_id)
        if unwrapped_object and not isinstance(unwrapped_object, RestObject):
            return self._get_wrapped_object(object_type=object_type, object=unwrapped_object)
        return unwrapped_object

    def get_objects(self, url):
        if self.caching and self.get_cached_objects(url):
            return self.get_cached_objects(url)

        function = self.gets_function_from_url(url)
        
        response = function()

        if self.caching and response.value and response.response_code == 200:
            self.set_cached_objects(url, response.contents)
        return response.contents

    def _get_object(self, url, object_id):
        if not object_id:
            raise ValueError("Object ID cannot be {}".format(object_id))
        return self.make_simple_request(url, object_id=object_id, command="GET")

    def _get_objects(self, url):
        return self.make_simple_request(url, command="GET")

    def get_object(self, url, object_id, find_if_not_cached=False):
        if self.caching:
            if not self.get_cached_objects(url):
                self.get_objects(url)

            cached_object = self.get_cached_object_by_id(object_type=url, object_id=object_id)
            if cached_object:
                return cached_object

        if not self.caching or (self.caching and find_if_not_cached):
            function = self.get_function_from_url(url)
            try:
                response = function(object_id=object_id)
            except NotFoundError as e:
                return None
            else:
                if self.caching and response.contents and response.response_code == 200:
                    self.set_cached_objects(url, response.contents)
                return response.contents
        else:
            return None

    def check_config_node_names(self, node_names, object_type):
        missing_node_names = list()
        for node_name in node_names:
            node_id = self.get_id_from_name(object_name=node_name, object_type=CONFIGURATION_NODES)
            if not node_id:
                missing_node_names.append(node_name)

        if missing_node_names:
            raise ValueError("Unable to find config nodes with names {}".format(", ".join(missing_node_names)))

    def add_objects(self, url, objects):
        if url in (CONFIGURATION_FLOWS, CONFIGURATION_METERS, CONFIGURATION_GROUPS):
            node_names = set([object.node_name for object in objects])
            self.check_config_node_names(node_names, object_type=url)

        #function = self.add_function_from_url(url=url)
        #converted_objects = [function(object) for object in objects]
        callback_partial = partial(self.add_object, url=url)

        def callback_function(object):
            return callback_partial(object=object)
        
        return run_collection(objects, callback_function, object_type=url.split("/")[-1], command="add")

    def add_object(self, url, object, check_status=False, **add_arguments):
        if self.caching and not self.get_cached_objects(url):
            self.get_objects(url)

        function = self.add_function_from_url(url=url)
        body = function(object, **add_arguments)

        if isinstance(body, list):
            responses = list()
            for b in body:
                responses.append(self.add_object_request(url, b, object, check_status=check_status))
            return responses
        else:
            return self.add_object_request(url, body, object, check_status=check_status)

    def add_object_request(self, url, body, object=None, check_status=False, content_type=APPLICATION_JSON):
        LOGGER.info("Adding an object of type {}".format(url))
        try:
            response = self.make_body_request(url=url, content_type=content_type, body=body)
        except BadRequestError as e:
            raise ValueError("An error occured when adding entry {}".format(object))

        if check_status and LC_SUCCESS_RETRY and response["errorState"] != "InProgress":
            for _ in range(LC_SUCCESS_RETRY):
                sleep(LC_TIMEOUT)
                response = self._get_lc(object_id).contents
                if response[PROPERTY_ERROR_STATE] != "InProgress":
                    break

        if response and response.get("id"):
            if object:
                object.add_attribute("id", response["id"])
            if self.caching:
                self.add_cached_object(url, value=response)
        return response

    def validate_add_function_from_url(self, url):
        if url == CONFIGURATION_NODES:
            return self.validate_add_configuration_node

    def create_object(self, url, *args, **kwargs):
        function = self.create_function_from_url(url=url)
        body = function(*args, **kwargs)

        validate_function = self.validate_add_function_from_url(url=url)
        if validate_function:
            result = validate_function(body)
            if not result:
                LOGGER.warning("Cannot add {} with name {} because conflicts with another object".format(url, body["displayName"]))
                return result

        response = self.make_body_request(url=url, content_type=APPLICATION_JSON, body=body)
        return response

    def resolve_entries_diff(self, add_entries, delete_entries, object_type, add_arguments=None, delete_arguments=None):
        if add_arguments is None:
            add_arguments = dict()
        if delete_arguments is None:
            delete_arguments = dict()

        for add_entry in add_entries:
            self.add_object(object=add_entry, url=object_type, **add_arguments)

        for delete_entry in delete_entries:
            if delete_entry.get_attribute("id"):
                if isinstance(delete_entry.get_attribute("id"), list):
                    delete_ids = delete_entry.get_attribute("id")
                else:
                    delete_ids = [delete_entry.get_attribute("id")]

                for delete_id in delete_ids:
                    self.delete_object(object_id=delete_id, url=object_type, **delete_arguments)
            else:
                raise ValueError("Unable to get object id from entry {}".format(delete_entry))

    def get_url_from_entry_type(self, entry):
        if isinstance(entry, Device) or isinstance(entry, Port):
            return CONFIGURATION_NODES
        elif isinstance(entry, FlowEntry):
            return CONFIGURATION_FLOWS
        elif isinstance(entry, GroupEntry):
            return CONFIGURATION_GROUPS
        elif isinstance(entry, MeterEntry):
            return CONFIGURATION_METERS
        elif isinstance(entry, Application):
            return CONFIGURATION_LCS
        elif isinstance(entry, Protocol):
            return CONFIGURATION_CSTS
        else:
            raise TypeError("Unknown type for {}".format(entry))

    # Smart function to determine the type of object and therefore the URL to use
    def add_entries(self, entries):
        url = self.get_url_from_entry_type(entries[0])
        return self.add_entries(url, entries)

    def diff_entries(self, entries):
        url = self.get_url_from_entry_type(entries[0])
        return self.diff_objects(url, entries)

    def diff_objects(self, url, entries):
        function_object = self.diff_function_from_url(url)
        return function_object(entries)

    def add_entries(self, url, objects):
        return [self.add_entry(url, object=object) for object in objects]

    def add_entry(self, url, object):
        response = self.add_object(url=url, object=object)
        object.add_attribute("status", response["errorState"])

    def get_names_from_objects(self, objects):
        if isinstance(objects, Device):
            return objects.print_name
        elif isinstance(objects, Port):
            if objects.owner and len(objects.owner.ports) == 1:
                return objects.owner.print_name
            elif objects.owner and len(objects.owner.ports) > 1 and sum([1 for port in objects.owner.ports if port.end]) == 1:
                return objects.owner.print_name
            elif objects.owner and isinstance(objects.owner, SEL274XSDevice) and objects.name == 4294967294:
                return objects.owner.print_name
            elif objects.mode in ("Failover", "PRP"):
                return objects.owner.print_name
            else:
                return objects.print_name
        elif isinstance(objects, str):
            return objects
        else:
            object_names = list()
            for object in objects:
                object_names.append(self.get_names_from_objects(object))
            return object_names

    def get_owner_from_port(self, port_object):
        operational_node_owning_port_object = self.get_operational_node(port_object["parentNode"])
        return operational_node_owning_port_object["id"]

    def get_other_ports_from_port(self, port_object):
        port_object_id = port_object["id"]
        attached_link_ids = port_object["attachedLinks"]
        other_ports = list()
        # Could be a device in failover mode and therefore two links
        for attached_link_id in attached_link_ids:
            attached_link_object = self.get_operational_link(attached_link_id)
            for attached_link_port_id in attached_link_object["endPoints"]:
                # Need to find the other side of the link that is not me
                if attached_link_port_id != port_object_id:
                    # I only return one, if more than one, need a traditional switch
                    other_ports.append(self.get_operational_port(attached_link_port_id))
        return other_ports


class RESTInterface(ControllerInterface, name=None, url=None):
    def __init__(self, username, password, role="PermissionLevel3", url="localhost", oauth_type=OAUTH_TYPE_USER, port=None, verbose=False, version_5056=None, caching=False, key_file=None, cert_file=None, auto_login=True, timeout=SOCKET_TIMEOUT,save_packets=False):
        super().__init__(caching=caching, verbose=verbose)

        if ":" in url and not port:
            url, port = url.split(":")
            port = int(port)

        self._session = Session(url=url, verbose=verbose, role=role, port=port, version_5056=version_5056, username=username, password=password, oauth_type=oauth_type, key_file=key_file, cert_file=cert_file, auto_login=auto_login, timeout=timeout, save_packets=save_packets)

    @property
    def version_5056(self):
        if self.session:
            return self.session.version_5056
    
    @version_5056.setter
    def version_5056(self, new_version):
        self.session.version_5056 = new_version

    @property
    def url(self):
        return self.session._host
    
    def __enter__(self):
        return self

    def __exit__(self, exc_ty, exc_val, exc_tb):
        self._session.logout()

    def get_controller_version(self):
        settings_5056 = self.make_simple_request("/configuration/settings.json").contents
        return settings_5056["controllerVersion"]

    def login(self, username=None, password=None, role=None):
        session = self.session.login(username=username, password=password, role=role)
        return session

    def logout(self):
        return self._session.logout()

    def commission_database(self, username=None, password=None):
        if username is None:
            username = self.session.username
        if password is None:
            password = self.session.password

        body = {"commissioningList": [{"@odata.type": "#Sel.BlueFrame.CommissioningManager.UserCommissioner.UserCommissioningConcern", "username": username, "password": password}]}
        request = Request(url=SECURITY_COMMISSION, command=COMMAND_POST)
        request.add_header("Content-Type", APPLICATION_JSON)
        request.add_body(body)
        return self.send_request(request, check=False)
