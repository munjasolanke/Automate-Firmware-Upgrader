from ipaddress import IPv4Interface
from time import sleep

from . import LOGGER

from .base import LogicalConnectionObject, LogicalConnectionObjectCollection

from .metaclasses import ObjectMixin
from .decorators import no_body_url
from .constants import CONFIGURATION_LCS, CONFIGURATION_NODES, CONFIGURATION_CSTS, PROPERTY_SETQUEUE, COMMAND_DELETE, COMMAND_POST, FUNCTION_RESUBMIT_LC, APPLICATION_JSON
from .constants import PROPERTY_ERRORS, PROPERTY_ERROR_STATE, PROPERTY_NAME, CODE_CREATED, PROPERTY_ID, CONFIGURATION_FLOWS, CONFIGURATION_GROUPS
from .constants import PROPERTY_IP_ADDRESS, OBJECT_NODES
from .exceptions import NotFoundError, BadRequestError, RequestError, NotFoundError

from ...automation.application import MulticastApplication, UnicastApplication
from ...automation.protocol import Ipv4Protocol, ArpProtocol
from ...automation.policy import Policies, IDSPolicy, IDSMissPolicy
from ...automation.device import EndDevice, RouterDevice, OpenFlowDevice, PortDevice
from ...automation.port import Port
from ...automation.named_object import NamedObject

from ...openflow.core.group_entry import AllGroup
from ...openflow.core.action_bucket import ActionBuckets, SimpleActionBucket
from ...openflow.core.instructions import WriteActionsInstruction
from ...openflow.core.actions import PopVlanAction, SetVlanVidAction, PushVlanAction, OutputAction, GroupAction
from ...openflow.core.match_fields import InPortMatch, Ipv4DstMatch, Ipv4SrcMatch, VlanVidMatch, ArpSpaMatch, ArpTpaMatch, EthTypeMatch, EthSrcMatch, EthDstMatch

from ...base.collection import ApplicationCollection

from ...tools.diff.diff import create_application_entries_diff

from ...globals import APPLICATION_FLOW_NAME_FORMAT, LC_SUCCESS_RETRY, LC_TIMEOUT

class LogicalConnectionMixin(metaclass=ObjectMixin, name="lc", url=CONFIGURATION_LCS):
    # LCs are different than the traditional add/delete for entries.
    def get_lc_objects(self):
        results = list()
        for lc in self.get_lcs():
            new_object = LogicalConnectionObject(config_body=lc, operational_body=None, interface=self)
            results.append(new_object)

        return LogicalConnectionObjectCollection(values=results, interface=self)

    def delete_application_entry(self, application_entry):
        # Need to figure out how to delete application entries with Table Miss
        if application_entry.get_attribute("id"):
            responses = list()
            for object_id in application_entry.get_attribute("id"):
                #self.delete_lc(object_id)
                lc_body = self.get_lc(object_id=object_id)
                if lc_body:
                    print("Delete application", application_entry)
                    LOGGER.warning("Delete application {}".format(application_entry))
                    responses.append(self.delete_lc_wrapper(object_id=object_id))
        else:
            raise ValueError("Unable to delete LCs that do not have an ID, they must be exported from the SEL-5056 or contain the id attribute")

    def delete_lc_wrapper(self, object_id, linked=False):
        responses = list()
        lc_body = self.get_lc(object_id=object_id)
        if not lc_body:
            LOGGER.warning("Unable to find LC with ID {} to delete".format(object_id))
            return [False]

        # Cheap but not accurate way to stop from deleting 
        if lc_body["communicationServiceTypeId"] == "SEL-5056: In Band Path":
            LOGGER.warning("Unable to delete an in-band LC")
            return [False]

        cst_name = self.get_name_from_id(object_id=lc_body["communicationServiceTypeId"], object_type=CONFIGURATION_CSTS)
        # Unreserve the VID if Table miss AND it is not part of an update.
        if "Table Miss" in cst_name and not linked:
            vid, strip = self._get_table_miss_arguments_from_lc(lc_body["id"])

            if vid:
                self._unreserve_vid(vid)

        responses.append(self.delete_lc(object_id=object_id))

        # Delete the CST if there are no more references to the CST anymore
        if len(lc_body["communicationServiceTypeId"]) == 32 and len(self.get_lcs_referencing_cst(lc_body["communicationServiceTypeId"])) == 0:
            responses.append(self.delete_cst(object_id=lc_body["communicationServiceTypeId"]))

        return responses

    def _resolve_application_entries_diff(self, add_entries, delete_entries, combine_arps=True, use_aliased_fields=True, maintain_comms=True):
        modify_entries = list()
        still_add_entries = list()
        added_lcs = list()

        len_add_entries = len(add_entries)
        # Need to group by protocol and do them all at once so that the CST name will stay the same
        combined_by_protocols = dict()
        not_combined_by_protocols = list()

        for add_index, add_entry in enumerate(add_entries):
            if add_entry.get_attribute("linked_delete"):
                LOGGER.info("Found an entry to add +1 to %s", add_entry)
                if add_entry.protocol.name not in combined_by_protocols:
                    combined_by_protocols[add_entry.protocol.name] = [add_entry]
                else:
                    combined_by_protocols[add_entry.protocol.name].append(add_entry)
            else:
                not_combined_by_protocols.append(add_entry)

        total_programmed = 0
        for protocol_name, add_entries_by_protocol in combined_by_protocols.items():
            temp_created_csts_all = list()
            temp_created_lcs_all = list()
            for add_index, add_entry in enumerate(add_entries_by_protocol):
                total_programmed += 1
                try:
                    print("Adding Application {} of {}: {}".format(total_programmed, len_add_entries, add_entry))
                    LOGGER.warning("Adding Application {} of {}: {}".format(total_programmed, len_add_entries, add_entry))
                    # Implement +1 add and delete for linked LCs
                    # Several steps to minimize traffic disruption
                    # 1. Add a temporary LC with the same information as the original except at flow priority + 1
                    # 2. Delete the original LC
                    # 3. Add the new LC at the original priority
                    # 4. Delete the temporary LC

                    # 1. Add a temporary LC with the same information as the original except at flow priority + 1                
                    # First need to add a temp LC with +1 priority
                    if maintain_comms:
                        temp_application_entry = add_entry.copy()
                        original_priority = add_entry.protocol.get_attribute("FlowPriority") if add_entry.protocol.get_attribute("FlowPriority") else 2000
                        temporary_priority = original_priority + 1

                        temp_application_entry.protocol.set_attribute("FlowPriority", temporary_priority)
                        temp_application_entry.protocol.name = "*" + temp_application_entry.protocol.name[1:]

                        temp_created_csts, temp_created_lcs = self.add_application_entry(application_entry=temp_application_entry, create_arp_automatically=False, use_aliased_fields=use_aliased_fields)
                        temp_created_csts_all.extend(temp_created_csts)
                        temp_created_lcs_all.extend(temp_created_lcs)
                        if combine_arps and add_entry.to_arp():
                            temp_application_entry = add_entry.to_arp()
                            temp_application_entry.protocol.name = "*ARP"
                            temp_application_entry.protocol.set_attribute("FlowPriority", temporary_priority)
                            temp_created_arp_csts, temp_created_arp_lcs = self.add_application_entry(application_entry=temp_application_entry, create_arp_automatically=False, use_aliased_fields=use_aliased_fields)
                            temp_created_csts_all.extend(temp_created_arp_csts)
                            temp_created_lcs_all.extend(temp_created_arp_lcs)
                except ValueError as e:
                    raise e
                    LOGGER.warning("Unable to program LC because {}".format(e))

            for add_index, add_entry in enumerate(add_entries_by_protocol):
                # 2. Delete the original LC
                delete_application_entries = add_entry.get_attribute("linked_delete")

                delete_indexes = list()
                for delete_application_entry in delete_application_entries:
                    self.delete_application_entry(delete_application_entry)
                    if delete_application_entry in delete_entries:
                        delete_indexes.append(delete_entries.index(delete_application_entry))

                # Must do them backwards for the delete_entries indexes stay correct
                for delete_index in delete_indexes[::-1]:
                    delete_entries.pop(delete_index)

            # Need to delete all of the LCs in the category so that the original CSTs are also deleted
            for add_index, add_entry in enumerate(add_entries_by_protocol):         
                # 3. Add the new LC at the original priority
                #add_entry.protocol.set_attribute("FlowPriority", original_priority)
                try:
                    created_csts, created_lcs = self.add_application_entry(application_entry=add_entry, create_arp_automatically=combine_arps, use_aliased_fields=use_aliased_fields)
                except ValueError as e:
                    raise e
                    LOGGER.warning("Unable to program LC because {}".format(e))

            # 4. Delete the temporary LC
            for temp_created_lc in temp_created_lcs_all:
                if temp_created_lc:
                    self.delete_lc_wrapper(object_id=temp_created_lc["id"], linked=True)

        # Now for the rest of the entries that are not related to delete entries
        for add_index, add_entry in enumerate(not_combined_by_protocols):
            print("Adding Application {} of {}: {}".format(total_programmed+add_index+1, len_add_entries, add_entry))
            LOGGER.warning("Adding Application {} of {}: {}".format(total_programmed+add_index+1, len_add_entries, add_entry))
            try:
            # This is a new LC not related to other presents or added, so can add
                created_csts, created_lcs = self.add_application_entry(application_entry=add_entry, create_arp_automatically=combine_arps, use_aliased_fields=use_aliased_fields)
                added_lcs.extend(created_lcs)
            except ValueError as e:
                raise e
                LOGGER.warning("Unable to program LC because {}".format(e))
            #for created_lc in created_lcs:
            #    if created_lc:
            #        lc_body = self.get_lc(object_id=created_lc["id"])
            #        if lc_body and lc_body["errorState"] != "Success":
            #            self.resubmit_lc(lc_body["id"])

        for delete_entry in delete_entries:
            LOGGER.warning("Deleting Application {}".format(delete_entry))
            # This is an old LC not related to any new application
            for object_id in delete_entry.get_attribute("id"):
                # Need to delete non ARP first
                if delete_entry.get_attribute("shared_arp_ids") and delete_entry.get_attribute("arp_id") and object_id in delete_entry.get_attribute("arp_id"):
                    pass
                else:
                    self.delete_lc_wrapper(object_id=object_id)

            for object_id in delete_entry.get_attribute("id"):
                if delete_entry.get_attribute("shared_arp_ids") and delete_entry.get_attribute("arp_id") and object_id in delete_entry.get_attribute("arp_id"):
                    #if len(self.get_lcs_referencing_cst(object_id)) == 0
                    
                    # Need to see if the LCs that reference this ARP still exist, if not, delete
                    for shared_arp_id in delete_entry.get_attribute("shared_arp_ids"):
                        result = self.get_lc(shared_arp_id)
                        if result is not None:
                            break
                    else:
                        self.delete_lc_wrapper(object_id=object_id)

        # Remove the tags
        for add_entry in add_entries:
            add_entry.delete_attribute("linked_delete")

        for delete_entry in delete_entries:
            delete_entry.delete_attribute("linked_add")

    def find_duplicates(self, entries):
        duplicates = list()
        for index, entry in enumerate(entries):
            if entry in entries[index+1:]:
                duplicates.append(entry)
        return duplicates

    # Get the LC that are refering configuration node IDs that are no longer valid
    def get_bad_lcs(self):
        bad_lcs = list()
        lcs = self.get_lcs()

        for lc in lcs:
            for node in lc["sourceEndPoints"] + lc["destinationEndPoints"]:
                config_node = self.get_configuration_node(object_id=node)
                if not config_node:
                    bad_lcs.append(lc)
            
        return bad_lcs

    # Get all of the temp LC that were created by the +1 scheme
    def get_temp_lcs(self):
        temp_lcs = list()
        lcs = self.get_lcs()

        for lc in lcs:
            cst = self.get_cst(object_id=lc["communicationServiceTypeId"])
            if cst["displayName"][0] == "*":
                temp_lcs.append(lc)

        return temp_lcs

    def diff_application_entries(self, new_entries, old_entries=None, combine_arps=True, ignore_ids=False, delete_bad=False, use_aliased_fields=True, maintain_comms=True, node_entries=None, networks=None):
        if delete_bad:
            bad_lcs = self.get_bad_lcs()
            for bad_lc in bad_lcs:
                self.delete_lc_wrapper(bad_lc["id"])

            for temp_lc in self.get_temp_lcs():
                self.delete_lc_wrapper(temp_lc["id"])

            for temp_cst in self.get_temp_csts():
                self.delete_object(url=CONFIGURATION_CSTS, object_id=temp_cst["id"])

        if not old_entries:
            old_entries = self.get_application_entries(combine_arps=combine_arps, node_entries=node_entries, networks=networks)
            # TODO Remove IB management LCs if present
            old_entries -= old_entries.has_protocol("SEL-5056: In Band Path")
            duplicate_old_entries = self.find_duplicates(old_entries)
            if node_entries and networks:
                old_entries = old_entries.is_only_in_networks(networks)
        else:
            duplicate_old_entries = list()

        add_entries, delete_entries = create_application_entries_diff(new_entries=new_entries, old_entries=old_entries)
        delete_entries.extend(duplicate_old_entries)
        delete_entries = delete_entries.remove(delete_entries.has_name("SEL-5056: In Band Path"))

        # Need to see if ARP is missing
        if combine_arps:
            add_entries += self.find_missing_arps(new_entries)

        self._resolve_application_entries_diff(add_entries=add_entries, delete_entries=delete_entries, combine_arps=combine_arps, use_aliased_fields=use_aliased_fields, maintain_comms=maintain_comms)

    def find_missing_arps(self, new_entries):
        # Need to see if ARP is missing
        add_entries = list()
        for new_entry in new_entries:
            if new_entry.arpable:
                #print("---->", new_entry, new_entry.attributes, new_entry.arpable)
                for old_entry in new_entry.get_attribute("linked_equal", []):
                    if old_entry.diff_eq(new_entry):
                        if not old_entry.get_attribute("arp_id"):
                            arp_application_entry = new_entry.to_arp()
                            arp_application_entry.name += " ARP"
                            add_entries.append(arp_application_entry)
        return add_entries

    def add_lc(self, cst_id, source_config_id, destination_config_ids):
        if cst_id is None or source_config_id is None or destination_config_ids is None:
            raise ValueError("CST id {}, source node id {} and destination(s) node id(s) {} must all not be None".format(cst_id, source_config_id, destination_config_ids))
        if [source_config_id] == destination_config_ids:
            raise ValueError("Duplicate values for source and destination for LC")

        source_config_object = self.get_configuration_node(source_config_id)
        if source_config_object["state"] != "Established":
            LOGGER.warning("Skipping programming LC from %s to %s with CST %s because the source is not adopted", source_config_id, destination_config_ids, cst_id)
            return False          
        
        if not isinstance(destination_config_ids, list):
            destination_config_ids = [destination_config_ids]

        new_destination_list = list()
        destination_config_objects = [self.get_configuration_node(destination_config_id) for destination_config_id in destination_config_ids]
        for destination_object in destination_config_objects:
            if destination_object["state"] == "Established":
                new_destination_list.append(destination_object["id"])
            else:
                LOGGER.warning("Skipping programming LC from {} with CST {} to destination {} because the destination is not adopted".format(source_config_id, cst_id, destination_object["id"]))
        destination_config_ids = new_destination_list

        if not destination_config_ids:
            LOGGER.warning("Skipping programming LC from %s to %s with CST %s because none of the destinations are adopted", source_config_id, destination_config_ids, cst_id)
            return False

        # ARP needs to be managed
        program_lc = self.need_to_program_arp(source_config_id, destination_config_ids, cst_id)

        is_already_present = self.find_lc(cst_id, source_config_id, destination_config_ids)
        if not is_already_present and len(destination_config_ids) == 1:
            # I don't check for multicast overlap here!
            if self.is_cst_reversable(cst_id):
                is_already_present = self.find_lc(cst_id, destination_config_ids[0], [source_config_id])

        if not is_already_present and program_lc:
            if isinstance(program_lc, dict):
                LOGGER.info("Deleting an LC from %s to %s with CST %s because new ARP LC has a higher priority", program_lc["sourceEndPoints"], program_lc["destinationEndPoints"], program_lc["communicationServiceTypeId"])
                self.delete_object(url=CONFIGURATION_LCS, object_id=program_lc["id"])
            response = self._add_lc(source_config_id=source_config_id, destination_config_ids=destination_config_ids, cst_id=cst_id)
            return response
        elif is_already_present:
            LOGGER.info("Skipping programming LC from %s to %s with CST %s because it is already present", source_config_id, destination_config_ids, cst_id)
            return False

    def need_to_program_arp(self, source_config_id, destination_config_ids, cst_id):
        cst_body = self.get_cst(object_id=cst_id)
        protocol_entry = self.convert_cst_to_protocol_entry(cst_body)

        if isinstance(protocol_entry, ArpProtocol):
            arp_protocols = self.get_arp_protocol_entries()
            # Are there any other ARPs between source and destination?
            for lc in self.get_lcs():
                if arp_protocols.has_attribute_value("id", lc["communicationServiceTypeId"]):
                    if (lc["sourceEndPoints"] == [source_config_id] and lc["destinationEndPoints"] == destination_config_ids) or\
                            (lc["destinationEndPoints"] == [source_config_id] and lc["sourceEndPoints"] == destination_config_ids):
                        # Here is an ARP already between the source and destination
                        # If the priority is equal or less, don't program the ARP
                        if protocol_entry.priority > arp_protocols.has_attribute_value("id", lc["communicationServiceTypeId"])[0].priority:
                            return False
                            #return lc This would be if I wanted to use the higher priority one
                        else:
                            # This is already an ARP that is "better" than this one
                            return False
            else:
                # There are no other ARPs so program this
                return True
        else:
            # If it is not an ARP, program it
            return True

    def _add_lc(self, source_config_id, destination_config_ids, cst_id):
        body = {
            "sourceEndPoints": source_config_id if isinstance(source_config_id, list) else [source_config_id],
            "destinationEndPoints": destination_config_ids,
            "communicationServiceTypeId": cst_id
            }        

        LOGGER.info("Programming an LC from %s to %s with CST %s", source_config_id, destination_config_ids, cst_id)
        response = self.add_object_request(url=CONFIGURATION_LCS, body=body)
        is_success = self.wait_for_lc_until_success(response["id"])
        if len(destination_config_ids) >= 29:
            self._fix_lc_bucket_issue(response["id"])
        return response

    def _fix_lc_bucket_issue(self, lc_id):
        def divide_list_into_n_chuncks(l, n=30):
            for i in range(0, len(l), n):
                yield l[i:i+n]

        for group_object in self.get_groups():
            if len(group_object["buckets"]) > 30:
                LOGGER.warning("Group with name {} and id {} has {} action buckets, spliting...".format(group_object["displayName"], group_object["groupId"], len(group_object["buckets"])))
                created_group_ids = list()
                first_group_id = self.get_highest_group_id_for_switch(group_object["node"]) + 1
                for index, buckets in enumerate(divide_list_into_n_chuncks(group_object["buckets"])):
                    group_id = first_group_id + index
                    node_name = self.get_name_from_id(object_type=CONFIGURATION_NODES, object_id=group_object["node"])
                    new_group_object = self.create_group_body(name=group_object["displayName"], node_name=node_name,
                                                                   group_type=group_object["groupType"], group_id=group_id, action_buckets=buckets)
                    new_group_object["tags"] = group_object["tags"]

                    self.add_object_request(CONFIGURATION_GROUPS, body=new_group_object)
                    created_group_ids.append(group_id)
                # Need to change the first group
                group_object["buckets"] = list()
                for created_group_id in created_group_ids:
                    group_object["buckets"].append(
                        {
                          "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.Bucket",
                          "actions": [
                            {
                              "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.GroupAction",
                              "groupId": created_group_id
                            }
                          ]
                        }
                    )
                LOGGER.info("Adjusting group {} because it has more than 30 action buckets".format(group_object["groupId"]))
                self.update_object(CONFIGURATION_GROUPS, object_body=group_object, object_id=group_object["id"], command="PUT")

    @no_body_url(url=CONFIGURATION_LCS, command=COMMAND_POST, function=FUNCTION_RESUBMIT_LC)
    def _resubmit_lc(self, object_id, response=None):
        #if self.caching:
        #   self.update_cache(url=CONFIGURATION_LCS, object_id=response.contents["id"], response=response, command=COMMAND_POST)
        return response

    def resubmit_lc(self, object_id):
        if self.version_5056 == "2.2.0.0":
            new_lc = self._resubmit_lc(object_id).contents
        else:
            original_lc = self.get_lc(object_id)
            response = self._resubmit_lc(object_id)
            for lc in self._get_lcs().contents:
                if lc["sourceEndPoints"] == original_lc["sourceEndPoints"] and \
                        lc["destinationEndPoints"] and original_lc["destinationEndPoints"] and \
                        lc["communicationServiceTypeId"] == original_lc["communicationServiceTypeId"]:
                    new_lc = lc

        if new_lc:
            is_success = self.wait_for_lc_until_success(new_lc["id"])
            new_lc = self.get_lc(new_lc["id"])
            if len(new_lc["destinationEndPoints"]) >= 29:
                self._fix_lc_bucket_issue(new_lc["id"])

        return new_lc

    def resubmit_non_success_lcs(self):
        lcs = self.get_lcs()
        for lc in lcs:
            if lc[PROPERTY_ERROR_STATE] != "Success":
                self.resubmit_lc(object_id=lc[PROPERTY_ID])

    def resubmit_ib_lcs(self):
        lcs = self.get_lcs()
        for lc in lcs:
            if lc["communicationServiceTypeId"] == "SEL-5056: In Band Path":
                self.resubmit_lc(object_id=lc[PROPERTY_ID])

    def get_destinations_from_policy(self, policies):
        ids_policies = policies.get_all(IDSPolicy)
        if ids_policies:
            return [policy.destination for policy in ids_policies]
        else:
            return []

    def filter_invalid_nodes(self, nodes):
        valid_nodes = list()
        for node in nodes:
            if self.version_5056 in ("2.1.0.0", "2.2.0.0"):
                valid_nodes.append(node)
            elif isinstance(node, Port) and (isinstance(node.owner, EndDevice) or isinstance(node.owner, RouterDevice)):
                valid_nodes.append(node)
            elif isinstance(node, EndDevice) or isinstance(node, RouterDevice):
                valid_nodes.append(node)
        return valid_nodes

    def add_application_entries(self, application_entries, node_entries=None, create_arp_automatically=True):
        return [self.add_application_entry(application_entry, create_arp_automatically=create_arp_automatically, node_entries=node_entries) for application_entry in application_entries]

    def add_lc_by_name_by_application(self, application_entry, responses, protocol=None, source=None, destinations=None):
        protocol = application_entry.protocol if protocol is None else protocol
        source = application_entry.source if source is None else source
        destinations = application_entry.destinations if destinations is None else destinations

        source = self.filter_invalid_nodes([source])
        destinations = self.filter_invalid_nodes(destinations)

        if not source:
            LOGGER.warning("Skipping {} because no source".format(application_entry.name))
            return [False]
        elif not destinations and not (application_entry.policies and isinstance(application_entry.policies[0].arguments, IDSMissPolicy)):
            LOGGER.warning("Skipping {} because no destinations or not a table miss policy".format(application_entry.name))
            return [False]
        else:
            source = source[0]

        return_responses = list()

        if responses:
            source_name = self.get_names_from_objects([source])[0]
            if not source_name:
                raise ValueError("Unable to resolve name for source {}".format(source))
            destination_list = self.get_destinations_from_policy(application_entry.policies) + destinations
            destinations_name = self.get_names_from_objects(destination_list)
            if None in destinations_name:
                raise ValueError("Unable to resolve name for one or more destinations {}".format(destinations))
            return_response = self.add_lc_by_names(cst_name=responses[0]["displayName"], source_name=source_name, destination_name=destinations_name)
            
            if type(return_response) is dict:
                self.adjust_lc_for_issues(application_entry=application_entry, response=return_response)
                #self.adjust_alias_for_lc(response=return_response, cst_name=responses[0]["displayName"], source_name=source_name, destination_name=destinations_name)
            return_responses.append(return_response)

            if application_entry.policies and isinstance(application_entry.policies[0], IDSMissPolicy):
                if return_response is not False:
                    if type(return_response) is not dict:
                        raise ValueError("Only 1 LC should have been created for table miss policy application not {}".format(len(return_response)))
                    lc_body = self.get_lc(return_response["id"])

                    if lc_body["errorState"] == "Success":
                        self.adjust_lc_entries_for_table_miss(return_response, application_entry.policies[0].vid, application_entry.policies[0].strip)
                    else:
                        LOGGER.error("LC for Table miss did not go to success")
                        self.delete_lc(return_response["id"])

        if len(responses) == 2:
            reverse_application = application_entry.reverse()
            source_name = self.get_names_from_objects(destinations)[0]
            destination_list = self.get_destinations_from_policy(reverse_application.policies) + [source]
            destinations_name = self.get_names_from_objects(destination_list)
            return_response = self.add_lc_by_names(cst_name=responses[1]["displayName"], source_name=source_name, destination_name=destinations_name)

            if type(return_response) is dict:
                self.adjust_lc_for_issues(application_entry=reverse_application, response=return_response)
                #self.adjust_alias_for_lc(response=return_response, cst_name=responses[1]["displayName"], source_name=source_name, destination_name=destinations_name)
            return_responses.append(return_response)
        elif len(responses) > 2:
            raise

        return return_responses

    def adjust_alias_for_lc(self, response, cst_name, source_name, destination_name):
        if type(response) is dict and APPLICATION_FLOW_NAME_FORMAT:
            lc_body = self.get_lc(object_id=response["id"])
            if lc_body["errorState"] == "Success":
                flow_entries = self._get_flow_entries_by_lc(response["id"])
                for flow_entry in flow_entries:
                    try:
                        flow_name = self.get_flow_name_from_format(cst_name, source_name, destination_name)
                        flow_entry["displayName"] = flow_name
                        self.make_body_request(url=CONFIGURATION_FLOWS, command="PUT", object_id=flow_entry["id"], body=flow_entry)
                    except (ValueError, TypeError, BadRequestError) as e:
                        LOGGER.error("Unable to adjust the name on flow entry {} because {}".format(flow_entry, e))
            else:
                LOGGER.error("LC with CST %s from %s to %s did not succeed", cst_name, source_name, destination_name)

    def adjust_lc_for_issues(self, application_entry, response):
        if "2.0" <= self.version_5056 <= "2.1":
            # SDNRC-1072
            # Started when there were LC to and from Switches and fixed in 2.2
            # An issue if there is multiple destinations and a switch is one of them
            # Need to:
            # 1. Gather the flows from the LC
            # 2. Find any duplicates, those with the same node, and match fields 
            # (table might be different for overflow and priority is always the same)
            # 2b. Remove the PopVlan action if the match field VlanVid is present with the value None
            # 3. Find the flow entry with the group action
            # 4. Add the other actions as group buckets if not already present
            # 5. Delete one of the flow entries and point the other to the new All group
            if len(application_entry.destinations) > 1 or (application_entry.destinations and application_entry.policies.get(IDSPolicy)):
                for destination in application_entry.destinations:
                    if isinstance(destination, OpenFlowDevice) or (isinstance(destination, Port) and isinstance(destination.owner, OpenFlowDevice)):
                        # 1.
                        flow_entries = self._get_flow_entries_by_lc(response["id"])
                        # 2.
                        detector_dict = dict()
                        for flow_entry in flow_entries:
                            node = flow_entry["node"]
                            if detector_dict.get(node):
                                detector_dict[node].append(flow_entry)
                            else:
                                detector_dict[node] = [flow_entry]

                        for node, same_node_flow_entries in detector_dict.items():
                            current_match_fields = list()
                            overlapping_match_fields = list()
                            for same_node_flow_entry in same_node_flow_entries:
                                match_fields = same_node_flow_entry["match"]["matchFields"]
                                if match_fields in current_match_fields and match_fields not in overlapping_match_fields:
                                    overlapping_match_fields.append(match_fields)

                                current_match_fields.append(match_fields)

                            for overlapping_match_field in overlapping_match_fields:
                                same_match_field_flow_entries = list()
                                for same_node_flow_entry in same_node_flow_entries:
                                    match_fields = same_node_flow_entry["match"]["matchFields"]
                                    if match_fields == overlapping_match_field:
                                        same_match_field_flow_entries.append(same_node_flow_entry)

                                # 2b. Correct for VLAN Pop
                                pop_vlan = False
                                for check_match_field in overlapping_match_field:
                                    if check_match_field["@odata.type"] == "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MatchFields.VlanVid" and check_match_field["value"] == "None":
                                        pop_vlan = True
                                        break

                                # 3.
                                group_entry = None
                                self.clear_information(url=CONFIGURATION_GROUPS)
                                group_entries = self.get_group_entries()
                                node_name = self.get_name_from_id(object_id=node, object_type=CONFIGURATION_NODES)
                                group_entries = group_entries.has_switch(node_name)
                                keep_flow_entry = None
                                action_buckets = list()
                                for same_match_field_flow_entry in same_match_field_flow_entries:
                                    instructions = self.convert_instructions_from_rest(same_match_field_flow_entry["instructions"])
                                    for instruction in instructions:
                                        if isinstance(instruction, WriteActionsInstruction):
                                            if instruction.get(GroupAction):
                                                if group_entry:
                                                    print(group_entry, instruction.get(GroupAction))
                                                    raise
                                                keep_flow_entry = same_match_field_flow_entry
                                                group_entry = group_entries.has_entry_id(instruction.get(GroupAction).value)[0]
                                            else:
                                                action_bucket = SimpleActionBucket(actions=instruction.values)
                                                # 2b. Remove extranous VLAN pop action
                                                if pop_vlan:
                                                    action_bucket.remove(PopVlanAction)
                                                action_buckets.append(action_bucket)

                                if not keep_flow_entry or not group_entry:
                                    raise ValueError("Unable to find the flow entry or the group to fix multicast issue to switch for switch {}".format(node_name))

                                changed_group = False
                                for action_bucket in action_buckets:
                                    if action_bucket not in group_entry.action_buckets:
                                        group_entry.add_action_bucket(action_bucket)
                                        changed_group = True

                                if changed_group:
                                    group_object = self.convert_group_entry_to_rest(group_entry)
                                    self.update_object(url=CONFIGURATION_GROUPS, command="PUT", object_id=group_entry.get_attribute("id"), object_body=group_object)

                                # 5.
                                for same_match_field_flow_entry in same_match_field_flow_entries:
                                    if same_match_field_flow_entry != keep_flow_entry:
                                        self.delete_object(url=CONFIGURATION_FLOWS, object_id=same_match_field_flow_entry["id"])

                                LOGGER.warning("SDNRC-1072 applied to {}".format(application_entry))

        if self.version_5056 >= "2.1":
            # SDNRC-2720
            # An issue if there is multiple destinations and the source is a switch and a destination is attached to the switch
            # Started when there were LC to and from Switches and not fixed
            # Need to:
            # For each destination:
            # 1. Gather the flows from the LC
            # 2. Find the flow from Local
            # 3. Get the group entry that the flow references
            # 4. See if the group contains an outport to the destination
            # 4a. If not, add the action bucket with the outport to the group
            if application_entry.policies.get(IDSPolicy) and (isinstance(application_entry.source, Port) and isinstance(application_entry.source.owner, OpenFlowDevice)):
                # This can be an expensive operation if caching is not enabled, but have no choice
                source = application_entry.source.owner
                node_entries = self.get_information(OBJECT_NODES)
                for destination in application_entry.destinations:
                    connected_port = destination.find_connected_openflow_switch_port()
                    if connected_port.owner == source:
                        # 1. If the same switch, then need to look at the flow and group to see if outport present
                        flow_objects = self._get_flow_entries_by_lc(response["id"])
                        # Need to find the flow entry from Local
                        for flow_object in flow_objects:
                            flow_entry = self.convert_flow_entry_from_rest(flow_object)
                            # 2
                            if flow_entry.match_fields.get(InPortMatch) and flow_entry.match_fields.get(InPortMatch) == InPortMatch("Local") and flow_entry.actions.get(GroupAction):
                                group_action = flow_entry.actions.get(GroupAction)
                                group_objects = self._get_groups()
                                group_entries = self.convert_group_entries_from_rest(group_objects.contents)
                                # 3
                                group_entries = group_entries.has_switch(source)
                                group_entries = group_entries.has_entry_id(group_action.value)
                                group_entry = group_entries[0]
                                # 4
                                for action_bucket in group_entry.action_buckets:
                                    if action_bucket.get(OutputAction) and action_bucket.get(OutputAction) == OutputAction(connected_port.name):
                                        break
                                else:
                                    # 4a
                                    new_action_bucket = SimpleActionBucket(actions=[OutputAction(connected_port.name)])
                                    group_entry.add_action_bucket(new_action_bucket)
                                    group_object = self.convert_group_entry_to_rest(group_entry)
                                    self.update_object(url=CONFIGURATION_GROUPS, command="PUT", object_id=group_entry.get_attribute("id"), object_body=group_object)

                                    LOGGER.warning("SDNRC-2720 applied to {}. This is fixed by using a Traditional Switch object for ports with multiple end devices".format(application_entry))

    def _reserve_vid(self, vid):
        LOGGER.info("Reserved VID {}".format(vid))
        return self.make_body_request(url="/api/default/config/vlanVidReservation/ReserveVlanVidRange", 
            body={"start": str(vid), "end": str(vid)})

    def _unreserve_vid(self, vid):
        LOGGER.info("Unreserved VID {}".format(vid))
        return self.make_simple_request(url="/api/default/config/vlanVidReservation", 
            object_id=str(vid), command=COMMAND_DELETE)

    # Find the next free vid
    def _get_next_free_vid(self, requested=None):
        reserved_vid_objects = self.make_simple_request(url="/api/default/config/vlanVidReservation/").contents

        reserved_vids = list()
        for potential_vid in reserved_vid_objects:
            reserved_vids.append(int(potential_vid["id"]))

        if requested is not None and requested not in reserved_vids:
            return requested

        for potential_vid in range(1, 4095)[::-1]:
            if potential_vid not in reserved_vids:
                return potential_vid
        else:
            return None

    def _get_flow_entries_by_lc(self, object_id):
        return self.make_simple_request("/api/default/config/flows", filters=[("tags/any(t: isof(t, 'Sel.Sel5056.Tags.LogicalConnectionTag') and t/Sel.Sel5056.Tags.LogicalConnectionTag/logicalConnectionId eq '" + str(object_id) + "')",)]).contents
    
    def adjust_lc_entries_for_table_miss(self, created_lc, vid=None, strip=True):
        # For each flow entry edit by:
        #   XDeleting EthSrcByAlias and EthDst Match fields, Leaving InPortByAlias
        #   XMoving entry to Table 3
        #   X(except for the first) Add VlanVid match field added in first
        # Find first entry, this is the one with the Inport of Local port, which is value "4294967294"
        # Edit first entry by:
        #   First entry also pushVlan and setVlanVid to next VlanVid value in reservation
        # Find last entr(ies), these is will output to the device, just need to find what port that is
        # Edit last entry by:
        #   Adding popVlan action

        LOGGER.info("Adjusting flow entries for table miss")
        # Get all flow entries for the created_lc
        flow_entries = self._get_flow_entries_by_lc(created_lc["id"])

        node_entries = self.get_information(OBJECT_NODES)

        destination_switches_and_ports = dict()
        destination_name = self.get_name_from_id(created_lc["destinationEndPoints"][0], object_type=CONFIGURATION_NODES)
        destination_node_entry = node_entries.has_name(destination_name)[0]
        for port_number, port_object in destination_node_entry._ports.items():
            connected_switch_port = port_object.find_connected_openflow_switch_port()
            if destination_switches_and_ports.get(connected_switch_port.end.owner.get_attribute("id")):
                destination_switches_and_ports[connected_switch_port.end.owner.get_attribute("id")].append(connected_switch_port.end.get_attribute("id"))
            else:
                destination_switches_and_ports[connected_switch_port.owner.get_attribute("id")] = [connected_switch_port.get_attribute("id")]               

        # Find a free VlanVid, then reserve it
        if len(flow_entries) > 1 or vid is not None:
            free_vid = self._get_next_free_vid(vid)

            if vid is not None and vid != free_vid:
                LOGGER.info("Unable to reserve vid {}".format(vid))
            # As long as the 0 < vid < 4095
            elif free_vid is not None:
                self._reserve_vid(free_vid)
            else:
                raise ValueError("Unable to find a free VID")

        # Force VID to be the vid argument even if already reserved
        if vid is not None:
            free_vid = vid

        for flow_entry in flow_entries:
            #converted_flow_entry = self.convert_flow_entry_from_rest(flow_entry)
            first_flow_entry = False
            last_flow_entry = False
            flow_entry["tableId"] = 3
            delete_fields = list()
            for index, match_field in enumerate(flow_entry["match"]["matchFields"]):
                if "EthDst" in match_field["@odata.type"] and match_field["value"] in ("00:00:00:00:00:00", "0"*12):
                    delete_fields.append(index)
                if "EthSrcByAlias" in match_field["@odata.type"]:
                    delete_fields.append(index)
                if "InPort" in match_field["@odata.type"] and match_field["value"] in ("Local", 4294967294):
                    if first_flow_entry:
                        raise ValueError("Found two first entries {}".format(flow_entry))

                    first_flow_entry = True
                    delete_fields.append(index)

            if flow_entry["node"] in destination_switches_and_ports:
                for instruction in flow_entry["instructions"]:
                    if "WriteActions" in instruction["@odata.type"]:
                        for action in instruction["actions"]:
                            if "OutputActionByAlias" in action["@odata.type"] and action["configPortId"] in destination_switches_and_ports[flow_entry["node"]]:
                                last_flow_entry = True

            # Got to do it backwards so the index doesn't change
            for index in delete_fields[::-1]:
                del flow_entry["match"]["matchFields"][index]

            if len(flow_entries) == 1 and strip is True:
                # No need for a VLAN because it will enter and exit the same switch
                flow_entry["displayName"] = flow_entry["displayName"] + " FIRST HOP"
            else:
                if first_flow_entry:
                    set_vlan_action = {"@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.SetFieldAction",
                        "field":{"@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MatchFields.VlanVid", "value":str(free_vid)}}
                    push_vlan_action = {"@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.PushVlanAction", "etherType": '0x8100'}
                    flow_entry["displayName"] = flow_entry["displayName"] + " FIRST HOP"

                    for instruction in flow_entry["instructions"]:
                        if "WriteActions" in instruction["@odata.type"]:
                            instruction["actions"].extend([push_vlan_action, set_vlan_action])
                            break

                    # There might be only one entry
                    if len(flow_entries) == 1 and strip is True:
                        for instruction in flow_entry["instructions"]:
                            if "WriteActions" in instruction["@odata.type"]:
                                instruction["actions"].append( {
                                      "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.PopVlanAction",
                                      "actionType": "PopVlan"
                                    })

                else:
                    # Need to increase the priority of all but the first entry to prevent overlap
                    flow_entry["priority"] += 2
                    
                    # If vid is not None then leave the VID on
                    if last_flow_entry and strip is True:
                        for instruction in flow_entry["instructions"]:
                            if "WriteActions" in instruction["@odata.type"]:
                                instruction["actions"].append( {
                                      "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.PopVlanAction",
                                      "actionType": "PopVlan"
                                    })

                    vlan_match_field = {"@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MatchFields.VlanVid", "value": str(free_vid)}
                    flow_entry["match"]["matchFields"].append(vlan_match_field)

            self.make_body_request(url=CONFIGURATION_FLOWS, command="PUT", object_id=flow_entry["id"], body=flow_entry)

    def is_source_destination_in_same_subnet(self, source, destination):
        return IPv4Interface(destination.ip_address) in IPv4Interface("/".join([source.ip_address, source.subnet])).network 

    def is_send_to_router(self, application_entry):
        if isinstance(application_entry.protocol, Ipv4Protocol) and isinstance(application_entry, UnicastApplication):
            if isinstance(application_entry.source, PortDevice) and isinstance(application_entry.destination, PortDevice):
                if application_entry.source.subnet is not None and application_entry.destination.subnet is not None:
                    if self.is_source_destination_in_same_subnet(application_entry.source, application_entry.destination):
                        return True
        
        return False

    def get_router_for_subnet(self, node_entries, network_address):
        for node_entry in node_entries:
            if isinstance(node_entry, RouterDevice):
                for port in node_entry.ports:
                    if port.network_address == network_address:
                        return port
            elif isinstance(node_entry, Port) and isinstance(node_entry.owner, RouterDevice):
                if node_entry.network_address == network_address:
                    return node_entry
        raise

    def add_application_entry(self, application_entry, create_arp_automatically=True, node_entries=None, send_to_router=False, use_aliased_fields=True):
        if application_entry.get_attribute("AutoARP") == False:
            create_arp_automatically = False

        LOGGER.info("Adding application entry {}".format(application_entry))
        if not application_entry.destinations and application_entry.policies and not isinstance(application_entry.policies[0], IDSMissPolicy):
            LOGGER.warning("Skipping {} because no destinations".format(application_entry))
            return list(), list()

        # fill_in_fields is just a fancy way of saying, I need to add in match fields specific to this application
        # Such as Ipv4Src
        fill_in_fields = True if (application_entry.policies.get(IDSPolicy) or application_entry.policies.get(IDSMissPolicy)) else False

        created_csts = list()
        created_lcs = list()

        if self.is_send_to_router(application_entry):
            source = application_entry.source
            if source.default_gateway and isinstance(source.default_gateway, NamedObject):
                source_router_entry = source.default_gateway
            elif node_entries:
                source_router_entry = self.get_router_for_subnet(node_entries, source.network_address)
            else:
                raise ValueError("Need node entries to find router required to get from {} to {} because destination IP {} is outside of subnet {}/{}".format(application_entry.source.print_name, application_entry.destination.print_name, application_entry.destination.ip_address, application_entry.source.ip_address, application_entry.source.subnet))

            if not source_router_entry:
                raise ValueError("Unable to find router for ip subnet".format(source.subnet))

            if source.is_connected():
                cst_responses = self.add_cst_by_application_entry(application_entry=application_entry, fill_in_fields=True, use_aliased_fields=use_aliased_fields)
                created_csts.extend(cst_responses)
                created_lcs.extend(self.add_lc_by_name_by_application(application_entry=application_entry, responses=cst_responses, destinations=[source_router_entry]))

                if create_arp_automatically:
                    cst_responses = self.add_cst_by_application_entry(application_entry=application_entry.to_arp(), destinations=[source_router_entry], fill_in_fields=fill_in_fields, use_aliased_fields=use_aliased_fields)
                    created_csts.extend(cst_responses)
                    created_lcs.extend(self.add_lc_by_name_by_application(application_entry=application_entry.to_arp(), responses=cst_responses, destinations=[source_router_entry]))

            destination = application_entry.destination
            if destination.default_gateway and isinstance(destination.default_gateway, NamedObject):
                destination_router_entry = destination.default_gateway
            elif node_entries:
                destination_router_entry = self.get_router_for_subnet(node_entries, destination.network_address)
            else:
                raise ValueError("Need node entries to find router")

            if not destination_router_entry:
                raise ValueError("Unable to find router for ip subnet".format(source.subnet))

            if application_entry.destination.is_connected():
                cst_responses = self.add_cst_by_application_entry(application_entry=application_entry, fill_in_fields=True, use_aliased_fields=use_aliased_fields)
                created_csts.extend(cst_responses)
                created_lcs.extend(self.add_lc_by_name_by_application(application_entry=application_entry, responses=cst_responses, source=destination_router_entry))

                if create_arp_automatically:
                    cst_responses = self.add_cst_by_application_entry(application_entry=application_entry.to_arp(), source=destination_router_entry, fill_in_fields=fill_in_fields, use_aliased_fields=use_aliased_fields)
                    created_csts.extend(cst_responses)
                    created_lcs.extend(self.add_lc_by_name_by_application(application_entry=application_entry.to_arp(), responses=cst_responses, source=destination_router_entry))

            if application_entry.protocol.bidirectional:
                reverse_application_entry = application_entry.reverse()
                source = reverse_application_entry.source
                if source.is_connected():
                    cst_responses = self.add_cst_by_application_entry(application_entry=reverse_application_entry, fill_in_fields=True, use_aliased_fields=use_aliased_fields)
                    created_csts.extend(cst_responses)
                    created_lcs.extend(self.add_lc_by_name_by_application(application_entry=reverse_application_entry, responses=cst_responses, destinations=[destination_router_entry]))

                    if create_arp_automatically:
                        cst_responses = self.add_cst_by_application_entry(application_entry=reverse_application_entry.to_arp(), destinations=[destination_router_entry], fill_in_fields=fill_in_fields, use_aliased_fields=use_aliased_fields)
                        created_csts.extend(cst_responses)
                        created_lcs.extend(self.add_lc_by_name_by_application(application_entry=reverse_application_entry.to_arp(), responses=cst_responses, destinations=[destination_router_entry]))

                if reverse_application_entry.destination.is_connected():
                    cst_responses = self.add_cst_by_application_entry(application_entry=reverse_application_entry, fill_in_fields=True, use_aliased_fields=use_aliased_fields)
                    created_csts.extend(cst_responses)
                    created_lcs.extend(self.add_lc_by_name_by_application(application_entry=reverse_application_entry, responses=cst_responses, source=source_router_entry))

                    if create_arp_automatically:
                        cst_responses = self.add_cst_by_application_entry(application_entry=reverse_application_entry.to_arp(), source=source_router_entry, fill_in_fields=fill_in_fields, use_aliased_fields=use_aliased_fields)
                        created_csts.extend(cst_responses)
                        created_lcs.extend(self.add_lc_by_name_by_application(application_entry=reverse_application_entry.to_arp(), responses=cst_responses, source=source_router_entry))

        else:
            cst_responses = self.add_cst_by_application_entry(application_entry, fill_in_fields=fill_in_fields, use_aliased_fields=use_aliased_fields)
            created_csts.extend(cst_responses)
            created_lcs.extend(self.add_lc_by_name_by_application(application_entry=application_entry, responses=cst_responses))

            if create_arp_automatically and isinstance(application_entry, UnicastApplication) and isinstance(application_entry.protocol, Ipv4Protocol):
                arp_application_entry = application_entry.to_arp()
                new_csts, new_lcs = self.add_application_entry(application_entry=arp_application_entry, use_aliased_fields=use_aliased_fields)
                created_csts.extend(new_csts)
                created_lcs.extend(new_lcs)
        
        application_entry.set_attribute("created_lcs", created_lcs)
        application_entry.set_attribute("created_csts", created_csts)
        return created_csts, created_lcs

    def add_lc_by_names(self, cst_name, source_name, destination_name):
        cst_id = self.get_id_from_name(object_name=cst_name, object_type=CONFIGURATION_CSTS)
        source_config_id = self.get_id_from_name(object_name=source_name, object_type=CONFIGURATION_NODES)
        if not source_config_id:
            LOGGER.warning("Unable to resolve config node with name {} into an ID. A config object with that name may not exist.".format(source_name))
            return False

        if type(destination_name) is list:
            destination_config_ids = [self.get_id_from_name(object_name=name, object_type=CONFIGURATION_NODES) for name in destination_name]
        else:
            destination_config_ids = [self.get_id_from_name(object_name=destination_name, object_type=CONFIGURATION_NODES)]
            destination_name = [destination_name]

        if None in destination_config_ids:
            for d_name, d_id in zip(destination_name, destination_config_ids):
                if d_id is None:
                    raise ValueError("Unable to find a configuration node for the destination node with name {}".format(d_name))
        response = self.add_lc(cst_id=cst_id, source_config_id=source_config_id, destination_config_ids=destination_config_ids)

        return response

    def wait_for_lc_until_success(self, object_id):
        if LC_SUCCESS_RETRY:
            response = self._get_lc(object_id).contents
            if response[PROPERTY_ERROR_STATE] != "InProgress":
                if self.caching:
                    self.update_cache(object_type=CONFIGURATION_LCS, object_id=response["id"], response=response, command=COMMAND_POST)
                return True
            for _ in range(LC_SUCCESS_RETRY):
                sleep(LC_TIMEOUT)
                response = self._get_lc(object_id).contents

                if response[PROPERTY_ERROR_STATE] != "InProgress":
                    if self.caching:
                        self.update_cache(object_type=CONFIGURATION_LCS, object_id=response["id"], response=response, command=COMMAND_POST)
                    return True
        return False

    def convert_application_entry_from_rest(self, entry, node_entries=None):
        external_node_entries = True if node_entries else False
        if not node_entries:
            node_entries = self.get_information(OBJECT_NODES)
        def get_node_entry_by_id(object_id, object_type=None):
            device = node_entries.has_attribute_value("id", object_id)
            if device:
                return device[0]

            device_name = self.get_name_from_id(object_type=CONFIGURATION_NODES, object_id=object_id)
            if device_name:
                device = node_entries.has_name(device_name)
                if device:
                    return device[0]
        
        # Get source names
        source_config_ids = entry["sourceEndPoints"]
        source_names = [get_node_entry_by_id(object_id=config_id, object_type=CONFIGURATION_NODES) for config_id in source_config_ids]
        if len(source_names) != 1:
            raise ValueError("Unexpectedly received {} sources instead of 1".format(len(source_names)))

        good = True
        if None in source_names or "" in source_names:
            if not external_node_entries:
                LOGGER.error("Unable to find node with id {}".format(source_config_ids[0]))
            else:
                LOGGER.info("Unable to find node with id {}".format(source_config_ids[0]))
            good = False
            source_names = ["*DELETED"]
        
        # Get destination names
        destination_config_ids = entry["destinationEndPoints"]
        destination_names = [get_node_entry_by_id(object_id=config_id, object_type=CONFIGURATION_NODES) for config_id in destination_config_ids]

        for index, name in enumerate(destination_names):
            if name is None:
                good = False
                destination_names[index] = "*DELETED"

        # Get Protocol entry
        cst_config_id = entry["communicationServiceTypeId"]
        cst_object = self.get_cst(object_id=cst_config_id)
        if not cst_object:
            raise ValueError("Unable to find the CST for LC {}".format(entry))
        cst_name = cst_object[PROPERTY_NAME]
        protocol_entry = self.get_protocol_entry(object_id=cst_config_id)
        if cst_name == "openflow-controller":
            cst_name = "IB Management"
        
        if not good:
            if not external_node_entries:
                LOGGER.warning("LC with CST {} had a deleted source {} or destination {}".format(cst_name, source_names, destination_names))
            else:
                LOGGER.info("LC with CST {} had a deleted source {} or destination {}".format(cst_name, source_names, destination_names))                
            return

        # Get classification
        classification = self.get_value_from_id(object_id=cst_config_id, object_type=CONFIGURATION_CSTS, attribute=PROPERTY_SETQUEUE)
        if not classification:
            classification = 2
        else:
            classification = classification['queueId']

        # Create Application entry
        if protocol_entry.unicast:
            if len(destination_names) > 1:
                raise ValueError("More than one destination for {}".format(cst_object))
            application_entry = UnicastApplication(name=cst_name, protocol=protocol_entry, source=source_names[0], destination=destination_names[0], classification=classification)
        else:
            application_entry = MulticastApplication(name=cst_name, protocol=protocol_entry, source=source_names[0], destinations=destination_names, classification=classification)

        # Add attributes
        application_entry.add_attribute("Status", [entry[PROPERTY_ERROR_STATE]])
        application_entry.add_attribute("Errors", entry[PROPERTY_ERRORS])
        application_entry.add_attribute("id", [entry["id"]])

        if good:
            return application_entry

    def get_application_entry(self, object_name):
        # Need to back track and assemble the corresponding LCs that comprise the application
        application_entries = self.get_application_entries()
        # TODO check present or not
        return application_entries.has_name(object_name)[0]

    def _get_table_miss_arguments_from_lc(self, lc_id):
        vid, strip = None, False
        flow_entries = self._get_flow_entries_by_lc(lc_id)
        for flow_entry in flow_entries:
            converted_flow_entry = self.convert_flow_entry_from_rest(flow_entry)
            if converted_flow_entry.actions.get(PushVlanAction, False) is not False and converted_flow_entry.actions.get(SetVlanVidAction) is not None:
                vid = converted_flow_entry.actions.get(SetVlanVidAction).value
            if converted_flow_entry.actions.get(PopVlanAction, False) is not False:
                strip = True

        if vid is None:
            strip = True

        return vid, strip

    # ignore_ids : If you have no IDS, then you don't have to worry about it
    def get_application_entries(self, combine_arps=True, ignore_ids=False, node_entries=None, networks=None, current_application_entries=None):
        def get_node_entry_by_id(object_id):
            device = node_entries.has_attribute_value("id", object_id)
            if device:
                return device[0]

            device_name = self.get_name_from_id(object_type=CONFIGURATION_NODES, object_id=object_id)
            if device_name:
                device = node_entries.has_name(device_name)
                if device:
                    return device[0]

        lcs = self.get_lcs()

        application_entries = ApplicationCollection(perform_validation=False)
        arps_waiting_ip = ApplicationCollection(perform_validation=False)
        # Need to convert some lcs back into application entries if there are IDSs involved.
        # The only way to know is to look back at my CST enties and see which are "PARTS"
        # Also need to combine arps if necessary
        # Remove VLAN from CST
        for lc_object in lcs:
            cst_object_id = lc_object["communicationServiceTypeId"]
            cst_object = self.get_cst(object_id=cst_object_id)

            # If -> in cst_object displayName and it is multicast is probably IDS related so need to undo the "IDS" part
            # Else, it is the whole of something
            if "Table Miss" in cst_object["displayName"]:
                # Add the IDS as a policy
                policies = Policies()

                if not node_entries:
                    node_entries = self.get_information(OBJECT_NODES)

                source_device = get_node_entry_by_id(lc_object["sourceEndPoints"][0])

                if not source_device:
                    LOGGER.warning("Unable to find source device with id: %s", lc_object["sourceEndPoints"][0])
                    continue
                elif node_entries and networks:
                    if not source_device.is_in_networks(networks):
                        continue

                for destination_id in lc_object["destinationEndPoints"]:
                    other_destination_device = get_node_entry_by_id(destination_id)
                    reserved_vid, strip = self._get_table_miss_arguments_from_lc(lc_object["id"])
                    new_policy = IDSMissPolicy(name=other_destination_device.print_name, destination=other_destination_device, vid=reserved_vid, strip=strip)
                    policies.add(new_policy)

                # Name is converted in this function
                protocol_entry = self.get_protocol_entry(object_id=cst_object_id)
                if protocol_entry.get(EthDstMatch) and protocol_entry.get(EthDstMatch).value == '000000000000':
                    protocol_entry.remove(EthDstMatch)

                new_application_entry = MulticastApplication(name=protocol_entry.name, policies=policies, protocol=protocol_entry, source=source_device, destinations=None)
                new_application_entry.add_attribute("Status", [lc_object[PROPERTY_ERROR_STATE]])
                new_application_entry.set_attribute("id", [lc_object['id']])
            elif ignore_ids is False and "->" in cst_object["displayName"] and cst_object["cstCommunicationType"] == "Multicast":
                destination_device = None
                if not node_entries:
                    #node_entries = self.get_node_entries()
                    node_entries = self.get_information(OBJECT_NODES)
                source_device = get_node_entry_by_id(lc_object["sourceEndPoints"][0])
                if not source_device:
                    LOGGER.warning("Unable to find source device with id: %s", lc_object["sourceEndPoints"][0])
                    continue
                elif node_entries and networks:
                    if not source_device.is_in_networks(networks):
                        continue

                cst_id = cst_object["id"]
                # Removed extra match fields from the CST that were added because of the IDS
                protocol_entry = self.get_protocol_entry(object_id=cst_id)
                protocol_entry.unicast = True
                protocol_entry.bidirectional = False

                if protocol_entry.get(Ipv4DstMatch) and protocol_entry.get(Ipv4DstMatch).mask:
                    pass
                elif protocol_entry.get(Ipv4DstMatch):
                    ipv4_destination = protocol_entry.get(Ipv4DstMatch).value
                    if node_entries.has_ip_address(ipv4_destination):
                        destination_device = node_entries.has_ip_address(ipv4_destination)[0]
                        protocol_entry.remove(Ipv4DstMatch)
                    else:
                        # If multicast address, choose the last destination
                        last_destination_id = lc_object["destinationEndPoints"][-1]
                        destination_device = get_node_entry_by_id(last_destination_id)

                        #LOGGER.error("Could not find the destination with IP address {} for LC with CST {}".format(ipv4_destination, cst_object["displayName"]))
                        #continue
                if protocol_entry.get(Ipv4SrcMatch) and protocol_entry.get(Ipv4SrcMatch).mask:
                    pass
                elif protocol_entry.get(Ipv4SrcMatch):
                    protocol_entry.remove(Ipv4SrcMatch)

                if protocol_entry.get(ArpSpaMatch) and protocol_entry.get(ArpSpaMatch).mask:
                    pass
                elif protocol_entry.get(ArpSpaMatch):
                    protocol_entry.remove(ArpSpaMatch)

                if protocol_entry.get(ArpTpaMatch) and protocol_entry.get(ArpTpaMatch).mask:
                    pass
                elif protocol_entry.get(ArpTpaMatch):
                    arp_destination = protocol_entry.get(ArpTpaMatch).value
                    if node_entries.has_ip_address(arp_destination):
                        destination_device = node_entries.has_ip_address(arp_destination)[0]
                        protocol_entry.remove(ArpTpaMatch)
                    else:
                        LOGGER.error("Could not find the destination with IP address {} for LC with CST {}".format(arp_destination, cst_object["displayName"]))
                        continue

                # Need to also look at MAC address?
                if protocol_entry.get(EthDstMatch) and protocol_entry.get(EthDstMatch).mask:
                    pass
                elif protocol_entry.get(EthDstMatch):
                    mac_destination = protocol_entry.get(EthDstMatch).value
                    if node_entries.has_mac_address(mac_destination):
                        destination_device = node_entries.has_mac_address(mac_destination)[0]
                        protocol_entry.remove(EthDstMatch)
                    else:
                        # If multicast address, choose the last destination
                        last_destination_id = lc_object["destinationEndPoints"][-1]
                        if node_entries.has_attribute_value("id", last_destination_id):
                            destination_device = node_entries.has_attribute_value("id", last_destination_id)[0]
                        else:
                            destination_object = self.get_configuration_node(object_id=last_destination_id)
                            destination_device = node_entries.has_name(destination_object["displayName"])[0]
                        # Only remove the EthDst if you can find it as it could be multicast GOOSE dest for example

                if protocol_entry.get(EthSrcMatch) and protocol_entry.get(EthSrcMatch).mask:
                    pass
                elif protocol_entry.get(EthSrcMatch):
                    protocol_entry.remove(EthSrcMatch)

                # Need to undo the other stuff I did to the CST
                if protocol_entry.get(VlanVidMatch) and protocol_entry.get(VlanVidMatch).value == "None":
                    protocol_entry.remove(VlanVidMatch)
                #protocol_entry.name = cst_object["displayName"].split("->")[0]
                
                # Need to check against the reverse direction
                flip_side_applications = application_entries.has_source(destination_device).has_destination(source_device)
                flip_side_applications.extend(arps_waiting_ip.has_source(destination_device).has_destination(source_device))
                found = False

                for flip_side_application in flip_side_applications:
                    if flip_side_application.protocol.reverse() == protocol_entry:
                        # Found the reverse direction
                        flip_side_application.protocol.bidirectional = True
                        flip_side_application.protocol.unicast = True
                        flip_side_application.get_attribute("id").append(lc_object["id"])
                        flip_side_application.get_attribute("Status").append(lc_object[PROPERTY_ERROR_STATE])
                        found = True

                if not found:
                    # Need to determine if it is a unicast or multicast application
                    # IDS is always multicast, but the original might also be multicast, not unicast
                    # Check the IP and MAC destination addresses
                    # I don't know if the destinations are IDS or the real destination, so lump them together
                    if "-M>" in cst_object["displayName"] or ((protocol_entry.get(EthTypeMatch) == EthTypeMatch("GOOSE")) or (protocol_entry.get(EthDstMatch) and protocol_entry.get(EthDstMatch).is_multicast()) or (protocol_entry.get(Ipv4DstMatch) and protocol_entry.get(Ipv4DstMatch).is_multicast())):
                        destinations = list()
                        for destination_id in lc_object["destinationEndPoints"]:
                            destination_object = self.get_configuration_node(object_id=destination_id)
                            destination_node = get_node_entry_by_id(destination_object["id"])
                            if node_entries and networks:
                                if not destination_node.is_in_networks(networks):
                                    LOGGER.info("Destination {} not in network so skipping for application with protocol".format(destination_object))
                                    continue
                            #destination_device = node_entries.has_name(destination_object["displayName"])[0]
                            destinations.append(destination_node)

                        policy = IDSPolicy(name=destinations[0].name, destination=destinations[0])

                        protocol_entry.unicast = False
                        new_application_entry = MulticastApplication(name=protocol_entry.name, protocol=protocol_entry, source=source_device, destinations=destinations[1:], policies=[policy])
                    else:
                        #protocol_entry.unicast = True
                        # Add the IDS as a policy
                        policies = Policies()
                        for destination_id in lc_object["destinationEndPoints"]:
                            other_destination_device = get_node_entry_by_id(destination_id)
                            if other_destination_device:
                                if destination_device != other_destination_device:
                                    new_policy = IDSPolicy(name=other_destination_device.print_name, destination=other_destination_device)
                                    policies.add(new_policy)

                        if not destination_device:
                            LOGGER.warning("Could not determine destination for application with protocol {} with source {}".format(protocol_entry.name, source_device))
                        new_application_entry = UnicastApplication(name=protocol_entry.name, policies=policies, protocol=protocol_entry, source=source_device, destination=destination_device)
                    new_application_entry.set_attribute("id", [lc_object['id']])
                    new_application_entry.add_attribute("Status", [lc_object[PROPERTY_ERROR_STATE]])
                else:
                    continue
            else:
                new_application_entry = self.convert_application_entry_from_rest(lc_object, node_entries=node_entries)
                if not new_application_entry:
                    continue

            new_application_entry.add_attribute("$converted_from_5056", True)
            if combine_arps and isinstance(new_application_entry.protocol, ArpProtocol):
                arps_waiting_ip.append(new_application_entry)
            else:
                application_entries.append(new_application_entry)

        # Still need to consider the arps. Don't want to export them, if there is arps.
        
        if combine_arps:
            # combine arps now
            for arp_waiting_ip in arps_waiting_ip:
                found = False
                source, destination = arp_waiting_ip.source, arp_waiting_ip.destinations[-1]
                
                # need to check for ARP, in either direction if bidirectional
                possible_application_entries = application_entries.has_source(source).has_destination(destination)
                if arp_waiting_ip.protocol.bidirectional:
                    possible_application_entries += application_entries.has_source(destination).has_destination(source)
                    ip_ones = list()
                    for possible_application_entry in possible_application_entries:
                        # @todo filter out multicast addresses
                        if possible_application_entry.protocol.get(EthTypeMatch) and possible_application_entry.protocol.get(EthTypeMatch).value == 0x800:
                            ip_ones.append(possible_application_entry)
                            found = True
                    # ARP belongs to all of the matching IP LCs
                    ip_application_ids = list()
                    for ip_one in ip_ones:
                        ip_application_ids.extend(ip_one.get_attribute("id"))
                        if not ip_one.get_attribute("arp_id"):
                            ip_one.set_attribute("arp_id", list())
                        ip_one.get_attribute("arp_id").extend(arp_waiting_ip.get_attribute("id"))
                        ip_one.get_attribute("id").extend(arp_waiting_ip.get_attribute("id"))
                        ip_one.get_attribute("Status").extend(arp_waiting_ip.get_attribute("Status"))

                    for ip_one in ip_ones:
                        ip_one.set_attribute("shared_arp_ids", ip_application_ids)
                        # Need to link them so I know when I can delete the ARP. Can't do it if I just delete one
                
                if found is False:
                    application_entries.append(arp_waiting_ip)
                #else:
                #   LOGGER.warning("Unable to find IP LC for ARP from %s to %s", source, destination)
                #   application_entries.append(arp_waiting_ip)

        if node_entries and networks:
            application_entries = application_entries.is_only_in_networks(networks)

        if current_application_entries:
            application_entries = self.match_logical_connections(application_entries, current_application_entries)

        return application_entries

    def match_logical_connections(self, controller_applications, user_applications):
        raise

    def find_lc_by_names(self, cst_name, source_name, destination_names):
        if not type(destination_names) is list:
            destination_names = [destination_names]
        cst_id = self.get_id_from_name(object_name=cst_name, object_type=CONFIGURATION_CSTS)
        source_id = self.get_id_from_name(object_name=source_name, object_type=CONFIGURATION_NODES)
        destination_ids = [self.get_id_from_name(object_name=destination_name, object_type=CONFIGURATION_NODES) for destination_name in destination_names]
        return self.find_lc(cst_id=cst_id, source_id=source_id, destination_ids=destination_ids)

    def find_lc(self, cst_id, source_id, destination_ids):
        for logical_connection in self.get_lcs():
            if logical_connection["communicationServiceTypeId"] == cst_id and set(logical_connection['destinationEndPoints']) == set(destination_ids) and logical_connection["sourceEndPoints"] == [source_id]:
                return logical_connection
        return False

    def get_names_from_lc(self, lc):
        source_names = [self.get_name_from_id(object_type=CONFIGURATION_NODES, object_id=object_id) for object_id in lc["sourceEndPoints"]]
        destination_names = [self.get_name_from_id(object_type=CONFIGURATION_NODES, object_id=object_id) for object_id in lc["destinationEndPoints"]]
        cst_name = self.get_name_from_id(object_type=CONFIGURATION_CSTS, object_id=lc["communicationServiceTypeId"])
        return source_names, destination_names, cst_name
