from . import LOGGER

from .metaclasses import ObjectMixin
from .decorators import no_body_url
from .constants import PROPERTY_LINKED, COMMAND_DELETE, OPERATIONAL_PORTS, PROPERTY_NAME, COMMAND_POST, CONFIGURATION_NODES
from .constants import FUNCTION_UNADOPT, FUNCTION_ADOPT_WITH_CONFIGURATION, FUNCTION_ADOPT, OPERATIONAL_NODES
from .constants import OPERATIONAL_SYNCHRONIZATION, CONFIGURATION_SETTINGS, TREE_OPERATIONAL, COMMAND_GET
from .constants import APPLICATION_JSON, FUNCTION_PACKET_OUT, FUNCTION_SYNCHRONIZATION_NODE, FUNCTION_GET_SYNCHRONIZATION_NODE
from .constants import FUNCTION_DISCONNECT, FUNCTION_REBOOT, FUNCTION_ADOPT_DEFAULT, OPERATIONAL_SYNCHRONIZATION

from .constants import FUNCTION_ADD_ABSTRACT_NODE, COMMAND_PATCH, PROPERTY_CONFIGURATIONS
from .constants import PROPERTY_PORTS, PROPERTY_TAGS, PROPERTY_ATTRIBUTES, PROPERTY_TRUST_STATE
# Exper
from .constants import VALUE_ADOPTED, PROPERTY_STATE, VALUE_UNADOPTED
from .constants import FUNCTION_ADD_ABSTRACT_NODE, COMMAND_PATCH, OBJECT_NODES, FUNCTION_ADD_SILENT_HOST

from .exceptions import BadRequestError

from ...base.tools import merge_dicts
from ...automation.device import EndDevice, SEL274XSDevice, SEL2740SDevice, SEL2742SDevice, ControllerDevice, OpenFlowDevice, TraditionalSwitchDevice
from ...automation.port import Port
from ...tools.diff.diff import create_configuration_node_entries_diff
from ...base.collection import NodeCollection, InterfacedObject
from ...automation import DEVICE_PORT_SEPARATOR

EVENT_TRANSLATED_DICT = {"chassis_and_module": "Chassis and Module", "configuration": "Configuration", 
        "link": "Link", "openflow": "Openflow", "security": "Security", "system_integrity": "System Integrity"}

class ConfigurationNodeMixin(metaclass=ObjectMixin, name="configuration_node", url=CONFIGURATION_NODES):
    def get_node_entries(self, operational_nodes=True, configuration_nodes=True):
        node_entries = self.convert_operational_nodes_from_rest() if operational_nodes else list()
        # Only add configuration objects that are not already linked, aka not already processed above
        if configuration_nodes:
            for configuration_object in self.get_configuration_nodes():
                if (operational_nodes and not configuration_object["linkedKey"]) or not operational_nodes:
                    node_entries.append(self.convert_configuration_node_from_rest(configuration_object))
        return NodeCollection(node_entries)

    def get_node_entry_by_name(self, name):
        configuration_object = self.get_configuration_node_by_name(object_name=name)
        if configuration_object["linkedKey"]:
            operational_object =  self.get_operational_node(object_id=configuration_object["linkedKey"])
            if operational_object:
                return self.convert_operational_node_from_rest(operational_object)
            else:
                raise ValueError("LinkedKey {} for node {} does not match any operational object".format(entry["linkedKey"], entry))
        else:
            return self.convert_configuration_node_from_rest(configuration_object)

    def get_configuration_node_entries(self):
        configuration_objects = self.get_configuration_nodes()
        return NodeCollection([self.convert_configuration_node_from_rest(configuration_object) for configuration_object in configuration_objects])

    def add_offline_host(self, node_entry):
        # Check type of node_entry

        # Get IP address
        if node_entry.ip_address:
            ip_address = node_entry.ip_address
        else:
            ip_address = "0.0.0.0"
        
        # Look for the configuration node of the host
        network = self.get_information(OBJECT_NODES)
        config_node_entry = network.has_name(node_entry.print_name)
        if config_node_entry:
            config_node_entry = config_node_entry[0]
        
        if config_node_entry and config_node_entry.get_attribute("state") == "Configured":
            if config_node_entry.get_attribute("id"):
                if config_node_entry.get_attribute("tags"):
                    for index, tag in enumerate(config_node_entry.get_attribute("tags")):
                        if "IpAddressTag" in tag["@odata.type"]:
                            if tag["ipAddress"] != ip_address:
                                config_node_entry.get_attribute("tags")[index]["ipAddress"] = ip_address
                                self.update_object(url=CONFIGURATION_NODES, object_id=config_node_entry.get_attribute("id"), object_body={"tags": config_node_entry.get_attribute("tags")})
                            break
                    else:
                        config_node_entry.get_attribute("tags").append({"@odata.type": "#Sel.Sel5056.Tags.IpAddressTag", "ipAddress": ip_address})
                        self.update_object(url=CONFIGURATION_NODES, object_id=config_node_entry.get_attribute("id"), object_body={"tags": config_node_entry.get_attribute("tags")})
                else:
                    new_tags = [{"@odata.type": "#Sel.Sel5056.Tags.IpAddressTag", "ipAddress": ip_address}]
                    self.update_object(url=CONFIGURATION_NODES, object_id=config_node_entry.get_attribute("id"), object_body={"tags": new_tags})
                    #update_object(self, url, object_body, object_id, command="PATCH")
                # Need to find if it is already an offline host or not
                config_id = config_node_entry.get_attribute("id")
            else:
                raise ValueError("Unable to find a configuration id for {}".format(node_entry.print_name))
        elif not config_node_entry:
            response = self.add_configuration_node(node_entry)
            config_id = response["id"]
        else:
            raise ValueError("So, I am suppose to do something here because you are adding an offline host but it is already present and adopted")

        if node_entry.ports[0].end:
            switch_port = node_entry.ports[0].find_connected_openflow_switch_port()
            switch_port_operational_id = switch_port.get_attribute("operatonal_id")
            switch_object = network.has_name(switch_port.owner.name)[0]
            switch_operational_object = self.get_operational_node(switch_object.get_attribute("operational_id"))
            switch_port_operational_id = None
            for port_id in switch_operational_object["ports"]:
                operational_port_object = self.get_operational_port(port_id)
                for attr in operational_port_object["attributes"]:
                    if "OpenFlowPortAttr" in attr["@odata.type"]:
                        if attr["portId"] == switch_port.name:
                            switch_port_operational_id = operational_port_object["id"]
                        break

                    if switch_port_operational_id:
                        break
            
            if switch_port_operational_id:
                self.make_body_request(url=OPERATIONAL_PORTS, object_id=switch_port_operational_id, function=FUNCTION_ADD_SILENT_HOST, body={"configNodeId": config_id})
            else:
                raise ValueError("Unable to find port {}".format(switch_port.name))
        else:
            raise ValueError("Not sure where {} is suppose to be connected to because port is not connected to anything in the topology".format(node_entry))

    def find_duplicate_configuration_nodes(self, node_objects):
        found_nodes_by_name = list()
        delete_entries = list()

        for node_object in node_objects:
            if node_object["displayName"] in found_nodes_by_name:
                delete_entries.append(node_object)
            else:
                found_nodes_by_name.append(node_object["displayName"])

        return delete_entries

    def diff_node_entries(self, new_entries, ignore_adopted=True, networks=None):
        # Delete duplicates, those items with the same name
        configuration_nodes = self.get_configuration_nodes()
        duplicate_configuration_nodes = self.find_duplicate_configuration_nodes(configuration_nodes)
        delete_entries = self.delete_objects(url="/api/default/config/nodes", objects=duplicate_configuration_nodes)

        old_entries = self.get_configuration_node_entries()

        add_entries, delete_entries = create_configuration_node_entries_diff(old_entries, new_entries=new_entries)
        # Don't delete the Controller Node
        delete_entries = delete_entries.not_has_type(ControllerDevice)
        add_entries = add_entries.not_has_type(ControllerDevice)

        if ignore_adopted:
            new_delete_entries = list()
            for d in delete_entries:
                if isinstance(d, Port) and d.owner and d.owner.get_attribute("state") == "Configured":
                    new_delete_entries.append(d)
                    d.set_attribute("id", d.owner.get_attribute("id"))
                elif d.get_attribute("state") == "Configured":
                    new_delete_entries.append(d)
                elif d.get_attribute("linked_add"):
                    new_delete_entries.append(d)
            delete_entries = new_delete_entries
        else:
            for d in delete_entries:
                if not d.get_attribute("linked_add"):
                    if isinstance(d, Port):
                        if d.owner and d.owner.get_attribute("operational_state") == "Adopted" and d.owner.get_attribute("operational_id"):
                            self.unadopt_node(d.owner.get_attribute("operational_id"))
                    elif d.get_attribute("operational_state") == "Adopted" and d.get_attribute("operational_id"):
                        self.unadopt_node(d.get_attribute("operational_id"))
        if networks:
            add_entries = add_entries.has_type(SEL274XSDevice).is_in_networks(networks).values + add_entries.ports_in_networks(networks).values

        self._resolve_configuration_entries_diff(add_entries=add_entries, delete_entries=delete_entries)

    def _resolve_configuration_entries_diff(self, add_entries, delete_entries):
        responses = list()
        for delete_entry in delete_entries:
            if delete_entry.get_attribute("linked_add"):
                if len(delete_entry.get_attribute("linked_add")) != 1:
                    raise ValueError("Unexpectly found after diff a node that matches to two nodes")
                else:
                    # Need to find the difference in settings
                    add_entry = delete_entry.get_attribute("linked_add")[0]

                # Need to fix where the Controller is being imported as an EndDevice not Controller Device
                if not isinstance(add_entry, SEL274XSDevice):
                    continue
                
                if isinstance(delete_entry, SEL274XSDevice):
                    if isinstance(delete_entry, SEL2740SDevice):
                        body = {"@odata.type": "#Sel.Sel5056.TopologyManager.Nodes.Sel2740SConfigNode"}
                    elif isinstance(delete_entry, SEL2742SDevice):
                        body = {"@odata.type": "#Sel.Sel5056.TopologyManager.Nodes.Sel2742SConfigNode"}
                    else:
                        raise ValueError("Unknown type for switch {}".format(delete_entry))
                    
                    if delete_entry.name != add_entry.name:
                        body["displayName"] = add_entry.name
                    if delete_entry.controller_ip != add_entry.controller_ip:
                        body["controllerIp"] = str(add_entry.controller_ip)
                    if delete_entry.default_gateway != add_entry.default_gateway:
                        body["controllerIp"] = str(add_entry.default_gateway)
                    if delete_entry.ip_address != add_entry.ip_address:
                        body["ipAddress"] = str(add_entry.ip_address)
                    if delete_entry.subnet != add_entry.subnet:
                        body["subnetMask"] = str(add_entry.subnet)
                    if self.version_5056 >= "2.0":
                        if delete_entry.ntp_servers != add_entry.ntp_servers:
                            body["ntpServers"] = add_entry.ntp_servers
                        if delete_entry.ptp_enable != add_entry.ptp_enable:
                            body["enablePtp"] = add_entry.ptp_enable
                        if delete_entry.snmp_enable != add_entry.snmp_enable:
                            body["enableSnmp"] = add_entry.snmp_enable

                    if delete_entry.get_attribute("id"):
                        delete_body = self.get_object(CONFIGURATION_NODES, object_id=delete_entry.get_attribute("id"))
                        configurations = delete_body.get("configurations", list())
                    else:
                        configurations = list()
                    
                    if self.version_5056 >= "2.2":
                        if delete_entry.front_port and not add_entry.front_port:
                            for index, tag in enumerate(configurations):
                                if "AlternateIpConfig" in tag["@odata.type"]:
                                    configurations.pop(index)
                            body["configurations"] = configurations
                        elif (not delete_entry and add_entry.front_port) or (delete_entry.front_port and add_entry.front_port):
                            # Add the alternate IP stuff
                            for index, tag in enumerate(configurations):
                                if "AlternateIpConfig" in tag["@odata.type"]:
                                    configurations.pop(index)
                        
                            new_tag = {"@odata.type":"#Sel.Sel5056.TopologyManager.Configurations.Sapphire.AlternateIpConfig",
                                "alternateIp":add_entry.front_port.ip_address, "alternateSubnetMask":add_entry.front_port.subnet}
                            configurations.append(new_tag)
                            body["configurations"] = configurations

                    if self.version_5056 >= "2.0":
                        if (delete_entry.syslog_servers != add_entry.syslog_servers and add_entry.syslog_servers is not None) or (delete_entry.local_events != add_entry.local_events and add_entry.local_events is not None) or (delete_entry.alarm_contact != add_entry.alarm_contact and add_entry.alarm_contact is not None):
                            body["eventCategories"] = self.convert_logging_settings_to_rest(add_entry)

                    #    raise ValueError("Unexpectly did not find anything to diff for from {} to {}".format(delete_entry, add_entry))
                else:
                    raise ValueError("Unable to diff a node that is not a SEL274XSDevice")

                if len(body) > 1: 
                    LOGGER.info("Found a node entry to modify from %s to %s", delete_entry, add_entry)
                    response = self.modify_object(url=CONFIGURATION_NODES, object_id=delete_entry.get_attribute("id"), mod_body=body)
                    responses.append(response)
                add_entries.pop(add_entries.index(add_entry))
            else:
                response = self.delete_object(url=CONFIGURATION_NODES, object_id=delete_entry.get_attribute("id"))
                # Need to clear out the cache of flows, groups, and meters
                if isinstance(delete_entry, SEL274XSDevice):
                    LOGGER.warning("Deleting a switch object so need to clear the cache")
                    self.clear_information()

        for add_entry in add_entries:
            self.add_node_entry(add_entry)

    def add_node_entries(self, entries):
        return [self.add_node_entry(entry=entry) for entry in entries]

    def add_node_entry(self, entry):
        if not self.validate_add_configuration_node(entry):
            LOGGER.warning("Cannot add configuration node with name {} because name already present".format(entry.name))
        else:
            return self.add_object(url=CONFIGURATION_NODES, object=entry)

    def convert_node_entries_to_rest(self, entries):
        return [self.convert_node_entry_to_rest(entry) for entry in entries]

    def convert_node_entry_to_rest(self, entry):
        if isinstance(entry, SEL274XSDevice):
            return self.convert_274XS_node_entry_to_rest(entry)
        else:
            return self.convert_end_device_node_entry_to_rest(entry)

    def create_configuration_node(self, **kwargs):
        return self.create_object(url=CONFIGURATION_NODES, **kwargs)

    def convert_configuration_node_objects_to_rest(self, *args, **kwargs):
        if len(args) + len(kwargs) > 1:
            return self.create_274XS_configuration_body(*args, **kwargs)
        else:
            return self.create_generic_configuration_body(*args, **kwargs)

    def create_generic_configuration_body(self, name):
        return {
            "displayName": name
            }

    def validate_add_configuration_node(self, body):
        for config_node in self.get_configuration_nodes():
            if config_node[PROPERTY_NAME] == body.name:
                return False
        else:
            return True

    def create_2740S_configuration_node(self, *args, **kwargs):
        self.create_object(url=CONFIGURATION_NODES, *kwargs)

    def create_274XS_configuration_body(self, name, controller_ip, default_gateway, ip_address, 
                subnet, ntp_servers=None, enable_ptp=False, enable_snmp=False, 
                alternate_ip_address=None, alternate_subnet=None, logging_categories=None, switch_type="Sel2740S"):
        ntp_servers = list() if not ntp_servers else ntp_servers

        if (alternate_ip_address and not alternate_subnet) or (not alternate_ip_address and alternate_subnet):
            raise ValueError("Alterate IP address and subnet must both be None or both defined")

        body = {
            "@odata.type": "#Sel.Sel5056.TopologyManager.Nodes.{}ConfigNode".format(switch_type),
            "displayName": name,
            "controllerIp": str(controller_ip),
            "defaultGateway": str(default_gateway),
            "ipAddress": str(ip_address),
            "subnetMask": str(subnet),
            "alarmMinimumDuration": 1,
                }
        if self.version_5056 >= "2.0":
            body.update({
                "enablePtp": enable_ptp,
                "enableSnmp": enable_snmp,
                "ntpServers": ntp_servers,
                })

            # Syslog Server
            if logging_categories:
                body["eventCategories"] = logging_categories

        if self.version_5056 >= "2.2":
            if alternate_ip_address and alternate_subnet:
                body["configurations"] = [
                    {"@odata.type":"#Sel.Sel5056.TopologyManager.Configurations.Sapphire.AlternateIpConfig",
                        "alternateIp":alternate_ip_address, "alternateSubnetMask":alternate_subnet}
                    ]

        return body

    def convert_logging_settings_to_rest(self, entry):
        # Syslog Servers
        logging_list = list()
        if self.version_5056 >= "2.0":
            logging_dict = dict()
            if entry.syslog_servers:
                for syslog_server in entry.syslog_servers:
                    name = syslog_server.name
                    ip_address = syslog_server.ip_address

                    if syslog_server.is_all_with_same_severity():
                        new_dict = dict()
                        new_dict["@odata.type"] = "#Sel.BlueFrame.EventBus.Syslog.SyslogBehavior"
                        new_dict["name"] = name
                        new_dict["ipAddress"] = ip_address
                        new_dict["port"] = syslog_server.port
                        new_dict["transportType"] = "Udp" if syslog_server.transport_type == "UDP" else ""
                        new_dict["rfcType"] = "Rfc3164"

                        severity = syslog_server.is_all_with_same_severity()
                        new_dict["severity"] = severity
                        if logging_dict.get("default"):
                            logging_dict["default"].append(new_dict)
                        else:
                            logging_dict["default"] = [new_dict]
                    else:
                        for category_name, severity in syslog_server.categories.items():
                            category_name = EVENT_TRANSLATED_DICT[category_name]
                            if severity:
                                new_dict = dict()
                                new_dict["@odata.type"] = "#Sel.BlueFrame.EventBus.Syslog.SyslogBehavior"
                                new_dict["name"] = name
                                new_dict["ipAddress"] = ip_address
                                new_dict["port"] = syslog_server.port
                                new_dict["transportType"] = "Udp" if syslog_server.transport_type == "UDP" else ""
                                new_dict["severity"] = severity
                                new_dict["rfcType"] = "Rfc3164"
                                if logging_dict.get(category_name):
                                    logging_dict[category_name].append(new_dict)
                                else:
                                    logging_dict[category_name] = [new_dict]

            if entry.alarm_contact:
                name = entry.alarm_contact.name
                if entry.alarm_contact.is_all_with_same_severity():
                    new_dict = dict()
                    new_dict["@odata.type"] = "#Sel.BlueFrame.Particle.AlarmContact.AlarmContactBehavior"
                    new_dict["name"] = name

                    severity = entry.alarm_contact.is_all_with_same_severity()
                    new_dict["severity"] = severity
                    if logging_dict.get("default"):
                        logging_dict["default"].append(new_dict)
                    else:
                        logging_dict["default"] = [new_dict]
                else:
                    for category_name, severity in entry.alarm_contact.categories.items():
                        category_name = EVENT_TRANSLATED_DICT[category_name]
                        if severity:
                            new_dict = dict()
                            new_dict["@odata.type"] = "#Sel.BlueFrame.Particle.AlarmContact.AlarmContactBehavior"
                            new_dict["name"] = name
                            new_dict["severity"] = severity
                            if logging_dict.get(category_name):
                                logging_dict[category_name].append(new_dict)
                            else:
                                logging_dict[category_name] = [new_dict]

            if entry.local_events:
                name = entry.local_events.name
                if entry.local_events.is_all_with_same_severity():
                    new_dict = dict()
                    new_dict["@odata.type"] = "#Sel.BlueFrame.Particle.LocalEventStore.LocalEventStoreBehavior"
                    new_dict["name"] = name

                    severity = entry.local_events.is_all_with_same_severity()
                    new_dict["severity"] = severity
                    if logging_dict.get("default"):
                        logging_dict["default"].append(new_dict)
                    else:
                        logging_dict["default"] = [new_dict]
                else:
                    for category_name, severity in entry.local_events.categories.items():
                        category_name = EVENT_TRANSLATED_DICT[category_name]
                        if severity:
                            new_dict = dict()
                            new_dict["@odata.type"] = "#Sel.BlueFrame.Particle.LocalEventStore.LocalEventStoreBehavior"
                            new_dict["name"] = name
                            new_dict["severity"] = severity
                            if logging_dict.get(category_name):
                                logging_dict[category_name].append(new_dict)
                            else:
                                logging_dict[category_name] = [new_dict]
            elif entry.local_events is None:
                pass
                # TODO Need 

            if logging_dict:
                for category_name in ["default"] + list(EVENT_TRANSLATED_DICT.values()):
                    if not logging_dict.get(category_name):
                        logging_body = list()
                    else:
                        logging_body = logging_dict[category_name]
                    
                    new_dict = dict()
                    new_dict["key"] = category_name
                    new_dict["id"] = category_name
                    new_dict["behaviors"] = logging_body
                    logging_list.append(new_dict)

        return logging_list  

    def convert_274XS_node_entry_to_rest(self, entry):
        kwargs = dict()

        # Add in alternate IP address stuff
        if self.version_5056 >= "2.2":
            if entry.mode == "IB" and entry.front_port:
                kwargs = {"alternate_ip_address": entry.front_port.ip_address,
                    "alternate_subnet": entry.front_port.subnet}
            elif entry.mode == "OOB":
                raise ValueError("Not yet supported")

        logging_objects = self.convert_logging_settings_to_rest(entry)

        for logging_object in logging_objects:
            if logging_object["behaviors"]:
                kwargs["logging_categories"] = logging_objects
                break

        if isinstance(entry, SEL2740SDevice):
            switch_type = "Sel2740S"
        elif isinstance(entry, SEL274XSDevice):
            switch_type = "Sel2742S"
        else:
            raise ValueError("Unknown type for switch {}".format(entry))

        return self.create_274XS_configuration_body(name=entry.print_name, 
                controller_ip=str(entry.controller_ip), 
                default_gateway=str(entry.default_gateway), 
                enable_ptp=entry.ptp_enable, enable_snmp=entry.snmp_enable, 
                ip_address=str(entry.ip_address), subnet=str(entry.subnet),
                ntp_servers=entry.ntp_servers, switch_type=switch_type, **kwargs)

    def convert_end_device_node_entry_to_rest(self, entry):
        # Create based on ports not devices
        if isinstance(entry, Port):
            return self.create_generic_configuration_body(self.get_names_from_objects(entry))
        else:
            if entry.mode in ("Failover", "PRP"):
                return self.create_generic_configuration_body(self.get_names_from_objects(entry))
            else:
                return [self.create_generic_configuration_body(self.get_names_from_objects(port)) for port in entry.ports]

    def convert_configuration_nodes_from_rest(self):
        return NodeCollection([self.convert_convert_configuration_node_from_rest(entry) for entry in self.get_operational_nodes()])

    def configuration_node_attributes(self, entry):
        openflow_attributes, host_attributes, other_attributes = dict(), dict(), dict()

        if entry.get("displayName") and DEVICE_PORT_SEPARATOR in entry.get("displayName"):
            host_name, port_name = entry.get("displayName").split(DEVICE_PORT_SEPARATOR)
            try:
                port_name = int(port_name)
            except ValueError:
                pass
        else:
            host_name, port_name = entry.get("displayName"), 0

        host_attributes["name"] = host_name
        other_attributes["state"] = entry["state"]
        other_attributes["id"] = entry["id"]
        host_attributes["ports"] = [port_name]
        host_attributes["type"] = entry.get("@odata.type", "")

        if entry.get("controllerIp"):
            openflow_attributes["controller_ip"] = entry["controllerIp"]

        if entry.get("defaultGateway"):
            openflow_attributes["default_gateway"] = entry["defaultGateway"]

        if entry.get("subnetMask"):
            openflow_attributes["subnet"] = entry.get("subnetMask")

        if entry.get("enablePtp"):
            openflow_attributes["ptp_enable"] = entry.get("enablePtp", False)

        if entry.get("enableSnmp"):
            openflow_attributes["snmp_enable"] = entry.get("enableSnmp", False)

        if entry.get("ipAddress"):
            openflow_attributes["ip_address"] = entry.get("ipAddress")

        if entry.get("ntpServers"):
            openflow_attributes["ntp_servers"] = entry.get("ntpServers")

        for tag in entry.get("configurations"):
            if "AlternateIpConfig" in tag["@odata.type"]:
                openflow_attributes["front_ip_address"] = tag["alternateIp"]
                openflow_attributes["front_subnet"] = tag["alternateSubnetMask"]

        # Syslog Servers
        logger_dict = dict()
        alarm_contact_dict = dict()
        local_events_dict = dict()
        for event_category in entry.get("eventCategories", list()):
            event_name = event_category["id"]
            if event_name == "System Integrity":
                event_name = "system_integrity"
            elif event_name == "Chassis and Module":
                event_name = "chassis_and_module"

            event_name = event_name.lower()

            for event_logger in event_category["behaviors"]:
                new_dict = dict()
                name = event_logger["name"]
                new_dict["name"] = name

                severity = event_logger["severity"]

                if event_name == 'default':
                    for all_event_name in EVENT_TRANSLATED_DICT:
                        new_dict[all_event_name] = severity
                else:
                    new_dict[event_name] = severity

                if "SyslogBehavior" in event_logger["@odata.type"]:
                    if not logger_dict.get(name):
                        new_dict["ip_address"] = event_logger["ipAddress"]
                        new_dict["port"] = event_logger["port"]
                        new_dict["transport_type"] = "UDP" if event_logger["transportType"] == "Udp" else "TCP"
                        logger_dict[name] = new_dict
                    else:
                        logger_dict[name].update(new_dict)
                elif "LocalEventStoreBehavior" in event_logger["@odata.type"]:
                    if not local_events_dict.get(name):
                        local_events_dict[name] = new_dict
                    else:
                        local_events_dict[name].update(new_dict)
                elif "AlarmContactBehavior" in event_logger["@odata.type"]:
                    if not alarm_contact_dict.get(name):
                        alarm_contact_dict[name] = new_dict
                    else:
                        alarm_contact_dict[name].update(new_dict)
                else:
                    raise

        if logger_dict:
            openflow_attributes["syslog_servers"] = list(logger_dict.values())
        if alarm_contact_dict:
            openflow_attributes["alarm_contact"] = list(alarm_contact_dict.values())[0]
        if local_events_dict:
            openflow_attributes["local_events"] = list(local_events_dict.values())[0]

        return openflow_attributes, host_attributes, other_attributes

    def convert_configuration_node_from_rest(self, entry):
        if entry.get("linkedKey"):
            operational_object = self.get_operational_node(object_id=entry["linkedKey"])
            if operational_object:
                return self.convert_operational_node_from_rest(operational_object)
            else:
                raise ValueError("LinkedKey {} for node {} does not match any operational object".format(entry["linkedKey"], entry))
        else:
            openflow_attributes, host_attributes, other_attributes = self.configuration_node_attributes(entry)
            return self.create_node_entry_from_attributes(openflow_attributes, host_attributes, other_attributes, device_type=None)


class OperationalNodeMixin(metaclass=ObjectMixin, name="operational_node", url=OPERATIONAL_NODES):
    @no_body_url(url=OPERATIONAL_NODES, function=FUNCTION_UNADOPT, command=COMMAND_POST)
    def unadopt_node(self, object_id, response=None, **kwargs):
        return response

    def unadopt_node_by_name(self, node_name):
        configuration_node_id = self.get_id_from_name(object_name=node_name, object_type=CONFIGURATION_NODES)
        operational_node_id = self.get_value_from_id(object_id=configuration_node_id, object_type=CONFIGURATION_NODES, attribute=PROPERTY_LINKED)
        if operational_node_id:
            return self.unadopt_node(object_id=operational_node_id)
        else:
            return None

    def adopt_node_by_name(self, object_id, configuration_object_name, **kwargs):
        configuration_object_id = self.get_id_from_name(object_name=configuration_object_name, object_type=CONFIGURATION_NODES)
        if configuration_object_id:
            try:
                return self.adopt_operational_node(object_id=object_id, configuration_object_id=configuration_object_id, **kwargs)
            except BadRequestError as e:
                raise ValueError("Unable to adopt node {}".format(configuration_object_name))
        else:
            return False

    @no_body_url(url=OPERATIONAL_NODES, command=COMMAND_POST, function=FUNCTION_DISCONNECT)
    def disconnect_node(self, object_id, response=None):
        return response

    #@no_body_url(url=OPERATIONAL_NODES, function=FUNCTION_ADOPT_DEFAULT, command=COMMAND_POST)
    def adopt_operational_node_with_default(self, object_id):
        return self.adopt_operational_node(object_id=object_id)
        #return response

    def adopt_operational_node(self, object_id, configuration_object_id=None, **kwargs):
        if configuration_object_id:
            body = {
                "configKey": configuration_object_id
            }

            response = self.make_body_request(url=OPERATIONAL_NODES, function=FUNCTION_ADOPT_WITH_CONFIGURATION, object_id=object_id, content_type=APPLICATION_JSON, body=body)
        else:
            response = self.make_simple_request(url=OPERATIONAL_NODES, function=FUNCTION_ADOPT, object_id=object_id, command=COMMAND_POST)

        if self.caching:
            response = self._get_operational_node(object_id=object_id).contents
            self.update_cache(object_type=OPERATIONAL_NODES, response=response, object_id=object_id, command=COMMAND_GET)
            configuration_object_id = response["linkedKey"]
            response = self._get_configuration_node(object_id=configuration_object_id).contents
            self.update_cache(object_type=CONFIGURATION_NODES, response=response, object_id=configuration_object_id, command=COMMAND_GET)
        return response

    @no_body_url(url=OPERATIONAL_NODES, function=FUNCTION_REBOOT, command=COMMAND_POST, required=True)
    def reboot_node(self, object_id, response=None, **kwargs):
        return response

    def convert_operational_nodes_from_rest(self):
        return NodeCollection([self.convert_operational_node_from_rest(entry) for entry in self.get_operational_nodes()])

    def convert_operational_node_from_rest(self, node):
        openflow_attributes = dict()

        if node["linkedKey"]:
            configuration_object = self.get_configuration_node(node["linkedKey"], find_if_not_cached=True)
            openflow_attributes, host_attributes, other_attributes = self.configuration_node_attributes(configuration_object)
        else:
            host_attributes = {"name": node["displayName"]}
            other_attributes = dict()
            configuration_object = None

        if host_attributes["name"] is None:
            host_attributes["name"] = ""

        if node.get("@odata.type"):
            host_attributes["type"] = node.get("@odata.type")

        device_type = None
        for attribute in node['attributes']:
            if '@odata.type' in attribute and "SelSapphireAttr" in attribute['@odata.type']:
                device_type = "sapphire"
                openflow_attributes["datapath_id"] = attribute["prettyDataPathId"]

            if '@odata.type' in attribute and "OpenFlowAttr" in attribute['@odata.type']:
                openflow_attributes["datapath_id"] = attribute["prettyDataPathId"]

            if '@odata.type' in attribute and "ControllerAttr" in attribute['@odata.type']:
                device_type = "controller"

            if "@odata.type" in attribute and "NetworkingAbstractionAttr" in attribute["@odata.type"]:
                device_type = "abstraction"

        ports = [self.get_operational_port(object_id=port_id) for port_id in node['ports']]

        # Need to remove all of the extra controller ports that are not connected
        # as they probably belong to the other interface
        if device_type == "controller":
            new_port_list = list()
            for port in ports:
                if port["attachedLinks"]:
                    new_port_list.append(port)

            ports = new_port_list

        ports = [self.convert_operational_port_from_rest(port) for port in ports if port]

        host_attributes["ports"] = ports #[port["displayName"] for port in ports]

        other_attributes["operational_state"] = node["state"]
        other_attributes["operational_id"] = node["id"]

        return self.create_node_entry_from_attributes(openflow_attributes, host_attributes, other_attributes, device_type=device_type, linked_to_configuration_object=configuration_object)

    def create_node_entry_from_attributes(self, openflow_attributes, host_attributes, other_attributes, device_type=None, linked_to_configuration_object=True):
        sub_device_type = host_attributes.get("type")
        if "type" in host_attributes.keys():
            del(host_attributes["type"])

        if openflow_attributes or device_type == "sapphire":
            new_dict = merge_dicts(host_attributes, openflow_attributes)

            if device_type == "sapphire" or new_dict.get("controller_ip"):
                if new_dict.get("datapath_id"):
                    new_dict["mac_address"] = new_dict["datapath_id"][4:]
                # Adjust for unadopted SEL-2740Ss
                if not new_dict.get("controller_ip"):
                    new_dict["controller_ip"] = "0.0.0.0"

                if "40S" in sub_device_type:
                    device_class = SEL2740SDevice
                    new_dict["ports"] = range(1, 20+1)
                elif "42S" in sub_device_type:
                    device_class = SEL2742Device
                    new_dict["ports"] = range(1, 12+1)

                return device_class(attributes=other_attributes, **new_dict)
            else:
                return OpenFlowDevice(attributes=other_attributes, **new_dict)
        elif device_type == "abstraction":
            return TraditionalSwitchDevice(attributes=other_attributes, **host_attributes)
        else:
            if device_type == "controller":
                object_type = ControllerDevice
            else:
                object_type = EndDevice

            return object_type(mode=None, attributes=other_attributes, **host_attributes)
    
    # Synchronization
    @no_body_url(url=TREE_OPERATIONAL, function=FUNCTION_GET_SYNCHRONIZATION_NODE, command=COMMAND_POST)
    def get_synchronize_nodes(self, object_id=None, response=None):
        return response

    def get_nodes_to_synchronize(self):
        return self.get_synchronize_nodes().value

    def synchronize_node(self, configuration_object_id, **kwargs):
        body = {
            "configNodeId": configuration_object_id
        }
        return self._make_body_request(url=TREE_OPERATIONAL, function=FUNCTION_SYNCHRONIZATION_NODE, content_type=APPLICATION_JSON, body=body)

    def synchronize_all_nodes(self):
        synchronization_list = self.get_synchronize_nodes()
        return [self.synchronize_node(configuration_object_id=config_node_id) for config_node_id in synchronization_list.value]

    def reboot_node_by_name(self, object_name):
        object_id = self.get_id_from_name(object_name=object_name, object_type=CONFIGURATION_NODES)
        operational_node_id = self.get_value_from_id(object_id=object_id, object_type=CONFIGURATION_NODES, attribute=PROPERTY_LINKED)
        self.reboot_node(operational_node_id)

    def get_synchronization_requests(self):
        return self.make_simple_request(url=OPERATIONAL_SYNCHRONIZATION).contents

    def add_traditional_switch(self, switch_name, switch_port, traditional_node_name):
        if switch_port not in range(1,20+1):
            raise ValueError("Switch port must be between 1-20 and not {} of type {}".format(switch_port, type(switch_port)))

        configuration_node_id = self.get_id_from_name(object_name=switch_name, object_type=CONFIGURATION_NODES)
        configuration_node_object = self.get_configuration_node(configuration_node_id)
        operational_node_object = self.get_operational_node(configuration_node_object["linkedKey"])
        target_operational_port_object = None
        for port_id in operational_node_object["ports"]:
            operational_port_object = self.get_operational_port(port_id)
            for attribute in operational_port_object["attributes"]:
                if "OpenFlowPortAttr" in attribute["@odata.type"] and attribute["portId"] == switch_port:
                    target_operational_port_object = operational_port_object
                    break

        if target_operational_port_object:
            object_id = target_operational_port_object["id"]
            body = {
                "configSetting": {"@odata.type":"#Sel.Sel5056.TopologyManager.Configurations.Abstraction.TraditionalSwitch"}
            }
            self._make_body_request(url=OPERATIONAL_PORTS, function=FUNCTION_ADD_ABSTRACT_NODE, object_id=object_id, content_type=APPLICATION_JSON, body=body)
            nodes = self._get_configuration_nodes().contents
            for node in nodes:
                if node["displayName"] == "TraditionalSwitch":
                    node["displayName"] = traditional_node_name
                    return self._make_body_request(url=CONFIGURATION_NODES, command=COMMAND_PATCH, body=node, object_id=node["id"])
            else:
                raise
        else:
            raise
