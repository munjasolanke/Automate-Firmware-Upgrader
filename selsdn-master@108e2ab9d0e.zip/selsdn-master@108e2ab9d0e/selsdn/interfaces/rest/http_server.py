import socket
import ssl

from re import search

from .commands import Response

WEB_PAGE = '''
<html>
<head>
    <script src="jquery.js"></script>
    <script>
        var OAUTHURL    =   'https://localhost/identity/connect/authorize?';
        var VALIDURL    =   'http://localhost:1234/index2.html?token=';
        var SCOPE       =   'Rest';
        var CLIENTID    =   'web-client';
        var REDIRECT    =   'http://localhost:1234/index.html';
        var LOGOUT      =   'http://accounts.google.com/Logout';
        var TYPE        =   'token';
        var ROLE        =   'role:SecurityAdministrator';
        var _url        =   OAUTHURL + 'acr_values=' + ROLE + '&scope=' + SCOPE + '&client_id=' + CLIENTID + '&redirect_uri=' + REDIRECT + '&response_type=' + TYPE;
        var acToken;
        var tokenType;
        var expiresIn;
        var user;
        var loggedIn    =   false;

        function login() {
            var win         =   window.open(_url, "windowname1", 'width=800, height=600'); 

            var pollTimer   =   window.setInterval(function() { 
                try {
                    console.log(win.document.URL);
                    if (win.document.URL.indexOf(REDIRECT) != -1) {
                        window.clearInterval(pollTimer);
                        var url =   win.document.URL;
                        acToken =   gup(url, 'access_token');
                        tokenType = gup(url, 'token_type');
                        expiresIn = gup(url, 'expires_in');
                        var win2 = window.open(REDIRECT + '?token=' + acToken, "windowname1", 'width=800, height=600');
                        win.close();
                        win2.close();
                    }
                } catch(e) {
                }
            }, 500);

        }

        function validateToken(token) {
            $.ajax({
                url: REDIRECT + token,
                data: null,
                success: function(responseText){  
                    getUserInfo();
                    loggedIn = true;
                    $('#loginText').hide();
                    $('#logoutText').show();
                },  
                dataType: "jsonp"  
            });
        }

        function getUserInfo() {
            $.ajax({
                url: VALIDURL + acToken,
                data: null,
                success: function(resp) {
                    user    =   resp;
                    console.log(user);
                    $('#uName').text('Welcome ' + user.name);
                    $('#imgHolder').attr('src', user.picture);
                },
                dataType: "jsonp"
            });
        }

        //credits: http://www.netlobo.com/url_query_string_javascript.html
        function gup(url, name) {
            name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
            var regexS = "[\\#&]"+name+"=([^&#]*)";
            var regex = new RegExp( regexS );
            var results = regex.exec( url );
            if( results == null )
                return "";
            else
                return results[1];
        }

        function startLogoutPolling() {
            $('#loginText').show();
            $('#logoutText').hide();
            loggedIn = false;
            $('#uName').text('Welcome ');
            $('#imgHolder').attr('src', 'none.jpg');
        }

    </script>
</head>

<body>
    <a href='#' onClick='login();' id="loginText"'> Click here to login </a>
    <a href="#" style="display:none" id="logoutText" target='myIFrame' onclick="myIFrame.location='https://www.google.com/accounts/Logout'; startLogoutPolling();return false;"> Click here to logout </a>
    <iframe name='myIFrame' id="myIFrame" style='display:none'></iframe>
    <div id='uName'></div>
    <img src='' id='imgHolder'/>
</body>
</html>
'''

def obtain_implicit_token(redirect_url, certfile=None, keyfile=None):
    address = ('', 1234)
    token = None
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(address)
        sock.listen(1)
        #with ssl.wrap_socket(sock, keyfile=keyfile, certfile=certfile) as ssock:
        while True:
            print("Waiting for connection")
            conn, add = sock.accept()
            data = conn.recv(1024)
            if b"GET /index.html?token=" in data:
                conn.send(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
                token = search(b"token=([^ ]+)", data).group(1).decode()
                break
            elif b"GET /index.html " in data:
                conn.send("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n".format(str(len(WEB_PAGE.encode()))).encode() + WEB_PAGE.encode())
            #elif b"GET /jquery.js " in data:
            #   conn.send("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n".format(str(len(JQUERY.encode()))).encode() + WEB_PAGE.encode())
            else:
                conn.send(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    return token

def obtain_authorization_code(redirect_url, certfile=None, keyfile=None):
    address = ('', 1234)
    token = None
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(address)
        sock.listen(1)
        #with ssl.wrap_socket(sock, keyfile=keyfile, certfile=certfile) as ssock:
        while True:
            print("Waiting for connection")
            conn, add = sock.accept()
            data = conn.recv(1024)
            print(data.decode("latin_1"))
            if b"GET /index.html?token=" in data:
                conn.send(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
                token = search(b"token=([^ ]+)", data).group(1).decode()
                break
            elif b"GET /index.html " in data:
                conn.send("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n".format(str(len(WEB_PAGE.encode()))).encode() + WEB_PAGE.encode())
            #elif b"GET /jquery.js " in data:
            #   conn.send("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n".format(str(len(JQUERY.encode()))).encode() + WEB_PAGE.encode())
            else:
                conn.send(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    return code
