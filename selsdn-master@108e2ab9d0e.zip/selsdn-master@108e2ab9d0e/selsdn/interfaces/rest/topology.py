from ...automation.device import ControllerDevice, OpenFlowDevice, TraditionalSwitchDevice

from .constants import CONFIGURATION_NODES, PROPERTY_LINKED, SETTINGS_PREFERENCES, SETTINGS_PREFERENCES_SET, OBJECT_NODES

class TopologyMixin():
    def rearrange_topology_view_by_node_objects(self, controller_name=None):
        node_entries = self.get_information(OBJECT_NODES)
        return self.rearrange_topology_view_by_node_entries(node_entries, controller_name=controller_name)

    def rearrange_topology_view_by_node_entries(self, topology=None, controller_name=None):
        node_entries = self.get_information(OBJECT_NODES)
        node_list = list()
        if controller_name:
            if node_entries.has_name(controller_name):
                controller_node = node_entries.has_name(controller_name)[0]
            else:
                raise ValueError("Unable to find node with name {}".format(controller_name))
        else:
            controller_node = node_entries.has_type(ControllerDevice)[0]
        operational_id = self.get_operational_id_from_node_entry(controller_node)
        node_list.append(operational_id)

        out_of_band = True
        for port in controller_node.ports:
            if port.end:
                if isinstance(port.end.owner, OpenFlowDevice):
                    out_of_band = False
                    #required_switch_object = required_node_entries.has_name(port.end.owner.name)[0]
                    self.get_topology_view_list_from_switch(port.end.owner, node_list=node_list, topology=topology)

        if out_of_band:
            switch_names = [n.name for n in node_entries.has_type(OpenFlowDevice)]
            switch_names.sort()
            for switch_name in switch_names:
                switch_object = node_entries.has_name(switch_name)[0]
                
        if node_list:
            body = {"key": "Stack-Node-Sort-Order", "value": str(node_list).replace("'", '\"')}
            return self.make_body_request(body=body, url=SETTINGS_PREFERENCES_SET)

    def get_operational_id_from_node_entry(self, node_entry):
        if node_entry.get_attribute('operational_id'):
            return node_entry.get_attribute('operational_id')
        elif node_entry.name:
            config_id = self.get_id_from_name(object_name=node_entry.name, object_type=CONFIGURATION_NODES)
            if config_id:
                return self.get_value_from_id(object_id=config_id, attribute=PROPERTY_LINKED, object_type=CONFIGURATION_NODES)

    def get_topology_view_list_from_switch(self, switch_object, node_list, topology=None):
        if topology and topology.has_name(switch_object.name):
            given_node_entry = topology.has_name(switch_object.name)[0]
        else:
            given_node_entry = None

        operational_id = self.get_operational_id_from_node_entry(switch_object)
        if operational_id and operational_id not in node_list:
            node_list.append(operational_id)

        # Do hosts first
        for port_number in range(1,20+1):
            if switch_object.get_port(port_number):
                self.get_topology_view_list_from_port(switch_object.get_port(port_number), node_list=node_list, topology=topology, do_switches=False)
            if given_node_entry and given_node_entry.get_port(port_number):
                self.get_topology_view_list_from_port(given_node_entry.get_port(port_number), node_list=node_list, topology=topology, do_switches=False)

        # Then do switches
        for port_number in range(1,20+1):
            if switch_object.get_port(port_number):
                self.get_topology_view_list_from_port(switch_object.get_port(port_number), node_list=node_list, topology=topology)
            if given_node_entry and given_node_entry.get_port(port_number):
                self.get_topology_view_list_from_port(given_node_entry.get_port(port_number), node_list=node_list, topology=topology)

    def get_topology_view_list_from_port(self, port, node_list, topology=None, do_switches=True):
        if do_switches:
            if port.end and isinstance(port.end.owner, OpenFlowDevice):
                operational_id = self.get_operational_id_from_node_entry(port.end.owner)
                if operational_id and operational_id not in node_list:
                    node_list.append(operational_id)
                    self.get_topology_view_list_from_switch(port.end.owner, node_list, topology=topology)
        else:   
            if port.end and isinstance(port.end.owner, TraditionalSwitchDevice):
                operational_id = self.get_operational_id_from_node_entry(port.end.owner)
                if operational_id and operational_id not in node_list:
                    node_list.append(operational_id)
                for subport in port.end.owner.ports[1:]:
                    if subport.end:
                        operational_id = self.get_operational_id_from_node_entry(subport.end.owner)
                        if operational_id and operational_id not in node_list:
                            node_list.append(operational_id)
            
            if port.end and not isinstance(port.end.owner, OpenFlowDevice):
                operational_id = self.get_operational_id_from_node_entry(port.end.owner)
                if operational_id and operational_id not in node_list:
                    node_list.append(operational_id)

    def get_topology(self):
        # Need unique names for Traditional Switches
        def get_next_traditional_switch_post_fix():
            start = 1

            while True:
                yield start
                start += 1

        next_number = get_next_traditional_switch_post_fix()

        node_entries = self.get_node_entries()

        for node_entry in node_entries:
            # Process from the switch point of view
            if isinstance(node_entry, OpenFlowDevice):
                if node_entry.get_attribute("operational_id"):
                    operational_id = node_entry.get_attribute("operational_id")
                else:
                    configuration_node_object = self.get_configuration_node(node_entry.get_attribute("id"))
                    operational_id = configuration_node_object["linkedKey"]

                # Maybe just a configuration object
                if not operational_id:
                    continue

                # Get the operational node object of the switch
                operational_node_object = self.get_operational_node(operational_id)
                for port_id in operational_node_object["ports"]:
                    operational_port_object = self.get_operational_port(port_id)
                    if operational_port_object:
                        for attribute in operational_port_object["attributes"]:
                            if attribute.get("portId"):
                                port_number = attribute.get("portId")
                                break
                        # Get the other operational ports attached to the port
                        other_operational_port_objects = self.get_other_ports_from_port(operational_port_object)
                        if len(other_operational_port_objects) > 1:
                            # Check that the traditional switch is already there
                            # Need to add in a traditional switch
                            # Number of ports = number of other attached devices plus the node_entry itself
                            this_node_entry = TraditionalSwitchDevice(name="Traditional Switch {}".format(next(next_number)), ports=len(other_operational_port_objects)+1)
                            node_entries.append(this_node_entry)
                            this_node_entry.get_port(1).end = node_entry.get_port(port_number)
                            #this_node_entry.get_port(1).set_attribute("operational_id", operational_port_object["id"])
                            node_entry.get_port(port_number).end = this_node_entry.get_port(1)
                            node_entry.get_port(port_number).set_attribute("operational_id", operational_port_object["id"])
                            node_entry.get_port(port_number).set_attribute("id", operational_port_object["linkedKey"])
                            port_numbers = range(2, len(other_operational_port_objects)+2)
                        else:
                            this_node_entry = node_entry
                            port_numbers = (port_number,)

                        for this_port_number, other_operational_port_object in zip(port_numbers, other_operational_port_objects):
                            if other_operational_port_object is None:
                                LOGGER.error("Found a None port when looking at {}", operational_node_object)
                                continue

                            other_operational_node_object = self.get_operational_node(other_operational_port_object["parentNode"])
                            other_device_objects = node_entries.has_attribute_value("operational_id", other_operational_node_object["id"])
                            if other_device_objects:
                                other_device_object = other_device_objects[0]

                                if isinstance(other_device_object, TraditionalSwitchDevice):
                                    continue

                                if isinstance(other_device_object, OpenFlowDevice):
                                    for attribute in other_operational_port_object["attributes"]:
                                        if attribute.get("portId"):
                                            other_port_number = attribute.get("portId")
                                            break
                                else:
                                    for port in other_device_object.ports:
                                        if not port.end:
                                            other_port_number = port.name
                                            break
                                    else:
                                        other_device_object.add_port(port.name)
                                        other_port_number = port.name

                                other_device_object.get_port(other_port_number).end = this_node_entry.get_port(this_port_number)
                                other_device_object.get_port(other_port_number).set_attribute("operational_id", other_operational_port_object["id"])
                                other_device_object.get_port(other_port_number).set_attribute("id", other_operational_port_object["linkedKey"])
                                this_node_entry.get_port(this_port_number).end = other_device_object.get_port(other_port_number)
                                this_node_entry.get_port(this_port_number).set_attribute("operational_id", operational_port_object["id"])
                                this_node_entry.get_port(this_port_number).set_attribute("id", operational_port_object["linkedKey"])
                    else:
                        print("Cannot find port {}".format(port_id))
            # Need to connect up devices to TraditionalSwitchDevices also
            elif isinstance(node_entry, TraditionalSwitchDevice):
                operational_id = self.get_operational_id_from_node_entry(node_entry)

                # Maybe just a configuration object
                if not operational_id:
                    continue

                # Need to connect up the nodes
                operational_node_object = self.get_operational_node(operational_id)
                while len(node_entry.ports) < len(operational_node_object["ports"]):
                    node_entry.add_port()

                # This first is the switch to traditional switch. Need to find that one.
                for port_id in operational_node_object["ports"]:
                    operational_port_object = self.get_operational_port(port_id)
                    other_operational_port_objects = self.get_other_ports_from_port(operational_port_object)

                    for other_operational_port_object in other_operational_port_objects:
                        # Need to treat switches differently than hosts
                        for attribute in other_operational_port_object["attributes"]:
                            if "OpenFlowPortAttr" in attribute["@odata.type"]:
                                switch_node = node_entries.has_datapath_id(attribute["prettyDataPathId"])
                                if not switch_node:
                                    LOGGER.warning("Unable to find node with datapath id {}".format(attribute["prettyDataPathId"]))
                                    continue
                                else:
                                    switch_node = switch_node[0]
                                switch_port = switch_node.get_port(attribute["portId"])

                                # Find the connected port
                                for port in node_entry.ports:
                                    # These two objects are already connected
                                    if port.end == switch_port:
                                        # Already connected to switch port
                                        break
                                else:
                                    # Add the connection to the next free port
                                    for port in node_entry.ports:
                                        if not port.end:
                                            port.end = switch_port
                                            switch_port.end = port.end
                                            break
                                    else:
                                        raise ValueError("Unable to find a port to connect the traditional switch to")
                                
                                # No reason to keep processing the attributes
                                break
                        else:
                            other_operational_node_object = self.get_operational_node(other_operational_port_object["parentNode"])
                            other_device_object = node_entries.has_attribute_value("operational_id", other_operational_node_object["id"])[0]

                            for port in node_entry.ports:
                                if not port.end:
                                    this_port = port
                                    break
                            else:
                                raise ValueError("There are no more free ports on".format(node_entry))

                            for port in other_device_object.ports:
                                if not port.end:
                                    other_port = port
                                    break
                            else:
                                raise ValueError("There are no more free ports on".format(other_device_object))

                            other_port.end = this_port
                            other_port.set_attribute("operational_id", other_operational_port_object["id"])
                            other_port.set_attribute("id", other_operational_port_object["linkedKey"])

                            this_port.end = other_port
                            this_port.set_attribute("operational_id", operational_port_object["id"])
                            this_port.set_attribute("id", operational_port_object["linkedKey"])

        return node_entries

    build_network = get_topology

    def get_owner_from_port(self, port_object):
            operational_node_owning_port_object = self.get_operational_node(port_object["parentNode"])
            return operational_node_owning_port_object["id"]

    def get_other_ports_from_port(self, port_object):
        port_object_id = port_object["id"]
        attached_link_ids = port_object["attachedLinks"]
        other_ports = list()
        # Could be a device in failover mode and therefore two links
        for attached_link_id in attached_link_ids:
            attached_link_object = self.get_operational_link(attached_link_id)
            for attached_link_port_id in attached_link_object["endPoints"]:
                # Need to find the other side of the link that is not me
                if attached_link_port_id != port_object_id:
                    # I only return one, if more than one, need a traditional switch
                    other_ports.append(self.get_operational_port(attached_link_port_id))
        return other_ports
