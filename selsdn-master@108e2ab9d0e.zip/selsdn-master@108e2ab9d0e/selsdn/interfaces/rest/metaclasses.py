from .decorators import no_body_url
from .constants import COMMAND_DELETE, CONFIGURATION_GROUPS, CONFIGURATION_FLOWS

class ObjectMixin(type):
    @classmethod
    def __prepare__(cls, clsname, bases, *, name, url):
        return super().__prepare__(name, bases)

    def __new__(cls, clsname, bases, ns, *, name, url):
        return super().__new__(cls, clsname, bases, ns)
        
    def __init__(self, clsname, bases, ns, *, name, url):   
        @no_body_url(url=url, required=None)
        def _get_objects(self, response=None):
            return response

        @no_body_url(url=url, required=True)
        def _get_object(self, object_id, response=None):
            return response

        def get_object(self, object_id, find_if_not_cached=False):
            return self.get_object(url=url, object_id=object_id)

        def get_objects(self):
            return self.get_objects(url=url)

        def get_object_by_name(self, object_name):
            object_id = self.get_id_from_name(object_name=object_name, object_type=url)
            if object_id:
                return self.get_object(url=url, object_id=object_id)

        @no_body_url(url=url, command=COMMAND_DELETE, required=True)
        def _delete_object(self, object_id, response=None):
            return response

        def delete_object(self, object_id):
            return self.delete_object(url=url, object_id=object_id)

        def delete_object_by_name(self, object_name):
            return self.delete_object_by_name(url=url, object_name=object_name)

        def update_object(self, object):
            command = "PUT" if url in (CONFIGURATION_GROUPS, CONFIGURATION_FLOWS) else "PATCH"
            return self.update_object(url=url, object_body=object, object_id=object["id"], command=command)

        def get_object_objects(self):
            return self.get_wrapped_objects(url)

        def get_object_object(self, object_id):
            return self.get_wrapped_object(url, object_id=object_id)

        if name and url:
            for function in (get_object_objects, get_object_object, _get_objects, update_object, _get_object, get_object, get_objects, get_object_by_name, _delete_object, delete_object, delete_object_by_name):
                setattr(self, function.__name__.replace("object", name, 1), function)

        return super().__init__(clsname, bases, ns)

#   def __init__(self, clsname, bases, ns, *, name, url):
#       super().__init__(clsname, bases, ns)
