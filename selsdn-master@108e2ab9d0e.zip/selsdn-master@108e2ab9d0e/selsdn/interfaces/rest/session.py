import socket
import ssl

from time import sleep, time
from webbrowser import open_new

from logging import getLogger
LOGGING_NAME = __name__
LOGGER = getLogger(LOGGING_NAME)

from .http_server import obtain_implicit_token
from .commands import Request, Response
from .exceptions import BadRequestError, ForbiddenError, InternalServerError, RESTException, NotFoundError, UnauthorizedError, ConflictError, SocketException
from .constants import CODE_BAD_REQUEST, CODE_FORBIDDEN, CODE_NOT_FOUND, CODE_INTERNAL_SERVER_ERROR, CODE_UNAUTHORIZED, CODE_CONFLICT
from .constants import ROLE_PL3, ROLE_SECURITY_ADMINISTRATOR, ROLE_MONITOR
from .constants import OAUTH_TYPE_CLIENT, OAUTH_TYPE_USER, OAUTH_TYPE_AUTHORIZATION, OAUTH_TYPE_IMPLICIT
from .constants import SOCKET_TIMEOUT
from .controller_version import ControllerVersion

IP_ADDRESS = 'localhost'
PORT_HTTPS = 443
VERSION_HTTP_1_1 = "1.1"

class Session:
    URL_TOKEN = '/identity/connect/token'
    URL_AUTHORIZATION = '/identity/connect/authorize'
    URL_LOGOFF = '/identity/connect/revocation'
    TOKEN_VALIDATE = '/identity/connect/accesstokenvalidation'
    URL_LOGIN = '/identity/login'
    URL_CONFIGURATION_SETTINGS = "/configuration/settings.json"

    def __init__(self, username, password, role="PermissionLevel3", port=PORT_HTTPS, version=VERSION_HTTP_1_1, url=IP_ADDRESS, tls=True, verbose=False, version_5056=None, oauth_type=OAUTH_TYPE_USER, cert_file=None, key_file=None, redirect_uri="http://localhost:1234/index.html", save_packets=False, auto_login=True, timeout=SOCKET_TIMEOUT):
        if ":" in url and not port:
            url, port = url.split(":")
            port = int(port)

        self._port = port if port else PORT_HTTPS
        self._version = version
        self._host = url
        self.verbose = verbose
        self.tls = tls
        self.oauth_type = oauth_type
        self.last_call_successful = False

        self.username = username
        self.password = password
        self._role = role
        
        # Populated after connections
        self._token = None
        self._socket = None
        self.version_5056 = version_5056

        self.cert_file = cert_file
        self.key_file = key_file

        self.last_role = role
        self.redirect_uri = redirect_uri

        self.save_packets = save_packets
        self.saved_packets = list()

        self.auto_login = auto_login

        if timeout < 1 or timeout > 1000:
            raise ValueError("Timeout must be between 1 and 1000 not {}".format(timeout))
        self.socket_timeout = timeout

        if not self.username and not self.password:
            if self.oauth_type == "Implicit":
                self._obtain_token_implicit()
            elif self.oauth_type == "AuthorizationCode":
                self._obtain_authorization_code()
            else:
                raise

        self.token_expiration_time = None

    def set_timeout(self, timeout):
        self.socket_timeout = timeout
        if self.socket:
            self.socket.settimeout(timeout)

    @property
    def version_5056(self):
        if self._version_5056._version is None:
            self.version_5056 = self._get_controller_version()
        return self._version_5056

    @version_5056.setter
    def version_5056(self, new_version):
        self._version_5056 = ControllerVersion(new_version)
    
    def _obtain_authorization_code(self):
        url = "https://{}:{}}/authorize?scope=appointments%20contacts&audience=appointments:api&response_type=code&client_id=YOUR_CLIENT_ID&redirect_uri=https://YOUR_APP/callback"
        open_new("http://localhost:1234/index.html")

    def _obtain_token_implicit(self):
        open_new("http://localhost:1234/index.html")

        token = obtain_implicit_token(redirect_url=self.redirect_uri, certfile=self.cert_file, keyfile=self.key_file)

        self._token = token
        LOGGER.info("Obtained token {}".format(token))

    @property
    def role(self):
        return self._role

    @role.setter
    def role(self, value):
        self._role = value

    @property
    def socket(self):
        return self._socket

    @property
    def logged_in(self):
        return self._token is not None and self.validate_token()
        # TODO also test the socket is open

    # Token Validation
    def validate_token(self):
        #return True
        if self._token:
            try:
                response = self._validate_token(self._token)
                return response.response_code == 200
            except BadRequestError:
                return False
        else:
            return False

    def _send_request(self, request, relogin=True, check=True, wait_for_response=True):
        response = None
        bytes_written = self.send(request, relogin=relogin, check=check)
        if wait_for_response:
            response = self.response()
            if not response:
                LOGGER.warning("Resending request because no response was received.")
                self.send(request, relogin=relogin, check=check)
                response = self.response()
                if not response:
                    raise ValueError("Unable to send the request to the SEL-5056 twice in a row because the SEL-5056 socket was unexpected closed twice")
        
        return response

    def send_request(self, request, check=True, *args, **kwargs):
        response = self._send_request(request=request, check=check, *args, **kwargs)

        if response and ((response.code == 401 and self.last_call_successful) or (response.code == 400 and response.data == {'error': {'code': '', 'message': '', 'details': []}})):
            if response.code == 401:
                LOGGER.warning("Token has expired, relogging in and trying request again")
                self.login()
                if check and isinstance(request, Request):
                    if request.get_header("Authorization"):
                        request.change_header("Authorization", "Bearer "+ self._token)
            else:
                LOGGER.warning("Unexpected Bad Request error, retrying request")
            response = self._send_request(request, *args, **kwargs)

        if response.get_header("Connection") and response.get_header("Connection") == "close":
            self.logout()
        elif 400 <= response.code <= 500:
            self.raise_error(response)
        else:
            self.last_call_successful = True
            return response

    def _validate_token(self, token):
        r = Request("POST", self.TOKEN_VALIDATE, host=self.host)
        r.add_query("token", token)
        return self.send_request(r, check=False)

    def disconnect(self):
        self._token = None
        if self.socket:
            self.socket.close()
        self._socket = None

    def _get_controller_version(self):
        r = Request("GET", self.URL_CONFIGURATION_SETTINGS, host=self.host)
        response = self.send_request(r, check=False)
        return response.body.body["controllerVersion"]

    def connect(self):
        s = socket.socket()
        s.settimeout(self.socket_timeout)
        if self.tls:
            if self.key_file and self.cert_file:
                s = ssl.wrap_socket(s, keyfile=self.key_file, certfile=self.cert_file)
                LOGGER.info("Adding in key and certs")
            else:
                s = ssl.wrap_socket(s)
        
        LOGGER.info("Connecting to {}".format(self.address_tuple))
        
        s.connect(self.address_tuple)
        self._socket = s

    def reconnect(self):
        self.disconnect()
        # try a second time

        try:
            self.connect()
        except socket.timeout as e:
            LOGGER.warning("Socket timed out, trying a second time in 5 seconds")
            sleep(5)
            self.connect()

    def login(self, username=None, password=None, role=None):
        if not self.socket:
            try:
                self.connect()
            except socket.timeout as e:
                LOGGER.warning("Socket timed out, trying a second time in 5 seconds")
                sleep(5)
                self.connect()

        username, = username if username else self.username, 
        password = password if password else self.password
        role = role if role else self.role

        if not self.logged_in:
            token = self.get_token(username, password, role)
            self.last_call_successful = False

        if not self.version_5056 and token:
            self.version_5056 = self._get_controller_version()

    @property
    def grant_type(self):
        if self.oauth_type == OAUTH_TYPE_USER:
            return 'password'
        elif self.oauth_type == OAUTH_TYPE_CLIENT:
            return 'client_credentials'
        elif self.oauth_type == OAUTH_TYPE_AUTHORIZATION:
            return 'authorization_code'
        else:
            raise

    @property
    def client_id(self):
        if self.oauth_type == OAUTH_TYPE_USER:
            return "password-client"
        elif self.oauth_type == OAUTH_TYPE_IMPLICIT:
            return "web-client"
        else:
            return "-".join([self.username, self.oauth_type])

    def get_token(self, username, password, role):
        self.username = username
        self.password = password
        self.role = role

        if self.oauth_type == OAUTH_TYPE_AUTHORIZATION:
            r = Request("POST", self.URL_AUTHORIZATION, host=self.host)
            r.add_header("Content-Type", "application/x-www-form-urlencoded")
            r.add_parameter("redirect_uri", self.redirect_uri)
            
            r.add_parameter("code", self.password)
            r.add_parameter("grant_type", self.grant_type)
        elif self.oauth_type == OAUTH_TYPE_IMPLICIT:
            r = Request("GET", self.URL_AUTHORIZATION, host=self.host)
            r.add_parameter("response_type", "token")
            r.add_parameter("redirect_uri", self.redirect_uri)
        else:
            r = Request("POST", self.URL_TOKEN, host=self.host)
            r.add_header("Content-Type", "application/x-www-form-urlencoded")

            r.add_parameter("grant_type", self.grant_type)
            #r.add_parameter("redirect_uri", self.redirect_uri)

        if self.oauth_type == OAUTH_TYPE_USER:
            r.add_parameter("username", self.username)
            r.add_parameter("password", self.password)

        if self.oauth_type in (OAUTH_TYPE_USER, OAUTH_TYPE_IMPLICIT):
            r.add_parameter("acr_values", "role:"+role)

        if self.oauth_type == OAUTH_TYPE_USER:
            r.add_parameter("client_secret", self.client_secret)

        if self.oauth_type != OAUTH_TYPE_AUTHORIZATION:
        # Parameters independent of the grant type
            r.add_parameter("scope", "Rest")
            r.add_parameter("client_id", self.client_id)
            r.add_parameter("state", '0')

        # For auth code need to log in as a user
        try:
            response = self.send_request(r, check=False)
        except BadRequestError as e:
            raise e

        if self.oauth_type == OAUTH_TYPE_IMPLICIT:
            if response.response_code == 302:
                referer = response.header.get_header("Location")
                first_cookie = response.header.get_header("Set-Cookie").split(";")[0]
                response_code = referer.split("=")[-1]
                r2 = Request("GET", self.URL_LOGIN, host=self.host)
                r2.add_query('signin', response_code)
                r2.add_header("Cookie", first_cookie)
                r2.add_header("Referer", referer)

                response2 = self.send_request(r2, check=False)
                import re
                print(response2.contents)
                result = re.search(b"{&quot;name&quot;:&quot;idsrv.xsrf&quot;,&quot;value&quot;:&quot;([^&]+)&quot;}", response2.contents)
                if result:
                    body_id = result.group(1).decode()
                else:
                    raise

                second_cookie = response2.header.get_header("Set-Cookie").split(";")[0]

                r3 = Request("POST", self.URL_LOGIN, host=self.host)
                r3.add_query('signin', response_code)
                r3.add_header("Content-Type", "application/x-www-form-urlencoded")
                r3.add_header("Cookie", "; ".join([first_cookie, second_cookie]))
                r3.add_header("Referer", referer)
                #r2.add_header("Referer", referer)
                r3.add_parameter("username", self.username)
                r3.add_parameter("password", self.password)
                r3.add_parameter("idsrv.xsrf", body_id)
                #r2.add_parameter("idsrv.xsrf", cookie)
                #r2.add_parameter("signin", response_code)
                print(r3.to_bytes())
                response3 = self.send_request(r3, check=False)
                print(response3.contents)
                referer = response.header.get_header("Location")
                #session_cookie, idsrv_cookie = response.header.get_header("Set-Cookie").split(" ")[0, -1]


                r.add_header("Referer", referer)
                r.add_header("Cookie", "; ".join([first_cookie, second_cookie]))
                response4 = self.send_request(r, check=False)
                print(response4.contents)
                self._token = input("Enter Token")

        else:
            if response.response_code == 200:
                self._token = response.body.body["access_token"]
                self.token_expiration_time = time() + response.body.body["expires_in"]
            else:
                self._token = None

        LOGGER.info("Received code {} with token {}".format(response.response_code, self._token))

        return response

    @property
    def client_secret(self):
        if self.oauth_type == OAUTH_TYPE_USER:
            if self.version_5056 == "1.4":
                return "SEL-5056 Rest Interface"
            else:
                return "Rest Interface"
        elif self.oauth_type == OAUTH_TYPE_CLIENT:
            return self.password

    def logout(self):
        if self.socket and self._token:
            r = Request("POST", self.URL_LOGOFF, host=self.host)
            r.add_header("Content-Type", "application/x-www-form-urlencoded")
            r.add_header("Authorization", "Bearer "+ self._token)
            r.add_parameter("token", self._token)
            r.add_parameter("token_type_hint", "access_token")
            r.add_parameter("client_id", self.client_id)
            if self.client_secret:
                r.add_parameter("client_secret", self.client_secret)

            try:
                self._send(r, relogin=False)
            except RuntimeError as e:
                self.connect()
                self._send(r, relogin=False)
            except (ConnectionResetError, ConnectionAbortedError):
                pass
            self.disconnect()
        elif self.socket:
            self.disconnect()

        self.token_expiration_time = None

    def __enter__(self):
        return self
    
    def __exit__(self, exc_ty, exc_val, exc_tb):
        self.logout()

    def send(self, data, relogin=True, check=True):
        bytes_written = False
        if relogin and self.auto_login and check and (not self.socket or not self.token):
            self.login()
        elif not self.socket and self.auto_login:
            self.connect()

        current_token = self._token
        if isinstance(data, Request):
            if not data.host:
                data.add_header("HOST", self.host)
            if check and not data.get_header("Authorization"):
                data.add_header("Authorization", "Bearer "+ self._token)
            
            if self.save_packets:
                self.saved_packets.append(data)

        try:
            bytes_written = self._send(data, relogin, check)
        except (ConnectionResetError, ConnectionAbortedError) as e:
            self._socket = None
            if self.auto_login:
                LOGGER.warning("Had to reset socket because of {}".format(e))
                self.login()
                if check and isinstance(data, Request):
                    if data.get_header("Authorization"):
                        data.change_header("Authorization", "Bearer "+ self._token)

                LOGGER.warning("Had to resend data")
                bytes_written = self._send(data, relogin, check)
            else:
                raise e 

        return bytes_written

    def _send(self, data, relogin=True, check=True):
        if isinstance(data, Request):
            data = data.to_bytes()

        LOGGER.debug(data)
        if self.socket:
            bytes_written = self.socket.write(data)
        else:
            raise RuntimeError("You are attempting to write to a socket that is not open.")

        data_written = data[:bytes_written]
        if self.verbose:
            print("DATA Sent")
            if bytes_written < len(data):
                print("Incomplete Messages sent")
            print(data_written[:1500].decode('latin_1').replace("\r\n", "\n"))#.replace('\n', '<LF>\n').replace(' ', '<SP>').replace('\r', '<CR>'), end='')
            if len(data_written) > 1500:
                print("\nTruncated...Sent", len(data_written), "bytes of data, last 50 characters")
                print(data_written[-50:].decode('latin_1').replace("\r\n", "\n"))#.replace('\n', '<LF>\n').replace(' ', '<SP>').replace('\r', '<CR>'), end='')
            print()
            print()

        LOGGER.debug("Wrote {} out of {} bytes".format(str(bytes_written), len(data)))
        return bytes_written == len(data)

    def flush_response_buffer(self, size=4096):
        return self.receive(size)

    def receive(self, size=8192):
        response = None
        if self.socket:
            try:
                data = self.socket.recv(size)
            except (ConnectionResetError, ConnectionAbortedError) as e:
                data = b""
        else:
            raise RuntimeError("You are attempting to write to a socket that is not open.")

        if data:
            response = Response.from_raw_data(data, self.socket.recv)

            if self.verbose:
                print("DATA Received")
                print(response.raw_data[:1500].decode('latin_1'))#.replace('\n', '<LF>\n').replace(' ', '<SP>').replace('\r', '<CR>'), end='')
                if len(response.raw_data) > 1500:
                    print("\nTruncated...Received", len(response.raw_data), "bytes of data, last 50 characters")
                    print(response.body.raw_data[-50:].decode('latin_1'))#.replace('\n', '<LF>\n').replace(' ', '<SP>').replace('\r', '<CR>'), end='')
                print()
                print()

            LOGGER.debug(response.raw_data)
            return response
        else:
            self._socket = None
            LOGGER.warning("The SEL-5056 socket was unexpectedly closed when trying to receive response.")
            return None

    def raise_error(self, response):
        code, error = response.code, response.error_message

        if response.code == CODE_BAD_REQUEST:
            raise BadRequestError(error)
        elif response.code == CODE_FORBIDDEN:
            raise ForbiddenError(error)
        elif response.code == CODE_NOT_FOUND:
            raise NotFoundError(error)
        elif response.code == CODE_INTERNAL_SERVER_ERROR:
            raise InternalServerError(error)
        elif response.code == CODE_UNAUTHORIZED:
            raise UnauthorizedError(error)
        elif response.code == CODE_CONFLICT:
            raise ConflictError(error)
        else:
            new_exception =  RESTException(error)
            raise new_exception

    def response(self, size=8192, retry=25):
        return self.receive(size=size)

    @property
    def port(self):
        return self._port

    @property
    def address_tuple(self):
        return (self.host, self.port)

    @property
    def version(self):
        return self._version

    @property
    def host(self):
        return self._host

    @property
    def token(self):
        if not self._token and self.auto_login:
            self.login()
        return self._token
