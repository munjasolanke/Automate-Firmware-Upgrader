from collections import defaultdict

from .constants import *
from .base import RestObject

class CacheMixIn:
    def _start_cache(self, caching):
        self._url_sources = (CONFIGURATION_CSTS, CONFIGURATION_LCS, CONFIGURATION_NODES, CONFIGURATION_FLOWS, 
                            CONFIGURATION_METERS, CONFIGURATION_GROUPS, CONFIGURATION_PORTS, OPERATIONAL_LINKS, 
                            OPERATIONAL_NODES, OPERATIONAL_PORTS)

        self.raw_data = defaultdict(list)
        for source in self._url_sources:
            self.raw_data[source] = list()
        self.objects = dict()

    def pull_information(self):
        for source in self._url_sources:
            gets_function = self.gets_function_from_url(source)
            values = gets_function().value
            self.set_cached_objects(source, values)

        self.objects["nodes"] = self.build_network()

    def get_information(self, object_type):
        if object_type == OBJECT_NODES and self.caching:
            if not self.objects.get(OBJECT_NODES):
                self.objects[OBJECT_NODES] = self.build_network()

            return self.objects[OBJECT_NODES]
        elif object_type == OBJECT_NODES:
            return self.build_network()
        else:
            raise

    def update_cached_object_by_index(self, object_type, index, value):
        self.get_cached_objects(object_type)[index] = value
        return value

    def delete_cached_object_by_id(self, object_type, object_id):
        total_length = len(self.get_cached_objects(object_type))
        for index, value in enumerate(self.get_cached_objects(object_type)[::-1]):
            if value[PROPERTY_ID] == object_id:
                return self.delete_cached_object_by_index(object_type=object_type, index=total_length-index-1)

    def delete_cached_object_by_index(self, object_type, index):
        return self.get_cached_objects(object_type).pop(index)

    def set_cached_objects(self, object_type, values):
        if not isinstance(values, list):
            raise TypeError("Cached collections for {} must be list or list like not {}".format(object_type, type(values)))
        self.raw_data[object_type] = values

    def get_cached_objects(self, object_type):
        return self.raw_data.get(object_type, list())

    def get_cached_object_by_id(self, object_type, object_id):
        for object_body in self.get_cached_objects(object_type):
            if object_body[PROPERTY_ID] == object_id:
                return object_body

    def update_cached_object_by_id(self, object_type, object_id, value):
        for index, object_body in enumerate(self.get_cached_objects(object_type)):
            if object_body[PROPERTY_ID] == object_id:
                return self.update_cached_object_by_index(object_type=object_type, index=index, value=value)

    def update_cached_object_by_index(self, object_type, index, value):
        self.get_cached_objects(object_type)[index] = value
        return value

    def delete_cached_object_by_id(self, object_type, object_id):
        total_length = len(self.get_cached_objects(object_type))
        for index, value in enumerate(self.get_cached_objects(object_type)[::-1]):
            if value[PROPERTY_ID] == object_id:
                return self.delete_cached_object_by_index(object_type=object_type, index=total_length-index-1)

    def delete_cached_object_by_index(self, object_type, index):
        return self.get_cached_objects(object_type).pop(index)

    def add_cached_object(self, object_type, value):
        if not isinstance(value, dict) and not isinstance(value, RestObject):
            raise TypeError("Cached items must be dict not type {} {}".format(type(value), value))
        self.raw_data[object_type].append(value)

    def set_cached_objects(self, object_type, values):
        for value in values:
            if not isinstance(value, dict) and not isinstance(value, RestObject):
                raise TypeError("Cached items must be dict not type {} {}".format(type(value), value))
        self.raw_data[object_type] = values

    def clear_information(self, object_type=None):
        if object_type:
            self.raw_data[object_type] = list()
        else:
            self.raw_data = defaultdict(list)

        self.objects = dict()

    def add_cached_objects(self, object_type, values):
        return self.set_cached_objects(object_type=object_type, values=values)

    def update_cache(self, object_type, response, object_id, command):
        if type(response) is not dict:
            raise TypeError("Unknown type {} for response".format(type(response)))

        if command in (COMMAND_GET, COMMAND_PATCH, COMMAND_PUT, COMMAND_POST):
            if not self.update_cached_object_by_id(object_type, object_id=object_id, value=response):
                self.add_cached_object(object_type=object_type, value=response)
        elif command == COMMAND_DELETE:
            self.delete_cached_object_by_id(object_type=object_type, object_id=object_id)
