from .metaclasses import ObjectMixin
from .exceptions import NotFoundError
from .constants import CONFIGURATION_CSTS, TREE_MATCHFIELDS, APPLICATION_JSON, COMMAND_DELETE, CODE_CREATED, PROPERTY_ID, OBJECT_NODES

from . import LOGGER

from ...openflow.core.match_fields import MatchField, Ipv4SrcMatch, Ipv4DstMatch
from ...openflow.core.match_fields import ArpSpaMatch, ArpTpaMatch, VlanVidMatch, EthDstMatch
from ...automation.protocol import GOOSEProtocol, Ipv4Protocol, Protocol, ArpProtocol
from ...automation.application import MulticastApplication, UnicastApplication
from ...automation.policy import IDSPolicy, IDSMissPolicy
from ...automation.device import OpenFlowDevice
from ...base.collection import ProtocolCollection

from ...globals import CST_SPACER

class CommunicationServiceTypeMixin(metaclass=ObjectMixin, name="cst", url=CONFIGURATION_CSTS):
    def get_temp_csts(self):
        return [cst for cst in self.get_csts() if cst["displayName"][0] == "*"]

    def convert_match_field_to_json(self, match_field, use_mask=True, use_aliased_fields=True):
        odata_type = self.convert_match_field_to_odata_type(match_field)
        value = None
        if use_aliased_fields and match_field.get_attribute("$alias"):
            if match_field.__class__ in (ArpSpaMatch, ArpTpaMatch, Ipv4SrcMatch, Ipv4DstMatch):
                node_entry = self.get_information(OBJECT_NODES).has_name(match_field.get_attribute("$alias").name)[0]
                # Aliases for switches are the configuration node id of the switch itself
                # However, if it is a mininet switch, it is not going to work
                if isinstance(node_entry, OpenFlowDevice):
                    value = str(match_field)
                    #value = node_entry.get_attribute("id")
                    #odata_type += "ByAlias"
                # Aliases for non-switches are a configuration port id itself
                else:
                    for port in node_entry.ports:
                        if port.ip_address == match_field.value:
                            value = port.get_attribute("id")
                            odata_type += "ByAlias"
                            break
                    else:
                        LOGGER.warning("Unable to find the port for device {} to create an alias for CST".format(match_field.get_attribute("$alias")))
                        value = str(match_field)
            else:
                raise
        else:
            value = str(match_field)

        if use_mask and match_field.is_maskable() and not match_field.get_attribute("$alias"):
            mask = None if not match_field.mask else str(match_field.mask)
            return {"@odata.type":odata_type, "value":value, 'mask':mask}
        else:
            if value == "DNP3":
                value = str(match_field.value)
            return {"@odata.type":odata_type, "value":value}

    def get_lcs_referencing_cst(self, object_id):
        lc_objects = self.get_lcs()
        references = list()
        for lc_object in lc_objects:
            if lc_object["communicationServiceTypeId"] == object_id:
                references.append(lc_object)
        return references

    def convert_match_field_to_odata_type(self, match_field, use_mask=False):
        if not isinstance(match_field, MatchField):
            raise TypeError("Match field must be of type {}}, not {}".format(MatchField, type(match_field)))

        return ".".join([TREE_MATCHFIELDS, match_field.__class__.__name__[:-5]])

    def convert_application_policy_to_protocols(self, application_entry, protocol=None, source=None, destinations=None):
        if isinstance(application_entry, MulticastApplication):
            return (self.convert_application_policy_to_protocol(application_entry, protocol, source, destinations),)
        elif application_entry.protocol.bidirectional:
            reverse_application = application_entry.reverse()
            return (self.convert_application_policy_to_protocol(application_entry, protocol, source, destinations), self.convert_application_policy_to_protocol(reverse_application, protocol=protocol.reverse(), source=destinations[0], destinations=[source]))
        else:
            raise ValueError("Don't know now to convert {} to protocols with policy {}".format(application_entry, application_entry.policies))

    def convert_application_policy_to_protocol(self, application_entry, protocol=None, source=None, destinations=None):
        protocol = application_entry.protocol if protocol is None else protocol
        source = application_entry.source if source is None else source
        destination = application_entry.destinations if not destinations else destinations[0]

        # Table miss is different
        if isinstance(application_entry.policies[0], IDSMissPolicy):
            if not application_entry.protocol.get(EthDstMatch):
                protocol_fields = protocol.values + [EthDstMatch("00:00:00:00:00:00")]
            else:
                protocol_fields = protocol.values
            new_protocol = Protocol.create_protocol_from_match_fields(name=protocol.name, match_fields=protocol_fields, unicast=False, unidirectional=False)
        else:
            new_protocol = Protocol.create_protocol_from_match_fields(name=protocol.name, match_fields=protocol.values)
            if isinstance(new_protocol, Ipv4Protocol):
                if not new_protocol.get(Ipv4SrcMatch):
                    new_match = Ipv4SrcMatch(source.ip_address)
                    new_match.add_attribute("$alias", source.owner)
                    new_protocol.add(new_match)
                if not new_protocol.get(Ipv4DstMatch):
                    new_match = Ipv4DstMatch(destination.ip_address)
                    new_match.add_attribute("$alias", destination.owner)
                    new_protocol.add(new_match)
            elif isinstance(new_protocol, ArpProtocol):
                if not new_protocol.get(ArpSpaMatch):
                    new_match = ArpSpaMatch(source.ip_address)
                    new_match.add_attribute("$alias", source.owner)
                    new_protocol.add(new_match)
                if not new_protocol.get(ArpTpaMatch):
                    new_match = ArpTpaMatch(destination.ip_address)
                    new_match.add_attribute("$alias", destination.owner)
                    new_protocol.add(new_match)

            if not (new_protocol.get(VlanVidMatch) or new_protocol.get(EthDstMatch)):
                new_protocol.add(VlanVidMatch("None"))

        if protocol.get_attribute("FlowPriority"):
            new_protocol.set_attribute("FlowPriority", protocol.get_attribute("FlowPriority"))

        return new_protocol

    def add_cst_by_application_entry(self, application_entry, protocol=None, source=None, destinations=None, fill_in_fields=False, use_aliased_fields=True):
        protocol = application_entry.protocol if protocol is None else protocol
        source = application_entry.source if source is None else source
        destinations = application_entry.destinations if destinations is None else destinations

        if isinstance(protocol, GOOSEProtocol) and protocol.get("VlanVid"):
            cst_name = "-".join([protocol.name, "VID "+str(protocol.get("VlanVid"))])
        else:
            cst_name = protocol.name

        if isinstance(application_entry, MulticastApplication) and not fill_in_fields:
            cst_type = "Multicast"
            return (self.add_protocol_entry(protocol, cst_name=cst_name, cst_type=cst_type, queue=application_entry.priority_queue, use_aliased_fields=use_aliased_fields),)
        elif not isinstance(application_entry, MulticastApplication) and not fill_in_fields:
            cst_type = None
            return (self.add_protocol_entry(protocol, cst_name=cst_name, cst_type=cst_type, queue=application_entry.priority_queue, use_aliased_fields=use_aliased_fields),)
        elif fill_in_fields:
            csts = list()
            original_cst_name = cst_name
            cst_type = "Multicast"
            protocol_objects = self.convert_application_policy_to_protocols(application_entry, protocol, source=source, destinations=destinations)
            if not protocol_objects:
                raise ValueError("Unable to convert {} to CSTs".format(application_entry))
            source_name = self.get_names_from_objects(source)
            destination_names = self.get_names_from_objects(destinations)
            if application_entry.policies.get(IDSPolicy) and not isinstance(application_entry.policies[0], IDSMissPolicy):
                cst_name = "->".join([original_cst_name, source_name, destination_names[0]])
            else:
                cst_name = original_cst_name
            
            new_cst_object = self.add_protocol_entry(protocol_objects[0], cst_name=cst_name, cst_type=cst_type, queue=application_entry.priority_queue, use_aliased_fields=use_aliased_fields)
            csts.append(new_cst_object)

            if len(protocol_objects) == 2:
                cst_name = "->".join([original_cst_name, destination_names[0], source_name])
                new_cst_object = self.add_protocol_entry(protocol_objects[1], cst_name=cst_name, cst_type=cst_type, queue=application_entry.priority_queue, use_aliased_fields=use_aliased_fields)
                csts.append(new_cst_object)
            
            return csts

    def add_protocol_entries(self, protocol_entries):
        return [self.add_protocol_entry(protocol_entry) for protocol_entry in protocol_entries]

    def add_protocol_entry(self, protocol_entry, cst_name=None, priority=None, queue=None, cst_type=None, failable_nodes=None, failable_links=None, use_aliased_fields=True):
        if not cst_name:
            cst_name = protocol_entry.name if protocol_entry.name else "(no alias given)"
        
        if not priority:
            priority = 2000 if not protocol_entry.get_attribute("FlowPriority") else protocol_entry.get_attribute("FlowPriority")

        if not queue:
            queue = 2 if not protocol_entry.get_attribute("SetQueue") else protocol_entry.get_attribute("SetQueue")

        if not cst_type:
            unidirectional = protocol_entry.unidirectional
            unicast = protocol_entry.unicast

            if unicast is False and unidirectional is False:
                raise ValueError("CST cannot be both bidirectional and multicast")
            if unicast is False:
                cst_type = "Multicast"
            elif unidirectional:
                cst_type = "Unicast"
            else:
                cst_type = "UnicastBidirectional"
        
        if not failable_nodes:
            failable_nodes = 0 if protocol_entry.get_attribute("NodeRedundancy") is None else protocol_entry.get_attribute("NodeRedundancy")

        if not failable_links:
            failable_links = 1 if protocol_entry.get_attribute("LinkRedundancy") is None else protocol_entry.get_attribute("LinkRedundancy")

        match_fields = protocol_entry.values

        LOGGER.info("Adding a CST with name {} type {} flow priority {} setQueue {} and match fields {}".format(cst_name, cst_type, priority, queue, match_fields))
        return self.add_cst_by_match_field_objects(priority=priority, queue=queue, cst_name=cst_name, match_fields=match_fields, cst_type=cst_type, failable_nodes=failable_nodes, failable_links=failable_links, use_aliased_fields=use_aliased_fields)

    def add_cst_by_match_field_objects(self, cst_name, match_fields, priority=2000, queue=2, cst_type="UnicastBidirectional", failable_nodes=0, failable_links=1, use_aliased_fields=True):
        converted_match_fields = [self.convert_match_field_to_json(match_field, use_aliased_fields=use_aliased_fields) for match_field in match_fields]
        return self.add_cst(priority=priority, queue=queue, cst_name=cst_name, match_fields=converted_match_fields, cst_type=cst_type, failable_nodes=failable_nodes, failable_links=failable_links)

    def add_cst(self, match_fields, cst_name, priority=2000, queue=2, cst_type="UnicastBidirectional", failable_nodes=0, failable_links=1):
        body = {
            "trafficMatch": {
                "matchFields": match_fields
                },
            # TODO Need to test that removing this still works in v2.0.
            #"policyId": "",
            "priority": priority,
            "numFailableNodes": failable_nodes,
            "numFailableLinks": failable_links,
            "cstCommunicationType": cst_type,
            "setQueue": {
                '@odata.type': '#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.SetQueueAction', 'queueId': queue
            },
            "displayName": cst_name
        }

        new_cst_name = self.calculate_new_cst_name(body)

        if new_cst_name != cst_name:
            LOGGER.info("Adjusting CST name because of CST overlap from {} to {}".format(cst_name, new_cst_name))
            body["displayName"] = new_cst_name

        # Overlap is checked by the calculate_new_cst_name function.
        # Just need to know if the name returned was choosen because it was the same as another
        if self.get_cst_by_name(new_cst_name):
            return self.get_cst_by_name(new_cst_name)
        else:
            LOGGER.info("Adding CST %s", cst_name)
        
            return self.add_object_request(url=CONFIGURATION_CSTS, content_type=APPLICATION_JSON, body=body)

    @property
    def max_length_cst_name(self):
        if not self.version_5056 or self.version_5056 < "2.2":
            return 32
        else:
            return 128

    def calculate_new_cst_name(self, new_body, overlap_strings=None):
        # Need to make sure that the cst name with the spacer and postfix and original does not exceed 30 characters
        # So shorten the original if necessary so that the spacer and the postfix can be applied and meet 30 characters
        # See if the original name is available without shorting
        if not overlap_strings:
            setqueue = str(new_body["setQueue"]['queueId'])
            overlap_strings = str(setqueue) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".replace(str(setqueue), "")

        overlapping = False
        # Need space for the *
        original_cst_name = new_body["displayName"][:self.max_length_cst_name]
        # Ajustment plus the CST_SPACER plus one for the added character at the end of the cst_name during overlap
        cst_name = new_body["displayName"][:self.max_length_cst_name-len(CST_SPACER)-1]
        taken_post_fix = list()

        if CST_SPACER in cst_name:
            base_cst_name, port_fix_cst_name = cst_name.split(CST_SPACER)[0], cst_name.split(CST_SPACER)[1]
            taken_post_fix.append(port_fix_cst_name)
        else:
            base_cst_name, port_fix_cst_name = cst_name, ''

        current_csts = self.get_csts()
        # First see if the original name is taken if the spacer is not present
        if not port_fix_cst_name:
            for current_cst in current_csts:
                current_cst_name = current_cst["displayName"]
                if current_cst_name == original_cst_name:
                    if self.check_cst_equal(current_cst, new_body):
                        LOGGER.info("Adjusting CST name from {} to {} because they are the same CST".format(original_cst_name, current_cst_name))
                        return current_cst_name
                    else:
                        overlapping = True

        # Then see about overlapping
        if not overlapping:
            for current_cst in current_csts:
                current_cst_name = current_cst["displayName"]
                if (CST_SPACER in current_cst_name and current_cst_name.split(CST_SPACER)[0] == base_cst_name):
                    if self.check_cst_equal(current_cst, new_body):
                        return current_cst_name
                    else:
                        taken_post_fix.append(current_cst_name.split(CST_SPACER)[1])

        # If there is no conflict, return the original name
        if taken_post_fix or overlapping:
            setqueue = str(new_body["setQueue"]['queueId'])
            for index, new_post_fix in enumerate(overlap_strings):
                if new_post_fix not in taken_post_fix:
                    new_name = CST_SPACER.join([base_cst_name, new_post_fix])
                    found_overlap = False
                    for cst in self.get_csts():
                        if cst["displayName"] == new_name:
                            if self.check_cst_equal(cst, new_body):
                                break
                            else:
                                found_overlap = True

                    if not found_overlap:
                        break
            else:
                raise ValueError("Ran out of append characters for the CST name")
            return new_name
        else:
            return original_cst_name

    def check_cst_equal(self, object_left, object_right):
        #if len(object_left["trafficMatch"]["matchFields"]) != len(object_right["trafficMatch"]["matchFields"]):
        #    return False

        if self.convert_match_fields_from_rest(object_left["trafficMatch"]["matchFields"]) != self.convert_match_fields_from_rest(object_right["trafficMatch"]["matchFields"]):
            return False

        for check_property in ("priority", "numFailableNodes", "numFailableLinks", "cstCommunicationType"):
            if object_left[check_property] != object_right[check_property]:
                return False

        if object_left["setQueue"] is None:
            object_left_setQueue = 2
        else:
            object_left_setQueue = object_left["setQueue"]['queueId']

        if object_left_setQueue != object_right["setQueue"]['queueId']:
            return False

        return True

    def get_protocol_entries(self):
        return [self.convert_cst_to_protocol_entry(body) for body in self.get_csts()]

    def get_protocol_entry_by_name(self, object_name):
        if not object_name:
            raise
        cst = self.get_cst_by_name(object_name)
        return [self.convert_cst_to_protocol_entry(cst)]

    def get_protocol_entry(self, object_id):
        cst = self.get_cst(object_id=object_id)
        return self.convert_cst_to_protocol_entry(cst)

    def convert_cst_type_from_rest(self, value):
        if value == "UnicastBidirectional":
            return True, True
        elif value == "Unicast":
            return True, False
        elif value == "Multicast":
            return False, False
        elif value == "ControllerRoute":
            return True, True
        else:
            raise ValueError("Unknown CST Type {}".format(value))

    def convert_cst_name_from_rest(self, cst_name):
        if CST_SPACER in cst_name:
            cst_name = cst_name.split(CST_SPACER)[0]

        if "->" in cst_name:
            cst_name = cst_name.split("->")[0]

        return cst_name

    def get_arp_csts(self):
        arp_csts = list()
        for cst in self.get_csts():
            if isinstance(self.convert_cst_to_protocol_entry(cst), ArpProtocol):
                arp_csts.append(cst)
        return arp_csts

    def convert_cst_to_protocol_entry(self, body):
        cst_name = self.convert_cst_name_from_rest(body["displayName"])
        unicast, bidirectional = self.convert_cst_type_from_rest(body["cstCommunicationType"])
        match_fields = self.convert_match_fields_from_rest(body["trafficMatch"]["matchFields"])
        classification = 2 if body["setQueue"] is None else int(body["setQueue"]["queueId"])
        protocol_entry = Protocol.create_protocol_from_match_fields(name=cst_name, match_fields=match_fields, unicast=unicast, unidirectional=not bidirectional, priority=classification)
        protocol_entry.add_attribute("FlowPriority", body["priority"])
        protocol_entry.add_attribute("Redundancy", body["numFailableLinks"])
        protocol_entry.add_attribute("SetQueue", classification)
        protocol_entry.add_attribute("id", body["id"])
        return protocol_entry

    def is_cst_reversable(self, cst_id):
        cst_name = self.get_name_from_id(object_id=cst_id, object_type=CONFIGURATION_CSTS)
        if not cst_name:
            raise ValueError("CST with ID {} does not have a name".format(cst_id))
        protocol_entry = self.get_protocol_entry_by_name(object_name=cst_name)[0]
        if protocol_entry.bidirectional and protocol_entry.is_reversable:
            return True

    def get_protocol_entries(self):
        return ProtocolCollection(values=[self.convert_cst_to_protocol_entry(cst) for cst in self.get_csts()])

    def get_arp_protocol_entries(self):
        return self.get_protocol_entries().has_type(ArpProtocol)
