import re
import string
import json

from collections import OrderedDict


class Request:
    def __init__(self, command, url, headers=None, host=None):
        if command in ("GET", "POST", "PUT", "PATCH", "DELETE"):
            self.command = command
        else:
            raise ValueError("{} is not a valid HTTP method".format(command))

        if not url:
            raise ValueError("URL must not be None")
        self.url = url

        self.headers = headers if headers else RequestHeaders()
        self.parameters = OrderedDict()
        self.queries = ''
        self.body = ''
        self.host = host
        self.raw_data = ''

        if host:
            self.add_header("HOST", host)

    @staticmethod
    def decode(data, callback):
        header_string, body_string = data.split(b"\r\n\r\n")
        headers = RequestHeaders(header_string.decode())
        message = Request(command=headers.command, url=header.url, headers=headers)
        message.headers = header
        message.body = Body(raw_body=body_string, callback=callback)
        message.raw_data = data
        return message

    def add_header(self, name, value):
        self.headers.set_header(name, str(value))

    def change_header(self, name, value):
        self.headers.set_header(name, str(value))

    def get_header(self, name):
        return self.headers.get_header(name)

    def add_parameter(self, name, value):
        self.parameters[name] = value

    def add_query(self, name, value):
        if self.queries:
            self.queries += "&"

        self.queries += self.convert_value(name) + "=" + self.convert_value(value) 

    def convert_filter_command(self, command):
        if command in ("eq", "gt", "in"):
            return command
        if command == ">":
            return "gt"
        elif command == "==":
            return "eq"
        else:
            raise ValueError("Unknown command {}".format(command))

    def add_filter_parameter(self, name, value, command="=="):
        str_value = "'{}'".format(value) if type(value) is str else value
        self.add_filter_simple(filter_str=name + ' ' + self.convert_filter_command(command) + ' '+ str_value)

    def add_filter_simple(self, filter_str):
        self.add_parameter(name="$filter", value=filter_str)

    def convert_value(self, value):
        if isinstance(value, int):
            return str(value)
        else:
            return "".join(self.convert_character(character) for character in value)

    def convert_character(self, character):
        if character in string.ascii_letters or character in string.digits:
            return character
        elif character in ("-", ".", "_", "~", "/", "(", ")", "'", '$'): # The last 4 might be incorrect
            return character
        else:
            return "%" + hex(ord(character))[2:].upper().zfill(2)

    def encode_parameters(self):
        return self.encode_www_form(self.parameters)

    def encode_www_form(self, params):
        parameter_string = ''
        for name, value in params.items():
            if parameter_string:
                parameter_string += "&"
            parameter_string += self.convert_value(name) + "=" + self.convert_value(value)

        return parameter_string

    def encode_url(self):
        parameters = '' if self.command != "GET" or len(self.parameters) == 0 else "?" + self.encode_parameters()
        queries = '' if len(self.queries) == 0 else "?" + self.queries
        return self.convert_value(self.url) + queries + parameters

    def encode_first_line(self):
        return self.command + ' ' + self.encode_url() + ' ' + 'HTTP/1.1\r\n'

    def encode_headers(self):
        return self.headers.encode()

    def encode_body(self):
        body = self.body if not self.parameters or self.command == "GET" else self.parameters
        if body is not None and type(body) is not bytes:
            if self.headers.get_header("Content-Type") and "application/json" in self.headers.get_header("Content-Type"):
                body_str = json.dumps(body).encode()
            elif self.headers.get_header("Content-Type") and "application/x-www-form-urlencoded" in self.headers.get_header("Content-Type"):
                body_str = self.encode_www_form(body)
            else:
                body_str = body
        else:
            body_str = ''

        return body_str

    def to_bytes(self):
        body_str = self.encode_body()

        # Add Length
        if self.command != "GET" and not self.get_header("Content-Length"): # removed and len(body) 
            self.add_header("Content-Length", str(len(body_str)))

        message = self.encode_first_line() + self.encode_headers() + '\r\n'
        if isinstance(body_str, bytes):
            return message.encode() + body_str
        else:
            message += body_str
            return message.encode()

    def add_body(self, body):
        self.body = body

    def __repr__(self):
        return self.to_bytes().decode()


class Headers:
    def get_header(self, name):
        if self.headers.get(name):
            return self.headers[name]
        else:
            return None

    def set_header(self, name, value):
        self.headers[name] = value

    def encode(self):
        return_string = ''
        for name, value in self.headers.items():
            return_string += name + ': ' + str(value) + '\r\n'
        return return_string


class ResponseHeaders(Headers):
    def __init__(self, headers=None, raw_data=b''):
        self.headers = headers if headers else dict()
        self.raw_data = raw_data

    @staticmethod
    def from_raw_data(raw_data):
        lines = raw_data.split("\r\n")
        headers_list = [line.split(": ") for line in lines]

        headers = dict()
        for header in headers_list:
            headers[header[0]] = header[1]

        new_headers = ResponseHeaders(headers, raw_data=raw_data)
        return new_headers


class RequestHeaders(ResponseHeaders):
    pass


class Body:
    def __init__(self, body, raw_data=b''):
        self.body = body
        self.raw_data = raw_data
        
    @staticmethod
    def from_raw_data(raw_body, headers, callback=None):
        transfer_encoding = headers.get_header("Transfer-Encoding")
        if transfer_encoding:
            body = Body.dechunk(raw_body, callback)
        elif headers.get_header("Content-Length"):
            #body = raw_body
            body = Body.delength(raw_body, int(headers.get_header("Content-Length")), callback)
        else:
            body = ''

        if headers.get_header("Content-Type"):
            content_type = headers.get_header("Content-Type")
            if content_type and "json" in content_type:
                converted_body = json.loads(body.decode())
            elif content_type and "octet-stream" in content_type:
                converted_body = body
            else:
                raise ValueError("Not sure how to deal with file type {}".format(content_type))
        else:
            converted_body = body

        new_body = Body(converted_body, raw_data=body)
        return new_body

    @staticmethod
    def delength(body, content_length, callback):
        pieces = []
        length = len(body)
        while length < content_length:
            rest = callback(8192)
            length += len(rest)
            pieces.append(rest)
        return body + b"".join(pieces)

    # If the body is chucked
    @staticmethod
    def dechunk(body, callback):
        pieces = list()
        current_index = 0
        rest = body
        while True: #len(rest) > 0:
            while True:
                try:
                    length, rest = re.match(b"([0-9A-Fa-f]+)\r\n(.*)", rest, flags=re.DOTALL).groups()
                    break
                except AttributeError:
                    rest += callback(8096)

            length = int(length, 16)
            
            if length == 0:
                break
            
            while len(rest) < length+2:
                rest += callback(length+2-len(rest))

            response, rest = rest[0:length], rest[length+2:]
            pieces.append(response)
        
            if len(rest) == 0:
                rest = callback(8096)

        return b"".join(pieces)

    def __str__(self):
        if type(self.body) is bytes:
            return self.body.decode("latin_1")
        else:
            return str(self.body)

class Response:
    def __init__(self, headers, body, code, major_version=None, text=None, minor_version=None, raw_data=b''):
        self.raw_data = raw_data
        self.headers = headers
        self.body = body
        self.major_version = major_version
        self.minor_version = minor_version
        self.response_code = code
        if isinstance(body, Body):
            self.data = body.body
        else:
            self.data = body

        if self.data and type(self.data) is dict and self.data.get("error"):
            self.error = self.data["error"]
            if isinstance(self.data["error"], dict):
                self.error_description = self.data["error"].get("message")
            else:
                self.error_description = self.error
        else:
            self.error = ""
            self.error_description = ""

    def get_header(self, name):
        return self.headers.get_header(name)

    @staticmethod
    def from_raw_data(raw_data, callback):
        notbody, body = raw_data.split(b'\r\n\r\n', 1)

        first_line, header = notbody.split(b"\r\n", 1)
        result = re.match(r"HTTP/(\d).(\d) (\d+) (\w+)", first_line.decode())
        major_version, minor_version, code, text = result.groups()

        major_version = int(major_version)
        minor_version = int(minor_version)
        code = int(code)

        headers = ResponseHeaders.from_raw_data(header.decode())
        
        if len(body):
            body = Body.from_raw_data(body, headers=headers, callback=callback)
            raw_data = notbody + body.raw_data
        else:
            body = Body("")

        return Response(headers=headers, body=body, code=code, major_version=major_version, minor_version=minor_version, text=text, raw_data=raw_data)

    @property
    def error_message(self):
        if self.error_description:
            return self.error_description
        elif self.error:
            return self.error
        else:
            return ''

    @property
    def code(self):
        return self.response_code

    @property
    def success(self):
        return 200 <= self.response_code < 300

    @property
    def value(self):
        if type(self.data) is dict:
            return self.data.get("value", None)
        else:
            return None

    def __repr__(self):
        return self.raw_data.decode() if type(self.raw_data) is bytes else self.raw_data

    @property
    def contents(self):
        return self.value if self.value is not None else self.data
