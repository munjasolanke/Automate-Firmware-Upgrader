from ...openflow.core.actions import OutputAction, GroupAction, PopVlanAction, PushVlanAction, SetVlanVidAction, SetVlanPcpAction, SetQueueAction, Actions

from .constants import CONFIGURATION_GROUPS, CONFIGURATION_PORTS, TYPE_ACTION, TREE_MATCHFIELDS

class ActionsMixin:
    def convert_actions_from_rest(self, actions):
        converted_actions = Actions()
        converted_actions.add_attribute("Errors", list())
        for action in actions:
            action_type = action['@odata.type'].split(".")[-1]
            try:
                converted_actions.add(self.convert_action_from_rest(action))
            except ValueError as e:
                converted_name = action_type.replace("ByAlias", "")
                converted_actions.get_attribute("Errors").append(converted_name)

        return converted_actions

    def convert_action_from_rest(self, action):
        action_type = action['@odata.type'].split(".")[-1]
        alias_value = False

        if action_type == "OutputAction":
            action_object = OutputAction(value=action["outPort"])
        elif action_type == "OutputActionByAlias":
            value = self.get_value_from_id(object_id=action["configPortId"], object_type=CONFIGURATION_PORTS, attribute="OpenFlowPortAttr")
            action_object = OutputAction(value=value)
            alias_value = action["configPortId"]
        elif action_type == "GroupAction":
            action_object = GroupAction(value=action["groupId"])
        elif action_type == "GroupActionByAlias":
            value = self.get_value_from_id(object_id=action["configGroupId"], object_type=CONFIGURATION_GROUPS, attribute="groupId")
            action_object = GroupAction(value=value)
            alias_value = action["configGroupId"]
        elif action_type == "PushVlanAction":
            action_object = PushVlanAction(value=action["etherType"])
        elif action_type == "PopVlanAction":
            action_object = PopVlanAction()
        elif action_type == "SetQueueAction":
            action_object = SetQueueAction(value=action["queueId"])
        elif action_type == "SetFieldAction":
            action_object = self.convert_set_field_action_from_rest(action["field"])
        else:
            raise ValueError("Unknown action type {}".format(action_type))

        action_object.set_attribute("$aliased", alias_value)

        return action_object

    def convert_set_field_action_from_rest(self, set_field):
        action_type = set_field['@odata.type'].split(".")[-1]
        action_value = set_field["value"]

        if action_type == "VlanVid":
            return SetVlanVidAction(value=action_value)
        elif action_type == "VlanPcp":
            return SetVlanPcpAction(value=action_value)
        else:
            raise ValueError("Unknown set field action type {}".format(action_type))

    def convert_actions_to_rest(self, actions):
        return [self.convert_action_to_rest(action) for action in actions]

    def convert_action_to_rest(self, action):
        set_field = False
        if isinstance(action, OutputAction):
            action_type = "OutputAction"
            action_name = "outPort"
            action_value = str(action)
        elif isinstance(action, GroupAction):
            action_type = "GroupAction"
            action_name = "groupId"
            action_value = action.value
        elif isinstance(action, SetVlanVidAction):
            set_field = True
            action_name = "VlanVid"
            action_value = str(action)
        elif isinstance(action, SetVlanPcpAction):
            set_field = True
            action_name = "VlanPcp"
            action_value = str(action)
        elif isinstance(action, PushVlanAction):
            action_name = "etherType"
            action_value = str(action)
        elif isinstance(action, PopVlanAction):
            action_name = False
        elif isinstance(action , SetQueueAction):
            action_name = "queueId"
            action_value = action.value
        else:
            raise TypeError("Unknown action type {} to convert".format(type(action)))

        if set_field:
            body = {
                "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.SetFieldAction",
                "field": {"@odata.type": ".".join([TREE_MATCHFIELDS, action_name]),
                    "value": action_value
                    }
            }
        elif action_name:
            body = {
                "@odata.type": ".".join([TYPE_ACTION, action.__class__.__name__]),
                action_name: action_value
            }
        else:
            body = {
                "@odata.type": ".".join([TYPE_ACTION, action.__class__.__name__])
            }

        return body
