from .constants import PROPERTY_ID, PROPERTY_NAME, PROPERTY_LINKED
from .constants import PROPERTY_STATE, PROPERTY_LINKS, PROPERTY_END_POINTS, PROPERTY_PORTS
from .constants import VALUE_UNADOPTED, VALUE_ESTABLISHED
from .constants import CONFIGURATION_NODES, OPERATIONAL_NODES
from .constants import CONFIGURATION_PORTS, OPERATIONAL_PORTS
from .constants import CONFIGURATION_LINKS, OPERATIONAL_LINKS, PROPERTY_TYPE
from ...base.collection import Collection

class RestObject:
    def __init__(self, interface):
        self._interface = interface

    @property
    def interface(self):
        return self._interface


class SingleTreeRestObject(RestObject):
    OBJECT_TYPE = None

    def __init__(self, body, interface, auto_synchronize=True):
        super().__init__(interface)
        if not body:
            raise ValueError("Need to add a body")

        self._unsynchronized = False
        self._body = body
        self._auto_synchronized = True

    def __repr__(self):
        return str(self.body)

    @property
    def body(self):
        return self._body

    @property
    def type(self):
        return self.body[PROPERTY_TYPE]
    
    @property
    def id(self):
        return self.body[PROPERTY_ID]

    @property
    def unsynchronized(self):
        return self._unsynchronized

    @property
    def name(self):
        return self.body.get(PROPERTY_NAME)
    
    @property
    def state(self):
        return self.body.get(PROPERTY_STATE)

    @property
    def unsynchronized(self):
        return self._unsynchronized

    def get_tags_by_type(self, name):
        return_value = list()
        for tag in self.body.get("tags", list()):
            if name in tag["@odata.type"]:
                return_value.append(tag)

        return return_value

    def get_attributes_by_type(self, name):
        return_value = list()
        for tag in self.body.get("attributes", list()):
            if name in tag[PROPERTY_TYPE]:
                return_value.append(tag)

        return return_value

    def add_tag_by_type(self, type, object_id, **kwargs):
        body = {PROPERTY_TYPE: '#Sel.Sel5056.Tags.{}'.format(type), "id": object_id}

        for name, value in kwargs.items():
            body[name] = value

    def synchronize(self):
        if self._unsynchronized:
            self.interface(object_type=self.OBJECT_TYPE, object_id=self.body["id"], body=self.body)

    @property
    def tags(self):
        if self.body.get("tags"):
            return self.body["tags"]

    @property
    def attributes(self):
        if self.body.get("attributes"):
            return self.body["attributes"]     


class SingleDualTreeRestObject(SingleTreeRestObject):
    @property
    def linked_key(self):
        return self.body[PROPERTY_LINKED]

    @property
    def state(self):
        return self.body[PROPERTY_STATE]
    

class SingleDualTreeTopologyRestObject(SingleDualTreeRestObject):
    @property
    def other_object_type(self):
        if "config" in self.OBJECT_TYPE:
            return self.OBJECT_TYPE.replace("config", "operational")
        elif "operational" in self.OBJECT_TYPE:
            return self.OBJECT_TYPE.replace("operational", "config")
        else:
            raise ValueError("Don't know the other object for {}".format(self.OBJECT_TYPE))

    @property
    def linked_object(self):
        if not self.linked_key:
            return None

        other_object = self.interface.get_object(self.other_object_type, object_id=self.linked_key)

        if other_object:
            return self._opposite_class_type()(other_object, interface=self.interface)
        else:
            return None


class SingleDualTreeOperationalTopologyRestObject(SingleDualTreeTopologyRestObject):
    def is_adopted(self):
        return self.state != VALUE_UNADOPTED

    def is_unadopted(self):
        return not self.is_adopted()

    def is_connected(self):
        return not self.is_disconnected()

    def is_disconnected(self):
        return self.state == VALUE_DISCONNECTED

    @property
    def trust_state(self):
        return self.state[PROPERTY_TRUST_STATE]


class SingleDualTreeConfigurationTopologyRestObject(SingleDualTreeTopologyRestObject):
    @property
    def configurations(self):
        return self.body[PROPERTY_CONFIGURATIONS]

    def get_configuration_by_type(self, name):
        return_value = list()
        for tag in self.body.get("configurations", list()):
            if name in tag[PROPERTY_TYPE]:
                return_value.append(tag)

        return return_value

    def is_adopted(self):
        return self.state == VALUE_ESTABLISHED

    def is_unadopted(self):
        return not self.is_adopted()


class ConfigTreeRestObject(SingleDualTreeRestObject):
    def get_operational_object(self):
        if self.linked_key:
            return OperationalTreeRestObject(self.interface.get_object(url=self.other_object_type, object_id=self.linked_key), interface=self.interface)


class OperationalTreeRestObject(SingleTreeRestObject):
    def get_configuration_object(self):
        if self.linked_key:
            return ConfigTreeRestObject(self.interface.get_object(url=self.other_object_type, object_id=self.linked_key), interface=self.interface)


class DualTreeRestObject(RestObject):
    CONFIG_TYPE = None
    OPERATIONAL_TYPE = None

    def __init__(self, config_body, operational_body, interface):
        super().__init__(interface)
        self._original_config_body = None
        self._original_operational_body = None
        # If of type dict, wrap
        self._config_body = config_body
        self._operational_body = operational_body

    @property
    def unsynchronized(self):
        return self._original_operational_body != self._operational_body or self._original_config_body != self._config_body

    @property
    def config_body(self):
        return self._config_body

    @property
    def operational_body(self):
        return self._operational_body

    @property
    def config_id(self):
        return self._config_body[PROPERTY_ID]

    @property
    def operational_id(self):
        return self._operational_body[PROPERTY_ID]

    def get_tags_by_type(self, name):
        raise

    def get_attributes_by_type(self, name):
        raise

    def add_tag_by_type(self, type, object_id, **kwargs):
        raise

    def synchronize(self):
        if self.config_body.unsynchronized:
            self.config_body.synchronize()

        if self.operational_body.unsynchronized:
            self.operational_body.synchronize()


class RestObjectCollection(Collection):
    def __init__(self, values, interface=None, object_type=None):
        if not object_type:
            object_type = self.OBJECT_TYPE
        converted_values = list()
        for value in values:
            if isinstance(value, dict):
                converted_values.append(object_type(value, interface=interface))
            else:
                converted_values.append(value)
        super().__init__(values=converted_values)
        self._interface = interface

    @property
    def class_type(self):
        """Returns the class of the object.
        """
        return self.__class__

    @property
    def values(self):
        return self._values

    def __repr__(self):
        return str(self.values)

    def has_name(self, value):
        results = [v for v in self.values if v.name == value]
        return self.class_type(values=results)

    @property
    def interface(self):
        return self._interface
    

class DualTreeRestObjectCollection(RestObjectCollection):
    pass


# Node Objects
class NodeObject(DualTreeRestObject):
    pass


class GenericNodeRestObject(SingleDualTreeTopologyRestObject):
    @property
    def port_ids(self):
        return self.body[PROPERTY_PORTS]


class OperationalNodeRestObject(GenericNodeRestObject, OperationalTreeRestObject, SingleDualTreeOperationalTopologyRestObject):
    OBJECT_TYPE = OPERATIONAL_NODES
    def _opposite_class_type(self):
        return ConfigurationNodeRestObject

    def unadopt(self):
        if self.id and self.is_adopted():
            return self.interface.unadopt_node(self.id)

    def adopt(self, configuration_name):
        if self.id and self.is_unadopted():
            return self.interface.adopt_node_by_name(self.id, configuration_name)

    def adopt_default(self):
        if self.id and self.is_unadopted():
            return self.interface.adopt_operational_node_with_default(self.id) 

    def reboot(self):
        if self.id:
            return self.interface.reboot_node(self.id)

    def disconnect(self):
        if self.id:
            return self.interface.disconnect_node(self.id)

    def is_openflow_switch(self):
        return bool(self.get_attributes_by_type("OpenFlowAttr"))

    def is_sel_switch(self):
        return bool(self.get_attributes_by_type("SelSapphireAttr"))

    def is_controller(self):
        return bool(self.get_attributes_by_type("ControllerAttr"))

    def is_traditional_switch(self):
        return bool(self.get_attributes_by_type("NetworkingAbstractionAttr"))
    
    def is_failover_mode(self):
        for port in self.ports:
            if port.is_failover_mode():
                return True
        else:
            return False

    def is_host(self):
        return not (self.is_openflow_switch() or self.is_traditional_switch())

    def enable_failover_mode(self):
        if len(self.port_ids) != 1:
            raise

        self.ports[0].enable_failover_mode()

    def disable_failover_mode(self):
        if len(self.port_ids) != 1:
            raise

        self.ports[0].disable_failover_mode()

    def detect_other_failover_port(self):
        if len(self.port_ids) != 1:
            raise

        return self.ports[0].detect_other_failover_port()

    @property
    def links(self):
        all_links = list()
        for port in self.ports:
            links = port.links
            if links:
                all_links.extend(links)
        return OperationalLinkObjectCollection(values=all_links, interface=self.interface)

    @property
    def ports(self):
        return OperationalPortObjectCollection(values=[self.interface.get_operational_port_object(object_id) for object_id in self.port_ids])

    @property
    def opposite_ports(self):
        results = list()
        for port in self.ports:
            opposite_ports = port.get_ports_on_other_side_of_links()
            if opposite_ports:
                results.extend(opposite_ports)

        return OperationalPortObjectCollection(values=results)

    @property
    def datapath_id(self):
        value = self.get_attributes_by_type("SelSapphireAttr")
        if value:
            return value[0]["prettyDataPathId"].lower()
    
    @property
    def discovery_port(self):
        value = self.get_attributes_by_type("SelSapphireAttr")
        if value:
            return value[0]["discoveryPort"]
    
    @property
    def ip_addresses(self):
        return [x["ipAddress"] for x in self.get_attributes_by_type("IpAttr")]

    @property
    def ip_address(self):
        # TODO What is the configuration offline host rule for this?
        ip_addresses = [x["ipAddress"] for x in self.get_attributes_by_type("IpAttr")]
        if ip_addresses:
            return ip_addresses[0]
        return None

    @property
    def mac_addresses(self):
        return [x["macAddress"] for x in self.get_attributes_by_type("EthernetAttr")]

    @property
    def mac_address(self):
        # TODO What is the configuration offline host rule for this?
        return [x["macAddress"] for x in self.get_attributes_by_type("EthernetAttr")][0]


class ConfigurationNodeRestObject(GenericNodeRestObject, ConfigTreeRestObject, SingleDualTreeConfigurationTopologyRestObject):
    OBJECT_TYPE = CONFIGURATION_NODES

    def is_traditional_switch(self):
        return bool(self.get_configuration_by_type("AbstractionConfig"))

    def is_sel_switch(self):
        if self.body.get(PROPERTY_TYPE):
            return "Sel274" in self.body["@odata.type"] and "SConfigNode" in self.body["@odata.type"]
        else:
            return False

    def is_openflow_switch(self):
        return bool(self.get_configuration_by_type("OpenFlowConfig"))

    def is_host(self):
        return not (self.is_openflow_switch() or self.is_traditional_switch())

    def get_operational_object(self):
        if self.linked_key:
            return OperationalNodeRestObject(self.interface.get_object(url=self.other_object_type, object_id=self.linked_key), interface=self.interface)

    def _opposite_class_type(self):
        return OperationalNodeRestObject


class NodeObjectCollection(RestObjectCollection):
    def get_hosts(self):
        return self.class_type(values=[v for v in self.values if v.is_host() is True])

    def has_ip_address(self, value):
        return self.class_type(values=[v for v in self.values if v.ip_address == value])

    def get_openflow_switches(self):
        return self.class_type(values=[v for v in self.values if (v.is_sel_switch() is True or v.is_openflow_switch() is True)])


class OperationalNodeObjectCollection(NodeObjectCollection):
    OBJECT_TYPE = OperationalNodeRestObject

    def get_unadopted_switches(self):
        return self.class_type(values=[v for v in self.values if (v.is_sel_switch() is True or v.is_openflow_switch() is True) and v.is_adopted() is False])

    def get_adopted_switches(self):
        return self.class_type(values=[v for v in self.values if (v.is_sel_switch() is True or v.is_openflow_switch() is True) and v.is_adopted() is True])

    def get_sel_openflow_switches(self):
        return self.class_type(values=[v for v in self.values if v.is_sel_switch() is True])

    def get_controllers(self):
        return self.class_type(values=[v for v in self.values if v.is_controller() is True])

    def get_controller(self):
        for v in self.values:
            if v.is_controller:
                return v


class ConfigurationNodeObjectCollection(NodeObjectCollection):
    OBJECT_TYPE = ConfigurationNodeRestObject


# Port Objects
class PortObject(DualTreeRestObject):
    pass


class GenericPortRestObject(SingleDualTreeTopologyRestObject):
    @property
    def link_ids(self):
        return self.body[PROPERTY_LINKS]

    def get_port_ids_on_other_side_of_links(self):
        other_ids = list()
        for object_id in self.link_ids:
            url = self.OBJECT_TYPE.replace("ports", "links")
            link_object = self.interface.get_object(url=url, object_id=object_id)
            other_ids.extend([port_id for port_id in link_object[PROPERTY_END_POINTS] if port_id != self.id])

        return other_ids

    def get_ports_on_other_side_of_links(self):
        object_ids = self.get_port_ids_on_other_side_of_links()
        values = [self.interface.get_object(url=self.OBJECT_TYPE, object_id=object_id) for object_id in object_ids]
        return OperationalPortObjectCollection(values=values, interface=self.interface)


class OperationalPortRestObject(GenericPortRestObject, SingleDualTreeOperationalTopologyRestObject):
    OBJECT_TYPE = OPERATIONAL_PORTS
    def _opposite_class_type(self):
        return ConfigurationPortRestObject

    def unadopt(self):
        if self.id and self.is_adopted():
            return self.interface.unadopt_port(self.id)

    def adopt(self, configuration_name):
        if self.id and self.is_unadopted():
            return self.interface.adopt_port_by_name(self.id, configuration_name)

    def adopt_default(self):
        if self.id and self.is_unadopted():
            return self.interface.adopt_operational_port_with_default(self.id)

    def is_failover_mode(self):
        return bool(self.get_attributes_by_type("SelRelayFailoverModeAttr"))

    def enable_failover_mode(self):
        self.interface.enable_relay_failover(object_id=self.id)

    def disable_failover_mode(self):
        self.interface.disable_relay_failover(object_id=self.id)

    def detect_other_failover_port(self):
        # Need to confirm there is at least one adopted link on this port
        for link in self.links:
            if link.is_adopted():
                self.interface.detect_other_port(object_id=self.id)
                return True
        return False

    @property
    def owner(self):
        if self.body.get("parentNode"):
            url = self.OBJECT_TYPE.replace("ports", "nodes")
            return OperationalNodeRestObject(self.interface.get_object(url=url, object_id=self.body.get("parentNode")), interface=self.interface)

    @property
    def number(self):
        port_name = None
        attr = self.get_attributes_by_type("OpenFlowPortAttr")
        if attr:
            port_name = attr[0]["portId"]
        return port_name

    @property
    def links(self):
        all_links = list()
        for link_id in self.link_ids:
            link_object = self.interface.get_operational_link(link_id)
            if link_object:
                all_links.append(OperationalLinkRestObject(link_object, interface=self.interface))

        return OperationalLinkObjectCollection(values=all_links, interface=self.interface)


class ConfigurationPortRestObject(SingleDualTreeConfigurationTopologyRestObject):
    OBJECT_TYPE = CONFIGURATION_PORTS
    def _opposite_class_type(self):
        return OperationalPortRestObject

    @property
    def owner(self):
        if self.body.get("parentNode"):
            url = self.OBJECT_TYPE.replace("ports", "nodes")
            return ConfigurationNodeRestObject(self.interface.get_object(url=url, object_id=self.body.get("parentNode")), interface=self.interface)


class OperationalPortObjectCollection(RestObjectCollection):
    OBJECT_TYPE = OperationalPortRestObject


class ConfigurationPortObjectCollection(RestObjectCollection):
    OBJECT_TYPE = ConfigurationPortRestObject


# Link Objects
class LinkObject(DualTreeRestObject):
    pass


class GenericLinkRestObject(SingleDualTreeTopologyRestObject):
    @property
    def port_ids(self):
        return self.body[PROPERTY_END_POINTS]

    def ports_on_other_side_of_link(self, ignore_port_id):
        other_ports = list()
        for object_id in self.port_ids:
            if object_id != ignore_port_id:
                url = self.OBJECT_TYPE.replace("links", "ports")
                port_object = self.interface.get_object(url=url, object_id=object_id)
                other_ports.append(OperationalPortRestObject(port_object, interface=self.interface))

        return OperationalPortObjectCollection(values=other_ports, interface=self.interface)


class OperationalLinkRestObject(GenericLinkRestObject, SingleDualTreeOperationalTopologyRestObject):
    OBJECT_TYPE = OPERATIONAL_LINKS
    def unadopt(self):
        if self.id and self.is_adopted():
            return self.interface.unadopt_link(self.id)

    def adopt(self, configuration_name):
        if self.id and self.is_unadopted():
            return self.interface.adopt_link_by_name(self.id, configuration_name)

    def adopt_default(self):
        if self.id and self.is_unadopted():
            return self.interface.adopt_operational_link_with_default(self.id)


class ConfigurationLinkRestObject(SingleDualTreeConfigurationTopologyRestObject):
    OBJECT_TYPE = CONFIGURATION_LINKS
    def _opposite_class_type(self):
        return OperationalLinkObjectCollection


class ConfigurationLinkObjectCollection(RestObjectCollection):
    OBJECT_TYPE = ConfigurationLinkRestObject
    def _opposite_class_type(self):
        return OperationalLinkRestObject


class OperationalLinkObjectCollection(RestObjectCollection):
    OBJECT_TYPE = OperationalLinkRestObject
    def _opposite_class_type(self):
        return ConfigurationLinkRestObject


class LogicalConnectionObject(DualTreeRestObject):
    def _convert_node_ids_to_node_list(self, object_ids):
        values = list()
        for object_id in object_ids:
            object_body = self.interface.get_configuration_node_object(object_id=object_id)
            values.append(object_body)
        return ConfigurationNodeObjectCollection(values=values, interface=self.interface)

    def resubmit(self):
        response = self.interface.resubmit_lc(object_id=self.id)
        if response:
            self.body = response

        return self

    @property
    def id(self):
        return self.config_body["id"]

    @property
    def source_ids(self):
        return self.config_body["sourceEndPoints"]
    
    @property
    def sources(self):
        return self._convert_node_ids_to_node_list(self.source_ids)

    @property
    def destination_ids(self):
        return self.config_body["destinationEndPoints"]

    @property
    def destinations(self):
        return self._convert_node_ids_to_node_list(self.destination_ids)

    @property
    def cst(self):
        return self.interface.get_cst_object(self.cst_id)

    @property
    def cst_id(self):
        return self.config_body["communicationServiceTypeId"]

    @property
    def state(self):
        return self.config_body["errorState"]

    @property
    def errors(self):
        return self.config_body["errors"]
    
    def __repr__(self):
        return str(self.config_body)


class LogicalConnectionObjectCollection(RestObjectCollection):
    OBJECT_TYPE = LogicalConnectionObject

    def resubmit_all(self):
        for value in self.values:
            value.resubmit
        return self

    def get_objects_by_status(self, value):
        results = list()
        for object_body in self.values:
            if object_body.state == value:
                results.append(object_body)
        return LogicalConnectionObjectCollection(values=results, interface=self.interface)

    def has_destination_name(self, name):
        results = list()
        for value in self.values:
            for destination in value.destinations:
                if destination.name == name:
                    results.append(value)
                    break
        return LogicalConnectionObjectCollection(values=results, interface=self.interface)

    def has_source_name(self, name):
        results = list()
        for value in self.values:
            for source in value.sources:
                if source.name == name:
                    results.append(value)
                    break
        return LogicalConnectionObjectCollection(values=results, interface=self.interface)

    def has_cst_name(self, name):
        results = list()
        for value in self.values:
            if cst.name == name:
                results.append(value)
        return LogicalConnectionObjectCollection(values=results, interface=self.interface)

    def has_node_name(self, name):
        source_results = self.has_source_name(name)
        destination_results = self.has_destination_name(name)
        return LogicalConnectionObjectCollection(values=source_results+destination_results, interface=self.interface)


class CommunicationServiceTypeRestObject(ConfigTreeRestObject):
    def get_protocol_entry(self):
        return self.interface.convert_cst_to_protocol_entry(self.body)

    def get_match_field_by_type(self, type):
        for match_field in self.body["trafficMatch"]["matchFields"]:
            if type in match_field["@odata.type"]:
                return match_field

    @property
    def cst_type(self):
        return self.body["cstCommunicationType"]
    
    @property
    def cast(self):
        return "Multicast" if "Multicast" in self.cst_type else "Unicast"
    
    @property
    def bidirectional(self):
        return True if "Bi" in self.cst_type else False


class CommunicationServiceTypeCollection(RestObjectCollection):
    OBJECT_TYPE = CommunicationServiceTypeRestObject

    def has_match_field(self, name):
        results = list()
        for value in self.values:
            if value.get_match_field_by_type(name):
                results.append(value)

        return CommunicationServiceTypeCollection(values=results, interface=self.interface)


class FlowObject(DualTreeRestObject):
    def get_match_field_by_type(self, type):
        if self.config_body:
            for match_field in self.config_body["match"]["matchFields"]:
                if type in match_field["@odata.type"]:
                    return match_field

    def get_instruction_by_name(self, name):
        if self.config_body:
            for instruction in self.config_body["instructions"]["matchFields"]:
                if name in instruction["@odata.type"]:
                    return instruction

    def get_write_action_by_name(self, name):
        if self.config_body:
            for action in self.get_instruction_by_name("WriteActions"):
                if name in action["@odata.type"]:
                    return action

    def add_match_field_by_type(self, type, value, mask):
        body = {
            "@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MatchFields.{}".format(type),
            "value":value}

        if mask:
            body["mask"] = value

        self.config_body["match"]["matchFields"].append(body)

        self._unsynchronized["config"] = True

    def add_write_action_by_type(self, type, value=None, *args, **kwargs):
        write_actions = self.get_instruction_by_name("WriteActions")

        if type == "PushVlanAction":
            body = {"@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.{}".format(type)}
        elif type == "SetVlanVid":
            body = {
                {"@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.{}".format("SetFieldAction"),
                "field": {"@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MatchFields.{}".format("VlanVid"),
                        "value": value}}
            }
        else:
            raise ValueError("What is action type {}?".format(type))

        write_actions.append(body)
        self._unsynchronized["config"] = True
