from .metaclasses import ObjectMixin
from .constants import CONFIGURATION_NODES, CONFIGURATION_METERS, APPLICATION_JSON

from ...openflow.core.meter_entry import MeterEntry, MEASUREMENT_PPS, MEASUREMENT_KBPS
from ...base.collection import MeterCollection
from ...tools.diff.diff import create_meter_entries_diff

class MeterEntryMixin(metaclass=ObjectMixin, name="meter", url=CONFIGURATION_METERS):
    def diff_meter_entries(self, new_entries, old_entries=None, ignore_system=True, delete_bad=False):
        return self.diff_openflow_entries(new_meters=new_entries, old_meters=old_entries, ignore_system=ignore_system, delete_bad=delete_bad)

    def add_meter_entries(self, meter_entries):
        return self.add_objects(url=CONFIGURATION_METERS, objects=meter_entries)
        #return [self.add_meter_entry(meter_entry=meter_entry) for meter_entry in meter_entries]

    def add_meter_entry(self, meter_entry):
        return self.add_object(url=CONFIGURATION_METERS, object=entry)

    def convert_meter_entry_to_rest(self, meter_entry):
        node_id = self.get_id_from_name(object_name=meter_entry.node_name, object_type=CONFIGURATION_NODES)
        if not node_id:
            raise ValueError("Unable to find node {} for meter entry {}".format(meter_entry.node_name, meter_entry))
        
        return self.create_meter_entry_body(meter_name=meter_entry.name, node_id=node_id, entry_id=meter_entry.entry_id, measurement_type=str(meter_entry.measurement_type), rate=meter_entry.rate, burst_size=meter_entry.burst_size, enabled=True)

    def create_meter_entry_body(self, meter_name, node_id, entry_id, rate, burst_size=None, measurement_type="pps", enabled=True):
        flags = [{"@odata.type":"#Sel.Sel5056.TopologyManager.OpenFlow.Meter.RateTypeFlagObjects.PacketsPerSecond", "@internal.typename":"PacketsPerSecond"}] if measurement_type == "pps" else [{"@odata.type":"#Sel.Sel5056.TopologyManager.OpenFlow.Meter.RateTypeFlagObjects.KilobitesPerSecond", "@internal.typename":"KilobitesPerSecond"}]

        if burst_size:
            flags.append({"@odata.type":"#Sel.Sel5056.TopologyManager.OpenFlow.Meter.RateTypeFlagObjects.Burst","@internal.typename":"Burst"})

        body = {
            "flags": flags,
            "meterBands":[{"@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MeterBandDrop",
                "@internal.typename":"MeterBandDrop","rate":rate,"burstSize":burst_size if burst_size else 0}],
            "enabled":enabled,
            "node":node_id,
            "displayName": meter_name,
            "meterId":entry_id
        }

        return body

    def get_meter_entries(self):
        response = self.get_meters()
        return self.convert_meter_entries_from_rest(response)

    def convert_meter_entries_from_rest(self, entries):
        return MeterCollection(values=[self.convert_meter_entry_from_rest(entry) for entry in entries])

    def convert_meter_entry_from_rest(self, entry):
        entry_id = entry["meterId"]
        name = entry["displayName"]
        node_name = self.get_name_from_id(object_id=entry["node"], object_type=CONFIGURATION_NODES)
        is_enabled = entry["enabled"]

        if entry["meterBands"]:
            rate = entry["meterBands"][0]["rate"]
            burst_size = entry["meterBands"][0]["burstSize"]
        else:
            rate = None
            burst_size = None
        
        measurement_type = MEASUREMENT_PPS
        for flag in entry["flags"]:
            if "KilobitesPerSecond" in flag["@odata.type"]:
                measurement_type = MEASUREMENT_KBPS
            if "PacketsPerSecond" in flag["@odata.type"]:
                measurement_type = MEASUREMENT_PPS
        if not measurement_type:
            raise ValueError("Meter {} on switch {} is has both types of measurement types which is not allows".format(name, node_name))

        object_id = entry["id"]
        attributes = {"id":object_id, "Enabled": is_enabled}
        attributes["system"] = True if self.get_tag_value_from_type("SystemTag", entry["tags"]) is not None else False
        
        return MeterEntry(name=name, node=node_name, entry_id=entry_id, measurement_type=measurement_type, rate=rate, burst_size=burst_size, attributes=attributes)
