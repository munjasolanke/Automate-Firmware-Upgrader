from .base import OperationalLinkRestObject, OperationalLinkObjectCollection
from .metaclasses import ObjectMixin
from .constants import OPERATIONAL_LINKS, FUNCTION_ADOPT_DEFAULT, COMMAND_POST, CONFIGURATION_LINKS, FUNCTION_ADOPT, COMMAND_GET, FUNCTION_UNADOPT

class ConfigurationLinkMixin(metaclass=ObjectMixin, name="configuration_link", url=CONFIGURATION_LINKS):
    pass


class OperationalLinkMixin(metaclass=ObjectMixin, name="operational_link", url=OPERATIONAL_LINKS):
    def adopt_operational_link_with_default(self, object_id):
        return self.adopt_operational_link(object_id=object_id)

    def adopt_operational_link(self, object_id, configuration_object_id=None, **kwargs):
        if configuration_object_id:
            body = {
                "configKey": configuration_object_id
            }

            response = self.make_body_request(url=OPERATIONAL_LINKS, function=FUNCTION_ADOPT_WITH_CONFIGURATION, object_id=object_id, content_type=APPLICATION_JSON, body=body)
        else:
            response = self.make_simple_request(url=OPERATIONAL_LINKS, function=FUNCTION_ADOPT, object_id=object_id, command=COMMAND_POST)
            
        if self.caching:
            response = self._get_operational_link(object_id=object_id).contents
            self.update_cache(object_type=OPERATIONAL_LINKS, response=response, object_id=object_id, command=COMMAND_GET)
            configuration_object_id = response["linkedKey"]
            response = self._get_configuration_link(object_id=configuration_object_id).contents
            self.update_cache(object_type=CONFIGURATION_LINKS, response=response, object_id=configuration_object_id, command=COMMAND_GET)
        return response

    def unadopt_operational_link(self, object_id):
        return self.make_simple_request(url=OPERATIONAL_LINKS, function=FUNCTION_UNADOPT, object_id=object_id, command=COMMAND_POST)
