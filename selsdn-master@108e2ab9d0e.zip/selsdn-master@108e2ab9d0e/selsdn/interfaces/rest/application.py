from .metaclasses import ObjectMixin
from .constants import SECURITY_APPLICATION_LINKS, APPLICATION_JSON, COMMAND_POST, FUNCTION_APPLICATION_PAIR
from .constants import FUNCTION_APPLICATION_DISABLE, FUNCTION_APPLICATION_ENABLE
from .decorators import no_body_url

class ApplicationMixin(metaclass=ObjectMixin, name="application", url=SECURITY_APPLICATION_LINKS):
    def register_application(self, name, grant_type, permissions, redirect_uris, thumbprint=None, ip_address=None):
        if ip_address is None:
            ip_address = redirect_uris[0]
        
        body = {
            "versions": ["1"],
            "applicationName": name,
            "certificateThumbprint": thumbprint,
            "applicationIp": ip_address,
            "authenticationTypes":[{
            "grantType": grant_type, 
            "permissions": tuple(permissions),
            "redirectUris": tuple(redirect_uris),
            }]}

        return self.make_body_request(url=SECURITY_APPLICATION_LINKS, content_type=APPLICATION_JSON, body=body)
    
    def pair_application(self, uri):
        body = {'url': uri}
        return self.make_body_request(url=SECURITY_APPLICATION_LINKS, content_type=APPLICATION_JSON, function=FUNCTION_APPLICATION_PAIR, body=body)

    @no_body_url(url=SECURITY_APPLICATION_LINKS, function=FUNCTION_APPLICATION_ENABLE, command=COMMAND_POST)
    def enable_application(self, object_id, response):
        return response

    @no_body_url(url=SECURITY_APPLICATION_LINKS, function=FUNCTION_APPLICATION_DISABLE, command=COMMAND_POST)   
    def disable_application(self, object_id, response):
        return response
