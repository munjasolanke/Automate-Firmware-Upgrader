from .base import OperationalPortRestObject, OperationalPortObjectCollection, ConfigurationPortObjectCollection, ConfigurationPortRestObject
from .metaclasses import ObjectMixin
from .decorators import no_body_url
from .constants import FUNCTION_ENABLE_RELAY_FAILOVER, FUNCTION_REMOVE_RELAY_FAILOVER, FUNCTION_DETECT_RELAY_FAILOVER
from .constants import FUNCTION_ADOPT_DEFAULT, FUNCTION_ADOPT
from .constants import OPERATIONAL_PORTS, CONFIGURATION_PORTS, COMMAND_POST, COMMAND_GET
from .constants import PROPERTY_LINKS
from ...automation.port import Port

class ConfigurationPortMixin(metaclass=ObjectMixin, name="configuration_port", url=CONFIGURATION_PORTS):
    pass


class OperationalPortMixin(metaclass=ObjectMixin, name="operational_port", url=OPERATIONAL_PORTS):
    @no_body_url(url=OPERATIONAL_PORTS, function=FUNCTION_ENABLE_RELAY_FAILOVER, command=COMMAND_POST)
    def enable_failover_mode(self, object_id, response=None):
        return response

    @no_body_url(url=OPERATIONAL_PORTS, function=FUNCTION_REMOVE_RELAY_FAILOVER, command=COMMAND_POST)
    def disable_failover_mode(self, object_id, response=None):
        return response

    @no_body_url(url=OPERATIONAL_PORTS, function=FUNCTION_DETECT_RELAY_FAILOVER, command=COMMAND_POST)
    def detect_other_port(self, object_id, response=None, **kwargs):
        return response

    #@no_body_url(url=OPERATIONAL_PORTS, function=FUNCTION_ADOPT_DEFAULT, command=COMMAND_POST)
    def adopt_operational_port_with_default(self, object_id):
        return self.adopt_operational_port(object_id=object_id)

    def adopt_operational_port(self, object_id, configuration_object_id=None, **kwargs):
        if configuration_object_id:
            body = {
                "configKey": configuration_object_id
            }
            response = self.make_body_request(url=OPERATIONAL_PORTS, function=FUNCTION_ADOPT_WITH_CONFIGURATION, object_id=object_id, content_type=APPLICATION_JSON, body=body)
        else:
            response = self.make_simple_request(url=OPERATIONAL_PORTS, function=FUNCTION_ADOPT, object_id=object_id, command=COMMAND_POST)

        if self.caching:
            response = self._get_operational_port(object_id=object_id).contents
            self.update_cache(object_type=OPERATIONAL_PORTS, response=response, object_id=object_id, command=COMMAND_GET)
            configuration_object_id = response["linkedKey"]
            response = self._get_configuration_port(object_id=configuration_object_id).contents
            self.update_cache(object_type=CONFIGURATION_PORTS, response=response, object_id=configuration_object_id, command=COMMAND_GET)
        return response

    def convert_operational_ports_from_rest(self, data):
        return [self.convert_operational_port_from_rest(port) for port in data['value']]

    def convert_operational_port_from_rest(self, port):
        port_attributes = {"mac_address": None, "ip_address":list()}
        for attribute in port['attributes']:
            if '@odata.type' in attribute and "EthernetAttr" in attribute['@odata.type']:
                port_attributes["mac_address"] = attribute['macAddress']

            if '@odata.type' in attribute and "IpAttr" in attribute['@odata.type']:
                port_attributes["ip_address"].append(attribute['ipAddress'])

        name = port["displayName"]
        port_object = Port(name=name, **port_attributes)
        port_object.add_attribute("operational_id", port["id"])
        port_object.add_attribute("id", port["linkedKey"])
        return port_object

    @no_body_url(url=OPERATIONAL_PORTS, function=FUNCTION_ADOPT_DEFAULT, command=COMMAND_POST)
    def adopt_operational_port_with_default(self, object_id, response=None):
        return response

    @no_body_url(url=OPERATIONAL_PORTS, function=FUNCTION_ENABLE_RELAY_FAILOVER, command=COMMAND_POST)
    def enable_relay_failover(self, object_id, response=None):
        return response
