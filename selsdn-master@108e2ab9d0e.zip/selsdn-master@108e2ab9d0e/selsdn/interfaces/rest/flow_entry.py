from .metaclasses import ObjectMixin
from .constants import CONFIGURATION_FLOWS, CONFIGURATION_NODES, CONFIGURATION_PORTS, TREE_MATCHFIELDS, APPLICATION_JSON
from .constants import COMMAND_DELETE, OPERATIONAL_NODES, PROPERTY_ERROR_STATE, PROPERTY_ID, OPERATIONAL_FLOW_STATS, OBJECT_NODES

from . import LOGGER
from ...openflow.core.flow_entry import FlowEntry, FlowEntryStats
from ...openflow.core.match_fields import MatchFields, MatchField, InPortMatch, EthSrcMatch, EthDstMatch, EthTypeMatch, VlanVidMatch, VlanPcpMatch, IpProtoMatch, Ipv4DstMatch, Ipv4SrcMatch, UdpSrcMatch, UdpDstMatch, TcpSrcMatch, TcpDstMatch, ArpOpMatch, ArpTpaMatch, ArpSpaMatch
from ...openflow.core.instructions import WriteActionsInstruction, MeterInstruction, GotoTableInstruction, ClearActionsInstruction, Instructions
from ...base.collection import FlowCollection
from ...tools.diff.diff import create_flow_entries_diff
from .base import DualTreeRestObject

class FlowEntryMixin(metaclass=ObjectMixin, name="flow", url=CONFIGURATION_FLOWS):
    def diff_flow_entries(self, new_entries, old_entries=None, ignore_system=True, delete_bad=False):
        return self.diff_openflow_entries(new_flows=new_entries, old_flows=old_entries, ignore_system=ignore_system, delete_bad=delete_bad)

    def resolve_flow_synchronization_request(self):
        synchronization_objects = list()

        flow_entries = self.get_flow_entries()
        flow_stats = self.get_flow_stats()

        sychronization_requests = self.get_synchronization_requests()

        for sychronization_request in sychronization_requests:
            odata_type = sychronization_request["@odata.type"]
            if "FlowDeleteSynchronizationRequest" in odata_type:
                flow_stat = flow_stats.has_entry_id(sychronization_request["cookie"])[0]
                flow_stat.set_attribute("$synchronization_action", "delete")
                flow_stat.set_attribute("$synchronization_link", flow_entries.has_entry_id(sychronization_request["cookie"]))
                synchronization_objects.append(flow_stat)
            elif "FlowAddSynchronizationRequest" in odata_type:
                flow_stat = flow_entries.has_entry_id(sychronization_request["cookie"])[0]
                flow_stat.set_attribute("$synchronization_action", "add")
                flow_stat.set_attribute("$synchronization_link", flow_entries.has_entry_id(sychronization_request["cookie"]))
                synchronization_objects.append(flow_stat)

        return synchronization_objects

    def get_flow_stats(self):
        flow_stats_objects = self.make_simple_request(url=OPERATIONAL_FLOW_STATS).contents
        flow_stats = self.convert_flow_stats_from_rest(flow_stats_objects)
        return flow_stats

    def convert_flow_stats_from_rest(self, flow_stats):
        node_entries = self.get_information(OBJECT_NODES)

        converted_flow_stats = FlowCollection(perform_validation=False)

        for switch_stat_collection in flow_stats:
            datapathid = switch_stat_collection["dataPathId"]
            switch = node_entries.has_datapath_id(datapathid)[0]
            for stat in switch_stat_collection["stats"]:
                converted_flow_stats.append(self.convert_flow_stat_from_rest(stat, switch=switch))

        return converted_flow_stats

    def convert_flow_stat_from_rest(self, flow_stat, switch):
        flow_stat["node"] = switch.get_attribute("id")
        flow_stat["displayName"] = "Cookie :{}".format(flow_stat["cookie"])
        flow_stat["errorState"] = "Success"
        flow_stat["id"] = None
        flow_stat["enabled"] = None
        flow_stat["tags"] = list()
        flow_entry = self.convert_flow_entry_from_rest(flow_stat)
        flow_entry.__class__ = FlowEntryStats
        flow_entry.byte_count = flow_stat["byteCount"]
        flow_entry.duration = flow_stat["duration"]
        flow_entry.packet_count = flow_stat["packetCount"]
        flow_entry.flags = flow_stat["flags"]
        return flow_entry

    def rename_flow_names(self, rename_string=None, skip_if_not_default_name=False, base_string=None, flow_entries=None):
        if not flow_entries:
            flow_objects = self._get_flows().contents
        else:
            flow_objects = flow_entries
        self.rename_openflow_names(object_type=CONFIGURATION_FLOWS, skip_if_not_default_name=skip_if_not_default_name, rename_string=rename_string, openflow_objects=flow_objects, base_string=base_string)

    def get_flow_entries(self, perform_validation=False):
        response = self.get_flows()
        return FlowCollection(self.convert_flow_entries_from_rest(response), perform_validation=perform_validation)

    def add_flow_entry(self, flow_entry):
        return self.add_flow_entries([flow_entry])

    def add_flow_entries(self, flow_entries):
        return self.add_objects(objects=flow_entries, url=CONFIGURATION_FLOWS)

    def convert_flow_entries_from_rest(self, flow_entries):
        return [self.convert_flow_entry_from_rest(flow_entry) for flow_entry in flow_entries]

    def convert_flow_entries_to_rest(self, flow_entries):
        return [self.convert_flow_entry_to_rest(flow_entry) for flow_entry in flow_entries]

    def convert_flow_entry_from_rest(self, flow_entry):
        error_state = False
        try:
            entry_id = flow_entry["cookie"]
            priority = flow_entry["priority"]
            table_id = flow_entry["tableId"]
            node = flow_entry["node"]
            try:
                node = self.get_name_from_id(object_id=node, object_type=CONFIGURATION_NODES)
            except TypeError as e:
                node = "DELETED"
            hard_timeout = flow_entry["hardTimeout"]
            instructions = self.convert_instructions_from_rest(flow_entry["instructions"])
            alias = flow_entry["displayName"]
            idle_timeout = flow_entry["idleTimeout"]
            match_fields = self.convert_match_fields_from_rest(flow_entry["match"]["matchFields"])
        except Exception as e:
            raise Exception("Error when parsing flow entry {} on node {}".format(entry_id, node))

        new_instructions = list()
        actions = None
        for instruction in instructions:
            if isinstance(instruction, WriteActionsInstruction):
                actions = instruction
            else:
                new_instructions.append(instruction)

        flow_object = FlowEntry(entry_id=entry_id, priority=priority, table_id=table_id, name=alias, node=node, match_fields=match_fields, actions=actions, instructions=new_instructions)
        if match_fields.get_attribute("Errors"):
            flow_object.add_attribute("Status", "Failure*")
        else:
            flow_object.add_attribute("Status", flow_entry[PROPERTY_ERROR_STATE])
        flow_object.add_attribute("id", flow_entry[PROPERTY_ID])
        flow_object.add_attribute("Enabled", flow_entry["enabled"])
        flow_object.add_attribute("Tags", flow_entry["tags"])
        flow_object.add_attribute("Status", flow_entry[PROPERTY_ERROR_STATE])
        if self.get_tag_value_from_type("LogicalConnectionTag", flow_entry["tags"]):
            cst_name, sources, destinations = self.get_logical_connection_information(self.get_tag_value_from_type("LogicalConnectionTag", flow_entry["tags"]))
            flow_object.add_attribute("CST", cst_name)
            flow_object.add_attribute("Sources", sources)
            flow_object.add_attribute("Destinations", destinations)
            flow_object.add_attribute("LC ID", self.get_tag_value_from_type("LogicalConnectionTag", flow_entry["tags"]))
        flow_object.add_attribute("system", True if self.get_tag_value_from_type("SystemTag", flow_entry["tags"]) is not None else False)

        return flow_object

    def get_logical_connection_information(self, object_id):
        lc_object = self.get_object(url="/api/default/config/logicalConnections", object_id=object_id)
        application_entry = self.convert_application_entry_from_rest(lc_object)
        return application_entry.protocol.name, application_entry.sources, application_entry.destinations

    def convert_flow_entry_to_rest(self, flow_entry):
        node_id = self.get_id_from_name(object_name=flow_entry.node_name, object_type=CONFIGURATION_NODES)
        if not node_id:
            raise ValueError("Unable to find node with name {} for flow entry {}".format(flow_entry.node_name, flow_entry))
        
        return {
            "node": node_id,
            "enabled": flow_entry.get_attribute("enabled", default_value=True),
            "priority": flow_entry.priority,
            "tableId": flow_entry.table_id,
            "displayName": flow_entry.name,
            "idleTimeout": 0,
            "hardTimeout": 0,
            "match": {"matchFields": self.convert_match_fields_to_rest(flow_entry.match_fields)},
            "instructions": self.convert_instructions_to_rest(flow_entry.instructions) + [self.convert_instruction_to_rest(WriteActionsInstruction(flow_entry.actions))],
        }

    def convert_instructions_from_rest(self, instructions):
        return [self.convert_instruction_from_rest(instruction) for instruction in instructions]

    def convert_instructions_to_rest(self, instructions):
        return [self.convert_instruction_to_rest(instruction) for instruction in instructions]
        
    def convert_instruction_from_rest(self, instruction):
        if instruction.get("@odata.type"):
            instruction_type = instruction["@odata.type"]
        else:
            instruction_type = instruction["instructionType"]

        if "WriteActions" in instruction_type:
            actions = self.convert_actions_from_rest(instruction["actions"])
            return WriteActionsInstruction(values=actions)
        elif "Meter" in instruction_type:
            return MeterInstruction(instruction["meterId"])
        elif "GoToTable" in instruction_type:
            return GotoTableInstruction(instruction["tableId"])
        elif "ClearActions" in instruction_type:
            return ClearActionsInstruction()
        else:
            raise ValueError("Unknown instruction type {}".format(instruction_type))

    def convert_instruction_to_rest(self, instruction):
        if isinstance(instruction, WriteActionsInstruction):
            return {"actions": self.convert_actions_to_rest(instruction.values),
                "@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.WriteActions"}
        elif isinstance(instruction, MeterInstruction):
            return {"meterId": instruction.value,
                "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.MeterInstruction"}
        elif isinstance(instruction, GotoTableInstruction):
            return {"tableId": instruction.value, "@odata.type":"#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.GoToTable"}
        elif isinstance(instruction, ClearActionsInstruction):
            return {"@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.ClearActions"}
        else:
            raise TypeError("Unknown Instruction {}".format(type(instruction)))

    def convert_match_fields_from_rest(self, match_fields):
        converted_match_fields = MatchFields()
        converted_match_fields.add_attribute("Errors", list())
        for match_field in match_fields:
            match_field_type, match_field_value, match_field_mask = self.get_match_field_value_type_from_rest(match_field)          
            converted_match_fields.add(self.convert_match_field_from_rest(match_field_type, match_field_value, match_field_mask, match_field=match_field))

        return converted_match_fields

    def get_match_field_value_type_from_rest(self, match_field):
        match_field_type = match_field["@odata.type"].split(".")[-1]
        match_field_value = self.convert_friendly_names_to_values(match_field_type=match_field_type, match_field_value=match_field["value"])
        
        if "mask" in match_field:
            match_field_mask = match_field["mask"]
        else:
            match_field_mask = None
        
        return match_field_type, match_field_value, match_field_mask

    def convert_match_field_from_rest(self, match_field_type, match_field_value, match_field_mask, match_field):
        match_object = None

        # Handle translated values 
        if match_field.get("translatedValue"):
            match_field_value = match_field.get("translatedValue")
            match_field_type = match_field_type.replace("ByAlias", "")

        if match_field_type == "InPort":
            match_object = InPortMatch(value=match_field_value)
        elif match_field_type == "InPortByAlias":
            value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="OpenFlowPortAttr")
            match_object = InPortMatch(value=value)
        elif match_field_type == "EthDst":
            match_object =  EthDstMatch(value=match_field_value.zfill(12), mask=match_field_mask)
        elif match_field_type == "EthDstByAlias":
            try:
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="EthernetAttr")
            except (TypeError, ValueError):
                # Might be a SEL-2740S node instead of a host port
                operational_object_id = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_NODES, attribute="linkedKey")
                value = self.get_value_from_id(object_id=operational_object_id, object_type=OPERATIONAL_NODES, attribute="macAddress")
            match_object =  EthDstMatch(value=value.zfill(12))
        elif match_field_type == "EthSrc":
            match_object =  EthSrcMatch(value=match_field_value.zfill(12), mask=match_field_mask)
        elif match_field_type == "EthSrcByAlias":
            try:
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="EthernetAttr")
            except (TypeError, AttributeError, ValueError):
                try:
                # Might be a SEL-2740S node instead of a host port
                    operational_object_id = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_NODES, attribute="linkedKey")
                    value = self.get_value_from_id(object_id=operational_object_id, object_type=OPERATIONAL_NODES, attribute="macAddress")
                except (TypeError, AttributeError, ValueError):
                    # Might also be a switch port
                    value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="hardwareAddress")
            match_object =  EthSrcMatch(value=value)
        elif match_field_type == "EthernetApplicationByAlias":
            argument = match_field["applicationEthType"]
            value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="EthernetApplicationAttr")
            match_object =  EthSrcMatch(value=value)
        elif match_field_type == "EthernetApplication":
            match_object =  EthSrcMatch(value=match_field_value)
        elif match_field_type == "EthType":
            match_object =  EthTypeMatch(value=match_field_value)
        elif match_field_type == "VlanVid":
            if match_field_mask not in ("Present", "None", None):
                match_field_mask = int(match_field_mask)
            match_object =  VlanVidMatch(value=match_field_value, mask=match_field_mask)
        elif match_field_type == "VlanPcp":
            match_object =  VlanPcpMatch(value=match_field_value)

        elif match_field_type == "IpProto":
            match_object =  IpProtoMatch(value=match_field_value)
        elif match_field_type == "Ipv4Dst":
            match_object =  Ipv4DstMatch(value=match_field_value, mask=match_field_mask)
        elif match_field_type == "Ipv4DstByAlias":
            try:
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="IpAttr")
            except (TypeError, AttributeError):
                # Might be a SEL-2740S node instead of a host port
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_NODES, attribute="ipAddress")
            match_object =  Ipv4DstMatch(value=value)
        elif match_field_type == "Ipv4Src":
            match_object =  Ipv4SrcMatch(value=match_field_value, mask=match_field_mask)
        elif match_field_type == "Ipv4SrcByAlias":
            try:
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="IpAttr")
            except (TypeError, ValueError):
                # Might be a SEL-2740S node instead of a host port
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_NODES, attribute="ipAddress")
            match_object =  Ipv4SrcMatch(value=value)
        elif match_field_type == "TcpSrc":
            match_object =  TcpSrcMatch(value=match_field_value)
        elif match_field_type == "TcpDst":
            match_object =  TcpDstMatch(value=match_field_value)
        elif match_field_type == "UdpSrc":
            match_object =  UdpSrcMatch(value=match_field_value)
        elif match_field_type == "UdpDst":
            match_object =  UdpDstMatch(value=match_field_value)

        elif match_field_type == "ArpOp":
            match_object =  ArpOpMatch(value=match_field_value)
        elif match_field_type == "ArpTpa":
            match_object =  ArpTpaMatch(value=match_field_value, mask=match_field_mask)
        elif match_field_type == "ArpTpaByAlias":
            try:
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="IpAttr")
            except (TypeError, ValueError):
                # Might be a SEL-2740S node instead of a host port
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_NODES, attribute="ipAddress")
            match_object =  ArpTpaMatch(value=value)
        elif match_field_type == "ArpSpa":
            match_object =  ArpSpaMatch(value=match_field_value, mask=match_field_mask)
        elif match_field_type == "ArpSpaByAlias":
            try:
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_PORTS, attribute="IpAttr")
            except (TypeError, ValueError):
                # Might be a SEL-2740S node instead of a host port
                value = self.get_value_from_id(object_id=match_field_value, object_type=CONFIGURATION_NODES, attribute="ipAddress")
            match_object =  ArpSpaMatch(value=value)
        else:
            raise ValueError("Unknown match field type {}".format(match_field_type))

        if "ByAlias" in match_field_type:
            match_object.set_attribute("$aliased", match_field_value)
        else:
            match_object.set_attribute("$aliased", False)

        return match_object

    def convert_friendly_names_to_values(self, match_field_type, match_field_value):
        if match_field_type in ("TcpSrc", "TcpDst"):
            if match_field_value.upper() == "FAST MESSAGE":
                return 23
            elif match_field_value.upper() == "FTP":
                return 21
            elif match_field_value.upper() == "FTPDATA":
                return 20
            else:
                return match_field_value
        elif match_field_type in ("UdpSrc", "UdpDst"):
            if match_field_value.upper() == "SNMPTRAP":
                return 162
            elif match_field_value.upper() == "FAST MESSAGE":
                return 23
            else:
                return match_field_value
        else:
            return match_field_value

    def convert_match_fields_to_rest(self, match_fields):
        return [self.convert_match_field_to_rest(match_field) for match_field in match_fields]

    def convert_match_field_to_rest(self, match_field):
        if match_field.get_attribute("$aliased"):
            match_field_type = match_field.__class__.__name__[:-5]+"ByAlias"
            match_field_value = match_field.get_attribute("$aliased")
        else:
            match_field_type = match_field.__class__.__name__[:-5]
            match_field_value = str(match_field.value)

        body = {"@odata.type": ".".join([TREE_MATCHFIELDS, match_field_type]), "value":match_field_value}
        if match_field.is_maskable() and match_field.mask is not None:
            if match_field_type == "VlanVid":
                mask_value = str(match_field.mask)
            else:
                mask_value = match_field.mask
            body["mask"] = mask_value
        return body

    def add_hard_timeout_to_flow_objects(self, flow_objects, timeout, ignore_system=True):
        if not isinstance(timeout, int) or timeout < 0 or timeout > 65535:
            raise TypeError("Timeout must be an integer between 1 and 65535")

        for flow_object in flow_objects:
            if isinstance(flow_object, dict) and flow_object.get("cookie"):
                pass
            elif isinstance(flow_object, FlowEntry) and flow_object.get_attribute("id"):
                pass
            else:
                raise ValueError("Flow object {} isn't in a recognizable format".format(flow_object))

        responses = list()
        for flow_object in flow_objects:
            if isinstance(flow_object, FlowEntry):
                flow_object = self.get_object(url=CONFIGURATION_FLOWS, object_id=flow_object.get_attribute("id"))
            
            if ignore_system and self.get_tag_value_from_type("SystemTag", flow_object["tags"]):
                LOGGER.info("Skipping adding a hard timeout to flow entry {} because it is a system generated flow and the ignore_system flag is True".format(flow_object["displayName"]))
                continue
            
            flow_object["hardTimeout"] = timeout
            flow_object["enabled"] = True

            response = self.modify_object(url=CONFIGURATION_FLOWS, object_id=flow_object["id"], mod_body=flow_object, command="PUT")
            responses.append(response)

        return responses

