from .metaclasses import ObjectMixin
from .constants import SECURITY_ROLES, APPLICATION_JSON
from .decorators import no_body_url

class RoleMixin(metaclass=ObjectMixin, name="role", url=SECURITY_ROLES):
    def add_role(self, *args, **kwargs):
        return self.create_object(SECURITY_ROLES, *args, **kwargs)

    def convert_role_to_rest(self, name, permissions):
        return {
            "roleName": name,
            "permissions": permissions,
            "displayName": name,
        }
