from base64 import b64encode

from . import LOGGER

from .constants import OPERATIONAL_PACKETS, OPERATIONAL_NODES, CONFIGURATION_NODES, PROPERTY_LINKED, FUNCTION_PACKET_OUT, APPLICATION_JSON
from .constants import OPERATOR_EQUALS, OPERATOR_GT

TABLE_MISS_ALIAS = "SEL-5056: Table 3 miss"

class PacketMixin:
    def packet_out(self, object_id, port_id, packet_data):
        if not object_id or not port_id or not packet_data:
            raise ValueError("Object id {}, port id {}, and packet data {} cannot be none".format(object_id, port_id, packet_data))
        converted_packet = b64encode(packet_data).decode()

        body = {
            "portId": port_id,
            "packetData": converted_packet
        }

        return self._make_body_request(url=OPERATIONAL_NODES, object_id=object_id, function=FUNCTION_PACKET_OUT, content_type=APPLICATION_JSON, body=body)

    def packet_out_by_name(self, object_name, packet_data, port_id, *args, **kwargs):
        object_id = self.get_id_from_name(object_name=object_name, object_type=CONFIGURATION_NODES)
        if object_id:
            operational_node_id = self.get_value_from_id(object_id=object_id, object_type=CONFIGURATION_NODES, attribute=PROPERTY_LINKED)
            if operational_node_id:
                return self.packet_out(object_id=operational_node_id, port_id=port_id, packet_data=packet_data, *args, **kwargs)
            else:
                LOGGER.error("Unable to find operational node for {} to send packet out".format(object_name))
        else:
            raise ValueError("No object with name {}".format(object_name))

    def get_packet_ins(self, last_id=None, *args, **kwargs):
        if last_id:
            filters = [("monotonicId", last_id, OPERATOR_GT)]
        else:
            filters = None

        return self.make_simple_request(url=OPERATIONAL_PACKETS, filters=filters, *args, **kwargs)
