from .metaclasses import ObjectMixin
from .constants import CONFIGURATION_NODES, CONFIGURATION_PORTS, CONFIGURATION_GROUPS, APPLICATION_JSON, COMMAND_DELETE, CONFIGURATION_CSTS
from .constants import PROPERTY_NAME

from ...openflow.core.group_entry import AllGroup, IndirectGroup, SelectGroup, FastFailoverGroup
from ...openflow.core.action_bucket import ActionBucket
from ...tools.diff.diff import create_group_entries_diff
from ...base.collection import GroupCollection

class GroupEntryMixin(metaclass=ObjectMixin, name="group", url=CONFIGURATION_GROUPS):
    def diff_group_entries(self, new_entries, old_entries=None, ignore_system=True, delete_bad=False):
        return self.diff_openflow_entries(new_groups=new_entries, old_groups=old_entries, ignore_system=ignore_system, delete_bad=delete_bad)

    def add_group_entries(self, group_entries):
        return self.add_objects(url=CONFIGURATION_GROUPS, objects=group_entries)
        #return [self.add_group_entry(group_entry) for group_entry in group_entries]

    def add_group_entry(self, group_entry):
        return self.add_object(url=CONFIGURATION_GROUPS, object=group_entry)
        #converted_group = self.convert_group_entry_to_rest(group_entry)
        #return self.make_body_request(url=CONFIGURATION_GROUPS, body=converted_group)

    def get_highest_group_id_for_switch(self, node_id):
        highest_group_id = 0
        self.clear_information(object_type=CONFIGURATION_GROUPS)
        group_objects = self.get_groups()
        for group_object in group_objects:
            if group_object["node"] == node_id:
                if group_object["groupId"] > highest_group_id:
                    highest_group_id = group_object["groupId"]

        return highest_group_id

    def get_group_entries(self):
        response = self.get_groups()
        return self.convert_group_entries_from_rest(response)

    def convert_group_entries_from_rest(self, group_entries):
        return GroupCollection(values=[self.convert_group_entry_from_rest(group_entry) for group_entry in group_entries])

    def convert_group_entry_from_rest(self, group_entry):
        entry_id = group_entry["groupId"]
        node = group_entry["node"]
        try:
            group_type = group_entry["groupType"]
            node = self.get_name_from_id(object_id=group_entry["node"], object_type=CONFIGURATION_NODES)
            alias = group_entry["displayName"]
            action_buckets = self.convert_action_buckets_from_rest(group_entry["buckets"])
            attributes = {"id": group_entry["id"], "Enabled": group_entry["enabled"]}
            attributes["system"] = True if self.get_tag_value_from_type("SystemTag", group_entry["tags"]) is not None else False

            if group_type == "All":
                return AllGroup(name=alias, node=node, entry_id=entry_id, action_buckets=action_buckets, attributes=attributes)
            elif group_type == "FastFailover":
                return FastFailoverGroup(name=alias, node=node, entry_id=entry_id, action_buckets=action_buckets, attributes=attributes)
            elif group_type == "Indirect":
                return IndirectGroup(name=alias, node=node, entry_id=entry_id, action_buckets=action_buckets, attributes=attributes)
            elif group_type == "Select":
                return SelectGroup(name=alias, node=node, entry_id=entry_id, action_buckets=action_buckets, attributes=attributes)
            else: #, IndirectGroup, SelectGroup that no one uses
                raise ValueError("Unknown group type {}".format(group_type))
        except Exception as e:
            if entry_id:
                raise Exception("Error when parsing group entry {} on node {}".format(entry_id, node))
            else:
                raise Exception("Error when parsing group entry {} on node {}".format(group_entry, node))

    def convert_group_entry_to_rest(self, group_entry):
        converted_buckets = self.convert_action_buckets_to_rest(group_entry.action_buckets)
        node_id = self.get_id_from_name(object_name=group_entry.node_name, object_type=CONFIGURATION_NODES)
        if not node_id:
            raise ValueError("Unable to find node with name {} for group entry {}".format(group_entry.node_name, group_entry))

        return self.create_group_body(name=group_entry.name, group_id=group_entry.entry_id, node_name=group_entry.node_name, group_type=group_entry.__class__.__name__[:-5], action_buckets=converted_buckets, enabled=group_entry.get_attribute("Enabled", default_value=True), tags=group_entry.get_attribute("tags"))

    def create_group_body(self, name, node_name, group_type, group_id, action_buckets, enabled=True, tags=None):
        node_id = self.get_id_from_name(object_name=node_name, object_type=CONFIGURATION_NODES)

        if tags is None:
            tags = list()

        body = {
            "displayName": name,
            "node": node_id,
            "enabled": enabled,
            "groupId": group_id,
            "groupType": group_type,
            "buckets": action_buckets,
            "tags": tags
        }

        return body

    def convert_action_buckets_from_rest(self, action_buckets):
        return [self.convert_action_bucket_from_rest(action_bucket) for action_bucket in action_buckets]

    def convert_action_buckets_to_rest(self, action_buckets):
        return [self.convert_action_bucket_to_rest(action_bucket) for action_bucket in action_buckets]

    def convert_action_bucket_from_rest(self, action_bucket):
        if action_bucket.get("@odata.type") and action_bucket['@odata.type'].split(".")[-1] == "PortBucketByAlias":
            watch_port = self.get_value_from_id(object_id=action_bucket["watchPortConfigId"], object_type=CONFIGURATION_PORTS, attribute="OpenFlowPortAttr")
            watch_group = None
        else:
            watch_port = action_bucket["watchPort"]
            watch_group = action_bucket["watchGroup"]

        actions = self.convert_actions_from_rest(action_bucket["actions"])

        return ActionBucket(watch_port=watch_port, watch_group=watch_group, actions=actions)

    def convert_action_bucket_to_rest(self, action_bucket):
        body = {
            "@odata.type": "#Sel.Sel5056.OpenFlowPlugin.DataTreeObjects.Bucket",
            "watchPort": str(action_bucket.watch_port),
            "watchGroup": str(action_bucket.watch_group),
            "actions": self.convert_actions_to_rest(action_bucket.values)
        }

        return body

    def rename_group_names(self, rename_string=None, skip_if_not_default_name=False, base_string=None):
        group_objects = self._get_groups().contents
        self.rename_openflow_names(object_type=CONFIGURATION_GROUPS, skip_if_not_default_name=skip_if_not_default_name, rename_string=rename_string, openflow_objects=group_objects, base_string=base_string)
