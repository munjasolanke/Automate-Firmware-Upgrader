from .metaclasses import ObjectMixin
from .constants import SECURITY_USERS, APPLICATION_JSON, COMMAND_PATCH
from .decorators import no_body_url

class UserMixin(metaclass=ObjectMixin, name="user", url=SECURITY_USERS):
    def add_user(self, *args, **kwargs):
        return self.create_object(SECURITY_USERS, *args, **kwargs)

    def convert_user_to_rest(self, name, password, roles):
        return {
            "@odata.type": "#Sel.BlueFrame.Core.SecurityManager.LocalUser",
            'roles': roles,
            'username': name,
            "clearTextPass": password,
            }

    def get_user_by_name(self, username):
        users = self.get_users()
        for user in users:
            if user["username"] == username:
                return user
        else:
            return False

    def change_user_password(self, username, old_password, new_password):
        user = self.get_user_by_name(username)
        body = {"oldPassword": old_password, "newPassword": new_password}
        return self.make_body_request(url=SECURITY_USERS, object_id=user["id"], body=body, function=FUNTION_UPDATE_PASSWORD)

    def modify_user_roles(self, username, roles):
        user = self.get_user_by_name(username)
        user[roles] = roles
        return self.make_body_request(SECURITY_USERS, body=user, command=COMMAND_PATCH)
