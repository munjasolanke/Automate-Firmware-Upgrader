from functools import wraps

from .constants import COMMAND_GET, COMMAND_POST, APPLICATION_JSON

# Decorate function to replace redundant lines of code
def no_body_url(url, function=None, command=COMMAND_GET, required=False):
    def decorate(func):
        @wraps(func)
        def wrapper(self, object_id=None, *args, **kwargs):
            self._validate_uuid(object_id, required=required)
            if required is None:
                request = self._make_simple_request(url, function=function, command=command, *args, **kwargs)
            else:
                request = self._make_simple_request(url, object_id=object_id, function=function, command=command, *args, **kwargs)

            response = self.send_request(request)

            if required is None:
                return func(self, response=response, *args, **kwargs)
            else:
                return func(self, object_id=object_id, response=response, *args, **kwargs)

        return wrapper
    return decorate

def body_url(url, function=None, command=COMMAND_POST, content_type=APPLICATION_JSON, required=False):
    def decorate(func):
        @wraps(func)
        def wrapper(self, object_id=None, body=None, *args, **kwargs):
            self._validate_uuid(object_id, required=required)
            if required is None:
                request = self._make_body_request(url, function=function, content_type=content_type, command=command)
            else:
                request = self._make_body_request(url, object_id=object_id, function=function, content_type=content_type, command=command)
            
            response = self.send_request(request)
            
            if required is None:
                return func(self, response=response, *args, **kwargs)
            else:
                return func(self, object_id=object_id, response=response, *args, **kwargs)

        return wrapper
    return decorate
