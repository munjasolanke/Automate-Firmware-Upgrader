from time import sleep
from struct import pack
from ipaddress import IPv4Address

from ...automation.device import EndDevice, SEL274XSDevice
from ...automation.port import Port

from .constants import FUNCTION_USER_INITIATED_HOST_DISCOVERY, TREE_OPERATIONAL

from . import LOGGER

class HostDiscoveryMixin():
    def resolve_port(self, port_object):
        if port_object.end and port_object.end.owner:
            if isinstance(port_object.end.owner, SEL274XSDevice):
                return port_object.end
            else:
                for port_object in port_object.end.owner.ports:
                    return self.resolve_port(port_object=port_object)
        else:
            # Couldn't find it
            return value

    def find_ports(self, port_entries):
        for port_entry in port_entries:
            self.find_port(port_entry=port_entry)

    def find_port(self, port_entry):
        switch_entry = self.resolve_port(port_entry)
        switch_name, switch_port = switch_entry.owner.name, switch_entry.name
        tpa = port_entry.ip_address

        if switch_port and switch_name and tpa:
            self.send_arp_request(switch=switch_name, port_id=switch_port, tpa=tpa)
            sleep(1)
        else:
            LOGGER.error("Skipping port {} because no IP address found for connected device".format(port_entry))

    def find_hosts(self, node_entries, network=None):
        for node_entry in node_entries:
            if isinstance(node_entry, EndDevice):
                self.find_host(node_entry=node_entry, network=network)
            elif isinstance(node_entry, Port):
                self.find_port(port_entry=node_entry, network=network)

    def find_host(self, node_entry, network=None):
        for port in node_entry.ports:
            if port.end and ((network and network in port.networks) or not network):
                self.find_port(port_entry=port)

    def find_host_by_ip_address(self, ip_address):
        operational_ports = self.get_operational_ports()
        for operational_port in operational_ports:
            for attribute in operational_port["attributes"]:
                if "OpenFlowPortAttr" in attribute["@odata.type"]:
                    raw_packet = self._create_arp_request_packet(ip_address)
                    self.packet_out(object_id=operational_port["parentNode"], port_id=attribute["portId"], packet_data=raw_packet)
                    break

    def send_arp_request(self, switch, port_id, tpa):
        if not switch or not port_id or not tpa:
            raise ValueError("One of switch {}, port ID {}, or ARP TPA {} is None".format(switch, port_id, tpa))

        raw_packet = self._create_arp_request_packet(tpa=tpa)

        return self.packet_out_by_name(object_name=switch, port_id=port_id, packet_data=raw_packet)

    def _create_arp_request_packet(self, tpa):
        raw_packet = b'\xff\xff\xff\xff\xff\xff\x000\xa7\x17\xf5\x1f\x08\x06\x00\x01\x08\x00\x06\x04\x00\x01\x000\xa7\x17\xf5\x1f\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        raw_packet += pack("!I", int(IPv4Address(tpa)))
        return raw_packet

    def user_initiated_host_discovery(self, ip_address):
        body = {"ip": str(ip_address)}
        return self.make_body_request(url=TREE_OPERATIONAL, function=FUNCTION_USER_INITIATED_HOST_DISCOVERY, body=body)
