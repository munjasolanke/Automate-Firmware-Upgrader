from .metaclasses import ObjectMixin
from .decorators import no_body_url
from .constants import CONFIGURATION_SETTINGS, SECURITY_IS_COMMISSIONED, COMMAND_POST, PROPERTY_ID, FUNCTION_DISCONNECT, PROPERTY_STATE
from .constants import CONFIGURATION_FLOWS, CONFIGURATION_NODES, CONFIGURATION_CSTS, PROPERTY_NAME, CONFIGURATION_GROUPS, PROPERTY_IP_ADDRESS
from .constants import CONFIGURATION_METERS, CONFIGURATION_GROUPS

from .constants import SETTINGS_SECURITY_MANAGER

from . import LOGGER

class SecurityManagerMixin(metaclass=ObjectMixin, name="security_manager", url=SETTINGS_SECURITY_MANAGER):
    def convert_security_manager_to_rest(self, maximum_login_attempts, lockup_seconds, login_attempt_windows):
        return {
            "maximumLoginAttempts": maximum_login_attempts,
            "lockoutSeconds": lockup_seconds,
            "loginAttemptWindow": login_attempt_windows,
        }

class MiscMixin:
    def get_switch_parameters(self):
        switches = dict()
        group_entries = self.get_group_entries()
        for group_entry in group_entries:
            node_name = group_entry.node_name
            if node_name not in switches:
                switches[node_name] = {"groups":0, "buckets":list(), 0:0, 1:0, 2:0, 3:0, "number_over_30":0}

            # groups
            switches[node_name]["groups"] = switches[node_name]["groups"] + 1

            # action buckets
            for this_action_bucket in group_entry.action_buckets:
                unique = True
                for found_action_bucket in switches[node_name]["buckets"]:
                    if this_action_bucket == found_action_bucket:
                        unique = False
                        break

                if unique:
                    switches[node_name]["buckets"].append(this_action_bucket)

            if len(group_entry.action_buckets) > 30:
                switches[node_name]["number_over_30"] = switches[node_name]["number_over_30"] + 1

        flow_entries = self.get_flow_entries()
        for flow_entry in flow_entries:
            node_name = flow_entry.node_name
            if node_name not in switches:
                switches[node_name] = {"groups":0, "buckets":list(), 0:0, 1:0, 2:0, 3:0, "number_over_30":0}
            table_id = flow_entry.table_id
            switches[node_name][table_id] = switches[node_name][table_id] + 1

        for node_name in switches:
            switches[node_name]["buckets"] = len(switches[node_name]["buckets"])

        return switches

    # Find things that are not Success
    def get_unsuccessful_states(self):
        unsuccessful_things = {"CONFIGURATION_FLOWS": list(), "CONFIGURATION_GROUPS": list(), "CONFIGURATION_LCS": list()}
        
        for entry in self._get_flow_entries().value:
            if entry["errorState"] != "Success":
                unsuccessful_things["CONFIGURATION_FLOWS"].append({"entry_id":entry["cookie"], "id":entry["id"], "errors":entry["errors"]})

        for entry in self._get_group_entries().value:
            if entry["errorState"] != "Success":
                unsuccessful_things["CONFIGURATION_GROUPS"].append({"entry_id":entry["cookie"], "id":entry["id"], "errors":entry["errors"]})

        for entry in self.get_lcs().value:
            if entry["errorState"] != "Success":
                unsuccessful_things["CONFIGURATION_LCS"].append({"entry_id":entry["cookie"], "id":entry["id"], "errors":entry["errors"]})

        return unsuccessful_things

    # Metadata
    def get_metadata(self, url):
        response = self.make_simple_request(url=url+"/$metadata")
        return response.data

    @no_body_url(url=CONFIGURATION_SETTINGS)
    def get_settings(self, object_id=None, response=None):
        return response.data

    # Commission SEL-5056
    def commission_5056(self, username, password):
        body = {"initialUser": username,"initialPassword": password}
        response = self._make_body_request(url=SECURITY_COMMISSION, content_type=APPLICATION_JSON, body=body)
        return response.data

    @no_body_url(url=SECURITY_IS_COMMISSIONED, command=COMMAND_POST)
    def is_5056_commissioned(self, object_id=None, response=None):
        return response.data

    def nuke_network(self, logical_connections=False, operational_hosts=False, operational_switches=False, configuration_hosts=False, configuration_switches=False, communication_service_types=False):
        if logical_connections:
            for lc in self.get_lcs()[::]:
                if lc["communicationServiceTypeId"] != "SEL-5056: In Band Path":
                    self.delete_lc_wrapper(object_id=lc[PROPERTY_ID])

        if operational_hosts or operational_switches:
            operational_switch_dicts, operational_host_dicts = list(), list()
            for node in self.get_operational_nodes():
                for a in node["attributes"]:
                    if "OpenFlowAttr" in a["@odata.type"]:
                        operational_switch_dicts.append(node)
                        break
                else:
                    operational_host_dicts.append(node)

        if operational_hosts:
            for host in operational_host_dicts:
                if host[PROPERTY_STATE] == "Adopted":
                    self.unadopt_node(object_id=host[PROPERTY_ID])
                self.disconnect_node(object_id=host[PROPERTY_ID])

        if operational_switches:
            for switch in operational_switch_dicts:
                if switch[PROPERTY_STATE] == "Adopted":
                    self.unadopt_node(object_id=switch[PROPERTY_ID])
                self.disconnect_node(object_id=switch[PROPERTY_ID])

        if configuration_switches or configuration_hosts:
            configuration_switch_dict, configuration_host_dict = list(), list()
            for node in self.get_configuration_nodes():
                if node.get("@odata.type"):
                    configuration_switch_dict.append(node)
                else:
                    configuration_host_dict.append(node)

        if configuration_switches:
            for node in configuration_switch_dict:
                self.delete_configuration_node(object_id=node[PROPERTY_ID])

        if configuration_hosts:
            for node in configuration_host_dict:
                if node[PROPERTY_STATE] == "Configured":
                    self.delete_configuration_node(object_id=node[PROPERTY_ID])

        if communication_service_types:
            for cst in self.get_csts()[::]:
                if not cst.get("@odata.type") or "CommunicationServiceTypePreDefined" not in cst["@odata.type"]:
                    self.delete_cst(cst[PROPERTY_ID])

    def rename_openflow_names(self, object_type, skip_if_not_default_name=False, rename_string=None, openflow_objects=None, base_string=None):
        if rename_string is None:
            rename_string = APPLICATION_FLOW_NAME_FORMAT

        # Do I need to look at LCs?
        get_type = None
        if "%c" in rename_string or "%s" in rename_string or "%d" in rename_string:
            get_type = "lc"
        elif "%fi" in rename_string:
            get_type = "flow"

        responses = list()
        len_openflow_objects = len(openflow_objects)
        for index, openflow_object in enumerate(openflow_objects):
            print("Updating name {} of {} for type {}".format(index+1, len_openflow_objects, object_type.split("/")[-1]))
            if skip_if_not_default_name and openflow_object["displayName"] != "SEL-5056: Logical Connections":
                continue

            new_name = list()
            if get_type == "lc":
                for tag in openflow_object["tags"]:
                    if "LogicalConnectionTag" in tag["@odata.type"]:
                        new_name.append(self.get_openflow_entry_name_string_for_lc(tag["logicalConnectionId"], rename_string=rename_string, openflow_object=openflow_object))
            elif get_type == "flow":
                if object_type == CONFIGURATION_GROUPS:
                    flow_objects = self.get_flows()
                    for flow_object in flow_objects:
                        if flow_object["node"] == openflow_object["node"]:
                            for instruction_object in flow_object["instructions"]:
                                if "WriteActions" in instruction_object["@odata.type"]:
                                    for action_object in instruction_object["actions"]:
                                        if "GroupAction" in action_object["@odata.type"]:
                                            if action_object["groupId"] == openflow_object["groupId"]:
                                                new_name.append(rename_string.replace("%fi", str(flow_object["cookie"])))

                elif object_type == CONFIGURATION_FLOWS:
                    new_name = [rename_string.replace("%f", object_type["flowId"])]
                else:
                    raise
            else:
                new_name = [rename_string]

            if new_name:
                new_name = ", ".join(new_name)

                if base_string:
                    new_name = base_string.replace("%s", new_name)

                if openflow_object["displayName"][-10:] == " FIRST HOP":
                    new_name += " FIRST HOP"

                # Only change the name if different
                if new_name != openflow_object["displayName"]:
                    if len(new_name) > 128:
                        print("Group name was {} characters long, shorten to 128 from {}".format(len(new_name), new_name))
                        new_name = new_name[:128]
                    openflow_object["displayName"] = new_name
                    response = self.update_object(url=object_type, command="PUT", object_id=openflow_object["id"], object_body=openflow_object)
                    responses.append(response)

        return responses

    def get_openflow_entry_name_string_for_lc(self, lc_id, openflow_object, rename_string=None):
        lc_object = self.get_lc(lc_id)
        source_name = self.get_value_from_id(object_type=CONFIGURATION_NODES, object_id=lc_object["sourceEndPoints"][0], attribute=PROPERTY_NAME)
        destination_names = list()
        for destination_id in lc_object["destinationEndPoints"]:
            destination_name = self.get_value_from_id(object_type=CONFIGURATION_NODES, object_id=destination_id, attribute=PROPERTY_NAME)
            destination_names.append(destination_name)

        cst_object = self.get_cst(object_id=lc_object["communicationServiceTypeId"])
        cst_name = cst_object["displayName"]

        if openflow_object.get("priority") and "Bidirectional" in cst_object["cstCommunicationType"]:
            # Need to figure out if forward or reverse direction and the switch source and desination_names
            source_id = self.get_id_from_name(object_name=source_name, object_type=CONFIGURATION_NODES)
            converted_flow_entry = self.convert_flow_entry_from_rest(openflow_object)
            if converted_flow_entry.match_fields.get("Ipv4Src"):
                flow_ip_address = converted_flow_entry.match_fields.get("Ipv4Src").value
            elif converted_flow_entry.match_fields.get("ArpSpa"):
                flow_ip_address = converted_flow_entry.match_fields.get("ArpSpa").value 
            else:
                raise ValueError("I don't support reversing names except for IP addresses")

            source_ip_address = self.get_value_from_id(object_id=source_id, object_type=CONFIGURATION_NODES, attribute=PROPERTY_IP_ADDRESS)
            if flow_ip_address == source_ip_address:
                source_name, destination_names = destination_names[-1], source_name

        return self.get_openflow_name_from_format_for_lc(cst_name, source_name, destination_names, rename_string=rename_string)

    def get_openflow_name_from_format_for_lc(self, cst_name, source_name, destination_name, rename_string=None):
        if rename_string is None:
            rename_string = APPLICATION_FLOW_NAME_FORMAT

        openflow_name = rename_string.replace("%c", str(cst_name)).replace("%s", str(source_name))
        if type(destination_name) is list:
            if "%s" in rename_string and (source_name is None or source_name == ''):
                LOGGER.warning("The source name is None or blank for the LC using CST {} to destinations {}".format(cst_name, ", ".join(map(str, destination_name))))
            if "%d" in rename_string and (None in destination_name or '' in destination_name):
                LOGGER.warning("One of the destination names is None or blank for the LC using CST {} from source {}".format(cst_name, str(source_name)))
            openflow_name = openflow_name.replace("%d", ", ".join(map(str, destination_name)))
        else:
            if "%s" in rename_string and (source_name is None or source_name == ''):
                LOGGER.warning("The source name is None or blank for the LC using CST {} to destination {}".format(cst_name, str(destination_name)))
            if "%d" in rename_string and (destination_name is None or destination_name == ''):
                LOGGER.warning("The destination name is None or blank for the LC using CST {} from source {}".format(cst_name, str(source_name)))
            openflow_name = openflow_name.replace("%d", str(destination_name))              
        return openflow_name

    def diff_openflow_entries(self, new_flows=None, new_groups=None, new_meters=None, old_flows=None, old_groups=None, old_meters=None, ignore_system=True, delete_bad=False):
        # Diff meters first, then groups, then flow entries

        # Get "old" entries if old not passed in
        if new_meters and not old_meters:
            if delete_bad:
                self.delete_bad_openflow_entries(CONFIGURATION_METERS)
            old_meters = self.get_meter_entries()

        if new_groups and not old_groups:
            if delete_bad:
                self.delete_bad_openflow_entries(CONFIGURATION_GROUPS)
            old_groups = self.get_group_entries()

        if new_flows and not old_flows:
            if delete_bad:
                self.delete_bad_openflow_entries(CONFIGURATION_FLOWS)
            old_flows = self.get_flow_entries()

        # Determine the add and delete entries for the diff
        if new_meters:
            add_meter_entries, delete_meter_entries = self.external_diff_function_from_url(CONFIGURATION_METERS)(new_entries=new_meters, old_entries=old_meters)
        else:
            add_meter_entries, delete_meter_entries = None, None

        if new_groups:
            add_group_entries, delete_group_entries = self.external_diff_function_from_url(CONFIGURATION_GROUPS)(new_entries=new_groups, old_entries=old_groups)
        else:
            add_group_entries, delete_group_entries = None, None

        if new_flows:
            add_flow_entries, delete_flow_entries = self.external_diff_function_from_url(CONFIGURATION_FLOWS)(new_entries=new_flows, old_entries=old_flows)
        else:
            add_flow_entries, delete_flow_entries = None, None

        return self.diff_openflow_entries_add_delete(add_meter_entries, delete_meter_entries, add_group_entries, delete_group_entries, add_flow_entries, delete_flow_entries, ignore_system=ignore_system)

    def diff_openflow_entries_add_delete(self, add_meter_entries=None, delete_meter_entries=None, add_group_entries=None, delete_group_entries=None, add_flow_entries=None, delete_flow_entries=None, ignore_system=True):
        # Prevent deleting entries with the SystemTag
        responses = list()

        if ignore_system:
            if delete_meter_entries:
                delete_meter_entries -= delete_meter_entries.has_attribute_value("system", True)
            if delete_group_entries:
                delete_group_entries -= delete_group_entries.has_attribute_value("system", True)
            if delete_flow_entries:
                delete_flow_entries -= delete_flow_entries.has_attribute_value("system", True)

        # First process entries that can be modified
        if add_meter_entries:
            add_meter_entries, delete_meter_entries, mod_responses = self.update_openflow_entries(object_type=CONFIGURATION_METERS, add_entries=add_meter_entries, delete_entries=delete_meter_entries)
            responses.extend(mod_responses)
        
        if add_group_entries:
            add_group_entries, delete_group_entries, mod_responses = self.update_openflow_entries(object_type=CONFIGURATION_GROUPS, add_entries=add_group_entries, delete_entries=delete_group_entries)
            responses.extend(mod_responses)
        
        if add_flow_entries:
            add_flow_entries, delete_flow_entries, mod_responses = self.update_openflow_entries(object_type=CONFIGURATION_FLOWS, add_entries=add_flow_entries, delete_entries=delete_flow_entries)
            responses.extend(mod_responses)

        # Second add entries
        if add_meter_entries:
            responses.extend(self.add_objects(url=CONFIGURATION_METERS, objects=add_meter_entries))

        if add_group_entries:
            responses.extend(self.add_objects(url=CONFIGURATION_GROUPS, objects=add_group_entries))

        if add_flow_entries:
            responses.extend(self.add_objects(url=CONFIGURATION_FLOWS, objects=add_flow_entries))

        # Third delete entries
        if delete_meter_entries:
            responses.extend(self.delete_objects(url=CONFIGURATION_METERS, objects=delete_meter_entries))

        if delete_group_entries:
            responses.extend(self.delete_objects(url=CONFIGURATION_GROUPS, objects=delete_group_entries))

        if delete_flow_entries:
            responses.extend(self.delete_objects(url=CONFIGURATION_FLOWS, objects=delete_flow_entries))

        return responses

    def update_openflow_entries(self, object_type, add_entries, delete_entries):
        remaining_delete_entries = list()
        modify_entries = list()
        for delete_entry in delete_entries:
            if delete_entry.get_attribute("linked_add"):
                modify_entries.append(delete_entry)
                add_entries.pop(add_entries.index(delete_entry.get_attribute("linked_add")[0]))
            else:
                remaining_delete_entries.append(delete_entry)

        if modify_entries:
            responses = self.modify_objects(url=object_type, objects=modify_entries, command="PUT")
        else:
            responses = list()

        return add_entries, remaining_delete_entries, responses

    def delete_bad_openflow_entries(self, object_type):
        entries = self.get_objects(url=object_type)
        for entry in entries[::]:
            if entry["node"] == None:
                self.delete_object(object_id=entry["id"], url=object_type)
            else:
                node_id = entry["node"]
                result = self.get_configuration_node(node_id)
                if not result:
                    self.delete_object(object_id=entry["id"], url=object_type)

    def delete_all_bad_openflow_entries(self):
        for object_type in (CONFIGURATION_FLOWS, CONFIGURATION_GROUPS, CONFIGURATION_METERS):
            self.delete_bad_openflow_entries(object_type)
