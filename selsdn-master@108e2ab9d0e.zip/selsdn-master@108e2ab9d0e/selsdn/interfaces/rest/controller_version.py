"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Class to simplify comparisons between SEL-5056 versions
"""


class ControllerVersion:
	def __init__(self, version):		
		if version is None:
			self._version = None
		else:
			self._version = str(version)[0:3]

	@staticmethod
	def _break_down_octets(value):
		converted_value = str(value).replace(".", "")
		groups = list()
		for index, digit in enumerate(converted_value):
			groups.append(converted_value[:index+1])
		return map(int, groups)

	def __eq__(self, other):
		this, that = self._break_down_octets(self.version), self._break_down_octets(other)
		for this_octet, that_octet in zip(this, that):
			if this_octet != that_octet:
				return False
		return True

	def __lt__(self, other):
		return self != other and self <= other

	def __le__(self, other):
		this, that = self._break_down_octets(self.version), self._break_down_octets(other)
		for this_octet, that_octet in zip(this, that):
			if this_octet > that_octet:
				return False
		return True

	def __ne__(self, other):
		return not self == other

	def __gt__(self, other):
		return not self <= other

	def __ge__(self, other):
		return self == other or not self <= other

	def __str__(self):
		return str(self._version)

	@property
	def version(self):
		return self._version
	
	@version.setter
	def version(self, value):
		self._version = value
