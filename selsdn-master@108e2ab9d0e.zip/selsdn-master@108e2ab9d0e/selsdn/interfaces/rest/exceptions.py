class SocketException(Exception):
    pass


class RESTException(Exception):
    @property
    def code(self):
        return "?"


class RequestError(RESTException):
    @property
    def code(self):
        return "?"  


class Code400Error(RequestError):
    @property
    def code(self):
        return "4XX"


class BadRequestError(Code400Error):
    @property
    def code(self):
        return 400


class UnauthorizedError(Code400Error):
    @property
    def code(self):
        return 401


class ForbiddenError(Code400Error):
    @property
    def code(self):
        return 403


class NotFoundError(Code400Error):
    @property
    def code(self):
        return 404


class ConflictError(Code400Error):
    @property
    def code(self):
        return 409  


class Code500Error(RequestError):
    @property
    def code(self):
        return "5XX"


class InternalServerError(Code500Error):
    @property
    def code(self):
        return 500
