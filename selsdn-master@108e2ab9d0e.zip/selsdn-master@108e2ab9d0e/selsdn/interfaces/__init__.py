try:
    from .pyselflow import PyselflowInterface
except ImportError:
    pass
from .rest import RESTInterface
