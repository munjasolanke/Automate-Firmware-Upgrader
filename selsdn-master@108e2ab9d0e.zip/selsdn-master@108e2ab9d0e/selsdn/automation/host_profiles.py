from collections import MutableMapping

class HostProfiles(MutableMapping):
    """A dictionary that applies an arbitrary key-altering
       function before accessing the keys"""

    def __init__(self, *args, **kwargs):
        self.profiles = dict()
        self.errors = dict()
        self.update(dict(*args, **kwargs))  # use the free update to set keys

    def __getitem__(self, key):
        return self.profiles[self.__keytransform__(key)]

    def __setitem__(self, key, value):
        self.profiles[self.__keytransform__(key)] = value

    def __delitem__(self, key):
        del self.profiles[self.__keytransform__(key)]

    def __iter__(self):
        return iter(self.profiles)

    def __len__(self):
        return len(self.profiles)

    def __keytransform__(self, key):
        return key

    def __repr__(self):
        return str(self.profiles)

