"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Base classes for networked and interfaced objects.
"""

from ipaddress import IPv4Interface, IPv4Network

from .named_object import NamedObject
from ..openflow.core.match_fields import EthMatch, Ipv4Match

class InterfaceIPAddress(Ipv4Match):
    @staticmethod
    def is_valid_mask_bits(value, mask):
        """Checks if the address and mask conform to the rules of OpenFlow
        masking. Raises an error if they are not integers.

        Arguments:
            value {int} -- match field address value
            mask {int} -- the mask of the address

        Returns:
            {bool} -- false if a value binary digit is 1 masked by 0
        """
        if not isinstance(value, int):
            raise TypeError("Value must be a number not {} of type {}".format(value, type(value)))

        if not isinstance(mask, int):
            raise TypeError("Mask must be a number not {} of type {}".format(mask, type(mask)))

        return True

    @property
    def subnet(self):
        return self.mask
    


class NetworkedObject(NamedObject):
    """Defines an object that can be part of one or more networks.
    """

    def __init__(self, name, networks=None, *args, **kwargs):
        """Sets up a networked object with the given name and networks.

        Arguments:
            name {str} -- the name of the object

        Keyword Arguments:
            networks {str/list} -- a network or list of networks (default: {None})
        """
        super().__init__(name, *args, **kwargs)
        self.networks = list()
        if networks:
            self.add_networks(networks)

    def is_in_network(self, value):
        """Checks whether the object includes a given network among networks
        that it belongs to.

        Arguments:
            value {str} -- queried network

        Returns:
            {bool} -- True if the value is found in the object's network list
        """
        return value in self.networks

    def is_in_networks(self, values):
        """Checks whether the object belongs one of the given networks.

        Arguments:
            value {list} -- list of networks

        Returns:
            {bool} -- True if one of the values is found in the object's network list
        """
        for value in values:
            if value in self.networks:
                return True
        return False

    def is_in_all_networks(self, values):
        for value in values:
            if value not in self.networks:
                return False
        return True

    def is_only_in_networks(self, values):
        """Checks whether the object belongs one of the given networks.

        Arguments:
            value {list} -- list of networks

        Returns:
            {bool} -- True if one of the values is found in the object's network list
        """
        for value in values:
            if value not in self.networks:
                return False
        return True

    def add_network(self, value):
        """Adds a network to the object's list of networks.

        Arguments:
            value {str} -- the new network being added
        """
        if value is not None and value not in self.networks:
            self.networks.append(value)

    def add_networks(self, values):
        for value in values:
            self.add_network(value)


class InterfacedObject(NetworkedObject):
    """Defines a network object that has an address interface.
    """

    def __init__(self, name, mac_address=None, ip_address=None,
                 subnet=None, default_gateway=None, mode=None,
                 *args, **kwargs):
        """Sets up a network object with the given addresses, gateway and mode.
        Throws an error if the default gateway is not in the subnet.

        Arguments:
            name {str} -- the name of the object

        Keyword Arguments:
            mac_address {object/str} -- the MAC address of the object (default: {None})
            ip_address {object/str} -- the IPv4 address of the object (default: {None})
            subnet {object/str} -- the IPv4 mask of the object (default: {None})
            default_gateway {object/str} -- the default gateway of the object (default: {None})
            mode {str} -- the network mode, defaulting to Failover (default: {None})
        """

        super().__init__(name=name, *args, **kwargs)

        self._mac_address = None if not mac_address else EthMatch(mac_address)
        self._ip_addresses = list()
        if ip_address:
            if isinstance(ip_address, list):
                for index, ip_addr in enumerate(ip_address):
                    if isinstance(subnet, list) and len(subnet)-1 >= index:
                        this_subnet = subnet[index]
                    elif isinstance(subnet, list) and len(subnet) > 0:
                        this_subnet = subnet[0]
                    elif isinstance(subnet, list) and len(subnet) == 0:
                        this_subnet = None
                    else:
                        this_subnet = subnet
                    self.add_ip_address(ip_addr, this_subnet)
            else:
                self.add_ip_address(ip_address, subnet)

        if isinstance(default_gateway, NetworkedObject) or hasattr(default_gateway, "ports"):
            self._default_gateway = default_gateway
        else:
            self._default_gateway = None if not default_gateway else Ipv4Match(default_gateway)
        self._mode = mode
        self._related_ports = list()

        # Check that the IP addresses make sense
        if self.subnet and self.ip_address and self.default_gateway:
            network = IPv4Network('/'.join([self.ip_address, self.subnet]), strict=False)
            if not IPv4Interface(str(self.default_gateway)) in network:
                raise ValueError("The default gateway {} for port {} is not in its subnet {}".format(self.default_gateway, self.print_name, network))

    def add_ip_address(self, ip_address, subnet=None):
        # TODO Check if the IP address is already present
        self._ip_addresses.append(InterfaceIPAddress(ip_address, subnet))
        return True

    def add_related_port(self, other_port):
        """Adds a related port to the object's list of related ports, if it is
        not listed already, and vice versa.

        Arguments:
            other_port {object} -- the port being added
        """
        if other_port not in self.related_ports:
            self._related_ports.append(other_port)
        
        if other_port == self:
            raise ValueError("Cannot add port {} to it's own related ports {}".format(other_port, self))

        if self not in other_port.related_ports:
            other_port.add_related_port(self)

    @property
    def related_ports(self):
        """Returns the list of related ports.
        """
        return self._related_ports

    @property
    def mac_address(self):
        """Returns the MAC address.
        """
        if self._mac_address:
            return self._mac_address.value

    @mac_address.setter
    def mac_address(self, value):
        """Returns the MAC address.
        """
        self._mac_address = EthMatch(value)

    @property
    def ip_address(self):
        """Returns the IPv4 address.
        """
        if self._ip_addresses:
            return self._ip_addresses[0].value

    @ip_address.setter
    def ip_address(self, value):
        """Returns the IPv4 address.
        """
        self.add_ip_address(value)

    @property
    def ip_addresses(self):
        return [ip_address.value for ip_address in self._ip_addresses]

    @property
    def subnet(self):
        """Returns the IPv4 mask.
        """
        if self._ip_addresses:
            return self.subnets[0]

    @property
    def subnets(self):
        return [ip_address.subnet for ip_address in self._ip_addresses]
    

    @property
    def network_address(self):
        """Returns the IPv4 network address with the mask applied.
        """
        if self.ip_address and self.subnet:
            return str(IPv4Interface("/".join([self.ip_address, self.subnet])).network).split("/")[0]

    @property
    def default_gateway(self):
        """Returns the default gateway.
        """
        if self._default_gateway:
            if hasattr(self._default_gateway, 'ip_address'):
                return self._default_gateway
            else:
                return self._default_gateway.value

    @property
    def mode(self):
        """Returns the network mode.
        """
        return self._mode

    def __eq__(self, other):
        """Two interfaced network objects are equal if they have equal MAC
        addresses(if applicable), equal IPv4 addresses and masks, equal default
        gateways, and have the same name.

        Arguments:
            other {object} -- network object used for comparison

        Returns:
            {bool} -- True if the objects are equal
        """
        # MAC Address will be found if the switch is adopted
        # but probably not in the node entries from csv
        if self.mac_address and other.mac_address and self.mac_address != other.mac_address:
            return False
        return super().__eq__(other) and \
            self.ip_address == other.ip_address and \
            self.default_gateway == self.default_gateway and \
            self.subnet == other.subnet

    # def __hash__(self):
    #   return super().__hash__() + str(self.ip_address) + \
    #       str(self.default_gateway) + str(self.default_gateway) + str(subnet)
