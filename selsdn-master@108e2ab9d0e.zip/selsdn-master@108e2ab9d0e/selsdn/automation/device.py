"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes for the different types of devices found in a selsdn network.
"""

from collections import OrderedDict
from ipaddress import IPv4Address

from .named_object import NamedObject
from .port import Port
from . import DEVICE_PORT_SEPARATOR

from ..openflow.core.ports import LocalPort, PhysicalPort
from ..openflow.core.match_fields import Ipv4Match, EthMatch, InPortMatch


class Device(NamedObject):
    """Device objects hold device information, such as IP addresses and number
    of ports.
    """

    def __init__(self, name, *args, **kwargs):
        """Initializes a device object.

        Arguments:
            name {str} -- the name of the device
        """
        super().__init__(name=name, *args, **kwargs)

    def __repr__(self):
        """String representation of a device object.

        Returns:
            {str} -- "[device type]:[device name]"
        """
        return "{}{}{}".format(self.__class__.__name__, DEVICE_PORT_SEPARATOR, self.name)

    def overlaps(self, other):
        """Two devices with the same name overlap.

        Arguments:
            other {device} -- another device used in comparison

        Returns:
            {bool} -- True if the devices overlap
        """
        return self.name == other.name

    @property
    def owner(self):
        """A device's owner property is itself.
        """
        return self

    def __hash__(self):
        """Converts the device's name and type(class) into a hashed numeral.

        Returns:
            {int} -- the device's name and class in hash format
        """
        return sum([ord(x) * index for index, x in enumerate("-".join([self.__class__.__name__, str(self.name)]))])


class PortDevice(Device):
    """A device object that has ports.
    """

    def __init__(self, name, ports=None, **kwargs):
        """Creates a new device object with ports. Throws an error if an
        incorrectly formatted port is provided in the list.

        Accepts additional device and port arguments to be used in constructing
        associated device and port objects. These arguments must be formatted
        as dictionary keywords- the following pairs will be 'donated' to newly
        constructed port objects:
                "mac_address":<value>
                "ip_address":<value>
                "subnet":<value>
                "default_gateway":<value>
                "mode":<value>
                "networks":<value>
                "associations":<value>

        Arguments:
            name {str} -- the name of the device

        Keyword Arguments:
            ports {list} -- list of ports (default: {None})

        Variable-Length Arguments:
            {dict} -- port and device arguments used for building those objects
        """
        device_args, port_args = self.filter_kwargs(kwargs)
        super().__init__(name=name, **device_args)

        self._ports = OrderedDict()

        # This is if the derived class is taking care of the port assignments
        if ports is False:
            pass
        elif ports is None and port_args:
            port_args["name"] = 0
            port = self.build_port(**port_args)
            self.add_port(port)
        elif type(ports) is not str and hasattr(ports, '__getitem__'):
            for port in ports:
                if isinstance(port, Port):
                    self.add_port(port)
                else:
                    port_args["name"] = port
                    port = self.build_port(**port_args)
                    self.add_port(port)
        elif isinstance(ports, int):
            for port_index in range(0, ports):
                port_args["name"] = port_index
                port = self.build_port(**port_args)
                self.add_port(port)
        elif ports is None:
            # The user may add ports later
            pass
        else:
            raise TypeError("Unknown format for ports {}".format(type(ports)))

        if len(self.ports) == 1:
            self.ports[0]._mode = ""

    def filter_kwargs(self, kwargs):
        """Sorts a variable number of arguments in dictionary format, to
        separate arguments used in constructing port objects from other
        arguments. Returns each group as a dictionary.

        Arguments:
            kwargs {dict} -- args that are 'donated' to constructors

        Returns:
            {tuple} -- format (A,B)
                A {dict} -- device args(not used to initialize ports)
                B {dict} -- port args(used for initializing ports)
        """
        port_args = dict()
        device_args = dict()
        for arg, value in kwargs.items():
            if arg in ("mac_address", "ip_address", "subnet",
                       "default_gateway", "mode",
                       "networks", "associations"):

                port_args[arg] = kwargs.get(arg)
            else:
                device_args[arg] = kwargs.get(arg)
        return device_args, port_args

    def build_port(self, **kwargs):
        """Creates a new port object using the given arguments as constructor
        arguments.

        Variable-Length Arguments:
            {dict} -- keyword args 'donated' to the new port object

        Returns:
            {object} -- port initialized using this method's args as its own
        """
        kwargs["owner"] = self
        return Port(**kwargs)

    def is_in_network(self, value):
        """Checks to see if one of a device's ports are in a network. If no
        ports are in the given network, the device does not belong to it.

        Arguments:
            value {object} -- the network being checked for

        Returns:
            {bool} -- True if at least one port is in the network
        """
        return self.is_in_networks([value])
        for port in self.local_ports:
            if port.is_in_network(value):
                return True
        return False

    def is_in_networks(self, values):
        for port in self.local_ports:
            if port.is_in_networks(values):
                return True
        return False

    @property
    def networks(self):
        """Returns the list of networks the device belongs to, as ordered by
        putting them in a set.
        """
        result = set()
        for port in self.local_ports:
            result.update(port.networks)
        return list(result)

    def get_ports_by_network(self, network):
        """Searches for all ports of the device that belong to a given network.

        Arguments:
            network {str} --the network the ports belong to

        Returns:
            {list} -- all ports of the device that belong to the network
        """
        return [port for port in self.local_ports if port.is_in_networks([network])]

    def get_ports_by_networks(self, networks):
        """Searches for all ports of the device that belong to a given network.

        Arguments:
            network {str} --the network the ports belong to

        Returns:
            {list} -- all ports of the device that belong to the network
        """
        return [port for port in self.local_ports if port.is_in_networks(networks)]

    def add_ports(self, ports):
        """Adds multiple port objects to the device's dictionary of ports.
        Ports without names are assigned their respective index numbers.

        Arguments:
            ports {list} -- the list of ports to be added
        """
        for port in ports:
            self.add_port(port)

    def add_port(self, port=None):
        """Adds a port object to the device's dictionary of ports. Ports
        without names are assigned their respective index numbers.

        Arguments:
            port {object} -- the port to be added
        """
        next_index = len(self.ports)
        if isinstance(port, Port):
            if not port.name:
                port.name = next_index
            self._ports[port.name] = port
            port.owner = self
        elif isinstance(port, int):
            self._ports[port] = Port(name=port, owner=self)
        else:
            self._ports[next_index] = Port(name=next_index, owner=self)

    def set_port(self, port, end):
        """Sets the end(connected) port for one of the device's ports.

        Arguments:
            port {object} -- the device's port
            end {object} -- the end(connected) port
        """
        if isinstance(port, Port):
            port.end = end
        else:
            self._ports[port].end = end

    def get_port(self, number):
        """Gets a port from the device's dictionary of ports.

        Arguments:
            number {*} -- the port being searched for

        Returns:
            {object} -- the port(None if not found)
        """
        return self._ports.get(number, None)

    def add_connection(self, port, end):
        """NOTE [DEPRECATED FUNCTION] DO NOT USE
        """
        if self._ports[port] is not None:
            raise ValueError("Port {} already connected to port {}".format(port, self.ports[port]))
        else:
            raise

    def remove_connection(self, port):
        """Removes a port's connection(it no longer has an end port to be
        connected with).

        Arguments:
            port {object} -- breaks this port's connection
        """
        self._ports[port].end = None

    def is_connected(self, network=None):
        """Checks if the device is connected to anything.

        Arguments:
            network {object} -- Network to test connection to

        Returns:
            {bool} -- True if one or more ports are connected
        """
        for port in self.ports:
            if port.is_connected(network):
                return True
        else:
            return False

    @property
    def associations(self):
        """Returns the list of a device's associations, and the associations of
        its ports.
        """
        associations = list()
        for port in self.ports:
            associations.extend(port.associations)
        return associations

    @property
    def port(self):
        """Returns the first added port of the device.
        """
        if self.ports:
            return self.ports[0]

    @property
    def ports(self):
        """Returns a list of the device's ports.
        """
        return list(self._ports.values())

    @property
    def mode(self):
        """Returns the network mode of the device.
        """
        if self.ports:
            return self.ports[0].mode

    @property
    def local_ports(self):
        """Returns a list of the device's ports. Alias for the ports property.
        """
        return self.ports

    def get_local_port(self, number):
        """Gets a port from the device's dictionary of ports. Alias for
        get_port().

        Arguments:
            number {*} -- the port being searched for

        Returns:
            {object} -- the port(None if not found)
        """
        return self.get_port(number)

    @property
    def network_address(self):
        """Returns the network address of the device.
        """
        if self.ports:
            return self.ports[0].network_address

    @property
    def other_mac_address(self):
        """Returns the MAC Address of the device.
        """
        return None

    @property
    def mac_address(self):
        """Returns the MAC address of the device's first added port(normally
        the MAC address of the device).
        """
        if self.ports:
            return self.ports[0].mac_address


    @property
    def ip_address(self):
        """Returns the IPv4 address of the device's first added port(normally
        the IPv4 address of the device).
        """
        if self.ports:
            return self.ports[0].ip_address

    @property
    def ip_addresses(self):
        """Returns the list of all IPv4 addresses of the device's ports.
        """
        ip_addresses = list()
        for p in self.local_ports:
            if p.ip_address:
                ip_addresses.extend(p.ip_addresses)
        return ip_addresses

    @property
    def mac_addresses(self):
        """Returns the list of all MAC addresses of the device's ports.
        """
        mac_addresses = list()
        for p in self.ports:
            if p.mac_address:
                mac_addresses.append(p.mac_address)
        return mac_addresses

    @property
    def subnet(self):
        """Returns the IPv4 subnet mask of the device.
        """
        if self.ports:
            return self.ports[0].subnet

    @property
    def default_gateway(self):
        """Returns the default gateway of the device.
        """
        if self.ports:
            return self.ports[0].default_gateway

    def __eq__(self, other):
        """TODO [WIP] this is wrong, but ports for diff are not yet working
        """
        return super().__eq__(other)  # and self.ports == other.ports

    # def __hash__(self):
    #	return super().__hash__() #+ str(self.ports)

    def __hash__(self):
        """Converts a device object with ports into a hashed numeral.

        Returns:
            {int} -- the device object in hash format
        """
        return super().__hash__() + sum([ord(x) * index for index, x in enumerate("-".join([str(self.networks), str(self.ip_address), str(self.associations) + str(self.ports) + str(self.mode)]))])

    def overlaps(self, other):
        """Two devices with port overlap if they are the same type of device
        with the same name.

        Arguments:
            other {device} -- another device used for comparison

        Returns:
            {bool} -- True if the devices overlap
        """
        return (isinstance(self, other.__class__) or isinstance(other, self.__class__)) and self.name == other.name

    def diff_eq(self, other):
        """Checks whether two devices are equal enough for a diffing function
        to treat them as equal, i.e. if they are the same type of device with
        the same name. Alias of overlaps().

        Arguments:
            other {device} -- another device used for comparison

        Returns:
            {bool} -- True if the devices overlap
        """
        return self.overlaps(other)

    def find_connected_openflow_switch_port(self):
        for port in self.ports:
            returned_port = port.find_connected_openflow_switch_port()
            if returned_port:
                return returned_port
        else:
            return None

    def find_connected_openflow_switch_ports(self):
        returned_ports = list()
        for port in self.ports:
            returned_port = port.find_connected_openflow_switch_ports()
            if returned_port:
                returned_ports.extend(returned_port)
        return returned_ports


class SwitchManagementDevice(PortDevice):
    pass


class NetworkDevice(PortDevice):
    """Base class for devices categorized as network devices.
    """
    pass


class RouterDevice(NetworkDevice):
    """Defines a router as a type of device object.
    """
    def __init__(self, name, *args, **kwargs):
        """Sets up a new router device object.

        Arguments:
            name {str} -- the name of the router
        """
        super().__init__(name=name, *args, **kwargs)

    def add_port(self, port):
        """Adds a port to the router. Throws an error if the port object is
        missing the router's IPv4 address and subnet mask data.

        Arguments:
            port {object} -- a port that is part of the router
        """
        if not port.ip_address or not port.subnet:
            raise ValueError("Router port must have an ip address and a subnet mask")
        super().add_port(port)


class TraditionalSwitchDevice(NetworkDevice):
    """Defines a traditional switch as a type of device object.
    """

    def __init__(self, name, *args, **kwargs):
        """Sets up a traditional switch device object.

        Arguments:
            name {str} -- the name of the switch

        Variable-Length Arguments:
            {dict} -- the value of key "ports" should be the total number of
                ports, formatted as an int
        """
        if isinstance(kwargs["ports"], int):
            kwargs["ports"] = range(1, kwargs["ports"] + 1)
        super().__init__(name=name, mode="switch", *args, **kwargs)

    @property
    def local_ports(self):
        """Returns an empty list.
        """
        return list()

    @property
    def networks(self):
        """Returns the list of networks the switch belongs to, in order.
        """
        result = set()
        for port in self.ports:
            result.update(port.networks)
        return list(result)

    def is_in_network(self, value):
        """Checks whether any of the switch's ports are connected to a network.
        If no ports are in the network, the switch does not belong to it.

        Arguments:
            value {object} -- the network being checked for

        Returns:
            {bool} -- True if at least one port is in the network
        """
        for port in self.ports:
            if port.is_in_network(value):
                return True
        return False


class OpenFlowDevice(NetworkDevice):
    """Base class for devices categorized as OpenFlow devices.
    """

    def __init__(self, name, datapath_id=None, *args, **kwargs):
        """Shared initialization features for all OpenFlow devices.

        Arguments:
            name {str} -- the name of the device

        Keyword Arguments:
            datapath_id {*} -- the datapath ID of the device (default: {None})
        """
        super().__init__(name=name, *args, **kwargs)
        self.datapath_id = datapath_id
        self.switch_ports = self.ports

    @property
    def datapath_id(self):
        """Returns the device's datapath ID.
        """
        return self._datapath_id

    @datapath_id.setter
    def datapath_id(self, value):
        """Setter for the device's datapath ID. Converts the datapath ID used
        in initialization to the correct format. Throw an error if the datapath
        ID exists but is not a string or integer.

        Arguments:
            value {*} -- the datapath ID
        """
        if value is None:
            self._datapath_id = None
        elif type(value) is str:
            self._datapath_id = value.replace(':', '').replace('-', '').lower().zfill(16)
        elif type(value) is int:
            self._datapath_id = hex(value)[2:].lower().zfill(16)
        else:
            raise TypeError("Unable to interpret {} as a datapath ID for switch {}".format(value, self.name))


class SELOpenFlowDevice(OpenFlowDevice):
    pass


class SEL2740SLogServer:
    def __init__(self, name="default", openflow=None, link=None, security=None, configuration=None, system_integrity=None, chassis_and_module=None):
        self.name = name

        self.openflow = openflow 
        self.link = link
        self.security = security 
        self.configuration = configuration
        self.system_integrity = system_integrity
        self.chassis_and_module = chassis_and_module

    @property
    def chassis(self):
        return self.chassis_and_module

    @property
    def system(self):
        return self.system_integrity

    def is_all_with_same_severity(self):
        if self.openflow == self.link == self.security == self.configuration == self.system_integrity == self.chassis_and_module:
            return self.openflow
        else:
            return False

    @property
    def categories(self):
        return {"chassis_and_module": self.chassis_and_module, "configuration": self.configuration,
                "link": self.link, "openflow": self.openflow, "security": self.security,
                "system_integrity": self.system_integrity}


    @staticmethod
    def build_from_all_categories(severity, name="default"):
        return SEL2740SSyslogServer( name=name, openflow=severity, link=severity, security=severity, configuration=severity, system_integrity=severity, chassis_and_module=severity)

    def __eq__(self, other):
        return type(self) == type(other) and self.categories == other.categories

    @property
    def class_name(self):
        return "Syslog Server"


class SEL2740SLocalEvents(SEL2740SLogServer):
    @property
    def class_name(self):
        return "Local Events"


class SEL2740SAlarmContact(SEL2740SLogServer):
    @property
    def class_name(self):
        return "Alarm Contact"


class SEL2740SSyslogServer(SEL2740SLogServer):
    def __init__(self, ip_address, name="default", port=514, transport_type="UDP", openflow=None, link=None, security=None, configuration=None, system_integrity=None, chassis_and_module=None):
        super().__init__(name=name, openflow=openflow, link=link, security=security, configuration=configuration, system_integrity=system_integrity, chassis_and_module=chassis_and_module)
        self.ip_address = ip_address
        self.port = port
        self.transport_type = transport_type

    @staticmethod
    def build_from_all_categories(ip_address, severity, name="default", port=514, transport_type="UDP"):
        return SEL2740SSyslogServer(ip_address=ip_address, name=name, port=port, transport_type=transport_type, openflow=severity, link=severity, security=severity, configuration=severity, system_integrity=severity, chassis_and_module=severity)

    def __eq__(self, other):
        return super().__eq__(other) and self.ip_address == other.ip_address and\
        self.port == other.port and self.transport_type == other.transport_type


class SEL274XSDevice(SELOpenFlowDevice):
    """Defines the SEL2740S OpenFlow switch as a type of device object.
    """

    def __init__(self, name, controller_ip, default_gateway=None, front_subnet=None,
                 subnet=None, ports=[_ for _ in range(1, 20 + 1)], mac_address=None,
                 ip_address=None, datapath_id=None, snmp_enable=False, ptp_enable=False,
                 ntp_servers=None, back_name=None, front_name=None, front_ip_address=None,
                 front_mac_address=None, front_networks=None, front_associations=None,
                 front_default_gateway=None,
                 mode="IB", syslog_servers=None, local_events=None, alarm_contact=None, *args, **kwargs):
        """Sets up a new SEL2740S object with the necessary parameters.

        Sets the MAC address to the datapath ID unless a MAC address is
        provided in the variable length arguments. Sets the datapath ID to the
        MAC address unless a separate datapath ID is provided.

        Sets the default gateway to the controller IP if a default gateway is
        not provided in the variable length arguments.

        Sets up ports and servers, throwing an error if the requested config is
        invalid.

        Arguments:
            name {str} -- the name of the switch
            controller_ip {str} -- the IPv4 address of the SEL-5056 controller

        Keyword Arguments:
            ports {*} -- list or number of physical ports of the switch (default: {[_ for _ in range(1, 20 + 1)]})
            mac_address {str} -- MAC address of the switch (default: {None})
            datapath_id {*} -- the datapath ID of the switch (default: {None})
            snmp_enable {bool} -- True if SNMP is enabled for the switch (default: {False})
            ptp_enable {bool} -- True if PTP is enabled for the switch (default: {False})
            ntp_servers {list} -- list of NTP servers, max 3 (default: {None})]
            local_events {dict} -- Categories for local events with severity, None if nothing defined (keepy default)
            alarm_contact {dict} -- Categories for alarm contant, None if nothing defined (keepy default)

        Variable-Length Arguments:
            {dict} -- the values of keys "mac_address", "default_gateway" and
                "name" are used to set up switch data
        """
        device_args, port_args = self.filter_kwargs(kwargs)
        switch_ports = list()

        if front_default_gateway and not front_ip_address and not front_subnet:
            raise ValueError("If defining the default gateway {}, must also fill in both ip address {} and subnet {}".format(front_default_gateway, front_ip_address, front_subnet))


        if (front_ip_address or front_subnet or front_default_gateway) and not (front_ip_address and front_subnet):
            raise ValueError("If defining the front ip address {}, subnet {}, or default gateway {}, must fill in all three values".format(front_ip_address, front_subnet, front_default_gateway))

        if mode == "OOB":
            datapath_mac = front_mac_address
        elif mode == "IB":
            datapath_mac = mac_address

        if not datapath_id and datapath_mac:
            mac_address_object = EthMatch(datapath_mac)
            if not datapath_id:
                datapath_id = "0000" + mac_address_object.value
        elif datapath_id and not datapath_mac:
            if mode == "OOB":
                front_mac_address = datapath_id[4:].lower()
            else:
                mac_address = datapath_id[4:].lower()

        super().__init__(name=name, datapath_id=datapath_id, ports=False, ip_address=ip_address, **device_args)

        # Must be after init
        self._mode = mode

        # I add in all of the switches ports for so that I can map them to the switch ports
        if isinstance(ports, int):
            for port_index in range(0, ports):
                new_port = Port(name=port_index, mode=None)
                switch_ports.append(new_port)
        elif ports:
            self.add_ports(ports)

        self.switch_ports = self.ports[::]

        # Default the controller ip to be the default gateway
        if not (default_gateway or front_default_gateway):
            default_gateway = controller_ip

        # Default gateway is one or the other
        if front_default_gateway:
            self._default_gateway = front_default_gateway
        elif default_gateway:
            self._default_gateway = default_gateway

        # Setup Local Port
        if ip_address or mac_address:
            if not back_name:
                back_name = LocalPort.VALUE
            self._local_port = self.build_port(name=back_name, ip_address=ip_address, mac_address=mac_address, default_gateway=default_gateway, subnet=subnet, **port_args)
            self._local_port.owner = self
            self.fake_switch_host = SwitchManagementDevice(name=name, ip_address=ip_address, mac_address=mac_address, subnet=subnet, default_gateway=default_gateway, **port_args)
            self._local_port.end = self.fake_switch_host.get_port(0)
            self.fake_switch_host.get_port(0).end = self._local_port
        else:
            self._local_port = None
        
        if front_ip_address or front_mac_address:
            if not front_name:
                front_name = "Front"
            self._front_port = Port(owner=self, name=front_name, subnet=front_subnet, ip_address=front_ip_address, default_gateway=front_default_gateway, mac_address=front_mac_address, networks=front_networks, associations=front_associations, mode=None)
        else:
            self._front_port = None

        try:
            self._controller_ip = Ipv4Match(controller_ip)
        except ValueError:
            raise ValueError("{} is not a valid Controller IP address".format(controller_ip))
        self.applications = list()

        self.snmp_enable = snmp_enable
        self.ptp_enable = ptp_enable
        if not ntp_servers:
            self.ntp_servers = list()
        else:
            if len(ntp_servers) > 3:
                raise ValueError("Only up to three NTP servers supported")
            else:
                for ntp_address in ntp_servers:
                    try:
                        # Test that they are ip addresses
                        IPv4Address(ntp_address)
                    except ValueError:
                        raise ValueError("NTP server address {} is not a valid IPv4 address".format(ntp_address))

                for ntp_address in ntp_servers:
                    if IPv4Address(ntp_address).is_multicast:
                        raise ValueError("NTP server cannot be a multicast {}".format(ntp_address))

                self.ntp_servers = ntp_servers

        if syslog_servers:
            new_syslog_servers = list()
            for syslog_server in syslog_servers:
                if isinstance(syslog_server, dict):
                    syslog_server = SEL2740SSyslogServer(**syslog_server)
                new_syslog_servers.append(syslog_server)
            syslog_servers = new_syslog_servers

        if local_events and isinstance(local_events, dict):
            local_events = SEL2740SLocalEvents(**local_events)

        if alarm_contact and isinstance(alarm_contact, dict):
            alarm_contact = SEL2740SAlarmContact(**alarm_contact)

        self.syslog_servers = syslog_servers
        self.local_events = local_events
        self.alarm_contact = alarm_contact

    def add_network(self, network):
        """Adds a network to the list of networks that the switch's local port
        belongs to.

        Arguments:
            network {str} -- a network
        """
        self.local_port.networks.append(network)

    def add_networks(self, networks):
        for network in networks:
            self.add_network(network)

    @property
    def mode(self):
        """Returns the network mode of the device.
        """
        return self._mode

    @property
    def ptp_enable(self):
        """Returns True if PTP is enabled.
        """
        return self._ptp_enable

    @ptp_enable.setter
    def ptp_enable(self, value):
        """Setter for ptp_enable.

        Arguments:
            value {bool} -- True if PTP is enabled.
        """
        if type(value) is bool:
            self._ptp_enable = value
        else:
            raise ValueError("PTP enable must be True or False not {}".format(value))

    @property
    def snmp_enable(self):
        """Returns True if SNMP is enabled.
        """
        return self._snmp_enable

    @snmp_enable.setter
    def snmp_enable(self, value):
        """Setter for snmp_enabled.

        Arguments:
            value {bool} -- True if SNMP enabled.
        """
        if type(value) is bool:
            self._snmp_enable = value
        else:
            raise ValueError("SNMP enable must be True or False not {}".format(value))

    @property
    def mac_address(self):
        """Returns the MAC address of the switch.
        """
        return self.local_port.mac_address

    @property
    def ip_address(self):
        """Returns the IPv4 address of the switch.
        """
        if self.mode == "IB":
            return self.local_port.ip_address
        else:
            return self.front_port.ip_address

    @property
    def ip_addresses(self):
        """Returns the list of all IPv4 addresses of the device's ports.
        """
        ip_addresses = list()
        if self.mode == "IB":
            ip_addresses.append(self.local_port.ip_address)
            if self.front_port and self.front_port.ip_address:
                ip_addresses.append(self.front_port.ip_address)
        else:
            ip_addresses.append(self.front_port.ip_address)
            if self.local_port and self.local_port.ip_address:
                ip_addresses.append(self.local_port.ip_address)

        return ip_addresses

    @ip_address.setter
    def ip_address(self, value):
        """Returns the IPv4 address of the switch.
        """
        self.local_port.ip_address = value

    @property
    def subnet(self):
        """Returns the IPv4 subnet mask of the switch.
        """
        return self.local_port.subnet

    @property
    def default_gateway(self):
        """Returns the default gateway of the switch.
        """
        return self._default_gateway

    @property
    def controller_ip(self):
        """Returns the IPv4 address of the switch's SEL-5056 controller.
        """
        return self._controller_ip.value

    def add_application(self, application):
        """Adds an application to the switch.

        Arguments:
            application {object} -- an application
        """
        self.applications.append(application)

    @property
    def local_ports(self):
        """Returns the local port(s) of the switch, listified.
        """
        local_ports = list()
        if self._local_port:
            local_ports.append(self._local_port)
        if self._front_port:
            local_ports.append(self._front_port)
        return local_ports

    @property
    def local_port(self):
        """Returns the local port of the switch.
        """
        if self.local_ports:
            return self.local_ports[0]

    @property
    def front_port(self):
        return self._front_port
    
    def get_local_port(self, number):
        """Searches for a local port in the switch with the given port ID.
        Normally the local port has the ID number 0xfffffffe.

        Arguments:
            number {hexadecimal} -- the queried port number

        Returns:
            {object} -- the local port(if found), otherwise None
        """

        if LocalPort.is_valid_value(number):
            return self._local_port
        else:
            return super().get_local_port(number)

    def __eq__(self, other):
        """Two SEL-2740S switches are equal if they have the same name and are
        connected to the same SEL-5056 controller.

        Arguments:
            other {device} -- another SEL-2740S used in comparison

        Returns:
            {bool} -- True if the switches are equal
        """
        return super().__eq__(other) and self.controller_ip == other.controller_ip

    def __hash__(self):
        """Converts the switch's data into a hashed numeral.

        Returns:
            {int} -- the switch object in hash format
        """ 
        return super().__hash__() + sum([ord(x) * index for index, x in enumerate(str(self.controller_ip))])

    def diff_eq(self, other):
        """Two 2740S switches are equivalent for the purpose of diff checks if
        they have the same name, IPv4 address and subnet mask, controller IPv4
        address, default gateway, NTP servers, and PTP and SNMP enable
        settings.

        Arguments:
            other {device} -- another device used in comparison

        Returns:
            {bool} -- True if the devices are equivalent
        """
        return_value = super().diff_eq(other) and \
            self.controller_ip == other.controller_ip and \
            self.subnet == other.subnet and \
            self.default_gateway == other.default_gateway and \
            self.ip_address == other.ip_address and \
            self.ntp_servers == other.ntp_servers and \
            self.ptp_enable == other.ptp_enable and \
            self.snmp_enable == other.snmp_enable

        if return_value is False:
            return return_value

        # Allow defaults to remain by checking if one is from the SEL-5056 and one is not
        # If the one that is not is None, that means there was setting for that event type
        # So skip the comparison
        check_syslog_servers = True
        check_alarm_contact = True
        check_local_store = True
        if not self.get_attribute("$converted_from_5056") and other.get_attribute("$converted_from_5056"):
            if self.syslog_servers is None:
                check_syslog_servers = False
            if self.alarm_contact is None:
                check_alarm_contact = False
            if self.local_events is None:
                check_local_store = False

        if self.get_attribute("$converted_from_5056") and not other.get_attribute("$converted_from_5056"):
            if other.syslog_servers is None:
                check_syslog_servers = False
            if other.alarm_contact is None:
                check_alarm_contact = False
            if other.local_events is None:
                check_local_store = False

        if check_syslog_servers:
            if self.syslog_servers and other.syslog_servers:
                for self_syslog_server in self.syslog_servers:
                    for other_syslog_server in other.syslog_servers:
                        if self_syslog_server == other_syslog_server:
                            break
                    else:
                        return False

                for other_syslog_server in other.syslog_servers:
                    for self_syslog_server in self.syslog_servers:
                        if self_syslog_server == other_syslog_server:
                            break
                    else:
                        return False

        if check_local_store:
            if self.local_events != other.local_events:
                return False

        if check_alarm_contact:
            if self.alarm_contact != other.alarm_contact:
                return False

        if return_value:
            if self.front_port and other.front_port:
                if self.front_port.ip_address != other.front_port.ip_address:
                    return False
                elif self.front_port.subnet != other.front_port.subnet:
                    return False
            if self.front_port and not other.front_port:
                return False
            elif other.front_port and not self.front_port:
                return False

        return return_value

    def get_port(self, number):
        """Gets a port from the SEl-2740S's dictionary of ports.

        Arguments:
            number {*} -- the port being searched for

        Returns:
            {object} -- the port(None if not found)
        """
        return_value = None
        if number == InPortMatch("Local").value:
            return_value = self._local_port
        elif isinstance(number, str) and self.local_port and self.local_port.name == number:
            return_value = self._local_port
        elif isinstance(number, str) and self.front_port and self.front_port.name == number:
            return_value = self.front_port
        elif isinstance(number, str) and self._ports.get(PhysicalPort(number).value):
            return self._ports.get(PhysicalPort(number).value)
        else:
            return_value = self._ports.get(number, None)

        return return_value

class SEL2740SDevice(SEL274XSDevice):
    """Defines the SEL2740S OpenFlow switch as a type of device object.
    """

    def __init__(self, name, ports=[_ for _ in range(1, 20 + 1)],  *args, **kwargs):
        kwargs["ports"] = ports
        super().__init__(name, *args, **kwargs)


class SEL2742SDevice(SEL274XSDevice):
    def __init__(self, name, ports=[_ for _ in range(1, 12 + 1)],  *args, **kwargs):
        kwargs["ports"] = ports
        super().__init__(name, *args, **kwargs)


class EndDevice(PortDevice):
    """Base class for devices categorized as End devices.
    """

    def __init__(self, name, ports=(0,), mode="Failover", *args, **kwargs):
        """Common initialization functionality for setting up End devices.

        Arguments:
            name {str} -- the name of the device

        Keyword Arguments:
            ports {tuple}/{list} -- list of the device's ports (default: {(0,)})
            mode {str} -- network mode of the device (default: {"Failover"})
        """
        super().__init__(name=name, ports=ports, mode=mode, *args, **kwargs)


class ControllerDevice(EndDevice):
    """Defines Controller device objects as a type of End Device.
    """
    pass


class TwoMacDevice(EndDevice):
    """Defines End Devices with 2 MAC Addresses.
    """

    @property
    def other_mac_address(self):
        """Returns the second MAC Address of the device.
        """
        if self.mac_address:
            return hex(int(self.mac_address, 16) + 1)[2:].rjust(12, "0").lower()

    # def __hash__(self):
    #	return super().__hash__() + str(self.other_mac_address)
