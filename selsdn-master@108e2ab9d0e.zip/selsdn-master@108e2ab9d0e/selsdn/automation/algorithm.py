from collections import defaultdict, namedtuple
from functools import partial

from ..base.collection import FlowCollection, GroupCollection, NodeCollection, MeterCollection
from ..base.value import Value

from ..openflow.core.group_entry import AllGroup, FastFailoverGroup, SelectGroup, IndirectGroup
from ..openflow.core.action_bucket import ActionBucket
from ..openflow.core.actions import ACTIONS, Actions
from ..openflow.core.actions import Actions, OutputAction, GroupAction, SetQueueAction, SetVlanVidAction, PushVlanAction, PopVlanAction, DropAction, ACTIONS, SetVlanPcpAction
from ..openflow.core.ports import LocalPort, PhysicalPort
from ..openflow.core.match_fields import TcpDstMatch, UdpDstMatch, TcpSrcMatch, UdpSrcMatch
from ..openflow.core.meter_entry import MeterEntry

from ..openflow.validation.validate_entries import validate_flows_and_groups
from ..openflow.compact.flow_entry import CompactedFlowEntry

from ..interfaces.csv.flow_parser import FlowEntryParser

from .protocol import Ipv4Protocol, TcpProtocol, UdpProtocol, EthernetProtocol, PTPProtocol
from .application import UnicastApplication, MulticastApplication
from .device import SEL2740SDevice, Device, NetworkDevice
from .port import Port


class BaseAlgorithm:
    def __init__(self, node_entries, group_entries=None, starting_group=1000):
        self.flow_entries = FlowCollection()
        self.group_entries = GroupCollection(values=group_entries, starting_group=starting_group)
        self.meter_entries = MeterCollection()
        self.node_entries = NodeCollection(values=node_entries)
        self.switch_list = self.node_entries.has_type(SEL2740SDevice)

        node_list = list()
        node_dict = dict()
        for node in node_entries:
            node_dict[node.name] = node
            if isinstance(node, SEL2740SDevice):
                node_list.append(node)

        self._nodes = node_dict
        self.switch_nodes = node_list

        self.next_group_id = dict()
        for switch_node in self.switch_nodes:
            self.next_group_id[switch_node.name] = starting_group

    def port_number_to_port_id(self, port_id):
        return str(PhysicalPort(port_id))

    def get_switch_ports(self, node, switch):
        if isinstance(node, SEL2740SDevice):
            if switch == node:
                return [LocalPort.VALUE]
            else:
                return list()
        else:
            ports = list()
            for port in self.get_device_ports(node):
                if port.end.owner == switch:
                    ports.append(port.end.name)
            return ports

    def get_device_ports(self, node):
        return node.ports

    def get_switch_names(self, node):
        return [switch.name for switch in self.get_switches(node)]

    def get_switches(self, node):
        if not node:
            raise ValueError("Node cannot be none")
        if isinstance(node, SEL2740SDevice):
            return [node]
        elif isinstance(node, Port):
            return_value = self.resolve_port(node)
            if type(return_value) is list:
                return [port.owner for port in return_value]
            else:
                return [return_value.owner]
        else:
            return_values = list()
            for port in node.ports:
                return_value = self.resolve_port(port)
                if type(return_value) is list:
                    return_values.extend([port.owner for port in return_value])
                elif return_value:
                    return_values.append(return_value.owner)
            return return_values

    # I want to return just one thing
    def resolve_to_switch_port(self, port_object):
        return_value = self.resolve_port(port_object)
        if type(return_value) is list:
            return return_value[0]
        else:
            return return_value

    # Maybe return multiple things
    def resolve_port(self, port_object):
        if isinstance(port_object, Device):
            return self.resolve_port(port_object.ports[0])
        elif port_object.end and port_object.end.owner:
            if isinstance(port_object.owner, SEL2740SDevice):
                return port_object
            if isinstance(port_object.end.owner, SEL2740SDevice):
                return port_object.end
            else:
                return_values = list()
                for other_port_object in port_object.end.owner.ports:
                    if port_object.end != other_port_object and isinstance(other_port_object.owner, NetworkDevice):
                        return_value = self.resolve_port(port_object=other_port_object)
                        if return_value:
                            return_values.append(return_value)
                return return_values

    def get_priority(self, application):
        return 2

    def lookup_group_id_by_alias(self, node, alias):
        return self.group_entries.get_entry_by_alias(alias=alias, switch=node)

    def create_actions(self, actions, node=None):
        new_actions = Actions()

        for action_name, action_value in actions.items():
            new_actions.add(self.create_action(action_name=action_name, value=action_value, node=node))

        return new_actions

    def create_action(self, action_name, value, node=None):
        action_name = action_name.lower()

        if action_name == 'output':
            if node:
                entry = None

                if OutputAction.is_valid_value(value):
                    return OutputAction(value)
                else:
                    try:
                        device = self.get_node(value)
                        device_port = device.port.end.name
                    except AttributeError as e:
                        raise ValueError("There is no connection found for {} on switch {}. Check topology.".format(value, node))
                    return OutputAction(device_port)
            else:
                return OutputAction(value)
        elif action_name == 'group':
            if node:
                entry = None
                if type(value) is int:
                    entry = self.group_entries.get_entry_by_id(entry_id=value, switch=node)

                if not entry:
                    entry = self.lookup_group_id_by_alias(node=node, alias=value)
                if entry:
                    value = entry.entry_id
            return GroupAction(value)
        elif action_name == 'setqueue':
            return SetQueueAction(int(value))
        elif action_name == 'setvlanvid':
            return SetVlanVidAction(int(value))
        elif action_name == 'pushvlan':
            return PushVlanAction(0x8100)
        elif action_name == 'popvlan':
            return PopVlanAction()
        elif action_name == 'setvlanpcp':
            return SetVlanPcpAction(int(value))
        elif action_name == 'drop':
            return DropAction()
        else:
            raise TypeError("Unknown type '{}'".format(action_name))

    def get_next_group_id(self, node):
        if type(node) is str:
            node = self.get_node(node, required=True)
        next_group_id = self.next_group_id[node.name]
        self.next_group_id[node.name] += 1
        return next_group_id

    def get_node(self, node, required=False):
        if isinstance(node, Device):
            return node
        try:
            node_object = self.nodes[node]
        except KeyError as e:
            if required:
                raise ValueError("No such node '{}'".format(node))
            else:
                return None
        return node_object

    def add_flow_entry(self, flow_entry):
        self.flow_entries.append(flow_entry)

    def add_group_entry(self, group_entry):
        self.group_entries.append(group_entry)

    def add_comment_line(self, line=""):
        new_entry = CompactedFlowEntry(node='', entry_type='', table=line, priority=None)
        self.add_flow_entry(new_entry)

    def add_group_entry_from_data(self, node, group_id, group_type, name=None, buckets=None):
        if not buckets:
            raise ValueError("Adding a group entry with no action buckets {}({})".format(name, group_id))

        if group_type == 'All':
            entry = AllGroup(name=name, node=node, entry_id=group_id, action_buckets=buckets)
        elif group_type in ('FastFailover', 'FF'):
            entry = FastFailoverGroup(name=name, node=node, entry_id=group_id, action_buckets=buckets)
        elif group_type == 'Select':
            entry = SelectGroup(name=name, node=node, entry_id=group_id, action_buckets=buckets)
        elif group_type == 'Indirect':
            entry = IndirectGroup(name=name, node=node, entry_id=group_id, action_buckets=buckets)

        self.add_group_entry(entry)

        return entry

    def create_simple_ff_bucket_entry(self, output, watch_port=None, watch_group=None, none=None, **arguments):
        if watch_port is None:
            watch_port = output
        return self.create_bucket_entry(watch_port=watch_port, output=output, **arguments)

    def create_simple_bucket_entry(self, output=None, group=None, node=None):
        if output:
            actions = self.create_actions(actions={"output":output}, node=node)
        elif group:
            actions = self.create_actions(actions={"group":group}, node=node)
        else:
            actions = list()
        return ActionBucket(actions=actions)

    def create_bucket_entry(self, watch_port=None, watch_group=None, node=None, **arguments):
        actions = self.create_actions(actions=arguments, node=node)
        return ActionBucket(watch_port=watch_port, watch_group=watch_group, actions=actions)

    def create_bucket_entry_ingress(self, watch_port, **arguments):
        return self.create_bucket_entry(output="Ingress", watch_port=watch_port, **arguments)

    def add_meter_entry_from_data(self, name, node, entry_id, measurement_type, rate, burst_size=None, attributes=None):
        entry = MeterEntry(name=name, node=node, entry_id=entry_id, measurement_type=measurement_type, rate=rate, burst_size=burst_size, attributes=attributes)
        self.meter_entries.append(entry)

    def add_flow_entry_from_data(self, node, table=0, application=None, entry_type=None, code=None, inport=None, ethdst=None, ethtype=None, vlanvid=None, vlanvid_mask=None, vlanpcp=None, ipsrc=None, ipsrc_mask=None, ipdst_mask=None, ipdst=None, tu_src=None, tu_dst=None, output=None, group=None, priority=1000, name=None, queue=None, setvlanpcp=None, popvlan=False, pushvlan=False, setvlanvid=None, gototable=None, meter=None):
        if application:
            protocol = application.protocol
            entry_type = self.get_entry_type_from_application(application)

            new_queue = self.get_priority(application)
            if queue != 2 and queue is None:
                queue = new_queue

            if inport is None:
                inport = application.source.print_name
            elif isinstance(inport, Device):
                inport = inport.print_name
            elif isinstance(inport, Port):
                inport = inport.print_name

            if isinstance(application.protocol, Ipv4Protocol):
                if ipsrc is None:
                    ipsrc = application.source.print_name

            if isinstance(application, UnicastApplication):
                if ipdst is None:
                    ipdst = application.destination.print_name
                if group == output == None:
                    output = application.destination.print_name
            if ethdst is None and protocol.get('ethdst'):
                ethdst = protocol.get('ethdst').value
                ethdst_mask = protocol.get('ethdst').mask
            if vlanvid is None and protocol.get('vlanvid'):
                vlanvid = protocol.get('vlanvid').value
                vlanvid_mask = protocol.get('vlanvid').mask
            if ethtype is None and protocol.get('ethtype'):
                ethtype = protocol.get('ethtype').value

            if application.protocol.unidirectional and not name:
                name = str(application.name) + ' ' + application.source.print_name + '' if not inport else application.name + ' ' + application.source.print_name + ' ' + str(inport)
            elif not application.protocol.unidirectional and not name:
                #print(application.source.name, application.destination.name)
                name = str(application.name) + ' ' + application.source.print_name + ' ' + application.destination.print_name + ' ' if not inport else str(application.name) + ' ' + application.source.print_name + ' ' + application.destination.print_name + ' ' + str(inport)

            if isinstance(application, UnicastApplication):
                if "TCP" in entry_type:
                    if application.forward:
                        tu_dst = str(protocol.get(TcpDstMatch))
                    else:
                        tu_src = str(protocol.get(TcpSrcMatch))
                elif "UDP" in entry_type:
                    if application.forward:
                        tu_dst = str(protocol.get(UdpDstMatch))
                    else:
                        tu_src = str(protocol.get(UdpSrcMatch))
                else:
                    if code is None:
                        code = protocol.get('IpProto')

        if type(node) is list:
            nodes = list()
            for n in node:
                if type(n) is str:
                    nodes.append(n)
                else:
                    nodes.append(n.name)
            node = ",".join(nodes)

        if isinstance(node, SEL2740SDevice):
            node = node.name

        if isinstance(inport, Device):
            inport = inport.name
        elif isinstance(inport, Port):
            inport = inport.print_name
        
        if ipdst is None and ipsrc is None and entry_type is None:
            entry_type="L2"
        elif entry_type is None:
            entry_type="IP,ARP"

        if isinstance(vlanvid, Value):
            vlanvid_mask = vlanvid.mask
            vlanvid = vlanvid.value

        if vlanpcp and not vlanvid:
            vlanvid = "Present"

        new_entry = CompactedFlowEntry(node=node, table=table, entry_type=entry_type, name=name, priority=priority, code=code, inport=inport, ethdst=ethdst, ethtype=ethtype, vlanvid=vlanvid, vlanvid_mask=vlanvid_mask, vlanpcp=vlanpcp, ipsrc=ipsrc, ipsrc_mask=ipsrc_mask, ipdst=ipdst, ipdst_mask=ipdst_mask, tu_src=tu_src, tu_dst=tu_dst, output=output, group=group, queue=queue, popvlan=popvlan, pushvlan=pushvlan, setvlanpcp=setvlanpcp, setvlanvid=setvlanvid, gototable=gototable, meter=meter)

        #tuple_class = namedtuple('GenericDict', new_entry.dict.keys())
        #tuple_entry = tuple_class(**new_entry.dict)
        tuple_entry = new_entry.dict

        entries = FlowEntryParser(node_entries=self.node_entries, group_entries=self.group_entries).create_entries([tuple_entry])

        for entry in entries:
            self.make_adjustments(entry, application)
            if application:
                entry.add_attribute("Application", application.name)
            self.add_flow_entry(entry)
        return new_entry

    def make_adjustments(self, entry, application=None):
        pass

    def get_entry_type_from_application(self, application):
        if isinstance(application.protocol, TcpProtocol):
            return "TCP,ARP"
        elif isinstance(application.protocol, UdpProtocol):
            return "UDP,ARP"
        elif isinstance(application.protocol, Ipv4Protocol):
            return "IP,ARP"
        elif isinstance(application.protocol, EthernetProtocol):
            return "L2"
        else:
            raise ValueError("Unsupported protocol type {}".format(application.protocol))

    def get_priority(self, application):
        return application.priority_queue

    def validate_network(self):
        validate_flows_and_groups(flow_entries=self.flow_entries, group_entries=self.group_entries, collection_check=True)

    @property
    def nodes(self):
        return self._nodes


class BaseRingAlgorithm(BaseAlgorithm):
    def __init__(self, node_entries, ring_switches, group_entries=None, pcp_normal=7, pcp_resourced=6, starting_group=1000000, port_left="D2", port_right="D1"):
        super().__init__(node_entries=node_entries, group_entries=group_entries, starting_group=starting_group)
        if pcp_normal == pcp_resourced:
            raise ValueError("PCP Normal and PCP Reverse cannot be the same")
        self.pcp_normal = pcp_normal 
        self.pcp_resourced = pcp_resourced
        self.ring_switches = NodeCollection(values=ring_switches)
        self.port_left = port_left
        self.port_right = port_right

    def get_ring_ports(self):
        return (self.port_left, self.port_right)

    def get_switch_index(self, node):
        if type(node) is str:
            return self.ring_switches.index(self.node_entries.has_name(node)[0])
        else:
            return self.ring_switches.index(node)

    def get_left_right_ordering_of_switch_pair(self, switches):
        return (switches[0], switches[1]) if self.get_switch_index(switches[0]) < self.get_switch_index(switches[1]) else (switches[1], switches[0])

    def get_normal_and_reverse_path_switches(self, application):
        source, destination = application.source, application.destination
        source_switches, destination_switches = self.get_switches(source), self.get_switches(destination)
        
        is_left = self.is_direction_for_shortest_path_from_source_to_destination_lower(application.source, application.destination)

        left_destination_switch, right_destination_switch = destination_switches[0], destination_switches[0]

        left_source_switch, right_source_switch = source_switches[0], source_switches[0]

        if is_left:
            # normal path
            destination_index = self.get_switch_index(right_destination_switch)
            source_index = self.get_switch_index(left_source_switch)

            if destination_index > source_index:
                normal_path = self.ring_switches[destination_index+1:] + self.ring_switches[0:source_index]
            else:
                normal_path = self.ring_switches[destination_index+1:source_index]
        else:
            destination_index = self.ring_switches.index(left_destination_switch)
            source_index = self.ring_switches.index(right_source_switch)

            if source_index > destination_index:
                normal_path = self.ring_switches[source_index+1:] + self.ring_switches[0:destination_index]
            else:
                normal_path = self.ring_switches[source_index+1:destination_index]
        
        reverse_path = self.get_all_other_ring_switches(normal_path+destination_switches+source_switches)

        if not isinstance(normal_path, list):
            normal_path = [normal_path]

        return normal_path, reverse_path

    def get_all_other_ring_switches(self, switches):
        return self.ring_switches.remove(switches)

    def create_flow_entries_for_unicast_same_switches(self, application, top=True):
        self.add_flow_entry_from_data(application=application, node=self.get_switch(application.source))

    def create_flow_entries_for_unicast_different_switches(self, application):
        afe_forward = partial(self.add_flow_entry_from_data, application=application)
        cge = partial(self.add_group_entry_from_data)
        cbe = partial(self.create_bucket_entry)

        source, destination = application.source, application.destination

        is_left = self.is_direction_for_shortest_path_from_source_to_destination_lower(application.source, application.destination)

        source_switch, destination_switch = self.get_switch(source), self.get_switch(destination)
        normal_path_switches, reverse_path_switches = self.get_normal_and_reverse_path_switches(application)

        # Check to see if there is one or two source switches, i.e. is the source device singly or dually connected
        group_id = 12 if is_left else 21
        normal_inport, reverse_inport = (self.port_right, self.port_left) if is_left else (self.port_left, self.port_right)
        normal_output, reverse_output = reverse_inport, normal_inport

        if isinstance(source, SEL2740SDevice):
            afe_forward(node=source_switch, inport="Local", group=group_id)
        else:
            afe_forward(node=source_switch, group=group_id)
        
        afe_forward(node=destination_switch, inport='')

        if normal_path_switches:
            for index, normal_path_switch in enumerate(normal_path_switches):
                if index == 0:
                    afe_forward(node=normal_path_switch, inport=source_switch, group=group_id)
                else:
                    afe_forward(node=normal_path_switch, inport=normal_path_switches[index-1], group=group_id)

        all_other_switches = self.get_all_other_ring_switches([destination_switch])

        if normal_path_switches:
            next_to_destination_switch = self.get_next_switch(destination_switch, not is_left)
            all_other_switches = all_other_switches.remove(next_to_destination_switch)
        else:
            all_other_switches = all_other_switches.remove(source_switch)

        for index, switch in enumerate(all_other_switches):
            if index == 0:
                afe_forward(node=switch, inport=destination_switch, group=group_id)
            else:
                afe_forward(node=switch, inport=all_other_switches[index-1], group=group_id)

    def create_flow_entries_for_multicast(self, application):
        afe_forward = partial(self.add_flow_entry_from_data, application=application, priority=1100)
        cge = partial(self.add_group_entry_from_data)
        cbe = partial(self.create_bucket_entry)
        cfe = partial(self.create_simple_ff_bucket_entry)
        cbi = partial(self.create_bucket_entry_ingress)

        source, destinations = application.source, application.destinations
        source_switch = self.get_switch(source)
        destinations_switches = [self.get_switch(node) for node in destinations]
        ending = " {} {}".format(source.print_name, application.name)

        ports_on_switches = defaultdict(list)
        for destination in destinations:
            switch_port = self.resolve_to_switch_port(destination)
            ports_on_switches[switch_port.owner.name].append(switch_port.name)

        # For syntonization add the Local Port for PTP
        if application.protocol.get("EthType") == PTPProtocol(vlan_vid=0).get("EthType"):
            for switch in self.ring_switches:
                ports_on_switches[switch.name].append("Local")

        is_lower = self.is_direction_for_shortest_path_from_source_to_destination_lower(source, destinations[0])
        max_distance = self.calculate_max_distance(source, destinations, is_lower)

        # Both the source and the destination are on the same switch
        if max_distance == 0:
            buckets = [cbe(output=port) for port in ports_on_switches[source_switch.name]]
            group_id = self.get_next_group_id(source_switch)
            cge(node=source_switch, group_id=group_id, name="Local"+ending, group_type="All", buckets=buckets)
            afe_forward(node=source_switch, inport=source, group=group_id)
        else:
            current_switch = source_switch
            source_group_id, reverse_group_id, normal_inport, reverse_inport = (12, 21, self.port_right, self.port_left) if is_lower else (21, 12, self.port_left, self.port_right)
            normal_outport, reverse_outport = reverse_inport, normal_inport

            # Source switch cases:
            buckets = [cfe(reverse_inport, setvlanpcp=self.pcp_normal), cfe(normal_inport, setvlanpcp=self.pcp_resourced)]
            group_id = self.get_next_group_id(source_switch)
            cge(node=source_switch, group_id=group_id, name="Source"+ending, group_type="FF", buckets=buckets)

            if ports_on_switches[source_switch.name]:
                buckets = [cbe(output=port) for port in ports_on_switches[source_switch.name]]
                local_group_id = self.get_next_group_id(source_switch)
                cge(node=source_switch, group_id=local_group_id, name="Local "+ending, group_type="All", buckets=buckets)

                buckets = [cbe(group=local_group_id), cbe(group=group_id)]
                group_id = self.get_next_group_id(source_switch)
                cge(node=source_switch, group_id=group_id, name="Source and Local"+ending, group_type="All", buckets=buckets)

            # 1 from Relay - forward out
            afe_forward(node=source_switch, priority=1102, inport=source, group=group_id)

            # Drop if looped or resourced
            # 2 from any port with PCP Resourced - drop
            afe_forward(node=source_switch, priority=1101, inport='', output='', vlanpcp=self.pcp_resourced)
            # 2 from Normal inport - drop
            afe_forward(node=source_switch, priority=1200, inport=normal_inport, output='')

            # 3 from Reverse Inport with PCP Normal - Mark packet and forward only
            afe_forward(node=source_switch, priority=1105, inport=reverse_inport, output=normal_inport, setvlanpcp=self.pcp_resourced)

            # Do the rest of the switches
            # 1 from Normal Inport with PCP normal - consume and forward on and reverse if needed
            # However, if last in line, consume only
            # 3 from normal inport with PCP Resourced - consume and forward only
            afe_forward_other_switches = partial(self.add_flow_entry_from_data, application=application, priority=1100)

            for hop in range(max_distance):
                previous_switch = current_switch
                current_switch = self.get_next_switch(current_switch, is_lower)
                port_buckets = [cbe(output=port) for port in ports_on_switches[current_switch.name]]

                # 2 from Reverse ports - do not consume forward on and only reverse if PCP Resourced
                afe_forward_other_switches(node=current_switch, inport=reverse_inport, output=reverse_outport, vlanpcp=self.pcp_normal)

                # All group for local ports
                if port_buckets:
                    local_group_id = self.get_next_group_id(current_switch)
                    cge(node=current_switch, group_id=local_group_id, name="Local"+ending, group_type="All", buckets=port_buckets)
    
                # normal
                # 1
                if hop == max_distance - 1:
                    afe_forward_other_switches(node=current_switch, inport=normal_inport, group=local_group_id)
                else:
                    # If normal direction and normal PCP
                    # Ether have destinations on this switch or we do not
                    if port_buckets:
                        buckets = [cbe(group=local_group_id)] + [cbe(group=source_group_id+200)]
                        group_id = self.get_next_group_id(current_switch)
                        cge(node=current_switch, group_id=group_id, name="Normal {} {}".format(source.print_name, str(normal_inport)), group_type="All", buckets=buckets)
                        afe_forward_other_switches(node=current_switch, inport=normal_inport, vlanpcp=self.pcp_normal, group=group_id)
                    else:
                        afe_forward_other_switches(node=current_switch, inport=normal_inport, vlanpcp=self.pcp_normal, group=source_group_id+200)

                    # 3 If normal direction and resourced PCP
                    # if it is the next switch, it will never receive resourced from the source
                    if hop != 0:
                        if port_buckets:
                            buckets = [cbe(group=local_group_id)] + [cbe(output=normal_outport)]
                            group_id = self.get_next_group_id(current_switch)
                            cge(node=current_switch, group_id=group_id, name="Resourced {}".format(source.print_name), group_type="All", buckets=buckets)
                            afe_forward_other_switches(node=current_switch, inport=normal_inport, vlanpcp=self.pcp_resourced, group=group_id)
                        else:
                            afe_forward_other_switches(node=current_switch, inport=normal_inport, vlanpcp=self.pcp_resourced, output=normal_outport)

                # 2 Only unreverse if the vlan pcp is PCP RESOURCED GOOSE because if it hasn't made it past the source
                # it is still travelling on the same path that it did in the forward direction
                # @TODO make a FF group here to consume in if need to reorient
                # The switch next to the source never needs to send it to the source in the reverse direction, rather should just consume if
                if port_buckets and hop != max_distance - 1:
                    # Ingress + Local Group
                    buckets = [cbe(group=local_group_id), cbe(output="Ingress")]
                    ingress_group_id = self.get_next_group_id(current_switch)
                    cge(node=current_switch, group_id=ingress_group_id, name="Local Reverse Ingress "+ending, group_type="All", buckets=buckets)

                    if hop == 0:
                        buckets = [cbe(watch_port=normal_inport), cbe(watch_port=reverse_inport,group=ingress_group_id)]
                    else:
                        buckets = [cfe(output=normal_inport), cbe(watch_port=reverse_inport, group=ingress_group_id)]
                    
                    group_id = self.get_next_group_id(current_switch)
                    cge(node=current_switch, group_id=group_id, name="Reverse to Local Port {} ".format(reverse_inport)+ending, group_type="FF", buckets=buckets)
                    afe_forward_other_switches(node=current_switch, inport=reverse_inport, group=group_id, vlanpcp=self.pcp_resourced)

                elif port_buckets and hop == max_distance - 1:
                    buckets = cfe(output=normal_inport), cbe(watch_port=reverse_inport, group=local_group_id)
                    group_id = self.get_next_group_id(current_switch)
                    cge(node=current_switch, group_id=group_id, name="Reverse to Local "+ending, group_type="FF", buckets=buckets)
                    afe_forward_other_switches(node=current_switch, inport=reverse_inport, group=group_id, vlanpcp=self.pcp_resourced)
                else:
                    # If no buckets, just the usual reverse
                    afe_forward_other_switches(node=current_switch, inport=reverse_inport, vlanpcp=self.pcp_resourced, group=reverse_group_id+200)

            # All the rest of the switches only can reverse, never forward
            for switch in self.get_all_other_ring_switches([self.get_node(node_name) for node_name in ports_on_switches.keys()]):
                afe_forward_other_switches(node=switch, inport=reverse_inport, output=reverse_outport, vlanpcp=self.pcp_resourced)

    def is_direction_for_shortest_path_from_source_to_destination_lower(self, source, destination):
        return self.calculate_distance(source, destination, True) < self.calculate_distance(source, destination, False)

    def calculate_max_distance(self, source, destinations, lower):
        max_distance = 0
        for destination in destinations:
            next_distance = self.calculate_distance(source, destination, lower)
            if next_distance > max_distance:
                max_distance = next_distance
        return max_distance

    def calculate_distance(self, source, destination, lower):
        source_switch_index = self.get_switch_index(self.get_switches(source)[0])
        destination_switch_index = self.get_switch_index(self.get_switches(destination)[0])

        if lower:
            hops = source_switch_index - destination_switch_index
            if hops < 0:
                hops = len(self.ring_switches) + source_switch_index - destination_switch_index
        else:
            hops = destination_switch_index - source_switch_index
            if hops < 0:
                hops = len(self.ring_switches) - source_switch_index + destination_switch_index

        return hops

    def get_next_switch(self, switch, lower):
        if lower:
            return self.get_lower_switch(switch)
        else:
            return self.get_higher_switch(switch)

    def get_lower_switch(self, switch):
        source_switch_index = self.get_switch_index(switch)
        if source_switch_index == 0:
            return self.ring_switches[len(self.ring_switches)-1]
        else:
            return self.ring_switches[source_switch_index-1]

    def get_higher_switch(self, switch):
        source_switch_index = self.get_switch_index(switch)
        if source_switch_index == len(self.ring_switches)-1:
            return self.ring_switches[0]
        else:
            return self.ring_switches[source_switch_index+1]

    def create_generic_group_entries(self):
        cbe = partial(self.create_bucket_entry)
        cfe = partial(self.create_simple_ff_bucket_entry)
        age = partial(self.add_group_entry_from_data)
        cbi = partial(self.create_bucket_entry_ingress)

        for switch in self.ring_switches:
            age(node=switch, group_id=12, group_type="FF", name="Left Top", buckets=[cfe(self.port_left), cfe(self.port_right)])
            age(node=switch, group_id=21, group_type="FF", name="Left Bottom", buckets=[cfe(self.port_right), cfe(self.port_left)])

            age(node=switch, group_id=212, group_type="FF", name="Left Top Ingress", buckets=[cfe(self.port_left), cbi(self.port_right)])
            age(node=switch, group_id=221, group_type="FF", name="Left Bottom Ingress", buckets=[cfe(self.port_right), cbi(self.port_left)])

    def get_switch(self, node):
        return self.get_switches(node)[0]

    def get_switch_port(self, node, switch):
        return self.get_switch_ports(node, switch)[0]

    def create_entries(self, application_entries):
        self.create_generic_group_entries()

        for index, application in enumerate(application_entries):
            try:
                if isinstance(application, MulticastApplication):
                    self.create_flow_entries_for_multicast(application)
                else:
                    self.create_flow_entries_for_unicast(application)
            except Exception as e:
                print("Error occured when creating entries for application {}".format(application))
                raise e

    def create_flow_entries_for_unicast(self, application):
        source, destination = application.source, application.destination
        source_switch, destination_switch = self.get_switch(source), self.get_switch(destination)

        if source_switch == destination_switch:
            self.create_flow_entries_for_unicast_same_switches(application)
            if application.protocol.bidirectional:
                self.create_flow_entries_for_unicast_same_switches(application.reverse())
        else:
            self.create_flow_entries_for_unicast_different_switches(application)
            if application.protocol.bidirectional:
                self.create_flow_entries_for_unicast_different_switches(application.reverse())


class AggregatedRingAlgorithm(BaseRingAlgorithm):
    def __init__(self, node_entries, ring_switches, *args, **kwargs):
        super().__init__(node_entries=node_entries, ring_switches=ring_switches, *args, **kwargs)
        self.ring_vlans = [3000+index for index, switch in enumerate(ring_switches)]

    def get_vlan_from_switch(self, switch):
        return self.ring_vlans[self.get_switch_index(switch)]

    def create_flow_entries_for_unicast_different_switches(self, application):
        afe_forward = partial(self.add_flow_entry_from_data, application=application)
        destination_switch = self.get_switches(application.destination)[0]
        source_switch = self.get_switches(application.source)[0]
        if source_switch == destination_switch:
            afe_forward(node=source_switch)
        else:
            destination_switch_vlan = self.get_vlan_from_switch(destination_switch)
            is_lower = self.is_direction_for_shortest_path_from_source_to_destination_lower(source=source_switch, destination=destination_switch)
            if is_lower:
                group_id = 312
            else:
                group_id = 321

            afe_forward(node=source_switch, pushvlan=True, setvlanvid=destination_switch_vlan, group=group_id)
            afe_forward(node=destination_switch, inport='', vlanvid=destination_switch_vlan, popvlan=True)

    def create_entries(self, application_entries):
        super().create_entries(application_entries)
        self.create_vlan_entries()

    def create_vlan_entries(self):
        for switch in self.ring_switches:
            afe_forward = partial(self.add_flow_entry_from_data)
            switch_vlan = self.get_vlan_from_switch(switch)
            
            # If packet has the switches vlan but not matched, drop
            afe_forward(node=switch, priority=990, vlanvid=switch_vlan)
            
            # The left and right switches should not forward the packet from the direction of the destination switch
            higher_switch = self.get_higher_switch(switch)
            afe_forward(node=higher_switch, priority=1100, vlanvid=switch_vlan, inport=switch.name)
            lower_switch = self.get_lower_switch(switch)
            afe_forward(node=lower_switch, priority=1100, vlanvid=switch_vlan, inport=switch.name)

            # Otherwise forward the traffic depending on the vlanpcp
            afe_forward(node=switch, priority=999, inport=self.port_left, vlanvid="Present", vlanpcp=self.pcp_resourced, output=self.port_right)
            afe_forward(node=switch, priority=999, inport=self.port_right, vlanvid="Present", vlanpcp=self.pcp_resourced, output=self.port_left)
            afe_forward(node=switch, priority=999, inport=self.port_left, vlanvid="Present", vlanpcp=self.pcp_normal, group=421)
            afe_forward(node=switch, priority=999, inport=self.port_right, vlanvid="Present", vlanpcp=self.pcp_normal, group=412)

    def create_generic_group_entries(self):
        super().create_generic_group_entries()
        cbe = partial(self.create_bucket_entry)
        cfe = partial(self.create_simple_ff_bucket_entry)
        age = partial(self.add_group_entry_from_data)
        cbi = partial(self.create_bucket_entry_ingress)

        for switch in self.ring_switches:
            age(node=switch, group_id=312, group_type="FF", name="3Left Top", buckets=[cfe(self.port_left, setvlanpcp=7), cfe(self.port_right, setvlanpcp=6)])
            age(node=switch, group_id=321, group_type="FF", name="3Left Bottom", buckets=[cfe(self.port_right, setvlanpcp=7), cfe(self.port_left, setvlanpcp=6)])

            age(node=switch, group_id=412, group_type="FF", name="4Left Top Ingress", buckets=[cfe(self.port_left), cbi(self.port_right, setvlanpcp=6)])
            age(node=switch, group_id=421, group_type="FF", name="4Left Bottom Ingress", buckets=[cfe(self.port_right), cbi(self.port_left, setvlanpcp=6)])
