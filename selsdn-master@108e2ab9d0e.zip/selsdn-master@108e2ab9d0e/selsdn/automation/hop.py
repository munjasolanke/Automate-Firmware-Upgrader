"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Class of Hop objects used by the What-If tool.
"""


class Hop:
    """Defines a hop of a packet's path through the network.
    """

    def __init__(self, ingress_port, device, egress_port=None,
                 flow_entries=None, group_entries=None, actions=None,
                 packet=None):
        """Setups a hop in a path through the network by taking in the
        essential properties of that specific node.

        Arguments:
            ingress_port {object} -- ingress port of the packet into the node
            device {device} -- the node visited by the hop

        Keyword Arguments:
            egress_port {object} -- egress port of the packet out of the node (default: {None})
            flow_entries {object} -- flow entries matched by the packet for this hop (default: {None})
            group_entries {object} -- group entries executed against by the packet for this hop (default: {None})
            actions {object} -- actions from the flows and groups executed against the packet for this hop (default: {None})
            packet {object} -- data packet being traced through the network (default: {None})
        """
        self.ingress_port = ingress_port
        self.device = device
        self.egress_port = egress_port
        self.flow_entries = flow_entries
        self.group_entries = group_entries
        self.actions = actions
        self.packet = packet

    def __repr__(self):
        """Configures the string representation of a hop.

        Returns:
            {str} -- "[ingress port]->[node]->[egress port]"
        """
        return "{}->{}->{}".format(self.ingress_port, self.device, self.egress_port)
