"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Basic utility functions for named objects.
"""

from ..base.base import BaseObject


class NamedObject(BaseObject):
    """Provides utility functions for BaseObject-derived objects that have a
    name property.
    """

    def __init__(self, name, attributes=None):
        """Initializes a BaseObject with a name as an additional property.

        Arguments:
            name {str} -- the name of the object

        Keyword Arguments:
            attributes {dict} -- lists the object's attributes (default: {None})
        """
        super().__init__(attributes)
        self._name = name

    @property
    def name(self):
        """Returns the name of the object.
        """
        return self._name

    @name.setter
    def name(self, value):
        """Setter for the name property.

        Arguments:
            value {str} -- the name of the object
        """
        self._name = value

    def __eq__(self, other):
        """Two named objects are equal if they both have the NamedObject class
        and have the same name.

        Arguments:
            other {object} -- object used for comparison

        Returns:
            {bool} -- True if the objects are equal
        """
        return isinstance(other, NamedObject) and self.name == other.name

    @property
    def print_name(self):
        """Returns the name of the object. Alias of the name property.
        """
        return str(self.name)
