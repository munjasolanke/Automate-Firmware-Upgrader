"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Defines Port objects.
"""

from .network_object import InterfacedObject

from . import DEVICE_PORT_SEPARATOR


class Port(InterfacedObject):
    """Port object that holds both information about the port and a reference
    to the connected port.
    """

    def __init__(self, name=None, owner=None, end=None,
                 associations=None, *args, **kwargs):
        """Sets up a port object with the provided settings.

        Keyword Arguments:
            name {str} -- friendly name of the port (default: {None})
            owner {device} -- the device the port belongs to (default: {None})
            end {object} -- another port that this port is connected to (default: {None})
            associations {list} -- list of associations containing the port (default: {None})
        """
        self._owner = owner
        super().__init__(name=name, *args, **kwargs)
        
        self._end = end
        self._associations = list()

        if associations:
            for association in associations:
                self.add_association(association)

    @property
    def print_name(self):
        """Returns a string naming the port, and its device's name(if
        applicable).
        """
        return DEVICE_PORT_SEPARATOR.join([self.owner.name if self.owner and self.owner.name is not None else '', str(self.name)])

    @property
    def owner(self):
        """Returns the device that the port belongs to.
        """
        return self._owner

    @owner.setter
    def owner(self, value):
        """Setter for the owner property.

        Arguments:
            value {device} -- the device the port belongs to
        """
        self._owner = value

    @property
    def end(self):
        """Returns the port that this port is connected to.
        """
        return self._end

    @end.setter
    def end(self, end):
        """Setter for the end property.

        Arguments:
            end {object} -- the port that this port is connected to
        """
        self._end = end

    def __repr__(self):
        """String representation of the port object.

        Returns:
            {str} -- format: "[device]:[port]->[connected device]:[connected port]"
        """
        if self.end:
            return "{}:{}->{}:{}".format(self.owner.name,
                                         self.name,
                                         self.end.owner.name,
                                         self.end.name)
        elif self.owner:
            return "{}:{}->None".format(self.owner.name,
                                        self.name)
        else:
            return "None:{}->None".format(self.name)

    def is_connected(self, network=None):
        """Checks if the port is connected to a port.

        Arguments:
            network {object} -- Network to test connection to

        Returns:
            {bool} -- True if this port is connected to a port
        """
        if network:
            if network in self.networks:
                return bool(self.end)
            else:
                return False
        else:
            return bool(self.end)

    def add_association(self, value):
        """Adds an assocation to the port.

        Arguments:
            value {object} -- the added association entry
        """
        self.associations.append(value)

    @property
    def associations(self):
        """Returns the list of the port's associations.
        """
        return self._associations

    def __eq__(self, other):
        """Two ports are equal if they have the same names, addresses, masks,
        default gateways, are on the same device and are connected to the same
        port(if applicable).

        Arguments:
            other {object} -- another port used for comparison

        Returns:
            {bool} -- True if the ports are equal
        """
        if not isinstance(other, InterfacedObject):
            return False
        return super().__eq__(other) and self.owner == other.owner and id(self.end) == id(other.end)

    @property
    def port_number(self):
        """Returns the port's number in the device's index.
        """
        if self.owner:
            return self.owner.ports.index(self) + 1

    def __hash__(self):
        """Converts a port object into a hashed numeral.

        Returns:
            {int} -- the port's name, device, connected port and associations in hashed format
        """
        return sum([ord(x) * index for index, x in enumerate("-".join([str(self.name) + str(self.owner), str(self.end), str(self.associations)]))])

    def find_connected_openflow_switch_port(self):
        """Finds the first OpenFlow switch attached to a port
        Used to skip any intermediate TraditionalSwitchDevices
        """
        from .device import OpenFlowDevice, TraditionalSwitchDevice
        
        if self.end and self.end.owner:
            if isinstance(self.owner, OpenFlowDevice):
                return self
            if isinstance(self.end.owner, OpenFlowDevice):
                return self.end
            elif isinstance(self.end.owner, TraditionalSwitchDevice):
                returned_port = self.end.owner.find_connected_openflow_switch_port()
                if returned_port:
                    return returned_port
        else:
            return None

    def find_connected_openflow_switch_ports(self):
        """Finds the list of OpenFlow switches attached to a port
        Used to skip any intermediate TraditionalSwitchDevices
        """
        from .device import OpenFlowDevice, TraditionalSwitchDevice

        returned_ports = list()
        
        if self.end and self.end.owner:
            if isinstance(self.owner, OpenFlowDevice):
                returned_ports.append(self)
            if isinstance(self.end.owner, OpenFlowDevice):
                returned_ports.append(self.end)
            elif isinstance(self.end.owner, TraditionalSwitchDevice):
                returned_port = self.end.owner.find_connected_openflow_switch_ports()
                if returned_port:
                    returned_ports.extend(returned_port)
        
        return returned_ports
