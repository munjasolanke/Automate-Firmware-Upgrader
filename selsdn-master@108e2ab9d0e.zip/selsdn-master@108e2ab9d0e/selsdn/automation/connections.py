"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions for recording and monitoring the connections that form the network
between switches and ports.
"""

from collections import defaultdict

from .device import SEL274XSDevice, TraditionalSwitchDevice
from .port import Port


class Connections:
    """Defines the dictionary of connections in the network and provides
    utility functions to interact with those connections.
    """

    def __init__(self):
        """Sets up a new empty dictionary of network connections.
        """
        self._switch_ports = defaultdict(dict)
        self._broken_links = None
        self._broken_switches = None
        self.errors = dict()
        self.restore()

    def add_link(self, f_s, f_p, s_s, s_p):
        """Adds a new connection between two ports to the dictionary. Each port
        can physically only be connected to one other port- throws an error if
        the connection requires a port that is already connected to something
        else.

        Arguments:
            f_s {device} -- first switch, one end of the connection
            f_p {object} -- first port, connection point for the first switch
            s_s {device} -- second switch, the other end of the connection
            s_p {object} -- second port, connection point for the second switch
        """
        if f_s not in self._switch_ports or f_p not in self._switch_ports[f_s]:
            self._switch_ports[f_s][f_p] = (s_s, s_p)

        if s_s not in self._switch_ports or s_p not in self._switch_ports[s_s]:
            self._switch_ports[s_s][s_p] = (f_s, f_p)

        if self._switch_ports[f_s][f_p] != (s_s, s_p):
            raise ValueError("{} port {} already connected to {} port {} so cannot connect to {} port {}".format(f_s, f_p, self._switch_ports[f_s][f_p][0], self._switch_ports[f_s][f_p][1], s_s, s_p))

        if self._switch_ports[s_s][s_p] != (f_s, f_p):
            raise ValueError("{} port {} already connected to {} port {} so cannot connect to {} port {}".format(s_s, s_p, self._switch_ports[s_s][s_p][0], self._switch_ports[s_s][s_p][1], f_s, f_p))

    def check_status(self, f_s, f_p):
        """Checks whether a connection is broken.

        Arguments:
            f_s {device} -- a switch that is part of the connection
            f_p {object} -- the connected port belonging to the switch

        Returns:
            {bool} -- True if the connection is broken
        """
        if f_s in self._broken_switches or f_p in self._broken_links[f_s]:
            return False
        else:
            s_s, s_p = self.find_connection(f_s, f_p)
            if s_s in self._broken_switches or s_p in self._broken_links[s_s]:
                return False

        return True

    def find_connection(self, f_s, f_p):
        """Looks up a switch and finds what is connected to one of its ports.
        Throws a value error if the switch or port aren't found.

        Arguments:
            f_s {device} -- the switch being looked up
            f_p {object} -- the port being checked for connections

        Returns:
            {tuple} -- format (A, B), None if the connection doesn't exist or is broken
                A {device} -- the switch at the other end of the connection
                B {object} -- the port at the other end of the connection
        """
        #print("checking connection", f_s, f_p, self._broken_switches, self._broken_links)
        connection = None
        if isinstance(f_s, SEL274XSDevice):
            f_s = f_s.name

        if isinstance(f_p, Port):
            f_p = f_p.name

        if f_s in self._broken_switches or f_p in self._broken_links[f_s]:
            connection = None
        else:
            if f_s not in self._switch_ports:
                raise ValueError("No such node {}".format(f_s))
            switch = self._switch_ports[f_s]

            if f_p not in switch:
                raise ValueError("Nothing connected to port {} on node {}".format(f_p, f_s))
            connection = switch[f_p]

            s_s, s_p = connection
            if s_s in self._broken_switches or s_p in self._broken_links[s_s]:
                connection = None

        #print("returning", connection)
        return connection

    def break_link(self, f_s, f_p):
        """Disables the connection to a port, if it exists.

        Arguments:
            f_s {device} -- the switch owning the port where the connection will break
            f_p {object} -- the port that will have its connection broken

        Returns:
            {tuple} -- format (A, B), None if the connection doesn't exist
                A {device} -- the switch at the other end of the broken connection
                B {object} -- the port at the other end of the broken connection
        """
        #print("breaking link", f_s, f_p)
        if isinstance(f_s, SEL274XSDevice):
            f_s = f_s.name

        if isinstance(f_p, Port):
            f_p = f_p.name

        connection = self.find_connection(f_s, f_p)
        if connection:
            s_s, s_p = connection
            self._broken_links[f_s].append(f_p)
            return s_s, s_p
        else:
            return None

    def unplug_switch(self, f_s):
        """Disables an entire switch. Deletes its list of broken connections
        if it exists(all connections to the switch are disabled no matter what
        if the switch itself is disabled).

        Arguments:
            f_s {device} -- the switch to be disabled

        Returns:
            {device} -- the disabled switch, None if it is already broken
        """
        if isinstance(f_s, SEL274XSDevice):
            f_s = f_s.name

        if f_s in self._broken_switches:
            return None
        else:
            if f_s in self._broken_links:
                self._broken_links[f_s] = list()
            self._broken_switches.append(f_s)
            return f_s

    def change_link(self, f_s, f_p, s_s, s_p):
        """Disconnects two ports with existing connections, and connects them
        to each other.

        Arguments:
            f_s {device} -- first switch, one end of the connection
            f_p {object} -- first port, connection point for the first switch
            s_s {device} -- second switch, the other end of the connection
            s_p {object} -- second port, connection point for the second switch
        """
        self._switch_ports[f_s][f_p] = (s_s, s_p)
        self._switch_ports[s_s][s_p] = (f_s, f_p)

    def restore(self):
        """Restores all disabled switches and connections in the network.
        """
        self._broken_links = defaultdict(list)
        self._broken_switches = list()

    @property
    def links(self):
        """Returns a dictionary of the network listing connections by port by
        switch.
        """
        return self._switch_ports

    @property
    def broken_links(self):
        """Returns the list of disabled connections in the network, including
        both the ports at the failure points and the switches they belong to.
        """
        broken_links = list()
        for switch, ports in self._broken_links.items():
            broken_links.extend(ports)

        return broken_links

    @property
    def broken_switches(self):
        """Returns the list of disabled switches in the network.
        """
        return self._broken_switches

    @classmethod
    def build_from_node_entries(self, node_entries):
        """Returns connection for a given set of node_entries.

        Arguments:
            node_entries {NodeCollection} -- list of node entries

        Returns:
            {conn} -- Connection object based on node entry connections
        """
        conn = Connections()

        for node_entry in node_entries:
                for port in node_entry.ports:
                    if port.end:
                        conn.add_link(f_s=node_entry.name, f_p=port.name, s_s=port.end.owner.name, s_p=port.end.name)

        return conn
