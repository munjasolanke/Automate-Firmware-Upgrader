"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Defines network protocol classes.
"""
from copy import deepcopy

from ..openflow.core.match_fields import MATCH_FIELDS_REVERSABLE, MatchFields, EthDstMatch, EthSrcMatch, VlanVidMatch, VlanPcpMatch, EthTypeMatch, IpProtoMatch, Ipv4DstMatch, Ipv4SrcMatch, TcpDstMatch, UdpDstMatch, MatchField, ArpTpaMatch, ArpSpaMatch, ArpOpMatch
from ..base.values import Values


class Protocol(MatchFields):
    """Defines protocol objects holding match field information relevant to the
    protocol rather than device. The match fields are called "protocol fields"
    in this context.
    """

    def __init__(self, name=None, unidirectional=True, match_fields=None,
                 attributes=None, unicast=True, priority=None, arp_protocol=None):
        """Sets up a protocol object.

        Keyword Arguments:
            name {string} -- the name of the protocol (default: {None})
            unidirectional {bool} -- True if the protocol is unidirectional (default: {True})
            match_fields {list} -- list of the protocol fields (default: {None})
            attributes {dict} -- additional attributes of the protocol (default: {None})
            unicast {bool} -- True if the protocol is unicast (default: {True})
        """
        super().__init__(attributes=attributes)
        self.unidirectional = unidirectional
        self._name = name
        self.unicast = unicast
        self.priority = priority

        if match_fields:
            for match_field in match_fields:
                self.add(match_field)

        self._arp_protocol = None
        self.arp_protocol = arp_protocol

    @property
    def arp_protocol(self):
        return self._arp_protocol
    
    @arp_protocol.setter
    def arp_protocol(self, value):
        if value and not isinstance(value, Protocol):
            raise TypeError("Arp Protocol must be of type Protocol, not {}".format(value))
        self._arp_protocol = value        

    @property
    def protocol_fields(self):
        """Returns a list of the protocol fields.
        """
        return self._values

    @property
    def bidirectional(self):
        """Returns True if the protocol is bidirectional.
        """
        return not self.unidirectional

    @bidirectional.setter
    def bidirectional(self, value):
        """Setter for bidirectional property.

        Arguments:
            value {bool} -- True sets the protocol to bidirectional, False sets
                it to unidirectional.
        """
        self.unidirectional = not value

    @property
    def multicast(self):
        """Returns True if the protocol is multicast.
        """
        return not self.unicast

    @multicast.setter
    def multicast(self, value):
        """Setter for the multicast property. Throws an error if attempting to
        set a bidirectional protocol to multicast.

        Arguments:
            value {bool} -- True sets the protocol to multicast, False sets it
                to unicast.
        """
        if self.bidirectional:
            raise ValueError("Protocol cannot be multicast and bidirectional at the same time.")
        self.unicast = not value

    def __repr__(self):
        """String representation of a protocol.

        Returns:
            {str} -- format "[protocol class]([object name])"
        """
        return "{}({})".format(self.__class__.__name__, self.name)

    @property
    def name(self):
        """Returns the name of the protocol object, or the protocol class if no
        object name was provided.
        """
        if self._name:
            return self._name
        else:
            return self.__class__.__name__[:-8]

    @name.setter
    def name(self, value):
        """Setter for the name property,

        Arguments:
            value {string} -- the name of the protocol object
        """
        self._name = value

    @property
    def is_reversable(self):
        """Checks whether the protocol is reversable based on it any
        of the match fields are reversable.

        Returns:
            {bool} -- True if the protocol contains any reversable fields
        """
        for match_field in MATCH_FIELDS_REVERSABLE:
            if self.get(match_field):
                return True
        else:
            return False

    def copy(self):
        """Returns a partly deepcopy of the protocol.

        Returns:
            {Protocol} -- A shallow copy of self
        """
        new_match_fields = self.values
        protocol = Protocol(name=self.name, unidirectional=self.unidirectional, match_fields=new_match_fields, attributes=deepcopy(self.attributes), unicast=self.unicast, priority=self.priority)
        protocol.__class__ = self.__class__
        return protocol 

    def reverse(self):
        """Makes a copy of the protocol with all protocol fields reversed where
        possible.

        Returns:
            {object} -- copy of the protocol with protocol fields reversed
        """
        new_match_fields = super().reverse()
        protocol = Protocol(name=self.name,
                            unidirectional=self.unidirectional,
                            match_fields=new_match_fields,
                            attributes=deepcopy(self.attributes),
                            unicast=self.unicast,
                            priority=self.priority,
                            arp_protocol=self.arp_protocol.reverse() if self.arp_protocol else None)
        protocol.__class__ = self.__class__
        return protocol

    @classmethod
    def create_protocol_from_match_fields_by_name(cls, name, unicast=True, unidirectional=False, priority=None, attributes=None, **kwargs):
        if "tcp_dst" in kwargs or "tcp_src" in kwargs:
            tcp_dst = kwargs.get("tcp_dst")
            tcp_src = kwargs.get("tcp_src")
            if kwargs.get("tcp_dst"):
                del(kwargs["tcp_dst"])
            if kwargs.get("tcp_src"):
                del(kwargs["tcp_src"])

            protocol = TcpProtocol(name=name, dst_port=tcp_dst, src_port=tcp_src, **kwargs)
        elif "udp_dst" in kwargs or "udp_src" in kwargs:
            protocol = UdpProtocol(name=name, **kwargs)
        elif "arp_spa" in kwargs or "arp_tpa" in kwargs:
            protocol = ArpProtocol(name=name, **kwargs)
        elif "ipv4_dst" in kwargs or "ipv4_src" in kwargs:
            protocol = Ipv4Protocol(name=name, **kwargs)
        else:
            protocol = EthernetProtocol(name=name, **kwargs)

        protocol.priority = priority
        return protocol

    @classmethod
    def create_protocol_from_match_fields(cls, name, match_fields,
                                          unicast=True, unidirectional=False, priority=None, attributes=None):
        """Creates a new protocol object with the network protocol type
        specified by the protocol fields. Search the protocol fields for UDP
        and TCP first, and then for ARP and IPv4, defaulting to Ethernet if
        none of those protocol types are found.

        Arguments:
            name {string} -- name for the new protocol object
            match_fields {list} -- match fields searched for a protocol type

        Keyword Arguments:
            unicast {bool} -- True if the protocol will be unicast (default: {True})
            unidirectional {bool} -- True if the protocol will be undirectional (default: {False})

        Returns:
            {object} -- new protocol object with the given name and type
        """
        if not isinstance(match_fields, MatchFields):
            match_fields = MatchFields(match_fields)

        ip_proto = match_fields.get("IpProto")
        if ip_proto:
            if ip_proto == IpProtoMatch("UDP"):
                protocol_class = UdpProtocol
            elif ip_proto == IpProtoMatch("TCP"):
                protocol_class = TcpProtocol
            else:
                protocol_class = Ipv4Protocol
        else:
            eth_type = match_fields.get("EthType")
            if eth_type:
                if eth_type == EthTypeMatch("ARP"):
                    protocol_class = ArpProtocol
                elif eth_type == EthTypeMatch("IPv4"):
                    protocol_class = Ipv4Protocol
                else:
                    protocol_class = EthernetProtocol
            else:
                protocol_class = EthernetProtocol

        protocol = Protocol(name=name, unidirectional=unidirectional,
                            unicast=unicast, match_fields=match_fields, attributes=attributes)
        protocol.__class__ = protocol_class
        if isinstance(protocol, Ipv4Protocol):
            protocol.arp_protocol = None
        protocol.priority = priority
        return protocol

    def __eq__(self, other):
        """Two protocols are equal if they are for the same protocol type and
        have the same name, Flow Priority, routing and equal protocol fields.

        Arguments:
            other {object} -- protocol used for comparison

        Returns:
            {bool} -- True if the protocol objects are equal
        """
        return isinstance(other, Protocol) and \
            self.compare_attribute("FlowPriority", other, default_value=2000) and \
            self.name == other.name and \
            self.bidirectional == other.bidirectional and \
            self.unicast == other.unicast and \
            super().__eq__(other)

    def diff_eq(self, other):
        """Determines whether two protocols are equal as far as needed for
        diffing. Does not check protocol type and name, unlike true logical
        equality.

        Arguments:
            other {object} -- protocol used for comparison

        Returns:
            {bool} -- True if the protocol objects are equal enough for diffing
        """
        # If the priority is different, are we safe?
        # Probably not, because if the protocols are the same, then why have two of the same thing.
        # However, if the protocols are not the same, but overlapping, then different
        return self.compare_attribute("FlowPriority", other, default_value=2000) and \
            self.bidirectional == other.bidirectional and \
            self.unicast == other.unicast and \
            super().__eq__(other)
        # IP with just opposite source and destination IP addresses are the same
        # Layer 2 with just opposite source and destination MAC addresses are the same
        # List of things that prevent == are the directional stuff, like:
        # InPortMatch, EthDstMatch, EthSrcMatch,
        # Ipv4SrcMatch, Ipv4DstMatch,
        # TcpSrcMatch, TcpDstMatch, UdpSrcMatch, UdpDstMatch
        # ArpSpaMatch, ArpTpaMatch
        # Match fields that do not by themselves have direction are:
        # ArpOpMatch, EthTypeMatch, VlanVidMatch, VlanPcpMatch, IpProtoMatch
        # But if one has one, and the other does, then they overlap.
        # To not overlap, both have to have one but different values

    def overlaps(self, other):
        """If the protocol fields are subset of the other and the priority is
        the same, they overlap.

        Arguments:
            other {object} -- protocol used for comparison

        Returns:
            {bool} -- True if the protocol objects overlap
        """
        return super().overlaps(other) and \
            self.compare_attribute("FlowPriority", other, default_value=2000)
        # However, this only matter in certain circumstances, 
        # aka, they are going to be used.


class EthernetProtocol(Protocol):
    """Characteristics of all ethernet protocols.
    """

    def __init__(self, eth_dst=None, vlan_vid=None, vlan_pcp=None,
                 eth_type=None, unidirectional=True, *args, **kwargs):
        """Sets up an Ethernet protocol object with the given destination, VLAN
        and ethernet subtype.

        Keyword Arguments:
            eth_dst {*} -- ethernet destination address (default: {None})
            vlan_vid {int} -- VLAN VID value (default: {None})
            vlan_pcp {int} -- VLAN PCP value (default: {None})
            eth_type {*} -- ethernet type (default: {None})
            unidirectional {bool} -- True if the protocol is unidirectional (default: {True})
        """
        super().__init__(unidirectional=unidirectional, *args, **kwargs)
        if eth_dst:
            protocol_field = EthDstMatch(eth_dst)
            self.add(protocol_field)

        # vlanvid of 0 would be False
        if vlan_vid is not None:
            protocol_field = VlanVidMatch(vlan_vid)
            self.add(protocol_field)

        # vlanpcp of 0 would be False
        if vlan_pcp is not None:
            protocol_field = VlanPcpMatch(vlan_pcp)
            self.add(protocol_field)

        if eth_type:
            protocol_field = EthTypeMatch(eth_type)
            self.add(protocol_field)


class TableMissProtocol(EthernetProtocol):
    """Ethernet protocol for routing missed traffic from a switch to an IDS or
    similar device.
    """

    def __init__(self, name="Table Miss", eth_dst=None):
        """Sets up a multicast missed traffic protocol object.
        Named 'Table Miss', ethernet destination 00:00:00:00:00:00, with
        priority 601.
        """
        super().__init__(name=name, unidirectional=True,
                         unicast=False, eth_dst=eth_dst)

        self.set_attribute("FlowPriority", 601)


class ArpProtocol(EthernetProtocol):
    """Characteristics of ARP ethernet protocols.
    """
    def __init__(self, arp_op=None, arp_tpa=None, arp_spa=None,
                 unidirectional=False, *args, **kwargs):
        """Sets up an ARP protocol object with a given source and destination.

        Keyword Arguments:
            arp_op {*} -- ARP Op code (default: {None})
            arp_tpa {*} -- ARP destination address (default: {None})
            arp_spa {*} -- ARP source address (default: {None})
            unidirectional {bool} -- True if the protocol is unidirectional (default: {False})
        """
        super().__init__(unidirectional=unidirectional, eth_type="ARP",
                         *args, **kwargs)

        if arp_op:
            protocol_field = ArpOpMatch(arp_op)
            self.add(protocol_field)

        if arp_tpa:
            protocol_field = ArpTpaMatch(arp_tpa)
            self.add(protocol_field)


class Ipv4Protocol(EthernetProtocol):
    def __init__(self, ip_proto=None, ipv4_dst=None, ipv4_src=None,
                 unidirectional=False, *args, **kwargs):
        """Sets up an IPv4 protocol object with a given IP protocol,
        source, and destination.

        Keyword Arguments:
            ip_proto {*} -- IPv4 sub-protocol (default: {None})
            ipv4_dst {*} -- IPv4 destination address (default: {None})
            unidirectional {bool} -- True if the protocol is unidirectional (default: {False})
        """
        super().__init__(unidirectional=unidirectional, eth_type="IPv4", *args, **kwargs)
        if ip_proto is not None:
            protocol_field = IpProtoMatch(ip_proto)
            self.add(protocol_field)

        if ipv4_dst:
            protocol_field = Ipv4DstMatch(ipv4_dst)
            self.add(protocol_field)

        if ipv4_src:
            protocol_field = Ipv4SrcMatch(ipv4_src)
            self.add(protocol_field)

    def to_arp(self):
        """Creates the corresponding ARP to an IPv4 protocol, a bidirectional
        protocol with the same attributes, source and destination addresses.

        Returns:
            {object} -- the corresponding ARP protocol
        """
        if self.arp_protocol:
            return self.arp_protocol
        else:
            protocol = Protocol(name="ARP", unidirectional=False, attributes=self.attributes, unicast=self.unicast)

            protocol.add(EthTypeMatch("ARP"))
            if self.get(Ipv4DstMatch):
                protocol.add(ArpTpaMatch(self.get(Ipv4DstMatch)))

            if self.get(Ipv4SrcMatch):
                protocol.add(ArpSpaMatch(self.get(Ipv4SrcMatch)))
            protocol.__class__ = ArpProtocol

            return protocol


class TUProtocol(Ipv4Protocol):
    """Characteristics of all TU IPv4 protocols.
    """

    pass


class TcpProtocol(TUProtocol):
    """Characteristics of all TCP IPv4 protocols.
    """
    def __init__(self, dst_port, src_port=None, *args, **kwargs):
        """Sets up a TCP protocol object with the given source and destination
        ports.

        Arguments:
            dst_port {*} -- TCP destination port

        Keyword Arguments:
            src_port {*} -- TCP source port (default: {None})
        """
        super().__init__(ip_proto=6, unidirectional=False,
                         *args, **kwargs)
        if dst_port is not None:
            protocol_field = TcpDstMatch(dst_port)
            self.add(protocol_field)

        if src_port is not None:
            protocol_field = TcpSrcMatch(src_port)
            self.add(protocol_field)


class UdpProtocol(TUProtocol):
    def __init__(self, dst_port, src_port=None, unidirectional=False, *args, **kwargs):
        """Sets up a UDP protocol object with the given source and destination
        ports.

        Arguments:
            dst_port {*} -- UDP destination port

        Keyword Arguments:
            src_port {*} -- UDP source port (default: {None})
            ipv4_dst {*} -- IPv4 destination address (default: {None})
            unidirectional {bool} -- True if the protocol is unidirectional (default: {False})
        """
        super().__init__(ip_proto=17, unidirectional=unidirectional,
                         *args, **kwargs)

        if dst_port is not None:
            protocol_field = UdpDstMatch(dst_port)
            self.add(protocol_field)

        if src_port is not None:
            protocol_field = UdpSrcMatch(src_port)
            self.add(protocol_field)


class NTPProtocol(UdpProtocol):
    """UDP protocol using the NTP port.
    """

    def __init__(self, dst_port=123, src_port=None):
        """Sets up a UDP protocol with destination port NTP(port 123).

        Keyword Arguments:
            dst_port {int} -- NTP destination port code (default: {123})
            src_port {*} -- UDP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port)


class MulticastEthernetProtocol(EthernetProtocol):
    """Characteristics of all multicast ethernet protocols.
    """

    def __init__(self, unidirectional=True,
                 unicast=False, *args, **kwargs):
        """Sets up an ethernet protocol flagged as multicast.

        Keyword Arguments:
            unidirectional {bool} -- must be True if multicast (default: {True})
            unicast {bool} -- must be False if multicast (default: {False})
        """
        super().__init__(unidirectional=unidirectional,
                         unicast=unicast, *args, **kwargs)


class GOOSEProtocol(MulticastEthernetProtocol):
    """Characteristics of GOOSE type ethernet protocols.
    """

    def __init__(self, eth_dst=None, vlan_vid=None,
                 vlan_pcp=None, eth_type=0x88b8, *args, **kwargs):
        """Sets up a GOOSE ethernet protocol.

        Keyword Arguments:
            eth_dst {*} -- ethernet destination address (default: {None})
            vlan_vid {int} -- VLAN VID value (default: {None})
            vlan_pcp {int} -- VLAN PCP value (default: {None})
            eth_type {hexadecimal} -- GOOSE protocol hex code (default: {0x88b8})
        """
        super().__init__(eth_dst=eth_dst, vlan_vid=vlan_vid,
                         vlan_pcp=vlan_pcp, eth_type=eth_type, *args, **kwargs)


class SVProtocol(MulticastEthernetProtocol):
    """Characteristics of SV type ethernet protocols.
    """

    def __init__(self, eth_dst=None, vlan_vid=None,
                 vlan_pcp=None, eth_type=0x88ba):
        """Sets up a SV ethernet protocol.

        Keyword Arguments:
            eth_dst {*} -- ethernet destination address (default: {None})
            vlan_vid {int} -- VLAN VID value (default: {None})
            vlan_pcp {int} -- VLAN PCP value (default: {None})
            eth_type {hexadecimal} -- SV protocol hex code (default: {0x88ba})
        """
        super().__init__(eth_dst=eth_dst, vlan_vid=vlan_vid,
                         vlan_pcp=vlan_pcp, eth_type=eth_type)


class PTPProtocol(MulticastEthernetProtocol):
    """Characteristics of PTP type ethernet protocols.
    """

    def __init__(self, vlan_vid=None, vlan_pcp=None,
                 eth_type=0x88f7, eth_dst="01:1B:19:00:00:00"):
        # NOTE: should args here be in the same order as elsewhere, in case a
        # variable uses protocol type classes interchangeably?
        """Sets up a PTP ethernet protocol.

        Keyword Arguments:
            vlan_vid {int} -- VLAN VID value (default: {None})
            vlan_pcp {int} -- VLAN PCP value (default: {None})
            eth_type {hexadecimal} -- PTP protocol hex code (default: {0x88f7})
            eth_dst {str} -- PTP multicast MAC address (default: {"01:1B:19:00:00:00"})
        """
        super().__init__(eth_dst=eth_dst, vlan_vid=vlan_vid,
                         vlan_pcp=vlan_pcp, eth_type=eth_type)


class MMSProtocol(TcpProtocol):
    """TCP protocol using the MMS port.
    """

    def __init__(self, dst_port=102, src_port=None, *args, **kwargs):
        """Sets up a TCP protocol with destination port MMS(port 102)

        Keyword Arguments:
            dst_port {int} -- MMS destination port code (default: {102})
            src_port {*} -- TCP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port, *args, **kwargs)


class TelnetProtocol(TcpProtocol):
    """TCP protocol using the TelNet port.
    """

    def __init__(self, dst_port=23, src_port=None):
        """Sets up a TCP protocol with destination port TelNet(port 23)

        Keyword Arguments:
            dst_port {int} -- TelNet destination port code (default: {23})
            src_port {*} -- TCP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port)


class HTTPProtocol(TcpProtocol):
    """TCP protocol using the HTTP port.
    """

    def __init__(self, dst_port=80, src_port=None):
        """Sets up a TCP protocol with destination port HTTP(port 80)

        Keyword Arguments:
            dst_port {int} -- HTTP destination port code (default: {80})
            src_port {*} -- TCP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port)


class HTTPSProtocol(TcpProtocol):
    """TCP protocol using the HTTPS port.
    """

    def __init__(self, dst_port=443, src_port=None):
        """Sets up a TCP protocol with destination port HTTPS(port 443)

        Keyword Arguments:
            dst_port {int} -- HTTPS destination port code (default: {443})
            src_port {*} -- TCP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port)


class SNMPProtocol(UdpProtocol):
    """UDP protocol using the SNMP port.
    """

    def __init__(self, dst_port=161, src_port=None):
        """Sets up a UDP protocol with destination port SNMP(port 161)

        Keyword Arguments:
            dst_port {int} -- SNMP destination port code (default: {161})
            src_port {*} -- UDP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port)


class DNP3TCPProtocol(TcpProtocol):
    """TCP protocol using the DNP3 port.
    """

    def __init__(self, dst_port=20000, src_port=None):
        """Sets up a TCP protocol with destination port DNP3(port 20000)

        Keyword Arguments:
            dst_port {int} -- DNP3 destination port code (default: {20000})
            src_port {*} -- TCP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port)


class SyslogProtocol(UdpProtocol):
    """UDP protocol using the Syslog port.
    """

    def __init__(self, dst_port=514, src_port=None):
        """Sets up a UDP protocol with destination port Syslog(port 514)

        Keyword Arguments:
            dst_port {int} -- Syslog destination port code (default: {514})
            src_port {*} -- UDP source port (default: {None})
        """
        super().__init__(dst_port=dst_port, src_port=src_port,
                         unidirectional=True)


class ICMPProtocol(Ipv4Protocol):
    """Characteristics of ICMP IPv4 protocols.
    """

    def __init__(self, ip_proto=1, unidirectional=False):
        """Sets up a ICMP protocol object.

        Keyword Arguments:
            ip_proto {int} -- IPv4 sub-protocol code for ICMP (default: {1})
            unidirectional {bool} -- True if the protocol is unidirectional (default: {False})
        """
        super().__init__(ip_proto=ip_proto, unidirectional=unidirectional)
