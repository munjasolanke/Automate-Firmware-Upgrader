"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Init file for automation. Sets up globals.
"""

from logging import getLogger

# sets default device port separator
DEVICE_PORT_SEPARATOR = ":"

# logger for automation
LOGGING_NAME = __name__
LOGGER = getLogger(LOGGING_NAME)
