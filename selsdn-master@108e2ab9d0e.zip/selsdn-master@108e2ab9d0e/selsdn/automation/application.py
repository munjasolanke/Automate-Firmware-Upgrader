"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes for selsdn network applications.
"""

from .network_object import NetworkedObject
from .protocol import Protocol, Ipv4Protocol, TableMissProtocol
from .policy import Policy, Policies, IDSPolicy, IDSMissPolicy
from .port import Port
from .named_object import NamedObject
from .device import OpenFlowDevice, Device
from ..openflow.core.match_fields import EthDstMatch

from . import LOGGER


class Application(NetworkedObject):
    """Defines the functions for an application. An application is any specific
    stream of information with a source and one or more destinations. It is an
    instance of communication in the network, defining who is trying to talk to
    who, and with what message. An individual application object will hold this
    data.
    """

    def __init__(self, name, protocol, source, classification=None,
                 attributes=None, networks=None, policies=None, arp_protocol=None):
        """Constructs a new application with the given data fields.

        Arguments:
            name {str} -- the name of the application
            protocol {object} -- the network protocol of the application
            source {device/list} -- the source device of the application, or list of sources

        Keyword Arguments:
            classification {*} -- the priority queue number of the application (default: {None})
            attributes {dict} -- miscellaneous attributes of the application (default: {None})
            networks {list} -- networks available for the application to use (default: {None})
            policies {list} -- list of SDN policies active for the application (default: {None})
        """
        super().__init__(name=name, attributes=attributes, networks=networks)
        self.protocol = protocol

        # Priority can be derived from the protocol if not set by the application
        if not isinstance(protocol, Protocol):
            raise TypeError("Protocol must be an object instance of Protocol not {}".format(protocol))

        self.classification = classification

        if source is None or (type(source) is list and None in source):
            raise ValueError("Must have a source")

        if type(source) is list:
            self.sources = source
            if True in [type(s) is list for s in source]:
                raise TypeError("Source cannot be a list within a list")
            self.source = source[0]
        else:
            self.source = source
            self.sources = [source]

        self._policies = Policies()
        policies = self.listify(policies)
        for policy in policies:
            self.add_policy(policy)

        self._arp_protocol = arp_protocol

    @property
    def arpable(self):
        """Returns if the application requires/needs ARP.
        """
        return False

    @property
    def classification(self):
        """Returns the classification of the application or if the application does not
        have a priority, returns the priority of the protocol.
        """
        if self._classification is None and self.protocol.get_attribute("SetQueue"):
            return self.protocol.get_attribute("SetQueue")
        else:
            return self._classification

    @classification.setter
    def classification(self, value):
        """Sets the classification
        """
        self._classification = value
    
    @property
    def policies(self):
        """Returns the list of SDN policies used to manage sending the stream
        of information.
        """
        return self._policies

    def add_policy(self, value):
        """Adds a policy to the application. If a table miss policy is being
        added, the source must be a switch, the destination(if it exists) must
        be the same as the application's, and a default MAC address of 0 in all
        fields is provided in case the SEL-5056 controller requires it.

        Arguments:
            value {object} -- a policy to be included in the application
        """
        if not isinstance(value, Policy):
            raise TypeError("Must add only policy objects for policies")
        elif isinstance(value, IDSMissPolicy):
            if not (isinstance(self.source, OpenFlowDevice) or (isinstance(self.source, Port) and isinstance(self.source.owner, OpenFlowDevice))):
                raise ValueError("Source must be a switch for table miss policy not {} of type {}".format(self.source, type(self.source)))

            if self.destinations and (((isinstance(self.destinations[0], Port) and self.destinations[0].owner != value.destination.owner)) or (isinstance(self.destinations[0], Device) and self.destinations != [value.destination.owner])):
                raise ValueError("Destination must be empty or the same as the IDS {} for table miss policy".format(value.destination))

            if "Table Miss" not in self.protocol.name:
                raise ValueError("Protocol name must contain the phrase 'Table Miss' not {} for an Table Miss IDS Protocol".format(self.protocol.name))
            
            if not self.destinations:
                self.destinations.append(value.destination)
        self.policies.add(value)

    @property
    def priority_queue(self):
        """Returns the priority queue of the application. The priority can be
        an integer from 1 to 4, Low, Medium, High, Critical, or undefined.
        Throws an error if the application has an invalid priority.
        """
        if self.classification in ("Critical", 4):
            return 4
        elif self.classification in ("High", 3):
            return 3
        elif self.classification in ("Medium", 2, None):
            return 2
        elif self.classification in ("Low", 1):
            return 1
        else:
            raise ValueError("Unable to resolve priority from {}".format(self.classification))

    def __repr__(self):
        """String representation of an application.

        Returns:
            {str} -- <type>(<name>)[<classification>]<protocol>, <source(s)>
        """
        source_str = ''
        for source in self.sources:
            if isinstance(source, str):
                if source_str:
                    source_str += "," + source
                else:
                    source_str += source
            else:
                if source_str:
                    source_str += "," + source.print_name
                else:
                    source_str += source.print_name

        return "{}({})[{}]{},{}".format(self.__class__.__name__, self.name, self.classification, self.protocol, source_str)

    def __eq__(self, other):
        """Two applications are equal if they have the same name, priority,
        policies, protocol, source(s) and destination(s).

        Arguments:
            other {object} -- another application used for comparison

        Returns:
            {bool} -- True if the applications are equal
        """
        return self.name == other.name and \
            self.priority_queue == other.priority_queue and \
            self.policies == other.policies and \
            self.protocol == other.protocol and \
            self.derived_list_compare(self.sources, other.sources) and \
            self.derived_list_compare(self.destinations, other.destinations)

    def diff_eq(self, other):
        """Two applications are equivalent for the application entry diff check
        if they have the same source(s) and destination(s) and their protocol
        and policies are also considered equal by diff checks.

        Arguments:
            other {object} -- another application used for comparison

        Returns:
            {bool} -- True if the applications are equivalent
        """
        return self.protocol.diff_eq(other.protocol) and \
            self.derived_list_compare(self.sources, other.sources) and \
            self.derived_list_compare(self.destinations, other.destinations) and \
            self.policies.diff_eq(other.policies) and \
            self.priority_queue == other.priority_queue
        # Need to look through all of the source and destinations for self and other
        # and convert to owner if there is a non-port present
        # Also need to consider that a bidirectional could be divided into two parts
        # If CST.diff_eq(other.protocol) == True and the source and destination are the same,
        # Then it is the same Application
        # I cannot consider the name to be a part of it because that is not a SEL-5056 thing

    def overlaps(self, other):
        """Two applications overlap if they have the same source(s) and their
        protocols overlap.

        Arguments:
            other {object} -- another application used for comparison

        Returns:
            {bool} -- True if the applications overlap
        """
        # I cannot consider the name to be a part of it
        # Probably if the protocol.overlaps(other.protocol) == True, also overlaps
        # But the issue is that just because one protocol contains a subset of another, then it might be used with a different priority
        # However, if they are the same priority, they do overlap
        # Also if the source is the same and the protocol overlaps, regardless of the destinations
        # Because from the same device, only one of each protocol can be used.
        return self.protocol.overlaps(other.protocol) and \
            self.derived_list_compare(self.sources, other.sources)

    def derived_value_compare(self, one_side, other_side):
        """Compares the names of two objects, using an object itself for
        comparison if it does not have a name property.

        Arguments:
            one_side {object} -- an object used by the application
            other_side {object} -- an object used by the application

        Returns:
            {bool} -- True if both objects have the same name
        """
        if isinstance(one_side, Port) and isinstance(other_side, Port):
            return one_side.owner.name == other_side.owner.name
        else:
            # TODO what is the error message?
            #LOGGER.warning("Comparing two different types of objects")
            one_side_value = one_side.owner.name if isinstance(one_side, NamedObject) else one_side
            other_side_value = other_side.owner.name if isinstance(other_side, NamedObject) else other_side
            return one_side_value == other_side_value

    def derived_list_compare(self, one_side, other_side):
        """Compares the contents of two lists of objects to see if they overlap.
        If the list contains ports of the same device, but don't have a mode
        (i.e. Failover or PRP), then they are related to each other.

        Arguments:
            one_side {list} -- any number of objects used by the application
            other_side {list} -- any number of objects used by the application

        Returns:
            {bool} -- True if both groups of objects have the same names
        """
        # TODO I should check to make sure the owner are the same, else doesn't make sense
        # Because they should be two applications not one in this data model
        one_side_all_ports = True
        one_side_names = list()
        for value in one_side:
            if isinstance(value, Port):
                one_side_names.append(value.owner.name)
            elif isinstance(value, NamedObject):
                one_side_names.append(value.name)
                one_port_all_ports = False
            elif type(value) is str:
                one_side_names.append(value)
                one_port_all_ports = False
            else:
                raise

        other_side_all_ports = True
        exclusive_list_of_ports = True
        other_side_names = list()
        for value in other_side:
            if isinstance(value, Port):
                other_side_names.append(value.owner.name)
                if value in one_side:
                    exclusive_list_of_ports = False
            elif isinstance(value, NamedObject):
                other_side_names.append(value.name)
                other_side_all_ports = False
            elif type(value) is str:
                other_side_names.append(value)
                other_side_all_ports = False
            else:
                raise

        if set(one_side_names) == set(other_side_names):
            # If they belong to the same owner but are all ports
            # Need to see how the ports are related,
            # I.e. if the port mode is None, then the ports can be different
            if one_side_all_ports and other_side_all_ports and exclusive_list_of_ports:
                for port in one_side:
                    if port.mode:
                        break
                else:
                    return False

        return set(one_side_names) == set(other_side_names)

    def to_arp(self):
        """Returns the ARP equivalent of the application if applicable.
        """
        return False

    def convert_source_and_destination_to_node_objects(self, node_entries):
        for index, source in enumerate(self.sources):
            if isinstance(source, str) and node_entries.has_name(source):
                self.sources[index] = node_entries.has_name(source)[0]

        for index, destination in enumerate(self.destinations):
            if isinstance(destination, str) and node_entries.has_name(destination):
                self.sources[index] = node_entries.has_name(destination)[0]


class UnicastApplication(Application):
    """Defines an application sending a unicast stream of information.
    """
    def __init__(self, name, destination, forward=True, *args, **kwargs):
        """Sets up a new unicast application.

        Arguments:
            name {str} -- the name of the application
            destination {device} -- the destination of the unicast stream

        Keyword Arguments:
            forward {bool} -- True if the direction is source to destination (default: {True})
        """
        # Have to do destination first because of Table Miss IDS
        if type(destination) is list:
            self.destinations = destination
            if True in [type(s) is list for s in destination]:
                raise TypeError("Destination cannot be a list within a list")
        else:
            if destination is None:
                self.destinations = []
            else:
                self.destinations = [destination]

        super().__init__(name, *args, **kwargs)

        self.forward = forward

    @property
    def destination(self):
        return self.destinations[0]

    def __repr__(self):
        """String representation of a unicast application.

        Returns:
            {str} -- <type>(<name>)[<classification>]<protocol>, <source>--><destination>
        """
        destination_str = ''
        for destination in self.destinations:
            if isinstance(destination, str):
                if destination_str:
                    destination_str += "," + destination
                else:
                    destination_str += destination
            else:
                if destination_str:
                    destination_str += "," + destination.print_name
                else:
                    destination_str += destination.print_name

        return super().__repr__() + "-->" + destination_str

    def reverse(self):
        """Creates a copy of the application with the protocol fields reversed
        and the packet sent in the opposite direction from the original.

        Returns:
            {object} -- the application, reversed
        """
        return UnicastApplication(name=self.name,
                                  protocol=self.protocol.reverse(),
                                  source=self.destination,
                                  destination=self.source,
                                  forward=not self.forward,
                                  classification=self.classification,
                                  policies=self.policies)

    @property
    def arp_protocol(self):
        return self.protocol.arp_protocol

    @property
    def arpable(self):
        return isinstance(self.protocol, Ipv4Protocol)
    
    @arp_protocol.setter
    def arp_protocol(self, value):
        if self.arp_protocol:
            self.protocol = self.protocol.copy()
            self.protocol.arp_protocol = arp_protocol

    def to_arp(self):
        """Creates the corresponding ARP equivalent to an IPv4 application.

        Returns:
            {object} -- the application, using ARP instead of IPv4
        """
        if isinstance(self.protocol, Ipv4Protocol):
            if self._arp_protocol:
                return self._arp_protocol
            else:
                return self.__class__(name=self.name,
                                  protocol=self.protocol.to_arp(),
                                  source=self.source,
                                  destination=self.destination,
                                  classification=self.classification,
                                  attributes=self.attributes,
                                  policies=self.policies)
        else:
            raise TypeError("The protocol type for this application is not a unicast Ipv4 so does not have an ARP equilavent")

    def copy(self):
        return UnicastApplication(name=self.name, protocol=self.protocol.copy(), arp_protocol=self.arp_protocol, source=self.sources, destination=self.destinations, classification=self.classification, attributes=self.attributes, networks=self.networks, policies=self.policies)

    def overlaps(self, other):
        # Two unicast application entries overlap if all three overlap
        #return super().overlaps(other) and self.derived_list_compare(self.destinations, other.destinations)
        return self.protocol.overlaps(other.protocol) and self.derived_list_compare(self.sources, other.sources) and self.derived_list_compare(self.destinations, other.destinations)


class MulticastApplication(Application):
    """Defines an application sending a multicast stream of information.
    """

    def __init__(self, name, destinations, *args, **kwargs):
        """Sets up a new multicast application.

        Arguments:
            name {str} -- the name of the application
            destinations {list} -- list of destinations for the application
        """
        # Have to do destinations first because of table miss policy
        if destinations is None:
            self.destinations = list()
        elif destinations == [None]:
            raise ValueError("Destinations cannot be a list with None")
        elif type(destinations) is not list:
            self.destinations = [destinations]
            #raise TypeError("Destinations must be a list")
        else:
            if True in [type(s) is list for s in destinations]:
                raise TypeError("Destinations cannot be a list within a list {}".format(destinations))
            self.destinations = destinations

        super().__init__(name, *args, **kwargs)

    def __repr__(self):
        """String representation of a multicast application.

        Returns:
            {str} -- <type>(<name>)[<classification>]<protocol>, <source>--><destination(s)>
        """
        return "{}({}){},{}->{}".format(self.__class__.__name__, self.name, self.protocol, self.source, self.destinations)

    def diff_eq(self, other):
        """Two multicast applications are equal for application entry diff if
        they have the same destinations(including IDS destination if
        applicable), the same policies, protocols considered the same by a diff
        test, the same source and destination(s).

        Arguments:
            other {object} -- multicast application used for comparison

        Returns:
            {bool} -- True if the applications are considered equal for diffing
        """
        # Need to consider that IDS policy is the same as an extra destination
        # So destination + IDS destination == destination is also a possibility
        if self.get_attribute("$converted_from_5056") or other.get_attribute("$converted_from_5056"):
            # Then I need to convert the policy stuff
            self_destinations = self.destinations + [policy.destination for policy in self.policies if isinstance(policy, IDSPolicy)]
            other_destinations = other.destinations + [policy.destination for policy in other.policies if isinstance(policy, IDSPolicy)]
        else:
            # Policies should be the same here
            # Need to consider SEL-5056 important policies
            if not self.policies.diff_eq(other.policies):
                return False
            self_destinations = self.destinations
            other_destinations = other.destinations

        return self.protocol.diff_eq(other.protocol) and \
            self.derived_value_compare(self.source, other.source) and \
            self.derived_list_compare(self_destinations, other_destinations)

    def copy(self):
        return MulticastApplication(name=self.name, protocol=self.protocol.copy(), source=self.sources, destinations=self.destinations, classification=self.classification, attributes=self.attributes, networks=self.networks, policies=self.policies)

    def overlaps(self, other):
        # Multicast can only have one set of destinations so if there are two applications with the overlapping protocols
        # and sources, but different destinations, then that is overlappsing.
        return self.protocol.overlaps(other.protocol) and self.derived_list_compare(self.sources, other.sources)
