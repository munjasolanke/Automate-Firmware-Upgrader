"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Plots a packet's path through the network. Used for What-If calculations.
"""
from copy import deepcopy

from .packet import Packet
from .device import SEL274XSDevice
from .hop import Hop
from . import LOGGER


class Path:
    """Properties and methods of a packet's path through a network.
    """

    def __init__(self, start, packet=None):
        """Creates a new network path object.

        Arguments:
            start {object} -- the port that is the packet's start point

        Keyword Arguments:
            packet {object} -- the packet being sent on the path (default: {None})
        """
        self._hops = list()
        self.start = start
        self.finish = start
        self._errors = list()
        self.packet = packet

    def add_error(self, error):
        """Adds an error to the list of errors encountered running the packet
        along the path.

        Arguments:
            error {str} -- an error message
        """
        self._errors.append(error)

    @property
    def start(self):
        """Returns the start point of the packet.
        """
        return self._start

    @start.setter
    def start(self, value):
        """Setter for the start property.

        Arguments:
            value {object} -- the start point of the packet is set to this port
        """
        self._start = value

    @property
    def finish(self):
        """Returns the last port of the packet.
        """
        return self._finish

    @finish.setter
    def finish(self, value):
        """Setter for the finish property.

        Arguments:
            value {object} -- the last port of the packet is set to this port
        """
        self._finish = value

    def add_hop(self, ingress_port, switch, egress_port=None,
                flow_entries=None, group_entries=None, actions=None,
                packet=None):
        """Adds a location on the object's path by creating a new hop object.
        The new hop includes the ports of the new location as well as its
        OpenFlow rules and restrictions. Tracks the most recent port in the
        object's path using its finish property, so that the point where the
        object stops will be discovered.

        Arguments:
            ingress_port {object} -- port where the device receives the packet
            switch {device} -- a device being added to the path

        Keyword Arguments:
            egress_port {object} -- port where the packet is sent to the next hop (default: {None})
            flow_entries {list} -- OpenFlow flow entries of the device (default: {None})
            group_entries {list} -- OpenFlow group entries of the device (default: {None})
            actions {list} -- OpenFlow actions available to the device (default: {None})
            packet {object} -- the packet being sent on the path (default: {None})
        """
        # ingress_port, device, egress_port, flow_entries=None,
        # group_entries=None, actions=None, packet=None
        new_hop = Hop(ingress_port=ingress_port,
                      device=switch,
                      egress_port=egress_port,
                      flow_entries=flow_entries,
                      group_entries=group_entries,
                      actions=actions,
                      packet=packet)
        self._hops.append(new_hop)
        # This is for the last hop, the finish port is the ingress port for the last hop
        if not isinstance(switch, SEL274XSDevice) and ingress_port:
            self.finish = ingress_port
        # Maybe didn't make it to final destination, but stopped mid way
        elif isinstance(switch, SEL274XSDevice) and ingress_port and not egress_port:
            self.finish = ingress_port
        elif egress_port:
            self.finish = egress_port

    @property
    def copy(self):
        """Returns a copy of a network path with a split copy of the packet.
        """
        new_path = Path(self.start)
        new_path._hops = self._hops[:]
        new_path.finish = self.finish
        new_path.packet = self.packet.split()
        new_path._errors = deepcopy(self.errors)
        return new_path

    def split(self):
        """Splits a packet and copies its path.

        Returns:
            {object} -- a copy of the path, as defined by its copy propertyf
        """
        return self.copy

    @property
    def hops(self):
        """Returns the list of hops(locations) in a packet's path through the
        network.
        """
        return self._hops

    def __repr__(self):
        """Defines the string representation of a path.

        Returns:
            {str} -- [start]->[hops]->[finish]
        """
        return "{}->{}->{}".format(self.start, self.hops, self.finish)

    @property
    def errors(self):
        """Returns the list of errors encountered in the packet's path through
        the network.
        """
        return self._errors

    @property
    def packet(self):
        """Returns the packet that uses this path.
        """
        return self._packet

    @packet.setter
    def packet(self, value):
        """Setter for the packet property.

        Arguments:
            value {object} -- the packet is set to be for this packet
        """
        if isinstance(value, Packet) or value is None:
            self._packet = value
        else:
            raise TypeError("Excepted a Packet object, but instead received an object of type", type(value))
