"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes for application policies.
"""

from ..base.values import Values

from .named_object import NamedObject
from .device import EndDevice
from .port import Port


class Policy(NamedObject):
    """Base class for the functions of an application policy.
    """
    def __eq__(self, other):
        return self.__class__ == other.__class__

    def diff_eq(self, other):
        return self == other

    def __repr__(self):
        return "{}".format(self.__class__.__name__)


class IDSPolicy(Policy):
    def __init__(self, destination, name='', *args, **kwargs):
        super().__init__(name=name, *args, **kwargs)

        if isinstance(destination, EndDevice) or isinstance(destination, Port):
            self.destination = destination
        else:
            raise TypeError("IDS destination must be a device not {} of type {}".format(destination, type(destination)))

    def __hash__(self):
        return sum([ord(x)*index for index, x in enumerate("-".join([self.__class__.__name__, str(self.name) + str(self.destination)]))])

    def __eq__(self, other):
        if self.__class__ == other.__class__:
            return self.derived_value_compare(self.destination, other.destination)
        else:
            return False

    def __repr__(self):
        return "{}@{}".format(self.__class__.__name__, self.destination)

    def copy(self, name=None, destination=None):
        name = name if name is not None else self.name
        destination = destination if destination is not None else self.destination
        return IDSPolicy(destination=destination, name=name)

    def derived_value_compare(self, one_side, other_side):
        """Compares the names of two objects, using an object itself for
        comparison if it does not have a name property.

        Arguments:
            one_side {object} -- an object used by the application
            other_side {object} -- an object used by the application

        Returns:
            {bool} -- True if both objects have the same name
        """
        if isinstance(one_side, Port) and isinstance(other_side, Port):
            return one_side.owner.name == other_side.owner.name
        else:
            # TODO what is the error message?
            #LOGGER.warning("Comparing two different types of objects")
            one_side_value = one_side.owner.name if isinstance(one_side, NamedObject) else one_side
            other_side_value = other_side.owner.name if isinstance(other_side, NamedObject) else other_side
            return one_side_value == other_side_value


class IDSMissPolicy(IDSPolicy):
    """Methods of an Intrusion Detection System(IDS) policy.
    """
    def __init__(self, name='', vid=None, strip=True, *args, **kwargs):
        super().__init__(name=name, *args, **kwargs)
        self.vid = vid
        self.strip = strip

    @property
    def vid(self):
        return self._vid
        
    @vid.setter
    def vid(self, value):
        if isinstance(value, int) or value is None:
            self._vid = value
        else:
            raise TypeError("VID must be an integer or None and not of type {}".format(type(value)))
            self._vid = value
    
    def __hash__(self):
        """Converts an IDS policy to a hashed numeral.

        Returns:
            {int} -- the IDS policy in hash format
        """
        return sum([ord(x) * index for index, x in enumerate("-".join([self.__class__.__name__, str(self.name) + str(self.destination)]))])

    def __eq__(self, other):
        if self.__class__ == other.__class__:
            if self.vid == other.vid and self.strip == other.strip:
                return super().__eq__(other)
            else:
                return False
        else:
            return False

    def copy(self, name=None, destination=None):
        name = name if name is not None else self.name
        destination = destination if destination is not None else self.destination
        return IDSMissPolicy(destination=destination, name=name, strip=self.strip, vid=self.vid)

    def diff_eq(self, other):
        if self.__class__ != other.__class__:
            return False
        elif self.vid is None and self.strip and other.vid and other.strip:
            return True
        elif other.vid is not None and self.vid != other.vid:
            return False
        elif other.strip != self.strip:
            return False
        else:
            return True

    def __repr__(self):
        if self.vid:
            return "{}:MISS-VID{}{}@{}".format(self.__class__.__name__, self.vid, self.destination, self.strip)
        else:
            return "{}:MISS@{}".format(self.__class__.__name__, self.destination)


class Policies(Values):
    """Defines an object listing the policies in an application.
    """
    VALUE_CLASS = Policy

    def diff_eq(self, other):
        if len(self) != len(other):
            return False

        for self_value in self:
            for other_value in other:
                if self_value.diff_eq(other_value):
                    break
            else:
                return False

        return True
        #return set(self.values) == set(other.values)

    def add(self, policy):
        """Adds a new policy to the list. The table miss policy must be the
        only one present.

        Arguments:
            policy {object} -- a policy being added to the application
        """
        if isinstance(policy, IDSMissPolicy) and len(self.values):
            raise ValueError("The table miss policy must be the only policy if present")
        else:
            super().add(policy)
