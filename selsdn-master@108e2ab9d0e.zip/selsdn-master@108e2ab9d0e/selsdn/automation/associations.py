"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Class for associations between network node entries.
"""
from copy import deepcopy

from . import LOGGER


class Associations:
    """Manages one or more associations between network node entries.
    """

    def __init__(self):
        """Creates a dictionary to sort associations of nodes by friendly name.
        """
        self._entries_by_alias = dict()
        self._associations_by_alias = dict()

    def add_association(self, name, associations):
        if not self._associations_by_alias.get(name):
            self._associations_by_alias[name] = associations
            for association in associations:
                self._entries_by_alias[association] = list()
        else:
            raise ValueError("An association alias of {} already added".format(name))

    def add_entry(self, node, association):
        """Adds an association to the dictionary of associations if not already
        present, then adds a SDN node to that association, raising an error if
        the node is already part of the association.

        Arguments:
            node {object} -- a network node
            association {str} -- name of an association between nodes
        """
        if self._associations_by_alias.get(association):
            associations = self._associations_by_alias.get(association)
            for a in associations:
                self.add_entry(node, a)
        else:
            # Create the association if not present
            if not self._entries_by_alias.get(association):
                self._entries_by_alias[association] = list()

            # Only add the node if not already present
            if node not in self._entries_by_alias[association]:
                self._entries_by_alias[association].append(node)
            else:
                if not self._entries_by_alias.get(association):
                    self._entries_by_alias[association] = list()

                # Only add the node if not already present
                if node not in self._entries_by_alias[association]:
                    self._entries_by_alias[association].append(node)
                else:
                    LOGGER.info("{} is already present in association {}".format(node, association))

    def get_entry(self, association):
        """Searches the dictionary of associations for a specific association
        of nodes.

        Arguments:
            association {str} -- name of an association between nodes

        Returns:
            {list} -- list of associated nodes. 'None' if not found.
        """
        if not type(association) is str:
            raise TypeError("Association must be type str not {}".format(type(association)))

        if self._entries_by_alias.get(association):
            return self._entries_by_alias[association]
        else:
            return None

    @property
    def values(self):
        """Returns the dictionary of associations.
        """
        return self._entries_by_alias

    def __len__(self):
        """Defines the length of this object as the length of its dictionary of
        associations.
        """
        return len(self._entries_by_alias)

    def get(self, value):
        return self.get_entry(value)

    def __repr__(self):
        return str(self._entries_by_alias)

    def __add__(self, other):
        entries_by_alias = deepcopy(self._entries_by_alias)
        associations_by_alias = deepcopy(self._associations_by_alias)

        for name, values in other._entries_by_alias.items():
            if entries_by_alias.get(name):
                entries_by_alias[name].extend(values)

            #and entries_by_alias[name] != values:
            #    raise ValueError("Cannot add associations together because they have same alias {} but different values {} and {}".format(name, entries_by_alias[name], values))
            else:
                entries_by_alias[name] = values

        for name, values in other._associations_by_alias.items():
            if associations_by_alias.get(name) :
                associations_by_alias[name].extend(values)
            #and associations_by_alias[name] != values:
            #    raise ValueError("Cannot add associations together because they have same alias {} but different values {} and {}".format(name, associations_by_alias[name], values))
            else:
                associations_by_alias[name] = values

        return_value = Associations()
        return_value._entries_by_alias = entries_by_alias
        return_value._associations_by_alias = associations_by_alias
        return return_value

    def __iadd__(self, other):
        return self.__add__(other)
