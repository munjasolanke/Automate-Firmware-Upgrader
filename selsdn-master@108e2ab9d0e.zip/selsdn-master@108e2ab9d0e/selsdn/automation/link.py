"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

[UNUSED] Defines the class of network link objects.
"""

from .named_object import NamedObject


class Link(NamedObject):
    """Object representing the connection between two ports.
    """

    def __init__(self, name, left_port, right_port, attributes=None):
        """Sets up a network link object.

        Arguments:
            name {str} -- the name of the link
            left_port {object} -- the first port in the connection
            right_port {object} -- the second port in the connection

        Keyword Arguments:
            attributes {dict} -- object attributes (default: {None})
        """
        super().__init__(name, attributes=attributes)
        self.left_port = left_port
        self.right_port = right_port

    def __repr__(self):
        """String representation of a link.

        Returns:
            {str} -- format "[link type]:[first device]:[port]->[second device]:[port]"
        """
        return "{}:{}:{}->{}:{}".format(self.__class__.__name__,
                                        self.left_port.device,
                                        self.left_port,
                                        self.right_port.device,
                                        self.right_port)
