"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Functions and classes for building a packet from an selsdn application, and
defining the properties and methods of packets.
"""

#from copy import deepcopy

from ..openflow.core.match_fields import MatchFields, MatchField
from ..openflow.core.match_fields import InPortMatch, EthDstMatch, EthSrcMatch, EthTypeMatch, VlanVidMatch, VlanPcpMatch
from ..openflow.core.match_fields import IpProtoMatch, Ipv4SrcMatch, Ipv4DstMatch, TcpSrcMatch, TcpDstMatch, UdpSrcMatch, UdpDstMatch
from ..openflow.core.match_fields import ArpOpMatch, ArpSpaMatch, ArpTpaMatch

from ..openflow.core.ports import LocalPort

from .protocol import *
from .application import MulticastApplication
from .device import SEL274XSDevice, Device, ControllerDevice, TwoMacDevice
from .port import Port

def form_arp_packet_from_ipv4_application(application, forward=True,
                                          inport=None):
    """NOTE [DEPRECATED FUNCTION] DO NOT USE

    Builds the corresponding ARP packet for an application sending a packet
    via IPv4 protocol.

    Arguments:
        application {object} -- an IPv4 selsdn application

    Keyword Arguments:
        forward {bool} -- True if the packet is being sent source to destination (default: {True})
        inport {*} -- the Inport of the application (default: {None})

    Returns:
        {object} -- a copy of the packet with ARP protocol and protocol fields
    """
    raise
    if forward:
        return ArpPacket(arp_spa=application.source.ip_address,
                         arp_tpa=application.destination.ip_address)
    else:
        return ArpPacket(arp_tpa=application.source.ip_address,
                         arp_spa=application.destination.ip_address)


def extract_port_from_device(node):
    """Gets the list of ports that exist in a network node. If the network node
    is itself a port, return the node.

    Arguments:
        node {*} -- a port or device

    Returns:
        {list} -- the port listified, or list of the device's local ports
    """
    if isinstance(node, Port):
        return [node]
    else:
        return [port for port in node.local_ports]


def form_packets_from_application(application):
    """Creates the packets specified in an application, accounting for ARP,
    direction and cast type.

    Arguments:
        application {object} -- a selsdn application

    Returns:
        {list} -- the packets described by the application
    """
    all_packets = list()
    for source in application.sources:
        new_packets = _form_packets_from_application(application, source)
        all_packets.extend(new_packets)
    return all_packets

def _form_packets_from_application(application, source):
    if isinstance(application, MulticastApplication):
        return [form_packet_from_protocol(protocol=application.protocol,
                                          source=source,
                                          destination=application.destinations,
                                          forward=True,
                                          inport=port.name) for port in extract_port_from_device(source)]
    elif application.protocol.unidirectional == True:
        all_packets = list()
        for destination in application.destinations:
            normal = ([form_packet_from_protocol(protocol=application.protocol,
                                                 source=source,
                                                 destination=destination,
                                                 forward=True,
                                                 inport=port.name) for port in extract_port_from_device(source)])
            all_packets.extend(normal)

        if isinstance(application.protocol, Ipv4Protocol):
            all_packets.extend([packet.arp for packet in all_packets])

        return all_packets
    else:
        all_packets = list()
        for destination in application.destinations:
            normal = ([form_packet_from_protocol(protocol=application.protocol,
                                                 source=source,
                                                 destination=destination,
                                                 forward=True,
                                                 inport=port.name) for port in extract_port_from_device(source)] +
                      [form_packet_from_protocol(protocol=application.protocol.reverse(),
                                                 source=destination,
                                                 destination=source,
                                                 forward=False,
                                                 inport=port.name) for port in extract_port_from_device(destination)])
            all_packets.extend(normal)
        
        if isinstance(application.protocol, Ipv4Protocol):
            all_packets.extend([packet.arp for packet in all_packets])

        return all_packets


def form_packet_from_application(application):
    """Creates an individual packet for a specific application and port.

    Arguments:
        application {object} -- a selsdn application

    Returns:
        {object} -- generated packet corresponding to the port and application
    """
    return form_packet_from_protocol(protocol=application.protocol,
                                         source=application.source,
                                         destination=application.destination,
                                         forward=True,
                                         inport=port.name)

def get_source_port(source, inport):
    """Gets the source port of the application. This is either the source
    itself if the source is the Inport of the application, or the source's
    Inport if the source is a device. Throws an error if the source is a port
    other than the Inport of the application.

    Arguments:
        source {*} -- the source node in the application route
        inport {*} -- the Inport of the application

    Returns:
        {object} -- the source port of the application
    """
    if isinstance(source, Port):
        if source.name == inport:
            return source
        else:
            raise ValueError("Port name {} is not the same as Inport name {}".format(source, inport))
    elif isinstance(source, Device):
        return source.get_local_port(inport)
    else:
        raise TypeError("Unknown object type for source {}".format(source))


def form_packet_from_protocol(protocol, source, destination, forward, inport):
    """Constructs an individual packet using data from the application,
    including setting up all the network protocols involved in this individual
    communication.

    Arguments:
        protocol {object} -- object listing the packet's network protocols
        source {*} -- the source device or port of the packet
        destination {device} -- the destination device of the packet
        forward {bool} -- True if the packet is sent source to destination
        inport {*} -- the Inport of the application

    Returns:
        {object}-- packet constructed from the application's information
    """
    packet = None
    source_port = get_source_port(source, inport)

    if isinstance(source, SEL274XSDevice):
        source_name = source.name
    elif isinstance(source, ControllerDevice):
        source_name = source.name
    else:
        source_name = source.local_ports[0].end.name if isinstance(source, Device) else source.name

    if isinstance(protocol, TcpProtocol):
        packet = TcpPacket(source=source,
                           source_port=source_port,
                           destination=destination)
    elif isinstance(protocol, UdpProtocol):
        packet = UdpPacket(source=source,
                           source_port=source_port,
                           destination=destination)
    elif isinstance(protocol, Ipv4Protocol):
        packet = IPv4Packet(source=source,
                            source_port=source_port,
                            destination=destination)
    elif isinstance(protocol, ArpProtocol) or (protocol.get(EthTypeMatch) and protocol.get(EthTypeMatch) == EthTypeMatch("ARP")):
        packet = ArpPacket(source=source, source_port=source_port, destination=destination)
    elif protocol.get(VlanVidMatch):
        packet = TaggedPacket(source=source,
                              source_port=source_port,
                              destination=destination,
                              vlan_id=protocol.get(VlanVidMatch),
                              vlan_pcp=protocol.get(VlanPcpMatch))
    else:
        packet = Layer2Packet(source=source,
                              source_port=source_port,
                              destination=destination)

    for packet_field in protocol:
        packet.add(packet_field)

    if isinstance(protocol, Ipv4Protocol):
        if source.ip_address:
            packet.add(Ipv4SrcMatch(source.ip_address))
        if protocol.unicast and destination.ip_address:
            packet.add(Ipv4DstMatch(destination.ip_address))
    elif isinstance(protocol, ArpProtocol):
        if source.ip_address:
            packet.add(ArpSpaMatch(source.ip_address))
        if protocol.unicast and destination.ip_address:
            packet.add(ArpTpaMatch(destination.ip_address))

    if not packet.get(EthSrcMatch) and packet.get(EthTypeMatch) and packet.get(EthTypeMatch) == EthTypeMatch("GOOSE") and isinstance(source.owner, TwoMacDevice) and source.owner.other_mac_address:
        packet.add(EthSrcMatch(source.owner.other_mac_address))
    
    if not packet.get(EthSrcMatch) and source.mac_address:
        packet.add(EthSrcMatch(source.mac_address))

    if isinstance(packet, ArpPacket) and forward != True and destination.mac_address:
        packet.override(EthDstMatch(destination.mac_address))
    elif protocol.unicast and destination.mac_address and not packet.get(EthDstMatch):
        packet.add(EthDstMatch(destination.mac_address))

    if destination and not type(destination) is list and destination.mac_address and not \
            packet.get(EthDstMatch) and not isinstance(protocol, ArpProtocol):
        packet.add(EthDstMatch(destination.mac_address))

    if inport is not False:
        if inport is None:
            inport = InPortMatch(source_name)
        else:
            if isinstance(source, SEL274XSDevice):
                inport = InPortMatch(inport)
            else:
                inport = InPortMatch(source_port.end.name)

        packet.add(inport)

    packet.forward = forward

    return packet


class Packet(MatchFields):
    """Defines the methods and properties shared by all types of network
    packets.
    """

    def __init__(self, source=None, destination=None, vlans=None,
                 source_port=None, attributes=None, forward=True):
        """Sets up a new packet object with the given properties.

        Keyword Arguments:
            source {device} -- the source device of the packet (default: {None})
            destination {device} -- the destination device of the packet (default: {None})
            vlans {list} -- VLANs used by the packet (default: {None})
            source_port {object} -- the source port of the packert (default: {None})
            attributes {dict} -- additional object attributes of the packet (default: {None})
            forward {bool} -- True if the packet is sent source to destination (default: {True})
        """
        super().__init__(attributes=attributes)
        self.source = source
        self.destination = destination
        self.source_port = source_port
        self.vlans = vlans if vlans else list()
        self._is_good_packet = True
        self.forward = forward
        self.raw_data = b""

    def add(self, packet_field):
        """Adds a network protocol field to the packet.

        Arguments:
            packet_field {object} -- a protocol field
        """
        super().add(packet_field)
        if isinstance(packet_field, VlanVidMatch):
            if not self.vlans:
                self.vlans.append([packet_field.value, 0])
                self.add(VlanPcpMatch(0))
            else:
                self.vlans[-1][0] = packet_field.value

        elif isinstance(packet_field, VlanPcpMatch):
            if not self.vlans:
                self.vlans.append([0, packet_field.value])
                self.add(VlanVidMatch(0))
            else:
                self.vlans[-1][1] = packet_field.value

    def push_vlan(self):
        """Push the packet's VLAN VID and PCP to its list of VLANs. If the list
        is empty, add default VLAN VID and PCP values of 0 instead.
        """
        if self.vlans:
            self.vlans.append([self.get("VlanVid").value, self.get("VlanPcp").value])
        else:
            super().add(VlanVidMatch(0))
            super().add(VlanPcpMatch(0))
            self.vlans.append([0, 0])

    def change_vid(self, value):
        """Changes the VLAN VID of the packet to a new value. Throws an error
        if this method is called for a packet that does not have a VLAN.

        Arguments:
            value {int} -- the new VLAN VID value
        """
        if self.vlans:
            if self.get(VlanVidMatch):
                self.override(VlanVidMatch(value))
            else:
                self.add(VlanVidMatch(value))
            self.vlans[-1] = [value, self.vlans[-1][1]]
        else:
            self._is_good_packet = False
            raise ValueError("Can't change vid because no VLAN header present")

    def change_pcp(self, value):
        """Changes the VLAN PCP of the packet to a new value. Throws an error
        if this methods is called for a packet that does not have a VLAN.

        Arguments:
            value {int} --the new VLAN PCP value
        """
        if self.vlans:
            if self.get(VlanPcpMatch):
                self.override(VlanPcpMatch(value))
            else:
                self.add(VlanPcpMatch(value))
            self.vlans[-1] = [self.vlans[-1][0], value]
        else:
            self._is_good_packet = False
            raise ValueError("Can't change pcp because no VLAN header present")

    def pop_vlan(self):
        """Pops the outer VLAN from the packet's VLAN list.

        Returns:
            {bool} -- True if successful
        """
        if self.vlans:
            self.vlans = self.vlans[:-1]
            if self.vlans:
                self.change_vid(self.vlans[-1][0])
                self.change_pcp(self.vlans[-1][1])
            else:
                self.remove(VlanVidMatch)
                self.remove(VlanPcpMatch)
            return True
        else:
            self._is_good_packet = False
            raise ValueError("Can't pop VLAN because no VLAN header present")

    def change_inport(self, value):
        """Changes the Inport of the packet to a different port.

        Arguments:
            value {object} -- the port being changed to
        """
        self.override(InPortMatch(value))

    def split(self):
        """Creates a new copy of the packet, but with individual protocol
        fields of the packet being copied over according to their own copy
        methods.

        Returns:
            {object} -- a copy of the packet
        """
        new_packet = self.__class__(source=self.source,
                                    destination=self.destination,
                                    source_port=self.source_port,
                                    vlans=[[x, y] for x, y in self.vlans])
        new_packet._is_good_packet = self.is_good_packet
        for packet_field in self.values:
            new_packet.override(packet_field.copy())
        return new_packet

    def remove_inport(self):
        """Removes the Inport field from the packet.
        """
        self.remove(InPortMatch)

    @property
    def inport(self):
        """Returns the Inport of the packet.
        """
        return self.get(InPortMatch).value

    @property
    def is_tagged(self):
        """Returns True if the packet has a VLAN.
        """
        return self.vlans

    @property
    def is_good_packet(self):
        """Returns True if the packet does not have unresolved errors.
        """
        return self._is_good_packet


class Layer2Packet(Packet):
    """Defines packets which contain OSI Layer 2 information(such as MAC
    addresses).
    """
    PRESENT_FIELDS = [InPortMatch, EthDstMatch, EthSrcMatch, EthTypeMatch]

    def __init__(self, in_port=None, eth_dst=None, eth_src=None,
                 eth_type=None, vlan_id=None, vlan_pcp=None, *t, **s):
        """Sets up a new packet object containing OSI Layer 2 information.

        Keyword Arguments:
            in_port {*} -- the Inport of the packet (default: {None})
            eth_dst {str} -- the MAC address of the destination (default: {None})
            eth_src {str} -- the MAC address of the source (default: {None})
            eth_type {str/int} -- the Layer 3 protocol used to transmit the packet (default: {None})
            vlan_id {int} -- the VLAN VID of the packet (default: {None})
            vlan_pcp {int} -- the VLAN PCP of the packet (default: {None})

        Variable Length Arguments:
            {*} -- must also include arguments necessary for initializing a
                base Packet object
        """
        super().__init__(*t, **s)
        for x, y in ((in_port, InPortMatch), (eth_dst, EthDstMatch),
                     (eth_src, EthSrcMatch), (eth_type, EthTypeMatch),
                     (vlan_id, VlanVidMatch), (vlan_pcp, VlanPcpMatch)):
            if x:
                self.override(y(x))


class TaggedPacket(Layer2Packet):
    """Defines packets which use VLAN tags.
    """
    PRESENT_FIELDS = Layer2Packet.PRESENT_FIELDS + [VlanVidMatch, VlanPcpMatch]

    def __init__(self, *t, **s):
        """Sets up a new packet object with one or more VLANs.

        Keyword Arguments:
            vlan_id {int} -- the VLAN VID of the packet (default: {None})
            vlan_pcp {int} -- the VLAN PCP of the packet (default: {None})

        Variable Length Arguments:
            {*} -- must also include arguments necessary for initializing a
                base Packet object and a Layer 2 Packet object
        """
        super().__init__(*t, **s)


class IPv4Packet(Layer2Packet):
    """Defines packets that use the IPv4 protocol(OSI Layer 3).
    """
    PRESENT_FIELDS = Layer2Packet.PRESENT_FIELDS + [IpProtoMatch, Ipv4SrcMatch, Ipv4DstMatch]

    def __init__(self, ip_proto=None, ipv4_src=None, ipv4_dst=None, *t, **s):
        """"Sets up a new packet object that uses the IPv4 protocol.

        Keyword Arguments:
            ip_proto {str/int} -- sub-protocol type used by the packet (default: {None})
            ipv4_src {str} -- IPv4 address of the source (default: {None})
            ipv4_dst {str} -- IPv4 address of the destination (default: {None})

        Variable Length Arguments:
            {*} -- must also include arguments necessary for initializing a
                base Packet object and a Layer 2 Packet object
        """
        super().__init__(*t, **s)
        self.add(EthTypeMatch(0x800))
        for x, y in ((ipv4_src, Ipv4SrcMatch), (ipv4_dst, Ipv4DstMatch)):
            if x:
                self.add(y(x))

    @property
    def arp(self):
        """Returns the equivalent ARP packet for an IPv4 packet.
        """
        eth_src = None if not self.get(EthSrcMatch) else self.get(EthSrcMatch).value
        eth_dst = None if not self.get(EthDstMatch) else self.get(EthDstMatch).value
        return ArpPacket(source=self.source,
                         source_port=self.source_port,
                         destination=self.destination,
                         vlans=self.vlans,
                         eth_dst="ff:ff:ff:ff:ff:ff" if self.forward and not eth_dst else eth_dst,
                         eth_src=eth_src,
                         arp_tpa=self.get(Ipv4DstMatch).value,
                         arp_spa=self.get(Ipv4SrcMatch).value)


class TcpPacket(IPv4Packet):
    """Defines packets that use the TCP protocol.
    """

    PRESENT_FIELDS = IPv4Packet.PRESENT_FIELDS + [TcpSrcMatch, TcpDstMatch]

    def __init__(self, tcp_src=None, tcp_dst=None, *t, **s):
        """Sets up a new packet object that uses the TCP protocol.

        Keyword Arguments:
            tcp_src {str/int} -- TCP port number/code of the source (default: {None})
            tcp_dst {str/int} -- TCP port number/code of the destination (default: {None})
        """
        super().__init__(ip_proto=6, *t, **s)
        for x, y in ((tcp_src, TcpSrcMatch), (tcp_dst, TcpDstMatch)):
            if x:
                self.add(y(x))


class UdpPacket(IPv4Packet):
    """Defines packets that use the UDP protocol.
    """

    PRESENT_FIELDS = IPv4Packet.PRESENT_FIELDS + [UdpSrcMatch, UdpDstMatch]

    def __init__(self, udp_src=None, udp_dst=None, *t, **s):
        """Sets up a new packet object that uses the UDP protocol.

        Keyword Arguments:
            udp_src {str/int} -- UDP port number/code of the source (default: {None})
            udp_dst {str/int} -- UDP port number/code of the destination (default: {None})
        """
        super().__init__(ip_proto=17, *t, **s)
        for x, y in ((udp_src, UdpSrcMatch), (udp_dst, UdpDstMatch)):
            if x:
                self.add(y(x))


class ArpPacket(Layer2Packet):
    """Defines packets that use the ARP protocol.
    """

    PRESENT_FIELDS = Layer2Packet.PRESENT_FIELDS + [ArpOpMatch, ArpSpaMatch, ArpTpaMatch]

    def __init__(self, arp_op=None, arp_tpa=None, arp_spa=None,
                 eth_dst="ff:ff:ff:ff:ff:ff", *t, **s):
        """Sets up a new packet object that uses the ARP protocol.

        Keyword Arguments:
            arp_op {int} -- ARP Opcode (default: {None})
            arp_tpa {str} -- IPv4 address of the destination (default: {None})
            arp_spa {str} -- IPv4 address of the source (default: {None})
            eth_dst {str} -- MAC address of the destination (default: {"ff:ff:ff:ff:ff:ff"})
        """
        super().__init__(eth_type=0x806, eth_dst=eth_dst, *t, **s)
        for x, y in ((arp_op, ArpOpMatch), (arp_tpa, ArpTpaMatch), (arp_spa, ArpSpaMatch)):
            if x:
                self.add(y(x))
