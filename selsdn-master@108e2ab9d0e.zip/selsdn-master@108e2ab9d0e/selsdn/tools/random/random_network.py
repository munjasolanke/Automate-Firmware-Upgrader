from ipaddress import ip_network
from random import sample

from ...automation.protocol import DNP3TCPProtocol, MMSProtocol, NTPProtocol, TelnetProtocol, HTTPProtocol, SNMPProtocol, PTPProtocol
from ...automation.application import UnicastApplication, MulticastApplication
from ...automation.device import SEL2740SDevice, EndDevice

from ...base.collection import NodeCollection, ApplicationCollection

def create_simple_random_network(number_of_switches, number_of_hosts, number_of_clients, ptp=None, number_of_applications=1, topology="ring", distribution="random", subnet="192.168.0.0/16", controller_ip="192.168.1.1", start_index=0):
    subnet_object = ip_network(subnet)
    switches = list()
    hosts = list()

    # Create Nodes
    ip_list = subnet_object.hosts()
    #if number_of_switches + number_of_hosts > len(ip_list):
    #   raise ValueError("Subnet too small for {} hosts and switches".format(number_of_switches + number_of_hosts))

    for index, address in zip(range(number_of_switches), ip_list):
        index += start_index
        new_device = SEL2740SDevice(name="-".join(["Switch",str(index)]), ip_address=str(address), subnet=str(subnet_object.netmask), default_gateway=controller_ip, controller_ip=controller_ip)
        switches.append(new_device)

    for index, address in zip(range(number_of_hosts), ip_list):
        index += start_index
        new_device = EndDevice(name="-".join(["Host",str(index)]), ip_address=str(address))
        hosts.append(new_device)

    number_of_hosts_per_switch = number_of_hosts // number_of_switches
    if number_of_hosts % number_of_switches:
        number_of_hosts_per_switch += 1

    if number_of_hosts_per_switch > 16:
        raise ValueError("Only 16 hosts per switch")

    # Create topology
    # Switch to Switch connections
    if len(switches) > 1:
        if topology == "ring":
            for index, switch in enumerate(switches):
                if switch == switches[-1]:
                    break
                switch.set_port(9, switches[index+1].get_port(10))
                switches[index+1].set_port(10, switch.get_port(9))

            switches[-1].set_port(9, switches[0].get_port(10))
            switches[0].set_port(10, switches[-1].get_port(9))
        elif topology == "mesh":
            for index, switch in enumerate(switches):
                done = 0
                for port_index, port in enumerate(range(9, 12+1)):
                    completed = False
                    if not switch.get_port(port).end:
                        for other_switch in get_next_switches(switches, start=index, end=index+done+1):
                            if other_switch == switch:
                                continue
                            if completed:
                                break
                            for other_port in range(9, 12+1):
                                if not other_switch.get_port(other_port).end:
                                    switch.set_port(port, other_switch.get_port(other_port))
                                    other_switch.set_port(other_port, switch.get_port(port))
                                    done += 1
                                    completed = True
                                    break
        else:
            raise ValueError("Topology must be one of ring or mesh, not {}".format(topology))       

    # Switch to Host connections
    for index, switch in enumerate(switches):
        for port_number in range(number_of_hosts_per_switch):
            next_host_index = index*number_of_hosts_per_switch+port_number
            if next_host_index >= len(hosts):
                break
            # Need to adjust for D module
            adjusted_port_number = port_number + 1
            if 9 <= port_number:
                adjusted_port_number += 4
            switch.set_port(adjusted_port_number, hosts[next_host_index].get_port(0))
            hosts[next_host_index].set_port(0, switch.get_port(adjusted_port_number))

    missing_hosts = hosts[index*number_of_hosts_per_switch+port_number+1:]
    if missing_hosts:
        print("missing hosts", missing_hosts)

    # Create applications
    if distribution == "random":
        clients = sample(hosts, k=number_of_clients)
    elif distribution == "first":
        clients = list()
        for index in range(number_of_clients):
            for switch in switches:
                client = switch.get_port(1).end.owner
                clients.append(client)
    elif distribution == "one":
        clients = list()
        for switch in switches:
            if len(clients) == number_of_clients:
                break
            for port in switch.ports:
                if port.end:
                    client = port.end.owner
                    clients.append(client)
                    if len(clients) == number_of_clients:
                        break
    else:
        raise ValueError("Distribution must be one of random or first, not {}".format(distribution))

    applications = list()
    application_list = get_application_list(number_of_applications)

    for host in hosts:
        if host in clients:
            continue

        for application in application_list:
            new_applications = [UnicastApplication(name="-".join([application.__name__[:-8], str(len(applications)+index)]), protocol=application(), source=client, destination=host) for index, client in enumerate(clients)]
            applications.extend(new_applications)

    # Create PTP stuff
    if ptp:
        ptp_masters, ptp_clients, vlan_id = ptp
        ptp_devices = sample(hosts, k=ptp_clients+ptp_masters)
        ptp_masters, ptp_clients = ptp_devices[:ptp_masters], ptp_devices[ptp_masters:]
        for ptp_master in ptp_masters:
            other_masters = ptp_masters[::]
            other_masters.remove(ptp_master)
            new_application = MulticastApplication(name="PTP", protocol=PTPProtocol(vlan_vid=vlan_id), source=ptp_master, destinations=ptp_clients+other_masters)
            applications.append(new_application)

    return NodeCollection(values=switches+hosts), ApplicationCollection(values=applications)

def get_application_list(number):
    return (DNP3TCPProtocol, MMSProtocol, NTPProtocol, TelnetProtocol, HTTPProtocol, SNMPProtocol)[:number]

def get_next_switches(switches, start, end):
    return switches[end:] + switches[:start]
