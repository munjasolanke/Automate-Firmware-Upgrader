from time import asctime,time,strftime
from math import floor

def dump_run_collection_header(info):
    print("Starting upload at time", info["start_time"], "to", info["command"], info["object_type"])
    print("Each % is", info["one_percent"], info["object_type"])

def dump_run_collection_percent(info):
    print("{}({}/{}) {}% @ {} -- {}: {:.2f} -- ave-{}: {:.2f} -- ~time-left: {:02d}:{:02d}:{:02d} -- total-time: {:02d}:{:02d}:{:02d}".format(
             info["object_type"],
             info["index"],
             info["totalNumGroups"],
             info["cur_percent"], 
             info["percent_time"], 
             info["acronym"],
             info["timepergroup"],
             info["acronym"],
             info["avetimepergroup"],
             info["tlhours"],
             info["tlminutes"],
             info["tlseconds"],
             info["tthours"],
             info["ttminutes"],
             info["ttseconds"]))

def dump_run_collection_exception(info,group_object,e):
    raise ValueError("Error programming {} {} because {}".format(info["object_type"], group_object, e))

global run_collection_header_dumper_callback
global run_collection_percent_dumper_callback
global run_collection_exception_callback
run_collection_header_dumper_callback = dump_run_collection_header
run_collection_percent_dumper_callback = dump_run_collection_percent
run_collection_exception_callback = dump_run_collection_exception
 
def set_run_collection_header_dumper_callback(override_callback):
    global run_collection_header_dumper_callback
    run_collection_header_dumper_callback = override_callback

def set_run_collection_percent_dumper_callback(override_callback):
    global run_collection_percent_dumper_callback
    run_collection_percent_dumper_callback = override_callback

def set_run_collection_exception_callback(override_callback):
    global run_collection_exception_callback
    run_collection_exception_callback = override_callback

def run_collection(object_list, callback, object_type, command):
    totalNumGroups = len(object_list)
    callback_function = callback
    group_objects = object_list
    acronym = "tp" + command[0] + object_type[0]
    responses = list()

    one_percent = totalNumGroups / 100
    current_progress = 0

    info = {}
    info["start_time"] = asctime()
    info["command"] = command
    info["object_type"] = object_type
    info["one_percent"] = one_percent
    info["totalNumGroups"] = totalNumGroups
    info["acronym"] = acronym

    display = totalNumGroups > 0

    if display:
        run_collection_header_dumper_callback(info)

    lasttime = time()
    starttime = time()
    last_percent = 0

    for index, group_object in enumerate(group_objects):

        cur_percent = floor((index / totalNumGroups) * 100)
        if display and cur_percent > last_percent:
            last_percent = cur_percent
            current_progress += 1
            curtime = time()
            difftime = curtime-lasttime
            timepergroup = difftime/one_percent
            timerunning = curtime-starttime
            if index > 0:
                avetimepergroup = timerunning/index
            else:
                avetimepergroup = 0
            timeleft = avetimepergroup * (totalNumGroups - index)
            tlhours, remainder = divmod(timeleft, 3600)
            tlminutes, tlseconds = divmod(remainder, 60)
            tthours, remainder = divmod(timerunning, 3600)
            ttminutes, ttseconds = divmod(remainder, 60)

            info["index"] = index
            info["cur_percent"] = cur_percent
            info["percent_time"] = strftime("%H:%M:%S")
            info["timepergroup"] = timepergroup
            info["avetimepergroup"] = avetimepergroup
            info["tlhours"] = int(tlhours)
            info["tlminutes"] = int(tlminutes)
            info["tlseconds"] = int(tlseconds)
            info["tthours"] = int(tthours)
            info["ttminutes"] = int(ttminutes)
            info["ttseconds"] = int(ttseconds)
            run_collection_percent_dumper_callback(info)

            lasttime = curtime

        try:
            responses.append(callback_function(group_object))
        except Exception as e:
            run_collection_exception_callback(info,group_object,e)
            

    return responses
