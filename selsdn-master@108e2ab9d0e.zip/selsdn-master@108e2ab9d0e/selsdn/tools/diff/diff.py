from collections import defaultdict

from ...base.collection import NodeCollection, FlowCollection, GroupCollection, InterfacedObject, ApplicationCollection
from ...base.collection import MeterCollection
from ...automation.device import ControllerDevice, OpenFlowDevice, EndDevice, TraditionalSwitchDevice
from ...openflow.validation.validate_entries import get_entries_by_switch_table_priority

from . import LOGGER

def create_topology_diff(old_entries, new_entries, networks, network_new_entries=False, ignore_hosts=False):
    for old_entry in old_entries:
        if isinstance(old_entry, TraditionalSwitchDevice):
            continue
        elif isinstance(old_entry, OpenFlowDevice):
            old_ports = old_entry.switch_ports
        else:
            old_ports = old_entry.get_ports_by_networks(networks)

        new_entry = new_entries.has_name(old_entry.name)
        if new_entry:
            new_entry = new_entry[0]
            new_ports = new_entry.get_ports_by_networks(networks) if network_new_entries else new_entry.ports

            if len(new_ports) != len(old_ports):
                print("{} has a different number of ports from {} to {}".format(
                    new_entry.name, len(old_ports), len(new_ports)))

            for old_port, new_port in zip(old_ports, new_ports):
                if old_port.end and not new_port.end:
                    if not (ignore_hosts and not isinstance(old_port.end.owner, OpenFlowDevice)):
                        print("{} port {} should be connected to {} but is not currently connected".format(new_entry.name, old_port.name, old_port.end.print_name))
                elif not old_port.end and new_port.end:
                    print("{} port {} should not be connected but is currently connected to {}".format(new_entry.name, old_port.name, new_port.end.print_name))
                elif old_port.end and new_port.end:
                    if isinstance(old_port.end.owner, TraditionalSwitchDevice):
                        old_note = old_port.find_connected_openflow_switch_port().print_name
                    else:
                        old_note = old_port.end.print_name

                    if isinstance(new_port.end.owner, TraditionalSwitchDevice):
                        new_note = new_port.find_connected_openflow_switch_port().print_name
                    else:
                        new_note = new_port.end.print_name

                    if old_note != new_note:
                        print("{} port {} should be connected to {} but is connected to {}".format(new_entry.name, old_port.name, new_note, old_note))
                else:
                    pass
                    #print("why I am here {} {}".format(old_port, new_port))
        else:
            print("Can't find {} in current entries".format(old_entry.name))

    for new_entry in new_entries:
        if isinstance(new_entry, TraditionalSwitchDevice):
            continue
        old_entry = old_entries.has_name(new_entry.name)
        if not old_entry:
            print("Can't find {} in original entries".format(new_entry.name))

def create_node_entries_diff(old_entries, new_entries):
    add_entries, delete_entries = create_generic_entries_diff(old_entries=old_entries, new_entries=new_entries, check_overlap=True)
    return NodeCollection(add_entries), NodeCollection(delete_entries)

def create_configuration_node_entries_diff(old_entries, new_entries):
    return create_node_entries_diff(old_entries=old_entries, new_entries=new_entries)

def create_application_entries_diff(old_entries, new_entries):
    # There is no overlap for application entries
    # There is overlap only in the programming
    if not old_entries:
        old_entries = ApplicationCollection()
    if not new_entries:
        new_entries = ApplicationCollection()
    add_entries, delete_entries = _create_application_entries_diff(old_entries=old_entries, new_entries=new_entries, check_overlap=True)
    return ApplicationCollection(add_entries), ApplicationCollection(delete_entries)

def _create_application_entries_diff(old_entries, new_entries, check_overlap=False):
    delete_entries = list()
    add_entries = list()

    already_matched = list()
    for source_name, old_applications_by_source in old_entries.entries_by_source_name.items():
        if new_entries.entries_by_source_name.get(source_name):
            new_applications_by_source = new_entries.entries_by_source_name[source_name]
            for old_entry in old_applications_by_source:
                for new_entry in new_applications_by_source:
                    if new_entry.diff_eq(old_entry):
                        LOGGER.info("{} overlaps with old entry {}".format(new_entry, old_entry))
                        if new_entry.get_attribute("linked_equal"):
                            new_entry.get_attribute("linked_equal").append(old_entry)
                        else:
                            new_entry.set_attribute("linked_equal", [old_entry])
                        already_matched.append(new_entry)
                        break
                    elif check_overlap and new_entry not in already_matched and new_entry.overlaps(old_entry):
                        LOGGER.info("{} overlaps with old entry {}".format(new_entry, old_entry))
                        if new_entry.get_attribute("linked_delete"):
                            new_entry.get_attribute("linked_delete").append(old_entry)
                        else:
                            new_entry.set_attribute("linked_delete", [old_entry])

                        if old_entry.get_attribute("linked_add"):
                            old_entry.get_attribute("linked_add").append(new_entry)
                        else:
                            old_entry.set_attribute("linked_add", [new_entry])

                        delete_entries.append(old_entry)
                        add_entries.append(new_entry)
                        break
                else:
                    LOGGER.info("Old entry {} does not match against any new entries so is deleted".format(old_entry))
                    delete_entries.append(old_entry)
        else:
            delete_entries.extend(old_applications_by_source)

    for source_name, new_applications_by_source in new_entries.entries_by_source_name.items():
        if old_entries.entries_by_source_name.get(source_name):
            old_applications_by_source = old_entries.entries_by_source_name[source_name]
            for new_entry in new_applications_by_source:
                for old_entry in old_applications_by_source:
                    if old_entry.diff_eq(new_entry):
                        LOGGER.info("{} matches against new entry {}".format(new_entry, old_entry))
                        break
                    elif check_overlap and new_entry.overlaps(old_entry):
                        LOGGER.info("{} overlaps with new entry {}".format(new_entry, old_entry))
                        break
                else:
                    LOGGER.info("New entry {} does not match against any old entries so is added".format(new_entry))
                    add_entries.append(new_entry)
        else:
            add_entries.extend(new_applications_by_source)

    return (add_entries, delete_entries)

def create_generic_entries_diff(old_entries, new_entries, check_overlap=False):
    delete_entries = list()
    add_entries = list()

    already_matched = list()
    for old_entry in old_entries:
        for new_entry in new_entries:
            if old_entry.diff_eq(new_entry):
                LOGGER.info("{} matches against old entry {}".format(new_entry, old_entry))
                already_matched.append(new_entry)
                break
            # This only applies if the the node is also the same
            elif check_overlap and new_entry not in already_matched and new_entry.overlaps(old_entry):
                LOGGER.info("{} overlaps with old entry {}".format(new_entry, old_entry))
                if new_entry.get_attribute("linked_delete"):
                    new_entry.get_attribute("linked_delete").append(old_entry)
                else:
                    new_entry.set_attribute("linked_delete", [old_entry])

                if old_entry.get_attribute("linked_add"):
                    old_entry.get_attribute("linked_add").append(new_entry)
                else:
                    old_entry.set_attribute("linked_add", [new_entry])

                delete_entries.append(old_entry)
                add_entries.append(new_entry)
                break
        else:
            LOGGER.info("Old entry {} does not match against any new entries so is deleted".format(old_entry))
            delete_entries.append(old_entry)

    for new_entry in new_entries:
        for old_entry in old_entries:
            if old_entry.diff_eq(new_entry):
                LOGGER.info("{} matches against old entry {}".format(new_entry, old_entry))
                break
            elif check_overlap and new_entry.overlaps(old_entry):
                LOGGER.info("{} overlaps with old entry {}".format(new_entry, old_entry))
                break
        else:
            LOGGER.info("New entry {} does not match against any old entries so is added".format(new_entry))
            add_entries.append(new_entry)

    return (add_entries, delete_entries)

def create_flow_entries_diff(old_entries, new_entries):
    add_entries = list()
    delete_entries = list()

    old_sorted_entries = get_entries_by_switch_table_priority(old_entries)
    new_sorted_entries = get_entries_by_switch_table_priority(new_entries)

    for switch, table_priorities in old_sorted_entries.items():
        for table, priorities in table_priorities.items():
            for priority, flow_entries in priorities.items():
                try:
                    new_entries = new_sorted_entries[switch][table][priority]
                except:
                    delete_entries.extend(flow_entries)
                else:
                    for old_entry in flow_entries:
                        for new_entry in new_entries:
                            if old_entry.diff_updatable_partial(new_entry):
                                if old_entry.eq_partial(new_entry):
                                    LOGGER.info("{} matches against old entry {}".format(new_entry, old_entry))
                                    break
                                else:
                                    LOGGER.info("{} overlaps with old entry {}".format(new_entry, old_entry))
                                    if new_entry.get_attribute("linked_delete"):
                                        new_entry.get_attribute("linked_delete").append(old_entry)
                                    else:
                                        new_entry.set_attribute("linked_delete", [old_entry])

                                    if old_entry.get_attribute("linked_add"):
                                        old_entry.get_attribute("linked_add").append(new_entry)
                                    else:
                                        old_entry.set_attribute("linked_add", [new_entry])

                                    delete_entries.append(old_entry)
                                    add_entries.append(new_entry)
                                    break

                        else:
                            LOGGER.info("Old entry {} does not match against any new entries so is deleted".format(old_entry))
                            delete_entries.append(old_entry)

    for switch, table_priorities in new_sorted_entries.items():
        for table, priorities in table_priorities.items():
            for priority, flow_entries in priorities.items():
                try:
                    old_entries = old_sorted_entries[switch][table][priority]
                except:
                    add_entries.extend(flow_entries)
                else:
                    for new_entry in flow_entries:
                        for old_entry in old_entries:
                            # Don't need to check if overlap because it also includes this
                            if old_entry.diff_updatable_partial(new_entry):
                                break
                        else:
                            LOGGER.info("New entry {} does not match against any old entries so is added".format(new_entry))
                            add_entries.append(new_entry)

    return FlowCollection(add_entries, perform_validation=False), FlowCollection(delete_entries, perform_validation=False)

def create_group_entries_diff(old_entries, new_entries):
    add_entries, delete_entries = create_generic_entries_with_entry_id_diff(old_entries=old_entries, new_entries=new_entries)
    return GroupCollection(add_entries), GroupCollection(delete_entries)

def create_meter_entries_diff(old_entries, new_entries):
    add_entries, delete_entries =  create_generic_entries_with_entry_id_diff(old_entries=old_entries, new_entries=new_entries)  
    return MeterCollection(add_entries), MeterCollection(delete_entries)

def create_generic_entries_with_entry_id_diff(old_entries, new_entries):
    add_entries = list()
    delete_entries = list()

    old_dict = defaultdict(list)
    for entry in old_entries:
        old_dict[entry.entry_id].append(entry)

    new_dict = defaultdict(list)
    for entry in new_entries:
        new_dict[entry.entry_id].append(entry)

    sorted_old_entries = sorted(old_entries, key=lambda old_entry: old_entry.entry_id)
    sorted_new_entries = sorted(new_entries, key=lambda new_entry: new_entry.entry_id)

    for old_entry in sorted_old_entries:
        if new_dict[old_entry.entry_id]:
            for new_entry in new_dict[old_entry.entry_id]:
                # This only applies if the the node is also the same
                if old_entry == new_entry:
                    LOGGER.info("{} matches against old entry {}".format(new_entry, old_entry))
                    break
                # This only applies if the the node is also the same
                elif new_entry.overlaps(old_entry):
                    LOGGER.info("{} overlaps with old entry {}".format(new_entry, old_entry))
                    if new_entry.get_attribute("linked_delete"):
                        new_entry.get_attribute("linked_delete").append(old_entry)
                    else:
                        new_entry.set_attribute("linked_delete", [old_entry])

                    if old_entry.get_attribute("linked_add"):
                        old_entry.get_attribute("linked_add").append(new_entry)
                    else:
                        old_entry.set_attribute("linked_add", [new_entry])

                    delete_entries.append(old_entry)
                    add_entries.append(new_entry)
                    break
            else:
                delete_entries.append(old_entry)
        else:
            delete_entries.append(old_entry)

    for new_entry in sorted_new_entries:
        if old_dict[new_entry.entry_id]:
            for old_entry in old_dict[new_entry.entry_id]:
                if old_entry == new_entry:
                    break
                elif new_entry.overlaps(old_entry):
                    break
            else:
                LOGGER.info("New entry {} does not match against any old entries so is added".format(new_entry))
                add_entries.append(new_entry)
        else:
            LOGGER.info("New entry {} does not match against any old entries so is added".format(new_entry))
            add_entries.append(new_entry)

    return (add_entries, delete_entries)
