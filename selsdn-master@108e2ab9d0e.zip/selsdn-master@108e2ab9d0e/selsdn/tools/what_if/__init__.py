"""Init file for what_if tests. Sets up the Logger for WhatIf.
"""
from logging import getLogger

LOGGING_NAME = __name__
LOGGER = getLogger(LOGGING_NAME)
