"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

The What-If method of testing OpenFlow configurations is a simulation tool that
takes a sample packet and tests whether it would be successfully transmitted
across a network to the target destination with the provided OpenFlow entries
and topology. Failover in the case of an unexpected break in the network is
included in the test.
"""

from copy import deepcopy
import operator

from . import LOGGER

from ...openflow.core.instructions import GotoTableInstruction, WriteActionsInstruction
from ...openflow.core.actions import OutputAction, GroupAction, SetVlanVidAction, SetVlanPcpAction, PushVlanAction, PopVlanAction, ActionSet
from ...openflow.core.group_entry import AllGroup, FastFailoverGroup
from ...openflow.core.ports import LocalPort, IngressPort, SpecialPorts, ControllerPort, PhysicalPort
from ...openflow.core.action_bucket import WatchGroup
from ...openflow.core.match_fields import VlanVidMatch, VlanPcpMatch

from ...automation.path import Path
from ...automation.link import Link
from ...automation.device import SEL274XSDevice, EndDevice, TraditionalSwitchDevice, Device, SwitchManagementDevice
from ...automation.port import Port
from ...automation.application import MulticastApplication
from ...automation.protocol import EthDstMatch
from ...automation.policy import IDSMissPolicy, IDSPolicy

from .result import WhatIfMulticastTest, WhatIfUnicastTest, WhatIfSubTest, WhatIfSubSubTest


class WhatIf:
    """Class for testing an OpenFlow configuration.
    """

    def __init__(self, flow_entries, group_entries, connections, nodes,
                 max_switches_links=None, match_failure=False):
        """Sets up a simulated OpenFlow network on which the series of What-If
        tests will run.

        Arguments:
            flow_entries {list} -- list of OpenFlow flow entries
            group_entries {list} -- list of OpenFlow group entries
            connections {list} -- list of connections in the simulated network
            nodes {list} -- list of devices in the simulated network

        Keyword Arguments:
            max_switches_links {tuple} -- 3-tuple with format (A, (B, C), D) (default: {None})
                A {int} -- maximum of switches to failover
                B, C {int} -- maximum combination of switches and links together
                D {int} -- maximum number of links to failover
        """
        self.flow_entries = list()
        self.flow_entries_sorted = dict()
        self.refresh_flow_entries(flow_entries)
        self.match_failure = match_failure
        self.group_entries = group_entries
        self.connections = connections
        self.current_application = None
        nodes_dict = dict()
        for node in nodes:
            nodes_dict[node.name] = node
        self.nodes = nodes_dict
        self.node_entries = nodes
        self.test_cases = list()
        # This tuple is number of switches and 0 links, number of switches and links
        # and number of links only to pull down for testing
        # try (1, (1,0), 1) for instance to test N-1
        self.max_test = (0, (0, 0), 0) if not max_switches_links else max_switches_links
        self.match_result_dict = dict()
        self.store_match_results = False

    def refresh_flow_entries(self, flow_entries):
        self.flow_entries = flow_entries
        self.flow_entries_sorted = self._sort_flow_entries(flow_entries)

    def _sort_flow_entries(self, flow_entries):
        sorted_flow_entries = dict()
        for flow_entry in flow_entries:
            if not sorted_flow_entries.get(flow_entry.node_name):
                sorted_flow_entries[flow_entry.node_name] = dict()

            if not sorted_flow_entries[flow_entry.node_name].get(flow_entry.table_id):
                sorted_flow_entries[flow_entry.node_name][flow_entry.table_id] = list()

            sorted_flow_entries[flow_entry.node_name][flow_entry.table_id].append(flow_entry)

        for switch, table_ids in sorted_flow_entries.items():
            for table_id in table_ids:
                sorted_flow_entries[switch][table_id] = sorted(sorted_flow_entries[switch][table_id], key=lambda x: x.priority, reverse=True)

        return sorted_flow_entries

    def run_one_switch_test(self, packet, switch_name, inport=None):
        switch = self.node_entries.has_name(switch_name)[0]
        if inport:
            inport = switch.get_port(inport)
            packet.change_inport(inport.name)
        self.store_match_results = True
        self.match_result_dict = dict()
        flow_entries, actions = self.determine_actions(switch, inport, packet)
        return self.match_result_dict[switch_name]

    def add_match_result(self, packet, node_name, flow_entry, match_result):
        if self.store_match_results is False:
            return
        if node_name not in self.match_result_dict:
            self.match_result_dict[node_name] = list()
        self.match_result_dict[node_name].append((packet, flow_entry, match_result))

    def convert_undertest(self, undertest):
        """Ensures the correct node or port is specified to be broken,
        regardless of format, during a failover test.

        Arguments:
            undertest {*} -- the node/port/combination under failover test

        Returns:
            {*} -- If a combination of switch and port is given with the
                switch named by string, return the port(or the switch if the
                port is None). Otherwise return the unmodified arg as the
                specified node/port/combination.
        """
        if type(undertest) is tuple:
            switch, port = undertest
            if type(switch) is str:
                if port:
                    switch = self.nodes[switch]
                    return switch.get_port(port)
                else:
                    return self.nodes[switch]

        return undertest

    def test_applications(self, applications, undertest=None,
                          do_undertest=False):
        """Runs a series of What-If tests on the simulated network using the
        test cases provided in the list of applications.

        Arguments:
            applications {list} -- application test cases to run through the network

        Keyword Arguments:
            undertest {*} -- node/port/combination broken by failover tests (default: {None})
            do_undertest {bool} -- True to enable failover testing (default: {False})
        """

        if undertest:
            undertest = self.convert_undertest(undertest)
            self.break_connections(undertest)

        for index, application in enumerate(applications):
            print("Testing application {}: {} of {}".format(application.name, index, len(applications)))
            application.convert_source_and_destination_to_node_objects(self.node_entries)
            result = self.test_application(application,
                                           undertest=undertest,
                                           do_undertest=do_undertest)
            if result:
                self.test_cases.append(result)

        self.connections.restore()

    def check_vlan_headers_against_original(self, path, original_vlans):
        """Checks that the VLAN headers when the packet reached its destination
        are the same as the VLAN headers when the packet was injected into the
        network. Adds an error message to the test path if they are not.

        Arguments:
            path {object} -- the network path of the packet under test
            original_vlans {tuple} -- network VLAN headers compared to the packet's VLAN headers
        """
        if tuple(path.packet.vlans) != original_vlans:
            path.add_error("Packet VLAN(s) at ingress {} do not match the VLAN(s) at egress {}".format(str(original_vlans).replace(",", ":"), str(tuple(path.packet.vlans)).replace(",", ":")))

    def return_ports(self, thing):
        """Lists the local ports of a device. Throws an error if something
        other than a port or device is provided.

        Arguments:
            thing {*} -- a port or device

        Returns:
            {list} -- contains the port, or all local ports of the device
        """
        if isinstance(thing, Port):
            return [thing]
        elif isinstance(thing, Device):
            return [port for port in thing.local_ports]
        else:
            raise

    def generate_results(self, subtest, outcome, destinations, packet):
        """Tests each destination in a packet's path, succeeding if the
        destination exists as a destination in the application. If it doesn't,
        the test fails unless it is not applicable(break point in a failover
        test). Throws an error if there is a duplicate destination.

        Next, tests each point in the packet's path, to determine whether all
        destinations are listed in every case. Succeeds if all destinations are
        listed, otherwise fails(unless not applicable due to break point in
        failover test).

        Arguments:
            subtest {object} -- test object for testing an individual packet
            outcome {list} -- the path of the packet through the network
            destinations {list} -- list of destinations in the network
            packet {object} -- simulated data packet sent through the network
        """
        for destination in destinations:
            missing_port = False
            for port in self.return_ports(destination):
                found = False
                for path in outcome:
                    # ("finish", path.finish,
                    #       "owner", path.finish.owner,
                    #       "destination", destination,
                    #       "port", port)
                    #("packet", path.packet)
                    if (isinstance(destination, Device) and path.finish.owner == destination and path.finish == port) or \
                            (isinstance(destination, Port) and path.finish == port):
                        if found is True:
                            path.add_error("Duplicate received to destination {} for port {}".format(port.owner.name, port.name))
                        else:
                            found = True
                        test = WhatIfSubSubTest(outcome=path, result=True)
                        subtest.add_test(test)
                        path.ignore = True

                if found is False:
                    path = Path(packet.source_port)
                    path.add_hop(ingress_port=None, switch=None, packet=packet.split())
                    path.packet = packet.split()
                    path.add_error("Packet was never received for destination {} for port {}".format(port.owner.name, port.name))
                    if subtest.undertest and \
                            port.end and \
                            port.end.owner.name + "*" in subtest.undertest:
                        result = "NA"
                    else:
                        result = None
                        missing_port = True
                    test = WhatIfSubSubTest(outcome=path, result=result)
                    subtest.add_test(test)
                    path.ignore = True

        for path in outcome:
            if hasattr(path, "ignore") and path.ignore:
                continue
            targets = list()
            for destination in destinations:
                if isinstance(destination, Port):
                    targets.append(destination.owner)
                else:
                    targets.append(destination)

            if isinstance(path.finish, Port):
                finish = path.finish.owner
            else:
                finish = path.finish

            if finish not in destinations:
                path.add_error("Didn't reach an expected destination")
                if missing_port:
                    result = None
                else:
                    result = "NA"
                test = WhatIfSubSubTest(outcome=path, result=result)

                subtest.add_test(test)

    def add_openflow_diagnostics(self, entry):
        """Adds diagnostic information related to the current application and
        number of match counts to the OpenFlow entry.

        Arguments:
            entry {object} -- diagnostics entry
        """
        # def add_hop(self, ingress_port, switch, egress_port, flow_entries,
        #               group_entries, actions, packet):
        if entry.get_attribute("whatif_applications"):
            entry.get_attribute("whatif_applications").add(self.current_application)
        else:
            entry.set_attribute("whatif_applications",
                                set([self.current_application]))

        if entry.get_attribute("whatif_count"):
            entry.set_attribute("whatif_count",
                                entry.get_attribute("whatif_count") + 1)
        else:
            entry.set_attribute("whatif_count",
                                1)

    def compute_outcome(self, testcase, outcome, destinations, packet,
                        undertest=None):
        """Tests the outcome of a packet being sent through the simulated
        OpenFlow network, calling lower level tests for both VLAN header and
        packet destination validation.

        Arguments:
            testcase {object} -- the test running with the current application
            outcome {*} -- the packet's full network path, typically a list
            destinations {*} -- the destination(s) used by the application, typically a list
            packet {object} -- simulated data packet sent through the network

        Keyword Arguments:
            undertest {*} -- failover test case(if any) (default: {None})

        Returns:
            {object} -- test object containing the successes and failures along the path
        """
        if not type(destinations) is list:
            destinations = [destinations]

        subtest = WhatIfSubTest(start=packet.source_port,
                                undertest=undertest,
                                target=destinations,
                                packet_type=type(packet))
        testcase.add_test(subtest)

        if not type(outcome) is list:
            outcome = [outcome]

        for path in outcome:
            self.check_vlan_headers_against_original(path, tuple(packet.vlans))

        self.generate_results(subtest=subtest,
                              outcome=outcome,
                              destinations=destinations,
                              packet=packet)
        return subtest

    def collect_destinations_from_policies(self, application):
        destinations = list()
        for policy in application.policies:
            if isinstance(policy, IDSPolicy) and not isinstance(policy, IDSMissPolicy):
                destinations.append(policy.destination)
        return destinations

    def test_application(self, application, undertest=None, do_undertest=True):
        """Tests the outcome of each packet in an application. Also runs
        failover tests for each packet, if that feature is enabled.

        Arguments:
            application {object} -- an application containing test packet routes

        Keyword Arguments:
            undertest {*} -- {*} -- failover test case(if any) (default: {None})
            do_undertest {bool} -- True to enable failover testing (default: {True})

        Returns:
            {object} -- the complete test cases of the application
        """
        if application.policies and isinstance(application.policies[0], IDSMissPolicy):
            LOGGER.warning("Skipping application {} because it is Table Miss".format(application))
            return None
        else:
            LOGGER.info("Testing application {}".format(application))

        self.current_application = application.name
        if isinstance(application, MulticastApplication):
            testcase = WhatIfMulticastTest(application)
        else:
            testcase = WhatIfUnicastTest(application)

        ids_destinations = self.collect_destinations_from_policies(application)

        for packet in testcase.packets:
            if type(packet.destination) is not list:
                destinations = [packet.destination] + ids_destinations
            else:
                destinations = packet.destination + ids_destinations[::]
            # ("Finding path for packet", packet,
            #       "inport", packet.get_packet_field("inport"),
            #       packet.source_port,
            #       packet.destination)

            # This is primary case
            outcome = self.run_test(packet)
            subtest = self.compute_outcome(testcase,
                                           outcome,
                                           destinations,
                                           packet,
                                           undertest=undertest)
            result = subtest.success

            if do_undertest:
                self.test_application_undertests(testcase,
                                                 subtest,
                                                 packet,
                                                 destinations)

        return testcase

    def test_application_undertests(self, testcase, base, packet, destinations):
        """Runs all failover tests defined in an application on one of its
        packets.

        Arguments:
            testcase {object} -- The complete test cases of the application
            base {object} -- the subtest of the packet under test
            packet {object} -- the packet under test
        """
        for undertest in base.generate_test_cases():
            self.test_application_undertest(testcase=testcase,
                                            base=None,
                                            undertest=undertest,
                                            packet=packet,
                                            destinations=destinations)
            self.connections.restore()

    def serialize_undertests(self):
        """Creates a sorted string containing the names of each unique failover
        test case, to prevent duplicate tests of the same undertest.

        Returns:
            {string} -- string listing switches/links to break for failover test
        """
        base_str = "* / ".join(sorted(self.connections._broken_switches, key=lambda p: p)) + "*"

        for device, ports in sorted(self.connections._broken_links.items(), key=lambda kv: kv[0]):
            # default dict might cause empty list on lookup
            ports.sort()
            if ports and device not in self.connections._broken_switches:
                node = self.nodes[device]
                if isinstance(node, SEL274XSDevice):
                    base_str += " / " + ":".join([device, ".".join(map(str, ports))])

        return base_str

    def break_connections(self, undertest):
        """Breaks a connection in the simulated network in order to test
        failover. Raises an error if it is not given a port or switch

        Arguments:
            undertest {*} -- port or switch to be broken for this test case

        Returns:
            {bool} -- True if the switch or link is successfully broken(and is
                not a Traditional Switch Device or the port of one)
        """
        if isinstance(undertest, Port):
            if isinstance(undertest.owner, TraditionalSwitchDevice):
                return False
            else:
                worked = self.connections.break_link(undertest.owner, undertest)
        elif isinstance(undertest, SEL274XSDevice):
            worked = self.connections.unplug_switch(undertest)
        elif isinstance(undertest, TraditionalSwitchDevice):
            return False
        else:
            raise ValueError("Unable to interpret {}".format(undertest))

        return worked

    def check_if_undertest_limit_exceeded(self):
        """Check to see if the current cumulative undertest is surpassed,
        returning True if so.

        Returns:
            {bool} -- True if the maximum broken switches and links is exceeded
        """
        if (len(self.connections.broken_switches) > self.max_test[0] and len(self.connections.broken_links) == 0) or \
                (len(self.connections.broken_links) >= self.max_test[1][1] and len(self.connections.broken_switches) > self.max_test[1][0]) or \
                (len(self.connections.broken_links) > self.max_test[1][1] and len(self.connections.broken_switches) >= self.max_test[1][0]) or \
                (len(self.connections.broken_links) > self.max_test[2] and len(self.connections.broken_switches) == 0):
            return True

        return False

    def test_application_undertest(self, testcase, base, undertest, packet, destinations):
        """Manages the settings of the topology to match the desired undertest
        case, and then runs it. If the test succeeds, runs the test again with
        an additional break in the network until the maximum limit of broken
        switches and links is reached, or a test fails.

        Arguments:
            testcase {object} -- The complete test cases of the application
            base {object} -- the subtest of the packet under test
            undertest {*} -- the points in the network broken to test failover
            packet {object} -- the packet under test
        """
        if not self.break_connections(undertest):
            return

        if self.check_if_undertest_limit_exceeded():
            return

        undertest = self.serialize_undertests()

        if testcase.is_tested(packet.source_port,
                              undertest,
                              packet_type=type(packet)):
            return

        outcomes = self.run_test(packet)
        subtest = self.compute_outcome(testcase,
                                       outcomes,
                                       destinations,
                                       packet,
                                       undertest=undertest)

        if subtest.success:
            for sub_undertest in subtest.generate_test_cases():
                old_broken_links = deepcopy(self.connections._broken_links)
                old_broken_switches = deepcopy(self.connections._broken_switches)
                self.test_application_undertest(testcase, None, sub_undertest, packet, destinations)
                self.connections._broken_switches = old_broken_switches
                self.connections._broken_links = old_broken_links

    def get_flow_entries_by_table(self, flow_entries, table_id):
        """Returns all the flow entries from one table.

        Arguments:
            flow_entries {list} -- all flow entries being searched
            table_id {int} -- the OpenFlow Table ID of the chosen table

        Returns:
            {list} -- list of flow entries in the specified table
        """
        return flow_entries.get(table_id, {})

    def get_sorted_by_priority(self, flow_entries):
        """Sorts a list of flow entries according to priority.

        Arguments:
            flow_entries {list} -- a list of flow entries

        Returns:
            {list} -- the list of flow entries sorted in order of priority
        """
        return flow_entries

    def is_match_to_match_fields(self, match_fields, packet, test_more=True):
        """Tests whether the match fields match the fields of the packet. For a
        match to be found, the match field must either not be present for a
        given value field of the packet, or must be present with the same
        value(or be within mask range) of the same value field in the packet.
        If any of the match fields do not match the packet, then the packet
        would be blocked by the SDN software in a real network. Throws a type
        error if the packet has the wrong value type in a match field.

        Skips ambiguous match fields and re-runs the test to cover them if no
        other match fields fail. Throws a value error if the bad match fields
        fail after a second test.

        Arguments:
            match_fields {list} -- list of a node's match fields
            packet {object} -- packet with match fields used in comparison

        Keyword Arguments:
            test_more {bool} -- enables re-running the test a second time(default: {True})
                (set to False when actually re-running the test to avoid an infinite loop)

        Returns:
            {bool} -- True if all match fields match the packet
        """
        # 5 States - Match Field, Packet Field, this function focuses on no match, else match
        # because just one no match means no match for the entire entry
        # 1 Not present, not present means match
        # 2 Not present, present means match
        # 3 Present, not present means no match
        # 4 Present and Present, but different value means no match
        # 5 Present and Present, and same value (or within mask range) means match
        test_later = list()
        for match_field in match_fields:
            match_field_class = match_field.__class__

            # 3
            # ("is",
            #       match_field_class,
            #       match_field_class in packet.PRESENT_FIELDS,
            #       packet.get(match_field_class))
            #([a.__class__ for a in packet.values])
            # VLAN ID and PCP are special so are done separate
            # If the match field for VlanVid is present and the value is Present.
            # In that case, if a VLAN is not present in the packet, not a match
            if isinstance(match_field, VlanVidMatch) and match_field.value in ("Present", "None"):
                if match_field.value == "Present":
                    if not packet.get(match_field):
                        return "Match Field of VLAN Present, but no VLAN on packet"
                elif match_field.value == "None":
                    if packet.get(match_field):
                        return "Match Field of VLAN None, but packet has VLAN"
            elif isinstance(match_field, VlanVidMatch) or isinstance(match_field, VlanPcpMatch):
                matching_packet_field = packet.get(match_field)
                if matching_packet_field is None or not match_field.is_matching_value(matching_packet_field.value):
                    return "Match field VLAN does not match packet VLAN"
            elif match_field_class not in packet.PRESENT_FIELDS:
                #print("False other because has", match_field_class, "but not in", packet.PRESENT_FIELDS)
                return "The type of packet doesn't match the type of match field (IP, ARP, Layer 2)"
            elif match_field_class in packet.PRESENT_FIELDS and not packet.get(match_field):
                # There was no packet value given to determine match
                #if match_field_class is EthDstMatch and match_field.is_multicast:
                #    # we are looking for a multicast destination address, can't match unicast
                #    return False

                if test_more:
                    test_later.append(match_field)
                else:
                    print("Stuck here")
                    print("match field", match_field_class)
                    print("ALL potential packet fields", packet.PRESENT_FIELDS)
                    print("match field in question", repr(match_field))
                    print("all match fields", match_fields)
                    print("set packet fields", packet.values)
                    print("get packet fields", packet.get(match_field))
                    raise ValueError("Cannot make a determination without a packet value for {}".format(match_field_class.__name__))
            # 4 and 5, present and present
            elif match_field_class in packet.PRESENT_FIELDS and packet.get(match_field):
                matching_packet_field = packet.get(match_field)
                if type(match_field.value) is not type(matching_packet_field.value):
                    raise TypeError("Different Types for match field",
                                    match_field.__class__.__name__,
                                    match_field.value,
                                    type(match_field.value),
                                    matching_packet_field.value,
                                    type(matching_packet_field.value))

                # If packet value doesn't match match field value (with mask) then no match
                #print("is matching value", match_field, matching_packet_field.value, match_field.is_matching_value(matching_packet_field.value))
                if not match_field.is_matching_value(matching_packet_field.value):
                    return "{} does not match packet value {} for match field type {}".format(match_field, str(matching_packet_field), match_field_class.__name__)
        else:
            return True

        if test_more and test_later:
            return self.is_match_to_match_fields(test_later,
                                                 packet,
                                                 test_more=False)

    def find_match_from_entries(self, packet, flow_entries):
        """Finds a flow entry matching the packet from a list of flow entries.
        Ignores disabled and failed status flow entries.

        Arguments:
            packet {object} -- packet being tested in the simulated network
            flow_entries {list} -- list of flow entries in a network node

        Returns:
            {object} -- the first flow entry matching the packet, if found
        """
        for flow_entry in flow_entries:
            if self.match_failure is False and (flow_entry.get_attribute("Status") and flow_entry.get_attribute("Status") != "Success") or \
                    flow_entry.get_attribute("Enabled") == False:
                continue

            match_result = self.is_match_to_match_fields(flow_entry.match_fields.values,
                                             packet)
            if self.store_match_results:
                self.add_match_result(packet, flow_entries[0].node_name, flow_entry, match_result)
            if match_result is True:
                return flow_entry

        return None

    def find_instruction_object_from_class(self, instructions,
                                           instruction_class):
        """Searches a list of instruction objects for the instruction with a
        specific class.

        Arguments:
            instructions {list} -- list of instruction objects
            instruction_class {class} -- the queried class type of instruction

        Returns:
            {object} -- the first instruction found of the queried class
        """
        for instruction in instructions:
            if isinstance(instruction, instruction_class):
                return instruction
        else:
            return None

    def get_goto_table_instruction(self, instructions):
        """Get the next Table ID, if there is a Goto Table instruction in the flow
        entry.

        Arguments:
            instructions {list} -- list of instruction objects

        Returns:
            {object} -- the Table ID number of the next table, if found
        """
        matching_instruction = self.find_instruction_object_from_class(instructions,
                                                                       GotoTableInstruction)
        if matching_instruction:
            return matching_instruction.value
        else:
            return None

    def find_actions(self, packet, flow_entries):
        """Searches all the flow entries of a node, table by table, for
        matching entries, then gets the actions in those entries.

        Arguments:
            packet {object} -- packet being tested in the simulated network
            flow_entries {list} -- list of flow entries in a network node

        Returns:
            {tuple} tuple of form (A, B)
                A {list} list of matching flow entries
                B {object} Action Set of actions in the matching flow entries
        """

        matching_flow_entries = list()
        actions = ActionSet()
        goto_table = 0
        while goto_table is not None:
            table_x_entries = self.get_flow_entries_by_table(flow_entries,
                                                             table_id=goto_table)
            sorted_by_priority = self.get_sorted_by_priority(table_x_entries)
            matching_entry = self.find_match_from_entries(packet,
                                                          flow_entries=sorted_by_priority)
            # This is the matching entry applied to the packet
            if matching_entry:
                self.add_openflow_diagnostics(matching_entry)
            matching_flow_entries.append(matching_entry)

            if not matching_entry:
                #LOGGER.warning("Didn't find any matching packets Found none matching in table {}".format(goto_table))
                return None, None
            for action in matching_entry.actions:
                actions.override(action)
            matching_entry_instructions = matching_entry.instructions
            goto_table = matching_entry_instructions.get(GotoTableInstruction)
            if goto_table:
                goto_table = goto_table.value

        return matching_flow_entries, actions

    def get_same_switch_flow_entries(self, switch):
        """Gets all of the flow entries on the given switch.

        Arguments:
            switch {object} -- a switch device in the simulated network

        Returns:
            {list} -- all flow entries in the test environment from the switch
        """
        if isinstance(switch, str):
            switch_name = switch
        else:
            switch_name = switch.name

        return self.flow_entries_sorted.get(switch_name, dict())

    def matching_entries_by_switch(self, packet, switch):
        """Finds all flow entries from a switch that match the packet.

        Arguments:
            packet {object} -- packet being tested in the simulated network
            switch {object} -- a switch device in the simulated network

        Returns:
            {list} -- matching flow entries belonging to the switch
        """
        same_switch_flow_entries = self.get_same_switch_flow_entries(switch)
        return self.matching_entries(same_switch_flow_entries, packet)

    def execute_write_actions(self, actions, packet):
        """Executes Pop Vlan, Push Vlan, Set Vlan VID and Set Vlan PCP actions
        on the matching packet.

        Arguments:
            actions {list} -- list of actions in the current flow entry
            packet {object} -- packet being tested in the simulated network

        Returns:
            {bool} -- True if actions are successful
        """
        if actions.get(PopVlanAction):
            packet.pop_vlan()

        if actions.get(PushVlanAction):
            if len(packet.vlans) < 4:
                packet.push_vlan()
            else:
                raise ValueError("Can't have more than 3 VLANs")

        if actions.get(SetVlanVidAction):
            action = actions.get(SetVlanVidAction)
            packet.change_vid(action.value)

        if actions.get(SetVlanPcpAction):
            action = actions.get(SetVlanPcpAction)
            packet.change_pcp(action.value)

        return True

    def find_group_entry(self, switch, group_id):
        """Retrieves the group entry object with the given Group ID and switch
        from the test environment's list of groups.

        Arguments:
            switch {*} -- a switch device or name in the simulated network
            group_id {int} -- an OpenFlow Group ID

        Returns:
            {object} -- the specified group entry, if it exists
        """
        if type(switch) is not str:
            switch = switch.name

        for group_entry in self.group_entries:
            if group_entry.node_name == switch and group_entry.entry_id == group_id:
                return group_entry
        return None

    def get_outport(self, switch, packet, actions):
        switch_name = switch if isinstance(switch, str) else switch.name
        """Resolve the appropriate outport(s) from the actions of an entry
        matching a packet. If the current entry is has a Group Action,
        determine the type of group. For All groups, get all the outports,
        while for Fast Failover groups get the watch ports. For Output actions
        without groups, get the destination port of the action.

        Other types of groups and actions are not supported by this function,
        and incorrectly configured groups and actions will result in an error.

        Arguments:
            switch {object} -- a switch device in the simulated network
            packet {object} -- packet being tested in the simulated network
            actions {list} -- list of actions in the current flow entry

        Returns:
            {tuple} -- tuple formatted (A, B)
                A {list} -- list of outports the packet can be sent to
                B {list} -- list of group entries accessed by the current flow entry
        """
        outports = list()
        group_entries = list()
        if actions and actions.get(GroupAction):
            value = actions.get(GroupAction).value
            group_entry = self.find_group_entry(switch, value)

            if not group_entry:
                raise ValueError("Unable to find group with id {}".format(value))
                # TODO add something in else reference is not good
            # Add diagnostic information to the entry
            self.add_openflow_diagnostics(group_entry)
            group_entries.append(group_entry)
            if isinstance(group_entry, AllGroup):
                for action_bucket in group_entry.action_buckets:

                    # Need to get the group actions
                    action_set = ActionSet(action_bucket)
                    new_packet = packet.split()

                    try:
                        self.execute_write_actions(packet=new_packet,
                                                   actions=action_set)
                        if action_bucket.get(GroupAction):
                            new_outport, new_groups = self.get_outport(switch,
                                                                       new_packet,
                                                                       action_bucket)
                            outports.extend(new_outport)
                            group_entries.extend(new_groups)
                        else:
                            outport = action_bucket.get(OutputAction).value
                            # (outport, SpecialPorts.is_valid_value(outport),
                            #       self.connections.find_connection(f_s=switch, f_p=outport))

                            if SpecialPorts.is_valid_value(outport) or \
                                    self.connections.find_connection(f_s=switch, f_p=outport):
                                error = None
                            else:
                                error = "Outport is not live"

                            outports.append((outport,
                                             new_packet,
                                             None))
                    except ValueError as e:
                        outports.append((None,
                                         new_packet,
                                         e))

            elif isinstance(group_entry, FastFailoverGroup):
                for action_bucket in group_entry.action_buckets:
                    if action_bucket.watch_group != WatchGroup():
                        raise ValueError("Watch Group not supported")

                    new_packet = packet.split()
                    # Need to check to see if the watch port port is up else skip
                    if self.connections.find_connection(switch_name,
                                                        action_bucket.watch_port.value):
                        # Need to get the group actions
                        action_set = ActionSet(action_bucket.actions)

                        try:
                            self.execute_write_actions(packet=new_packet,
                                                       actions=action_set)
                            error = None
                            if action_bucket.get(GroupAction):
                                outport, new_groups = self.get_outport(switch,
                                                                       new_packet,
                                                                       action_bucket)
                                group_entries.extend(new_groups)
                            else:
                                if action_bucket.get(OutputAction):
                                    outport = action_bucket.get(OutputAction).value

                                    # (outport, not SpecialPorts.is_valid_value(outport),
                                    #       not self.connections.find_connection(f_s=switch, f_p=outport))
                                    if SpecialPorts.is_valid_value(outport) or \
                                            self.connections.find_connection(f_s=switch, f_p=outport):
                                        error = None
                                    else:
                                        error = "Outport is not live"
                                else:
                                    error = "This is a bucket with no group or output action"
                                    outport = None

                            if type(outport) is list:
                                outports.extend(outport)
                            else:
                                outports.append((outport,
                                                 new_packet,
                                                 error))
                            break
                        except ValueError as e:
                            outports.append((None,
                                             new_packet,
                                             e))
                            break
                else:
                    outports.append((None,
                                     new_packet,
                                     "No live ports in Fast Failover group so dropped"))
            else:
                raise TypeError("Unsupported Group {}".format(group_entry))

        elif actions and actions.get(OutputAction):
            outport = actions.get(OutputAction).value

            if SpecialPorts.is_valid_value(outport) or \
                    self.connections.find_connection(f_s=switch, f_p=actions.get(OutputAction).value):
                error = None
            else:
                error = "Outport is not live"

            outports.append((outport,
                             packet,
                             error))

        return outports, group_entries

    def determine_actions(self, switch, inport, packet):
        """Determines the action set from the flow entries of a switch device.

        Arguments:
            switch {object} -- a switch device in the simulated network
            inport {object]} -- the inport of the switch device
            packet {object} -- packet being tested in the simulated network

        Returns:
            Returns:
            {tuple} tuple of form (A, B)
                A {list} list of matching flow entries from the switch
                B {object} Action Set of actions in the matching flow entries from the switch
        """
        packet.change_inport(inport.name)
        LOGGER.info("Changing Inport to {}".format(inport.name))
        #("The inport is now", inport.name)
        flow_entries = self.get_same_switch_flow_entries(switch)
        return self.find_actions(packet=packet,
                                 flow_entries=flow_entries)

    def determine_outport(self, switch, packet, actions):
        """Determines the set of outport(s) and group entries of a packet
        based on the switch and action set. If there are no actions, return
        empty lists.

        Arguments:
            switch {object} -- a switch device in the simulated network
            packet {object} -- packet being tested in the simulated network
            actions {list} -- list of actions in the current flow entry

        Returns:
            {tuple} -- tuple formatted (A, B)
                A {list} -- list of outports the packet can be sent to
                B {list} -- list of group entries accessed by the current flow entry
        """
        if actions:
            return self.get_outport(switch,
                                    packet,
                                    actions)
        else:
            return list(), list()

    def run_test(self, packet, inport=None):
        """Run a packet through the simulation.

        Arguments:
            packet {object} -- packet being tested in the simulated network

        Returns:
             {object} -- The next hop on the path of the packet
        """
        new_packet = packet.split()

        if inport:
            switch = inport.owner
            port = inport
            
            path = Path(start="",
                        packet=new_packet)
            path.add_hop(None, switch, port, [], [], [], new_packet.split())
        else:
            start = packet.source_port
            device = packet.source

            path = Path(start=start,
                        packet=new_packet)
            path.add_hop(None, device, start, [], [], [], new_packet.split())

            if isinstance(device, SEL274XSDevice):
                switch, port = device, start
            # TODO Reconcile Start and Device in this case.
            elif isinstance(device, Port) and isinstance(device.owner, SEL274XSDevice):
                switch, port = device.owner, device
            else:
                switch, port = start.end.owner, start.end

            if isinstance(switch, TraditionalSwitchDevice):
                for switch_port in switch.ports:
                    if switch_port.end and isinstance(switch_port.end.owner, SEL274XSDevice):
                        switch = switch_port.end.owner
                        path.add_hop(port, switch, switch_port, [], [], [], new_packet.split())
                        port = switch_port.end
                        new_packet.change_inport(port.name)
                        break
                else:
                    raise ValueError("I can't find a SEL-2740S attached to {}".format(switch))

        new_path = self.calculate_path(switch,
                                       port,
                                       new_packet,
                                       path)

        return new_path

    def get_hop(self, inport, switch, outport, path, flow_entries,
                group_entries, actions, packet):
        """Gets the next hop for a packet, adding to the path and returning its
        outport information if applicable.

        Arguments:
            inport {object} -- the inport of the switch device
            switch {object} -- the switch device for the next hop
            outport {object} -- the outport of the switch device(if it's a Controller or Local port)
            path {object} -- the network path the packet is being tested on
            flow_entries {list} -- flow entries for the next hop
            group_entries {list} -- group entries for the next hop
            actions {list} -- actions for the next hop
            packet {object} -- packet being tested in the simulated network

        Returns:
            {tuple} -- formatted (A, B)
              A {*} -- the switch(if outport is local) or the outport's end owner
              B {*} -- the outport(if it is local) or the outport's end
        """
        if IngressPort.is_valid_value(outport):
            outport = inport
        elif ControllerPort.is_valid_value(outport):
            outport = outport
        else:
            outport = switch.get_local_port(outport)
        path.add_hop(inport, switch, outport, flow_entries=flow_entries,
                     group_entries=group_entries, actions=actions,
                     packet=packet.split())

        # ("get_hop", inport, outport, id(outport), switch, switch.local_ports,
        #       [(port, id(port), outport==port) for port in switch.local_ports])
        if not outport:
            switch_port = (None, None)
        elif outport in switch.local_ports:
            switch_port = (switch, outport)
        elif outport.end:
            switch_port = (outport.end.owner, outport.end)
        else:
            switch_port = (None, None)

        return switch_port

    def is_port_controller_port(self, inport, outport):
        """Determine whether the outport is a Controller port.

        Arguments:
            inport {object} -- the inport into the switch device
            outport {object} -- the outport of the switch device

        Returns:
            {bool} -- True if the outport is a Controller port
        """
        return ControllerPort.is_valid_value(outport)

    def is_port_ingress_port(self, inport, outport):
        """Determine whether the outport is the Ingress port.

        Arguments:
            inport {object} -- the inport into the switch device
            outport {object} -- the outport of the switch device

        Returns:
            {bool} -- True if the outport is the same port as the inport.
            False if the outport is not Ingress, is the inport but does not use
            the Ingress Port number, or if the device is a traditional switch.
        """
        if not outport or IngressPort.is_valid_value(outport) or \
                isinstance(inport.owner, TraditionalSwitchDevice):
            return False

        switch = inport.owner
        outport = switch.get_local_port(outport)

        return inport == outport

    def calculate_path(self, switch, inport, packet, path):
        """Calculates the next hop on the path of the packet, adding the
        appropriate match field, flow and group entries to the path. Can
        identify the final hop and different types of switches, and throws
        an error if a hop is invalid.

        Arguments:
            switch {object} -- the switch device for the next hop
            inport {object} -- the inport into the switch device
            packet {object} -- packet being tested in the simulated network
            path {object} -- the network path the packet is being tested on

        Returns:
            {object} -- the next hop on the path of the packet
        """
        LOGGER.info("Calculating path from switch {} port {} for packet {}".format(switch, inport, packet))

        if switch is None or inport is None:
            raise ValueError("Switch {} or inport {} is unexpectedly None".format(switch, inport))

        # Check to see if reached a point where cannot proceed
        # (reached end device or Local port on OpenFlow switch)
        if isinstance(switch, EndDevice) or \
                isinstance(switch, SwitchManagementDevice) or \
                (isinstance(switch, SEL274XSDevice) and inport in switch.local_ports and packet.source_port != inport):
            path.add_hop(inport, switch, None, [], [], [], path.split())
            return path

        elif isinstance(switch, SEL274XSDevice):
            flow_entries, actions = self.determine_actions(switch,
                                                           inport,
                                                           packet)
            if not flow_entries or not actions:
                path.add_error("No matching flow entries or actions so packet dropped")
                path.add_hop(inport, switch, None, flow_entries,
                             actions, path.split())
                return path

            try:
                self.execute_write_actions(actions=actions,
                                           packet=packet)
            except ValueError as e:
                LOGGER.error(str(e))
                path.add_error(e)
                path.add_hop(inport, switch, None, flow_entries,
                             actions, path.split())
                return path

            #path.packet = packet.split()
            outports, group_entries = self.determine_outport(switch,
                                                             packet,
                                                             actions)
        elif isinstance(switch, TraditionalSwitchDevice):
            outports = [(port.name, packet.split(), None) for port in switch.ports if port != inport]
            flow_entries, group_entries, actions = list(), list(), list()
        else:
            raise TypeError("Unknown type for {}".format(switch))

        LOGGER.info("The outports are now {}".format([outport[0] for outport in outports]))

        if outports:
            if self.is_port_ingress_port(inport, outports[0][0]):
                path.add_error("Trying to send the packet into the ingress port without special Ingress port on switch {}".format(switch.name))
                path.add_hop(inport, switch,
                             None if outports[0][0] is None else switch.get_local_port(outports[0][0]),
                             flow_entries, group_entries, actions, path.split())
                paths = path
            elif self.is_port_controller_port(inport, outports[0][0]):
                path.add_error("Sent to Controller, GAME OVER!")
                path.add_hop(inport, switch,
                             None if outports[0][0] is None else switch.get_local_port(outports[0][0]),
                             flow_entries, group_entries, actions, path.split())
                paths = path
            elif outports[0][2]:
                path.add_error(outports[0][2])
                path.add_hop(inport, switch,
                             None if outports[0][0] is None else switch.get_local_port(outports[0][0]),
                             flow_entries, group_entries, actions, path.split())
                paths = path
            else:
                new_path = path.split()
                new_path.packet = outports[0][1]
                new_switch, new_port = self.get_hop(inport, switch, outports[0][0], new_path,
                                                    flow_entries, group_entries, actions,
                                                    outports[0][1].split())
                paths = self.calculate_path(new_switch,
                                            new_port,
                                            outports[0][1],
                                            new_path)

        else:
            path.add_error("No outport so packet dropped")
            path.add_hop(inport, switch, None, flow_entries,
                         actions, path.split())
            return path

        if len(outports) > 1:
            if type(paths) is not list:
                paths = [paths]

            for outport in outports[1:]:
                if self.is_port_ingress_port(inport, outport[0]):
                    new_path = path.split()
                    new_path.add_error("Trying to send the packet into the ingress port without special Ingress port on switch {}".format(switch.name))
                    new_path.add_hop(inport, switch,
                                     None if outport[0] is None else switch.get_local_port(outport[0]),
                                     flow_entries, group_entries, actions, outport[1].split())
                    paths.append(new_path)
                elif outport[2]:
                    new_path = path.split()
                    new_path.add_error(outport[2])
                    new_path.add_hop(inport, switch,
                                     None if outport[0] is None else switch.get_local_port(outport[0]),
                                     flow_entries, group_entries, actions, outport[1].split())
                    paths.append(new_path)
                else:
                    new_path = path.split()
                    new_path.packet = outport[1]
                    new_switch, new_port = self.get_hop(inport, switch, outport[0], new_path,
                                                        flow_entries, group_entries, actions,
                                                        outport[1].split())
                    new_path = self.calculate_path(new_switch,
                                                   new_port,
                                                   outport[1],
                                                   new_path)

                    if type(new_path) is list:
                        paths.extend(new_path)
                    else:
                        paths.append(new_path)

        return paths
