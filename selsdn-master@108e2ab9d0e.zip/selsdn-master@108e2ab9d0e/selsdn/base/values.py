"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Provides base classes for objects that are lists of Value objects.
"""

from .base import BaseObject


class Values(BaseObject, list):
    """Class defining an object that is also a list of multiple values. Each
    value is typically an object inheriting the Value class.
    """

    # optional class requirement for values
    VALUE_CLASS = None

    def __init__(self, values=None, attributes=None):
        """Init for Values object.

        Keyword Arguments:
            values {*} -- values to be initially listed in the object (default: {None})
            attributes {dict} -- attributes assigned to an object (default: {None})
        """
        super().__init__(attributes=attributes)
        self._values = list()

        if values:
            if isinstance(values, list):
                for value in values:
                    self.add(value)
            else:
                self.add(values)

        if isinstance(values, Values):
            for name, value in values.attributes.items():
                self.add_attribute(name, value)

    def add(self, value):
        """Appends a value to the object's list. If a class requirement is
        used for this list, raises an error if the value is the wrong class.

        Arguments:
            value {*} -- a value being added to the object's list
        """
        if self.VALUE_CLASS and not isinstance(value, self.VALUE_CLASS):
            raise TypeError("Expected objects of type {} not type {}".format(self.VALUE_CLASS.__name__,
                                                                             value.__class__.__name__))
        else:
            self._values.append(value)

    def remove(self, value):
        """Removes all values from the object's list of the specified class. If
        the object has a class requirement, providing an item of the required
        class as an argument infers removing all values of its class from the
        list.

        Arguments:
            value {*} -- a class or an object belonging to the required class
        """
        if isinstance(value, self.VALUE_CLASS):
            value_class = value.__class__
        else:
            value_class = value

        # NOTE: shouldn't this use the private version of the list(self._values)?
        for index, current_value in enumerate(self.values):
            if current_value.__class__ == value_class:
                self.values.pop(index)

    def get(self, name, default_value=None):
        """Gets the first value named by a string(case insensitive), or of a
        queried class, from the object's list of values. If a string or type is
        not provided, gets the first value found of the same class type as the
        query.

        Arguments:
            name {*} -- query for values to be looked up in the list

        Returns:
            {*} -- the first matching value found in the list(None if no match was found)
        """
        if type(name) == str:
            for value in self.values:
                if value.name == name:
                    return value
                if value.name.lower() == name.lower():
                    return value
        elif type(name) == type:
            for value in self.values:
                if value.__class__ == name:
                    return value
        else:
            for value in self.values:
                if value.__class__ == name.__class__:
                    return value

        return default_value

    def get_value(self, name, default_value=None):
        """Gets the value with name else returns the default_value if not found

        Arguments:
            name {*} -- query for values to be looked up in the list
            default_value {*} -- value returned if name not found

        Returns:
            {*} -- the value from object with name name or default_value
        """
        return_value = self.get(name)
        if return_value:
            return return_value.value
        else:
            return default_value

    def get_all(self, name):
        """Gets a list of all values with the same name as a string(case
        insensitive), or all values of a queried class, from the object's list
        of values. If a string or type is not provided, gets all values found
        of the same class type as the query.

        Arguments:
            name {*} -- query for values to be looked up in the list

        Returns:
            {list} -- list of all matching values (None if no match was found)
        """
        results = list()
        if type(name) == str:
            for value in self.values:
                if value.name == name:
                    results.append(value)
                elif value.name.lower() == name.lower():
                    results.append(value)
        elif type(name) == type:
            for value in self.values:
                if value.__class__ == name:
                    results.append(value)
        else:
            for value in self.values:
                if value.__class__ == name.__class__:
                    results.append(value)

        return results

    def change(self, other_value):
        """Gets the first item in the object's list of the same class as the
        argument and changes it's value attribute to the arg's value attribute.
        Raises an error if no item matches the class of the arg.

        Arguments:
            other_value {object} -- object with a value attribute or method
        """
        current_value = self.get(other_value)
        if current_value:
            current_value.value = other_value.value
        else:
            raise ValueError("Could not find a match for {}".format(other_value.__class__.__name__))

    def override(self, other_value):
        """If an item exists in the object's list with the same class as the
        argument, override it's value attribute with the argument's value.
        Otherwise, add the argument to the list.

        Arguments:
            other_value {object} -- object with a value attribute or method
        """
        if self.get(other_value):
            self.change(other_value)
        else:
            self.add(other_value)

    def overlaps(self, other_values):
        """Checks that no values overlap between this object and another.

        Arguments:
            other_values {object} -- an object that is also a list of values

        Returns:
            {bool} -- false if any value overlaps between the two objects, otherwise true
        """
        for self_value in self.values:
            for other_value in other_values.values:
                if self_value.overlaps(other_value):
                    return False
        return True

    def index(self, value):
        """Searches the object's list for a value and returns the index number
        of the first match.

        Arguments:
            value {*} -- search query

        Returns:
            {int} -- index of value in the values list
        """
        for index, val in enumerate(self.values):
            if val == value:
                return index

    @property
    def values(self):
        """Property for self._values.

        Returns:
            {list} -- private values list belonging to the object
        """
        return self._values

    def __eq__(self, other):
        """Two objects that are lists of values are equal if the lists are the
        same length and values.

        Arguments:
            other {*} -- item being compared to the object with a values list

        Returns:
            {bool} -- true if both items are equal
        """
        if len(self.values) != len(other.values):
            return False

        for self_value in self.values:
            if other.get(self_value):
                if other.get(self_value) != self_value:
                    return False
            else:
                return False
        else:
            return True

    def __repr__(self):
        """Defines the printable repr string of an object that is a list of
        values to include reprs of the list contents.

        Returns:
            {str} -- "[class name] [object name], [values list]"
        """
        if hasattr(self, "name"):
            return self.__class__.__name__ + " " + self.name + ", ".join(map(repr, self.values))
        else:
            return self.__class__.__name__ + " " + ", ".join(map(repr, self.values))

    def __iter__(self):
        """Defines the iteration of the object as iterating along its list of
        values.

        Returns:
            {*} -- iteration of the values list
        """
        return iter(self.values)

    def __len__(self):
        """Defines the length property of the object as the length of its list
        of values.

        Returns:
            {int} -- length of the values list
        """
        return len(self.values)

    def __getitem__(self, index):
        """Defines the getitem property of the object as getting a value at the
        queried index in the object's values list.

        Arguments:
            index {int} -- index to be accessed in the values list

        Returns:
            {*} -- the value located at the index in the values list
        """
        return self.values.__getitem__(index)

    def __str__(self):
        """Defines the str property of the object as converting the values list
        to a string.

        Returns:
            {str} -- object's values list in string format
        """
        return str(self.values)

    def __contains__(self, key):
        """Defines the contains property of the object as checking whether its
        values list contains the query.

        Arguments:
            key {*} -- value being searched for in the values list

        Returns:
            {bool}-- true if the key argument is in the values list
        """
        for value in self.values:
            if value == key:
                return True
        else:
            return False

    def __add__(self, other):
        """Defines addition for the object as adding its values list to another
        object's values list.

        Arguments:
            other {object} -- a different object that is also a list of values

        Returns:
            {object} -- new object with both lists combined for its values
        """
        if isinstance(other, Values):
            return self.__class__(values=self.values + other.values)
        elif isinstance(other, list):
            return self.__class__(values=self.values + other)
        else:
            raise

    def __iadd__(self, other):
        return self.__add__(other)

    def __isub__(self, other):
        return self.__sub__(other)

    def __sub__(self, other):
        """Defines subtraction for the object as getting the difference between
        its values list and another object's list.

        Arguments:
            other {list} -- another list or object inheriting the values class

        Returns:
            {object} -- new object that lists values found in the original list but not in other
        """
        return_values = list()
        for value in self:
            if value not in other:
                return_values.append(value)
        return self.__class__(values=return_values)

    def extend(self, values):
        """Adds the contents of another list to the object's values list.

        Arguments:
            values {list} -- a list of values
        """
        for value in values:
            self.add(value)

    def append(self, value):
        """Adds a single value to the object's values list.

        Arguments:
            value {*} -- item to be listed in the object
        """
        self.add(value)

    def diff_eq(self, other):
        """Compares an object's values list to another to check if they are
        equal.

        Arguments:
            other {*} -- item being compared to the object's values list

        Returns:
            {bool} -- true if both objects have equal values lists
        """
        return self == other

    def pop(self, index):
        """Calls pop method on the object's list of values.

        Arguments:
            index {int} -- location in list of the value to remove

        Returns:
            {*} -- the removed value
        """
        return self._values.pop(index)

class UniqueValues(Values):
    """Class defining an object that is a values list, with the additional
    requirement that values may not share the same class unless they are equal.
    """

    def add(self, value):
        """Requires that a new value match the class requirement of the object's
        values list, and be a different class than the other values in the
        list(except where it is equal to another one). Raises an error if these
        requirements are not met. Otherwise, appends the value to the values
        list.

        Arguments:
            value {*} -- a value being added to the object's list
        """
        if not isinstance(value, self.VALUE_CLASS):
            raise TypeError("Expected objects of type {} not type {}".format(self.VALUE_CLASS.__class__.__name__,
                                                                             value.__class__.__name__))
        else:
            for old_value in self.values:
                if value.__class__ == old_value.__class__ and value != old_value:
                    raise ValueError("Trying to add {} but action already present")
            self._values.append(value)
