"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Defines the Value base class of objects.
"""
from re import fullmatch

from .base import BaseObject
from .tools import reverse_translate

# global regular expressions to match strings that are an integer in decimal or
# hexadecimal format, respectively.
INT_RE = '\d+'
HEX_RE = '0x[\dABCDEFabcedf]+'


class Value(BaseObject):
    """Base class for many non-list objects in the selsdn module.
    """

    # initialize dictionary to store value names and translate them to numbers
    # this dictionary is not populated here but in other classes inheriting it
    TRANSLATER = dict()

    def __init__(self, value, attributes=None):
        """Initializes a Value object, storing its defined attributes in its
        BaseObject attributes dictionary, defining the value of the Value
        object and a reversed version of its TRANSLATER dictionary(if defined
        in the class inheriting Value).

        Arguments:
            value {*} -- the value that is stored and accessed by this object

        Keyword Arguments:
            attributes {dict} -- attributes assigned to an object (default: {None})
        """
        super().__init__(attributes=attributes)
        self._value = None
        self.value = value
        self.REVERSE_TRANSLATE = reverse_translate(self.TRANSLATER)

    @classmethod
    def is_valid_value(cls, value):
        """Checks that the value is valid for the class type. Checks the
        _is_valid_value of the derived class if the value is not in the
        translater. Gives a type error if value is invalid.

        Arguments:
            value {*} -- the value that is being validated

        Returns:
            {bool} -- true if value is found to be valid
        """
        try:
            if isinstance(value, str) and value.upper() in cls.TRANSLATER:
                return True
            else:
                return cls._is_valid_value(value)
        except TypeError as e:
            return False

    @property
    def value(self):
        """Defines the value property.

        Returns:
            {*} -- value of the Value object after being ran through the setter
        """
        return self._value

    @value.setter
    def value(self, value):
        """Setter and validation for the value property.

        Arguments:
            value {*} -- the value that is stored and accessed by this object
        """
        value = self.convert_value(value)
        if self.is_valid_value(value):
            self._value = value
        else:
            raise ValueError("Invalid Value {} of type {} for {}".format(value,
                                                                         type(value),
                                                                         self.__class__.__name__))

    def overlaps(self, other):
        """Usually a check to see if two objects are equal enough to conflict.
        Unless overridden by a derived class, two objects overlap if they are
        equal.

        Arguments:
            other {object} -- second object being used for comparison

        Returns:
            {bool} -- true if both objects are equal
        """
        return self == other

    def __eq__(self, other):
        """Two objects derived from Value are equal if they are the same class
        with equal values.

        Arguments:
            other {object} -- second object being used for comparison

        Returns:
            {bool} -- true if both objects are equal
        """
        return self.__class__ == other.__class__ and self.value == other.value

    def __repr__(self):
        """Defines the repr string for this object as representing the class
        and individual instance names of the object as readable text.

        Returns:
            {str} -- "[class name]:[object name]"
        """
        return "{}:{}".format(self.__class__.__name__, str(self))

    def convert_value(self, value):
        """Converts the value stored in an object to its appropriate format.

        If the value is in the translater, return the translated value.

        Strings with contents that are integers in decimal or
        hexadecimal formats are converted to integers in those formats, while
        other strings, integers and blank values are unchanged.

        If a value is itself a Value object, return its value attribute.

        If the value is anything else, raise an error.

        Arguments:
            value {*} -- the value that is stored and accessed by this object

        Returns:
            {*} -- the value in its correct format
        """
        if isinstance(value, str) and value.upper() in self.TRANSLATER:
            return self.TRANSLATER[value.upper()]
        elif isinstance(value, str):
            if fullmatch(INT_RE, value):
                return int(value)
            elif fullmatch(HEX_RE, value):
                return int(value, 16)
            else:
                return value
        elif isinstance(value, int):
            return value
        elif isinstance(value, Value):
            return value.value
        elif value is None:
            return value
        else:
            raise ValueError("Not sure how to convert {} of type {} to type {}".format(value,
                                                                                       type(value),
                                                                                       self.__class__.__name__))

    def __str__(self):
        """Defines the str property of this object, converting the value to a
        string. If a value is indexed in the object's translater, converts its
        index name instead.

        Returns:
            {str} -- the string of this object's value attribute
        """
        if self.value in self.REVERSE_TRANSLATE:
            return str(self.REVERSE_TRANSLATE[self.value])
        else:
            return str(self.value)

    def copy(self):
        """Creates a new object with the same class and value attribute as
        self.

        Returns:
            {object} -- a new object with the same class and value
        """
        return self.__class__(self.value, attributes=self.attributes)
