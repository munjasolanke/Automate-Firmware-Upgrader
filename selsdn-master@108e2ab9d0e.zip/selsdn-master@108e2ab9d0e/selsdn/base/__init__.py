"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Sets up the logging module for the files in this directory.
"""

from logging import getLogger

LOGGING_NAME = "selsdn"
LOGGER = getLogger(LOGGING_NAME)
