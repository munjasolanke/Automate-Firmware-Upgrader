"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Defines utility functions for selsdn type conversion and dictionary management.
"""

from functools import wraps
from re import fullmatch

# global regular expressions to match strings that are an integer in decimal or
# hexadecimal format, respectively.
INT_RE = '\d+'
HEX_RE = '0x[\dABCDEFabcedf]+'


def convert_value(func):
    """Decorator that changes the string argument of another function to an
    integer in decimal or hexadecimal, if the string's contents are a number in
    that format. Executes the decorated function with its string argument
    converted to an integer beforehand.

        Arguments:
            func {function} -- decorated function with string argument <value>
            value {str} -- arg of func to be converted to int if matches format

        Returns:
            {function} -- func(value) where <value> has been converted to int
        """
    @wraps(func)
    def wrapper(value):
        if fullmatch(INT_RE, value):
            value = int(value)
        elif fullmatch(HEX_RE, value):
            value = int(value, 16)
        return func(value)
    return wrapper


def merge_dicts(*dicts):
    """Creates a new combined dictionary containing all keys and values of any
    number of smaller dictionaries.

    Arguments:
        dicts {dict} -- all dictionaries to be merged(variable number of args)

    Returns:
        {dict} -- new dictionary containing all old dictionaries' contents
    """
    new_dict = dict()
    for added in dicts:
        new_dict.update(added)
    return new_dict


def reverse_translate(old_dict):
    """Swaps a dictionary's keys with their corresponding values.

    Arguments:
        old_dict {dict} -- dictionary that needs keys and values swapped

    Returns:
        {dict} -- old_dict with the values and keys swapped
    """
    reversed_dict = dict()
    for key, value in old_dict.items():
        reversed_dict[value] = key
    return reversed_dict
