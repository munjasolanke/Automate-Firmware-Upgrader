"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Classes, methods and properties for lists of selsdn network objects.
"""

from collections import defaultdict
from functools import partial

from . import LOGGER
from .values import Values
from .value import Value

from ..automation.device import Device, TraditionalSwitchDevice, SEL274XSDevice, OpenFlowDevice
from ..automation.port import Port
from ..automation.named_object import NamedObject
from ..automation.application import Application
from ..automation import DEVICE_PORT_SEPARATOR
from ..automation.associations import Associations

from ..openflow.core.group_entry import GroupEntry
from ..openflow.core.flow_entry import FlowEntry
from ..openflow.core.match_fields import InPortMatch
from ..openflow.core.actions import OutputAction, GroupAction


class Collection(Values):
    """Defines the base methods and properties of collection objects.
    Collection objects are lists of automation or OpenFlow objects, such as
    applications or node entries, with additional functionality provided by
    the methods and properties of their classes.
    """

    @property
    def class_type(self):
        """Returns the class of the object.
        """
        return self.__class__

    @property
    def entries(self):
        """Returns the values listed by the object.
        """

        return self.values

    def __getitem__(self, index):
        """Getting an item from a collection by index works as normal, unless
        the index is a slice, in which case a new collection is returned of the
        same type with the slice applied to the values.

        Arguments:
            index {int} -- list index of the item

        Returns:
            {*} -- the contents of the collection at the index, or a new collection with the slice
                applied(if index is a slice)
        """
        if isinstance(index, slice):
            return self.class_type(values=self.values.__getitem__(index))
        else:
            return self.values.__getitem__(index)

    def get_item_name(self, item):
        """Gets the name of an item in the collection.. If it is a port,
        include the name of its parent device. Return the item itself if it is
        not a device or port.

        Arguments:
            item {*} -- a member of the collection

        Returns:
            {*} -- the name of the item, or the item itself if it isn't a device or port
        """
        if isinstance(item, Device):
            return item.name
        elif isinstance(item, Port):
            return DEVICE_PORT_SEPARATOR.join([item.owner.name, str(item.name)])
        else:
            return item


class EntryCollection(Collection):
    """Defines the base methods and properties of collections of entries, such
    as OpenFlow groups, flows, meters and protocols, network ports and nodes.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.errors = dict()

    def __add__(self, other):
        new_object = super().__add__(other)
        new_object.errors = self.errors
        if isinstance(other, EntryCollection):
            new_object.errors.update(other.errors)
        return new_object

    def __iadd__(self, other):
        return self.__add__(other)

    def has_attribute(self, value):
        """Filters a collection for entries with a particular attribute.

        Arguments:
            value {*} -- queried attribute

        Returns:
            {object} -- new collection, containing only entries with the given attribute
        """
        return self.class_type(values=[v for v in self.values if v.get_attribute(value) is not None])

    def has_attribute_value(self, attribute, value):
        """Filters a collection for entries with a particular attribute with an
        exact value.

        Arguments:
            attribute {*} -- queried attribute
            value {*} -- queried value

        Returns:
            {object} -- new collection, containing only entries with the given attribute and value
        """
        if type(value) is not str and hasattr(value, '__getitem__'):
            return self.class_type(values=[v for v in self.values if v.get_attribute(attribute) in value])
        else:
            return self.class_type(values=[v for v in self.values if v.get_attribute(attribute) == value])

    def not_has_attribute_value(self, attribute, value):
        if type(value) is not str and hasattr(value, '__getitem__'):
            return self.class_type(values=[v for v in self.values if v.get_attribute(attribute) not in value])
        else:
            return self.class_type(values=[v for v in self.values if v.get_attribute(attribute) != value])        

    def has_name(self, value):
        """Filters a collection for entries with a particular name property.

        Arguments:
            value {str} -- queried name

        Returns:
            {object} -- new collection, containing only entries with the given name
        """
        if hasattr(value, "name"):
            value = value.name
        return self.class_type(values=[v for v in self.values if v.name == value])

    def has_in_name(self, value):
        """Filters a collection for entries with a particular combination of
        characters in its name property.

        Arguments:
            value {str} -- queried substring

        Returns:
            {object} -- new collection, containing only entries where the given substring is part
                of the name
        """
        return self.class_type(values=[v for v in self.values if value in v.name])

    def has_type(self, value):
        """Filters a collection for entries that are objects of a particular
        class(or a class derived from it).

        Arguments:
            value {class} -- queried class

        Returns:
            {object} -- new collection, containing only entries of the given class, or of a class
                derived from it
        """
        return self.class_type(values=[v for v in self.values if isinstance(v, value)])

    def not_has_type(self, value):
        """Filters a collection for entries that do not belong to a particular
        object class, nor a derived class of that type.

        Arguments:
            value {class} -- queried class

        Returns:
            {object} -- new collection, containing only entries that do not belong to the given
                class, nor to a class derived from it
        """
        return self.class_type(values=[v for v in self.values if not isinstance(v, value)])

    def remove(self, value):
        """Filters a collection to remove all entries matching a particular
        value.

        Arguments:
            value {*} -- queried value

        Returns:
            {object} -- new collection, without the entries of the given value
        """
        if type(value) is not str and hasattr(value, '__getitem__'):
            return self.class_type([v for v in self.values if v not in value])
        else:
            return self.class_type([v for v in self.values if v != value])

    def replace_by_name(self, name, new_object):
        for index, value in enumerate(self.values):
            if value.name == name:
                self.values[index] = new_object
                return True
        else:
            return False



class InterfacedObject(EntryCollection):
    """Defines the base methods and properties of collections of network
    components that are of type InterfacedObject.
    """

    def has_ip_address(self, value):
        """Filters a collection for entries with a particular IPv4 address.

        Arguments:
            value {str} -- queried IPv4 address

        Returns:
            {object} -- new collection, containing only entries with the given IPv4 address
        """
        return self.class_type(values=[v for v in self.values if value in v.ip_addresses])

    def is_in_network(self, value):
        """Filters a collection for entries that are part of a particular network.

        Arguments:
            value {str} -- queried network name

        Returns:
            {object} -- new collection, containing only entries belonging to the named network
        """
        return self.class_type(values=[v for v in self.values if v.is_in_network(value)])

    def is_in_networks(self, values):
        """Filters a collection for entries that belong to one of the given networks.

        Arguments:
            value {list} -- queried network names

        Returns:
            {object} -- new collection, containing only entries belonging to one of the given networks
        """
        return self.class_type(values=[v for v in self.values if v.is_in_networks(values)])        

    def is_connected(self):
        """Filters a collection for entries that are connected to other network
        components.

        Returns:
            {object} -- new collection, containing only the connected entries
        """
        return self.class_type(values=[v for v in self if v.is_connected()])

    def has_mac_address(self, value):
        """Filters a collection for entries with a particular MAC address.

        Arguments:
            value {str} -- queried MAC address

        Returns:
            {object} -- new collection, containing only entries with the given MAC address
        """
        return self.class_type(values=[v for v in self.values if value in v.mac_addresses])


class NodeCollection(InterfacedObject):
    """A collection of devices serving as nodes in a network (in the context of
    this class, "node" refers to a device).
    """

    # entries in this collection must be devices
    VALUE_CLASS = Device

    def __init__(self, values=None, associations=None):
        """Sets up a collection of devices.

        Keyword Arguments:
            values {list} -- devices to be entered into the collection (default: {None})
            association_entries {dict} -- network associations of the collection (default: {None})
        """
        super().__init__(values=values)
        self.associations = associations if associations else Associations()

    def sort(self, key=lambda x: x.print_name, reverse=False):
        self._values = sorted(self.values, key=key, reverse=reverse)

    def connected_to(self, switch=None):
        """Filters the collection for node(device) entries connected to a
        particular switch.

        Keyword Arguments:
            switch {device} -- queried switch (default: {None})

        Returns:
            {object} -- new collection, containing only devices connected to the switch
        """
        if isinstance(switch, Device):
            switch = switch.name
        node_entries = self.class_type()
        for node_entry in self:
            for port in node_entry.ports:
                if switch:
                    if port.end.owner.name == switch:
                        node_entries.add(node_entry)
                        break
                elif port.end:
                    node_entries.add(node_entry)
                    break

        return node_entries

    def ports_in_network(self, network):
        """Creates a new collection containing all ports, if belonging to
        devices in the node collection, that are part of a particular network.

        Arguments:
            network {str} -- name of the network

        Returns:
            {object} -- PortCollection containing ports belonging to the network
        """
        return_values = PortCollection()
        for node in self:
            for port in node.ports:
                if port.is_in_network(network):
                    return_values.append(port)
        return return_values

    def ports_in_networks(self, networks):
        return_values = PortCollection()
        for node in self:
            for port in node.ports:
                if port.is_in_networks(networks):
                    return_values.append(port)
        return return_values

    def unique_items(self):
        """Creates a new collection containing the unique interfaced objects in
        the node collection. Specifically, the ports of devices where there is
        more than one local port, else the devices themselves.

        Returns:
            {object} -- collection listing the unique interfaced objects in the network
        """
        return_values = InterfacedObject()
        for node in self:
            ports = node.ports
            if isinstance(node, TraditionalSwitchDevice) or \
                    isinstance(node, SEL274XSDevice) or \
                    len(ports) == 1 or \
                    (len(ports) == 2 and node.mode == "Failover"):
                return_values.append(node)
            else:
                for port in ports:
                    return_values.append(port)
        return return_values

    def has_datapath_id(self, value):
        """Filters the node collection for OpenFlow devices with a particular
        datapath identifier.

        Arguments:
            value {str} -- queried datapath ID

        Returns:
            {object} -- new collection, containing only OpenFlow devices with the given datapath ID
        """
        if isinstance(value, int):
            value = hex(value)[2:].lower().zfill(16)
        else:
            value = value.lower().zfill(16)
        values = self.has_type(OpenFlowDevice)
        return self.class_type(values=[v for v in values if v.datapath_id == value])

    def __add__(self, other):
        new_object = super().__add__(other)
        new_object.associations = self.associations + other.associations
        return new_object


class PortCollection(InterfacedObject):
    """A collection of ports.
    """
    pass


class OpenFlowEntryCollection(EntryCollection):
    """Defines the base methods and properties of collections of OpenFlow
    entries such as groups, flows, and meters.
    """

    def has_entry_id(self, value):
        """Filters the collection for entries with a particular numerical
        identifier, such as a Flow, Group or Meter ID.

        Arguments:
            value {int} -- queried entry ID

        Returns:
            {object} -- new collection, containing only entries with the given entry ID
        """
        if type(value) is not str and hasattr(value, '__getitem__'):
            return self.class_type(values=[v for v in self.values if v.entry_id in value])
        else:
            return self.class_type(values=[v for v in self.values if v.entry_id == value])    
    
    def has_switch(self, value):
        """Filters the collection for entries belonging to a particular switch.

        Arguments:
            value {device/str} -- a switch, or friendly name of a switch

        Returns:
            {object} -- new collection, containing only entries belonging to the switch
        """
        if isinstance(value, Value) or isinstance(value, NamedObject):
            value = value.name
        return self.class_type(values=[v for v in self.values if v.node_name == value])

    def is_enabled(self):
        """Filters the collection for entries with the Enabled attribute set to
        True, or without that attribute(considered enabled automatically).

        Returns:
            {object} -- new collection, containing only enabled entries
        """
        return self.class_type(values=[v for v in self.values if v.get_attribute("Enabled", True) or not v.get_attribute("Enabled")])

    def is_disabled(self):
        """Filters the collection for entries with the Enabled attribute set to
        False.

        Returns:
            {object} -- new collection, containing only disabled entries
        """
        return self.class_type(values=[v for v in self.values if v.get_attribute("Enabled", False)])


class FlowCollection(OpenFlowEntryCollection):
    """A collection of flow entries.
    """

    # entries in this collection must be flow entries
    VALUE_CLASS = FlowEntry

    def __init__(self, values=None, perform_validation=True):
        """Sets up a new collection of flow entries.

        Keyword Arguments:
            values {list} -- flow entries to be entered into the collection (default: {None})
            perform_validation {bool} -- True if performing validation enabled (default: {True})
        """
        self.entries_by_switch_table_priority = defaultdict(dict)
        self.perform_validation = perform_validation
        self.overlapping_entries = list()
        super().__init__(values=values)

    @property
    def class_type(self):
        return partial(self.__class__, perform_validation=self.perform_validation)

    def has_table_id(self, value):
        return self.class_type(values=[v for v in self.values if v.table_id==value])

    def add(self, entry):
        """Adds a new flow entry to the collection. If performing validation is
        enabled for this collection, skip duplicate entries, and raise an error
        if the entry is not a valid flow or overlaps an existing entry.

        Arguments:
            entry {object} -- a flow entry
        """
        # Indicates if a new entry to add
        new = True

        switch = entry.node_name
        table_id = entry.table_id
        priority = entry.priority
        eth_type = entry.match_fields.get("EthType")
        eth_type = None if not eth_type else eth_type.value

        if self.perform_validation:
            try:
                for old_entry in self.entries_by_switch_table_priority[switch][table_id][priority]:
                    if entry.overlaps_partial(old_entry):
                        if entry.eq_partial(old_entry):
                            new = False
                            LOGGER.warning("Skipping {} because identical to {}".format(entry, old_entry))
                        else:
                            new = False
                            self.overlapping_entries.append(entry)
                            raise ValueError("Entry {} not added because it overlaps with {}".format(entry, old_entry))
            except KeyError as e:
                pass
                # Does not overlap so can be added

        if new:
            if table_id in self.entries_by_switch_table_priority[switch]:
                if priority in self.entries_by_switch_table_priority[switch][table_id]:
                    self.entries_by_switch_table_priority[switch][table_id][priority].append(entry)
                else:
                    self.entries_by_switch_table_priority[switch][table_id][priority] = [entry]
            else:
                self.entries_by_switch_table_priority[switch][table_id] = {priority: [entry]}

            super().add(entry)
            return True
        else:
            return False

    def has_priority(self, value):
        """Filters the collection for entries with a particular priority value.

        Arguments:
            value {int} -- queried priority

        Returns:
            {object} -- new collection, containing only entries with the given priority
        """
        if type(value) is not str and hasattr(value, '__getitem__'):

            return self.class_type(values=[v for v in self.values if v.priority in value])
        else:
            return self.class_type(values=[v for v in self.values if v.priority == value])

    def has_action(self, value):
        """Filters the collection for flow entries with a particular action.

        Arguments:
            value {object} -- queried action instruction or action value

        Returns:
            {object} -- new collection, containing only entries with the given action instruction or
                the type of the action value
        """
        return self.class_type(values=[v for v in self.values if v.actions.get(value)])

    def has_action_value(self, value):
        """Filters the collection for flow entries with a particular action and action value.

        Arguments:
            value {*} -- queried action value

        Returns:
            {object} -- new collection, containing only entries with the exact action value
        """
        if type(value) is not str and hasattr(value, '__getitem__'):
            results = self.class_type()
            for entry in self.values:
                for v in value:
                    if v in entry.actions:
                        results.append(entry)
            return results
        else:
            return self.class_type(values=[v for v in self.values if v.actions.get(value) and v.actions.get(value) == value])

    def has_match_field(self, value):
        """Filters the collection for flow entries with a particular match
        fieldd.

        Arguments:
            value {*} -- queried match field or match field value

        Returns:
            {object} -- new collection, containing only entries with the match field or match field
                type of the value
        """
        return self.class_type(values=[v for v in self.values if v.match_fields.get(value)])

    def not_has_match_field(self, value):
        """Filters the collection for flow entries without a particular match
        field.

        Arguments:
            value {*} -- queried match field or match field value

        Returns:
            {object} -- new collection, containing only entries without the match field or match
                field type of the value
        """
        return self.class_type(values=[v for v in self.values if not v.match_fields.get(value)])

    def has_match_field_value(self, value):
        """Filters the collection for flow entries with an exact match field
        value.

        Arguments:
            value {*} -- queried match field value

        Returns:
            {object} -- new collection, containing only entries with the exact match field value
        """
        return self.class_type(values=[v for v in self.values if v.match_fields.get(value) and v.match_fields.get(value) == value])

    def resolves_to_ingress_port(self, value, include_controller=False):
        """Filters the collection for flow entries that would match a packet
        that ingressed on a specific port, ignoring all other match criteria.

        Arguments:
            value {port} -- an InPort match field object or valid InPort value

        Keyword Arguments:
            include_controller {bool} -- if True, include flow entries with the InPort match field
                set to "Controller" (default: {False})

        Returns:
            {object} -- new collection, containing only entries that would match a packet that
                ingressed on the specific port, ignoring all other match criteria
        """
        if type(value) in (int, str):
            value = InPortMatch(value)
        elif not isinstance(value, InPortMatch):
            raise TypeError("Unable to parse value {} for inport".format(value))

        inport_value = self.has_match_field_value(value)
        no_inport_field = self.not_has_match_field(value)
        if include_controller:
            controller_value = self.has_match_field_value(InPortMatch("Controller"))
        else:
            controller_value = self.class_type()
        return inport_value + no_inport_field + controller_value

    def resolves_to_egress_port(self, value, group_entries, include_controller=False):
        """Filters the collection for flow entries that could egress a packet
        out a particular port.

        Arguments:
            value {port} -- queried out port
            group_entries {list} -- list of groups to search for groups resolving to the out port

        Keyword Arguments:
            include_controller {bool} -- if True, include flow entries with the Output action
                targeting "Controller" (default: {False})

        Returns:
            {object} -- new collection, containing only entries that could egress a packet out the
                specific port
        """
        a = self.has_action_value(OutputAction(value))
        b = self.has_action_value(OutputAction("All"))
        c = self.has_action_value(OutputAction("Controller")) if include_controller else self.class_type()

        port_group_chain = group_entries.resolves_to_egress_port(value, include_controller=include_controller)
        d = self.has_action_value([GroupAction(entry.entry_id) for entry in port_group_chain])

        # Get all flow entries that resolve to Ingress when the Inport is X or there is no Inport
        ingress_group_chain = group_entries.resolves_to_egress_port("Ingress")
        ingress_flow_entries = self.has_match_field_value(InPortMatch(value)) + self.not_has_match_field(InPortMatch)
        e = ingress_flow_entries.has_action_value([GroupAction(entry.entry_id) for entry in ingress_group_chain])

        f = ingress_flow_entries.has_action_value(OutputAction("Ingress"))

        # all of the flow entries that have an out port of X
        return a + b + c + d + e + f

    def __sub__(self, other):
        """Defines subtraction for the object as getting the difference between
        its values list and another object's list.

        Arguments:
            other {list} -- another list or object inheriting the values class

        Returns:
            {object} -- new object that lists values found in the original list but not in other
        """
        return_values = list()
        for value in self:
            if value not in other:
                return_values.append(value)
        return self.__class__(perform_validation=self.perform_validation, values=return_values)


class GroupCollection(OpenFlowEntryCollection):
    """A collection of group entries.
    """

    # entries in this collection must be group entries
    VALUE_CLASS = GroupEntry

    def __init__(self, values=None, starting_group=1000):
        """Sets up a new collection of group entries.

        Keyword Arguments:
            values {list} -- list of groups to be entered into the collection (default: {None})
            starting_group {int} -- starting point for cycling through the groups (default: {1000})
        """
        self._entries_by_id = defaultdict(dict)
        self._entries_by_alias = defaultdict(dict)
        self._counter = starting_group
        super().__init__(values=values)

    def get_next_counter(self):
        """Increments the collection's group counter to cycle through the
        groups.

        Returns:
            {int} -- the current counter value, increased by 1
        """
        self._counter += 1
        return self._counter

    def resolves_to_egress_port(self, value, include_controller=False):
        """Filters the collection for group entries that could egress a packet
        out a particular port.

        Arguments:
            value {port} -- queried out port

        Keyword Arguments:
            include_controller {bool} -- if True, include group entries with the Output action
                targeting "Controller" (default: {False})

        Returns:
            {object} -- new collection, containing only entries that could egress a packet out the
                specific port
        """
        if type(value) in (int, str):
            value = OutputAction(value)
        elif not isinstance(value, OutputAction):
            raise TypeError("Unable to parse value {} for outport".format(value))

        # Need to cycle through all of the groups once for each chain (3)
        first_chain = self.has_action_value(value)
        first_chain += self.has_action_value(OutputAction("All"))
        if include_controller:
            first_chain += self.has_action_value(OutputAction("Controller"))
        second_chain = self.has_action_value([GroupAction(entry.entry_id) for entry in first_chain])
        third_chain = self.has_action_value([GroupAction(entry.entry_id) for entry in second_chain])
        return first_chain + second_chain + third_chain

    def has_action(self, value):
        """Filters the collection for group entries with a particular type of
        action in one or more of their action buckets.

        Arguments:
            value {*} -- queried action or action value

        Returns:
            {object} -- new collection, containing only entries with the given action, or the action
                type of the value
        """
        results = self.class_type()
        for entry in self.values:
            for action_bucket in entry.action_buckets:
                if action_bucket.get(value):
                    results.append(entry)
        return results

    def has_action_value(self, value):
        """Filters the collection for group entries with an exact action value.

        Arguments:
            value {*} -- queried action value

        Returns:
            {object} -- new collection, containing only entries with the exact action value
        """
        if not (type(value) is not str and hasattr(value, '__getitem__')):
            value = [value]

        results = self.class_type()
        for entry in self.values:
            for action_bucket in entry.action_buckets:
                for v in value:
                    if v in action_bucket:
                        results.append(entry)
        return results

    def add(self, entry):
        """Adds a new group entry to the collection. Cycles through groups to
        check for duplicates, raising an error if one is found. Returns the
        duplicate instead with its Group ID intact, however, if the new group
        entry does not have an Group ID provided.

        Arguments:
            entry {object} -- a group entry
        """
        new = True

        if not entry.node:
            raise ValueError("Node for entry {} empty".format(entry.node))

        if entry.entry_id is None:
            for entry_id in self._entries_by_id[entry.node_name]:
                for old_entry in self._entries_by_id[entry_id]:
                    entry.entry_id = old_entry.entry_id
                    if old_entry == entry:
                        return old_entry
            else:
                entry.entry_id = self.get_next_counter()
        else:
            current_entry = self._entries_by_id[entry.node_name].get(entry.entry_id)
            if current_entry:
                new = False
                if current_entry != entry:
                    raise ValueError("Entry {} not added because it overlaps with entry {}".format(current_entry, entry))
                else:
                    LOGGER.warning("Entry {} not added because it duplicates {}".format(entry, current_entry))
            else:
                self._entries_by_id[entry.node_name][entry.entry_id] = entry

        # if entry.name:
        # 	current_entry = self._entries_by_alias[entry.node_name].get(entry.name)
        # 	if current_entry:
        # 		new = False
        # 		if current_entry != entry:
        # 			raise ValueError("Cannot add entry {} because entry with alias {} already found for {} on switch {}".format(current_entry, entry.name, entry, entry.node))
        # 	else:
        # 		self._entries_by_alias[entry.node_name][entry.name] = entry

        if new:
            super().add(entry)


class MeterCollection(OpenFlowEntryCollection):
    """A collection of meter entries.
    """

    def is_pps(self):
        """Filters the collection for meter entries that measure bandwidth in
        packets per second(pps).

        Returns:
            {object} -- new collection, containing only entries measured in pps
        """
        return self.class_type(values=[v for v in self.values if v.measurement_type == "pps"])

    def is_kbps(self):
        """Filters the collection for meter entries that measure bandwidth in
        kilobytes per second(kbps).

        Returns:
            {object} -- new collection, containing only entries measured in kbps
        """
        return self.class_type(values=[v for v in self.values if v.measurement_type == "kbps"])


class ProtocolCollection(EntryCollection):
    """A collection of protocol entries.
    """
    def __init__(self, values=None, associations=None):
        """Sets up a collection of devices.

        Keyword Arguments:
            values {list} -- devices to be entered into the collection (default: {None})
            association_entries {dict} -- network associations of the collection (default: {None})
        """
        super().__init__(values=values)
        self._associations = None
        self.associations = self._associations = associations if associations else Associations()

    @property
    def associations(self):
        return self._associations

    @associations.setter
    def associations(self, value):
        if value:
            if isinstance(value, Associations):
                self._associations = value
            else:
                raise TypeError("Associations must be of type Associations not {}".format(type(value)))
        else:
            self._associations = Associations()

    def is_unidirectional(self):
        """Filters the collection for unidirectional protocols.

        Returns:
            {object} -- new collection, containing only unidirectional protocols
        """
        return self.class_type(values=[v for v in self.values if v.unidirectional])

    def is_bidirectional(self):
        """Filters the collection for bidirectional protocols.

        Returns:
            {object} -- new collection, containing only bidirectional protocols
        """
        return self.class_type(values=[v for v in self.values if v.bidirectional])

    def is_multicast(self):
        """Filters the collection for multicast protocols.

        Returns:
            {object} -- new collection, containing only multicast protocols
        """
        return self.class_type(values=[v for v in self.values if not v.unicast])

    def is_unicast(self):
        """Filters the collection for unicast protocols.

        Returns:
            {object} -- new collection, containing only unicast protocols
        """
        return self.class_type(values=[v for v in self.values if v.unicast])

    def __add__(self, other):
        new_object = super().__add__(other)
        new_object.associations = self.associations + other.associations
        return new_object


class ApplicationCollection(EntryCollection):
    """A collection of application entries.
    """
    VALUE_CLASS = Application

    def __init__(self, values=None, perform_validation=True):
        """Sets up a new collection of applications.

        Keyword Arguments:
            values {list} -- application entries included in the collection (default: {None})
            perform_validation {bool} -- True if performing validation enabled (default: {True})
        """
        self.entries_by_source_name = defaultdict(list)
        self.perform_validation = perform_validation
        self.overlapping_entries = list()
        super().__init__(values=values)

    @property
    def class_type(self):
        return partial(self.__class__, perform_validation=self.perform_validation)

    def has_protocol(self, value):
        return self.class_type(values=[v for v in self.values if v.protocol.name == value])


    def is_unidirectional(self):
        """Filters the collection for unidirectional applications.

        Returns:
            {object} -- new collection, containing only unidirectional applications
        """
        return self.class_type(values=[v for v in self.values if v.protocol.unidirectional])

    def is_bidirectional(self):
        """Filters the collection for bidirectional applications.

        Returns:
            {object} -- new collection, containing only bidirectional applications
        """
        return self.class_type(values=[v for v in self.values if v.protocol.bidirectional])

    def is_multicast(self):
        """Filters the collection for multicast applications.

        Returns:
            {object} -- new collection, containing only multicast applications
        """
        return self.class_type(values=[v for v in self.values if not v.protocol.unicast])

    def is_unicast(self):
        """Filters the collection for unicast applications.

        Returns:
            {object} -- new collection, containing only unicast applications
        """
        return self.class_type(values=[v for v in self.values if v.protocol.unicast])

    def has_source(self, value):
        """Filters the collection for applications with a particular source.

        Arguments:
            value {*} -- queried source device or port

        Returns:
            {object} -- new collection, containing only applications with the given source
        """
        if isinstance(value, NamedObject):
            value = value.name

        return_values = list()

        for v in self.values:
            if isinstance(v.source, NamedObject):
                if v.source.name == value:
                    return_values.append(v)
            else:
                if v.source == value:
                    return_values.append(v)

        return self.class_type(values=return_values)

    def has_destination(self, value):
        """Filters the collection for applications with a particular
        destination.

        Arguments:
            value {*} -- queried destination device or port

        Returns:
            {object} -- new collection, containing only applications with the given destination
        """
        if isinstance(value, NamedObject):
            value = value.name

        return_values = list()

        for app in self.values:
            for v in app.destinations:
                if isinstance(v, NamedObject):
                    if v.name == value:
                        return_values.append(app)
                else:
                    if v == value:
                        return_values.append(app)

        return self.class_type(values=return_values)

    def is_in_network(self, value):
        """Filters the collection for applications where the source or one or
        more destinations is part of a particular network.

        Arguments:
            value {str} -- name of queried network

        Returns:
            {object} -- new collection, containing only applications with endpoint(s) in the given
                network
        """
        return_values = list()
        for v in self.values:
            if v.source.is_in_network(value) or True in [destination.is_in_network(value) for destination in v.destinations]:
                return_values.append(v)

        return self.class_type(values=return_values)

    def is_in_networks(self, values):
        """Filters the collection for applications where the source or one or
        more destinations is part of a particular network.

        Arguments:
            value {str} -- name of queried network

        Returns:
            {object} -- new collection, containing only applications with endpoint(s) in the given
                network
        """
        return_values = list()
        for v in self.values:
            if v.source.is_in_networks(values) or True in [destination.is_in_networks(values) for destination in v.destinations]:
                return_values.append(v)

        return self.class_type(values=return_values)

    def is_only_in_network(self, value):
        return_values = list()
        for v in self.values:
            if v.source.is_in_network(value) and False not in [destination.is_in_network(value) for destination in v.destinations]:
                return_values.append(v)

        return self.class_type(values=return_values)

    def is_only_in_networks(self, values):
        return_values = list()
        for v in self.values:
            if not isinstance(v.source, str):
                if v.source.is_in_networks(values) and False not in [type(destination) is not str and destination.is_in_networks(values) for destination in v.destinations]:
                    return_values.append(v)

        return self.class_type(values=return_values)        

    def is_connected(self):
        """Filters the collection for applications where both source and
        destination are connected nodes.

        Returns:
            {object} -- new collection, containing only fully connected applications
        """
        return self.has_source_connected().has_destinations_connected()

    def has_source_connected(self):
        """Filters the collection for applications where the source is
        currently connected to the rest of the network.

        Returns:
            {object} -- new collection, containing only applications with connected sources
        """
        return self.class_type(values=[application for application in self if application.source.is_connected()])

    def has_destinations_connected(self):
        """Filters the collection for applications where the all destination(s)
        are currently connected to the rest of the network.

        Returns:
            {object} -- new collection, containing only applications with connected destination(s)
        """
        return self.class_type(values=[application for application in self if False not in [destination.is_connected() for destination in application.destinations]])

    def add(self, entry):
        """Adds a new application entry to the collection. If validation is
        enabled, log a warning message whenever a duplicate or overlapping
        application is added.

        Arguments:
            entry {object} -- the application to be added
        """
        # To speed up compare, store applications by source and then compare among common searches
        # Because source can be a Port or a Device, store under device name
        if isinstance(entry.source, str):
            source_name = entry.source
        else:
            source_name = entry.source.owner.name

        new = True
        if self.perform_validation and self.entries_by_source_name.get(source_name):
            for old_entry in self.entries_by_source_name[source_name]:
                if entry == old_entry:
                    new = False
                    LOGGER.warning("Entry {} not added because it duplicates entry {}".format(old_entry, entry))
                    break
                elif entry.overlaps(old_entry):
                    new = False
                    self.overlapping_entries.append(entry)
                    LOGGER.warning("Entry {} not added because it overlaps with entry {}".format(entry, old_entry))
                    break

        if new:
            if self.entries_by_source_name.get(source_name):
                self.entries_by_source_name[source_name].append(entry)
            else:
                self.entries_by_source_name[source_name] = [entry]
            super().add(entry)
            return True
        else:
            return False

    def convert_strs_to_objects(self, node_entries):
        for application in self.values:
            application.convert_source_and_destination_to_node_objects(node_entries)


class LogCollection(EntryCollection):
    pass
