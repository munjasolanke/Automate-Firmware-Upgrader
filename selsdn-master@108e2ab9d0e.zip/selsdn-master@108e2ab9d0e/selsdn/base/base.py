"""Copyright (c) 2019 Schweitzer Engineering Laboratories, Inc.
SEL Confidential

Base class to support additional runtime attributes for derived objects.
"""


class BaseObject:
    """Class of common functions inherited by objects used in selsdn. An
    object can have any number of attributes each with their own names and
    values.
    """

    def __init__(self, attributes=None):
        """Initializes an object, and gives it attributes if specified in the
        superclass call. Otherwise provides an empty dictionary for attributes.

        Keyword Arguments:
            attributes {dict} -- attributes assigned to an object (default: {None})
        """
        if attributes and not isinstance(attributes, dict):
            raise TypeError("Unknown type {} for attributes, must be of type dict".format(type(attributes)))
        self.attributes = attributes if attributes else {}

    def get_attribute(self, name, default_value=None):
        """Searches the attributes of an object for a value listed under the
        provided dictionary key.

        Arguments:
            name {str} -- name of dict key being searched for

        Keyword Arguments:
            default_value {value} -- default return if key not found (default: {None})

        Returns:
            {value} -- associated value of key, or default_value if not found
        """
        return self.attributes.get(name, default_value)

    def set_attribute(self, name, value):
        """Assigns an attribute to the object's attributes dictionary with the
        provided name and value. Writes over any existing attribute under the
        given name. Alias of add_attribute.

        Arguments:
            name {str} -- Attribute name to reference the value as a dict key.
            value {value} -- Attribute value being added to the object.
        """
        self.attributes[name] = value

    def delete_attributes(self, name):
        """Removes an attribute from an object.

        Arguments:
            name {str} -- name(dict key) of removed attribute
        """
        del(self.attributes[name])

    def add_attribute(self, name, value):
        """Assigns an attribute to the object's attributes dictionary with the
        provided name and value. Writes over any existing attribute under the
        given name. Alias of set_attribute.

        Arguments:
            name {str} -- Attribute name to reference the value as a dict key.
            value {value} -- Attribute value being added to the object.
        """
        self.attributes[name] = value

    def __ne__(self, other):
        """Determines if one object is not identical to another.

        Returns:
            {bool} -- true if the two objects are not identical
        """
        return not self.__eq__(other)

    def listify(self, item):
        """Takes anything and converts it into Python's list format.

        Arguments:
            item {*} -- a list or item that can be contained in a list

        Returns:
            {list} -- Constructs an empty list if item is nonexistent or false.
                Returns item indexed 0 in a new list, or unchanged if it is
                already a list.
        """
        if item and not isinstance(item, list):
            return [item]
        else:
            return list() if not item else item

    def delete_attribute(self, name):
        """Deletes an attribute.

        Arguments:
            name {str} -- The name of the attribute to delete

        Returns:
            {bool} -- True if the attribute was found and deleted
        """
        if name in self.attributes.keys():
            del(self.attributes[name])
            return True
        else:
            return False

    def compare_attribute(self, attribute, other, true_if_none=True, default_value=None):
        """Compares two attributes of an object to check if they are equal.

        Arguments:
            attribute {str} -- name key of first attribute
            other {str} -- name key of second attribute

        Keyword Arguments:
            true_if_none {bool} -- treat 2 false/non-existent attributes as equal (default: {True})
            default_value {value} -- default attribute value if key not found (default: {None})

        Returns:
            {bool} -- true if the two attributes are equal
        """
        if true_if_none and not self.get_attribute(attribute) and not other.get_attribute(attribute):
            return True
        if self.get_attribute(attribute, default_value) and other.get_attribute(attribute, default_value):
            return self.get_attribute(attribute, default_value) == other.get_attribute(attribute, default_value)
        else:
            return False
